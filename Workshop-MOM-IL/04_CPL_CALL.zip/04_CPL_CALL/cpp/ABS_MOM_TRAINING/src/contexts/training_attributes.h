#pragma once

#include "attribute.h"
#include "attributectx.h"
#include "training_const.h"

class CoverageItemContextTraining;
class CoverageContextTraining;
class ContractContextTraining;
class InsuredPersonContextTraining;


/// Declaration of ContractAttribute
class ContractAttribute : public Attribute
{
public:
	ContractAttribute(ContractContextTraining* pCtx, Record* r = NULL)
		: Attribute((AttributeContext*)(pCtx), r)
	{
		m_pContract = pCtx;
	}

	virtual ~ContractAttribute() {};

protected:
	ContractContextTraining *m_pContract; /// pointer to ContractContext

};

/// Declaration of CoverageAttribute
class CoverageAttribute : public Attribute
{
public:
	CoverageAttribute(CoverageContextTraining* pCtx, Record* r = NULL)
		: Attribute((AttributeContext*)(pCtx), r)
	{
		m_pCoverage = pCtx;
	}
	virtual ~CoverageAttribute() {};

protected:
	CoverageContextTraining *m_pCoverage; /// pointer to ContractContext

};

/// Declaration of CoverageItemAttribute
class CoverageItemAttribute : public Attribute
{
public:
	CoverageItemAttribute(CoverageItemContextTraining* pCtx, Record* r = NULL)
		: Attribute((AttributeContext*)(pCtx), r)
	{
		m_pCoverageItem = pCtx;
	}
	virtual ~CoverageItemAttribute() {};

protected:
	CoverageItemContextTraining *m_pCoverageItem; /// pointer to ContractContext

};

/// Declaration of InsuredPersonAttribute
class InsuredPersonAttribute : public Attribute
{
public:
	InsuredPersonAttribute(InsuredPersonContextTraining* pCtx, Record* r = NULL)
		: Attribute((AttributeContext*)(pCtx), r)
	{
		m_pInsuredPerson = pCtx;
	}
	virtual ~InsuredPersonAttribute() {};

protected:
	InsuredPersonContextTraining *m_pInsuredPerson; /// pointer to ContractContext

};






//-----------------------------------------------------------------------------
// Declaration of PremiumTraining
DECL_ATTR_NAME(PremiumTraining);
DECL_ATTR_NAME(PremiumTrainingField);

typedef GenericAttribute<CoverageItemAttribute, CoverageItemContextTraining, ksPremiumTraining, ksPremiumTrainingField, -1, -1, -1, -1, Number, false, e_Old> PremiumTrainingBase;
//typedef GenericTarifAttribute<ksPremiumTraining, ksPremiumTrainingField, -1, -1, -1, -1, Number> PremiumTrainingBase;
class PremiumTraining : public PremiumTrainingBase
{
	///
	/// This class calculates the training premium
	///
public:
	PremiumTraining(CoverageItemContextTraining* pParent, Record* pRec = NULL) : PremiumTrainingBase(pParent, pRec) {};
protected:
	void Calculate();
	void CalculateOld();
};


//-----------------------------------------------------------------------------
// Declaration of InsuranceDuration
DECL_ATTR_NAME(InsuranceDuration);
DECL_ATTR_NAME(InsuranceDurationField);
typedef GenericAttribute<CoverageItemAttribute, CoverageItemContextTraining, ksInsuranceDuration, ksInsuranceDurationField, e_n_n_SKIX, e_n_o_SKIX, -1, -1, Number, false, e_Old> InsuranceDurationBase;
class InsuranceDuration : public InsuranceDurationBase
{
	///
	/// Class InsuranceDuration
	/// This class determines the insurance duration of a tariff
	///
public:
	InsuranceDuration(CoverageItemContextTraining* pParent, Record* pRec) : InsuranceDurationBase(pParent, pRec) {};
protected:
	void Calculate();
};


//-----------------------------------------------------------------------------
// Declaration of ProductCode
DECL_ATTR_NAME(ProductCode);
DECL_ATTR_NAME(ProductCodeField);
typedef GenericAttribute<CoverageAttribute, CoverageContextTraining, ksInsuranceDuration, ksInsuranceDurationField, e_tarif_nr_n_SKIX, e_tarif_nr_o_SKIX, -1, -1, Number, false, e_Old> ProductCodeBase;
class ProductCode : public ProductCodeBase
{
	///
	/// Class ProductCode
	/// This class provides a product code for the coverage
	///
public:
	ProductCode(CoverageContextTraining* pParent, Record * pRec) : ProductCodeBase(pParent, pRec) {};
protected:
	void Calculate() override;
	void CalculateOld() override;
};


///-----------------------------------------------------------------------------
/// Declaration of RateClass
DECL_ATTR_NAME(RateClass);
DECL_ATTR_NAME(RateClassField);
typedef GenericAttribute<ContractAttribute, ContractContextTraining, ksRateClass, ksRateClassField, e_RateClass_n_SKIX, e_RateClass_o_SKIX, -1, -1, Text, false, e_Old> RateClassBase;
class RateClass : public RateClassBase
{
	///
	/// Class RateClass 
	/// This class determines the rate class
	///
public:
	RateClass(ContractContextTraining* pCtx, Record* r) : RateClassBase(pCtx, r) {
		conversion_map& cm = const_cast<conversion_map&>(Kind()->GetConversionMap());
		cm.TakeOver(math::assign::map_list_of("A", 2.0)("E", 1.0)("X", 1.0)
			("O", 3.0)("F", 4.0)("G", 5.0)("1", 6.0)("2", 7.0)("3", 8.0));
	};

protected:
	void Calculate() override;
	void CalculateOld() override;
};

//-----------------------------------------------------------------------------
// Declaration of RiskGroup
DECL_ATTR_NAME(RiskGroup);
DECL_ATTR_NAME(RiskGroupField);
typedef GenericAttribute<InsuredPersonAttribute, InsuredPersonContextTraining, ksRiskGroup, ksRiskGroupField, e_RiskGroup_IP1_n_SKIX, e_RiskGroup_IP1_o_SKIX, e_RiskGroup_IP2_n_SKIX, e_RiskGroup_IP2_o_SKIX, Text, false, e_Old> RiskGroupBase;
class RiskGroup : public RiskGroupBase
{
	///
	/// Class RiskGroup
	/// This class determines the risk group for a person
	///
public:
	RiskGroup(InsuredPersonContextTraining* pIPCtx, Record* r) : RiskGroupBase(pIPCtx, r) {
		conversion_map& cm = const_cast<conversion_map&>(Kind()->GetConversionMap());
		cm.TakeOver(math::assign::map_list_of("M", 0.0) ("W", 1.0));
	};

protected:
	void Calculate() override;
	void CalculateOld() override;
};

//-----------------------------------------------------------------------------
// Declaration of MainInsured
DECL_ATTR_NAME(MainInsured);
DECL_ATTR_NAME(MainInsuredField);
typedef GenericAttribute<InsuredPersonAttribute, InsuredPersonContextTraining, ksMainInsured, ksMainInsuredField, FLAG_MAININSURED, -1, -1, -1, Text, false, e_Old> MainInsuredBase;
class MainInsured : public MainInsuredBase
{
	///
	/// Class MainInsured
	/// This class determines the main insured person of the tariff
	///
public:
	MainInsured(InsuredPersonContextTraining* pIPCtx, Record* r) : MainInsuredBase(pIPCtx, r) {
		conversion_map& cm = const_cast<conversion_map&>(Kind()->GetConversionMap());
		cm.TakeOver(math::assign::map_list_of("J", 1.0)("N", 0.0));
	};

protected:
	void Calculate() override;
};