#pragma once

#include <vector>

#include "training_context.h"
#include "training_const.h"
#include "training_attributes.h"

class ContractContextTraining;
class CoverageItemContextTraining;

class CoverageContextTraining : public BaseContextTraining
{
public:
	CoverageContextTraining(const std::string &key, ContractContextTraining* pContract, bool load= true);
	virtual ~CoverageContextTraining();
	virtual void Load() override;
	virtual void Save() override;
	
	CoverageItemContextTraining * GetCoverageItem(std::size_t n) { return m_vCoverageItem[n]; }

	Record m_CoverageRecord;
	ProductCode m_ProductCode;

private:


	ContractContextTraining * m_pContract;
	
	std::vector<CoverageItemContextTraining *> m_vCoverageItem;
};


