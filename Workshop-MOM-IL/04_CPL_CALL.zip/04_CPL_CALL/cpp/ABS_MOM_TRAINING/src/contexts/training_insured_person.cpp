#include "training_insured_person.h"
#include "training_coverage_item.h"

InsuredPersonContextTraining::InsuredPersonContextTraining(const std::string &key, CoverageItemContextTraining* pCoverageItem, bool load/*= true*/)
    : BaseContextTraining(key, (AttributeContext*)pCoverageItem)
	
	//Records
    , m_InsuredPersonRecord(key, "PAP#\tNP#", "TVERSPERS", this)

	//Attributes
	, m_RiskGroup(this, &m_InsuredPersonRecord)
	, m_MainInsured(this, &m_InsuredPersonRecord)
{
	if (load) {
		Load();
	}
}

InsuredPersonContextTraining::~InsuredPersonContextTraining()
{
    m_pCoverageItem->RemoveSubContext(this);
}

void InsuredPersonContextTraining::Load ()
{
}
