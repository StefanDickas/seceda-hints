#pragma once

#include "training_context.h"
#include "training_const.h"
#include "training_attributes.h"

class CoverageItemContextTraining;

class InsuredPersonContextTraining : public BaseContextTraining
{
public:
	InsuredPersonContextTraining(const std::string &key, CoverageItemContextTraining* pCoverageItem, bool load= true);
	virtual ~InsuredPersonContextTraining();
	virtual void Load() override;
	
	Record m_InsuredPersonRecord;

	RiskGroup m_RiskGroup;
	MainInsured m_MainInsured;

private:
	CoverageItemContextTraining * m_pCoverageItem;
};


