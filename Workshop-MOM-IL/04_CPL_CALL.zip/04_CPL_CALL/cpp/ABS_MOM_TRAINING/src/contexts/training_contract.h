#pragma once

#include <vector>
#include <training_context.h>
#include <training_attributes.h>

class CoverageContextTraining;

class ContractContextTraining : public BaseContextTraining , public RootObjectCtx
{
public:
	ContractContextTraining(const std::string &key, bool load = true);
	virtual ~ContractContextTraining();

	virtual void Load() override;
	virtual void Compute() override;
	virtual void InitTCDTableMap() override;
	virtual bool IsTCDTable(int id) override;
	virtual bool IsTCDTable(const std::string& sTableName) override;
	virtual void Save() override;

private:
	Record m_ContractRecord;

	RateClass m_RateClass;
	InputAttribute m_HSPKey;

	std::vector<CoverageContextTraining *> m_vCoverage;
};



