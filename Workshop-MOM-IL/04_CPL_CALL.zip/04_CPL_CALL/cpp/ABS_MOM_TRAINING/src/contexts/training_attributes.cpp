#pragma once

#include "training_attributes.h"
#include "training_contract.h"
#include "training_coverage.h"
#include "training_coverage_item.h"


//-----------------------------------------------------------------------------
// Implementation of SumInsuredDiscount
IMPL_ATTR_NAME(PremiumTraining, "PremiumTraining");
IMPL_ATTR_NAME(PremiumTrainingField, "JAHRESTPR_NETTO");

///
/// This method calculates the training premium
///
void PremiumTraining::Calculate()
{

	Number result;
	GetContext()->RunCalculationRule("SR", LTB_CATEGORY_PREMIUM, result);


	AttributeRange range(Kind()->Proto());
	GetContext()->GetRange("EINAL", &range);

	double minValue = range.MinValue().AsDouble();
	double maxValue = range.MaxValue().AsDouble();

	if (result.AsDouble() <= 0.0) {
		SetValue(2000.0);
	} else {
		SetValue(1500.0);
	}

}

void PremiumTraining::CalculateOld()
{
	SetOldValue(0.0);

}

//-----------------------------------------------------------------------------
// Implementation of InsuranceDuration
IMPL_ATTR_NAME(InsuranceDuration, "InsuranceDuration");
IMPL_ATTR_NAME(InsuranceDurationField, "VERSDAUER");
///
/// This method determines the current insurance duration of a tariff
///
void InsuranceDuration::Calculate()
{
	SetValue(GetInput());
}



// Class ProductCode 
IMPL_ATTR_NAME(ProductCode, "ProductCode");
IMPL_ATTR_NAME(ProductCodeField, "SP_PRODKBEZ");

/// 
/// This method provides the short description as double - works only if the text contains a number
///
void ProductCode::Calculate()
{
	std::string val = GetInput().AsString();
	if (val != "") {
		SetValue(GetInput().AsDouble());
	} else {
		SetValue(12345);
	}
}

/// 
/// This method provides the original short description as double - works only if the text contains a number
///
void ProductCode::CalculateOld()
{
	Attribute::CalculateOld();
}



// Class RateClass 
IMPL_ATTR_NAME(RateClass, "RateClass");
IMPL_ATTR_NAME(RateClassField, "TARIFBEREICH");
///
/// determines the rate class based on the input - if empty the old value is used
///
void RateClass::Calculate()
{
	if (!GetInput().Empty()) {
		SetValue(GetInput());
	}
	else {
		SetValue(GetOld());
	}
}

///
/// in new business the current value is used as original value
/// in all other cases the stored value is used
///
void RateClass::CalculateOld()
{
	SetOldValue(Get());
}




// Class RiskGroup 
IMPL_ATTR_NAME(RiskGroup, "RiskGroup");
IMPL_ATTR_NAME(RiskGroupField, "RISIKOGRUPPE");

///
/// calculates the risk group, a calculation rule is used for that purpose
///
void RiskGroup::Calculate()
{
	SetValue(GetInput());
}

///
/// calculates the original value of the risk group
///
void RiskGroup::CalculateOld()
{
	SetOldValue(GetInput());
}


// Class MainInsured 
IMPL_ATTR_NAME(MainInsured, "MainInsured");
IMPL_ATTR_NAME(MainInsuredField, "KZHAUPTVP");

///
/// determines the main insured oerson of the respective tariff
/// 
void MainInsured::Calculate()
{
	SetValue(GetInput());
}