#pragma once

#include "training_context.h"
#include "training_const.h"
#include "training_attributes.h"

class CoverageContextTraining;
class InsuredPersonContextTraining;

class CoverageItemContextTraining : public BaseContextTraining
{
public:
	CoverageItemContextTraining(const std::string &key, CoverageContextTraining* pCoverage, bool load= true);
	virtual ~CoverageItemContextTraining();
	virtual void Load() override;

	Record m_CoverageItemRecord;
	Record m_LifeLayerRecord;
	Record m_InsuranceRateRecord;
	Record m_ProdTemplateRecord;

	
	PremiumTraining	m_PremiumTraining;
	InsuranceDuration m_InsuranceDuration;
	InputAttribute	m_InsRateKeyInput;
	InputAttribute m_ProdTemplateKey;

	virtual Attribute* FindAttribute(int id, bool rekursiv) override;

private:
	CoverageContextTraining * m_pCoverage;
	InsuredPersonContextTraining * m_pInsuredPerson;
};


