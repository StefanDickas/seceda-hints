#include "training_coverage_item.h"
#include "training_insured_person.h"
#include "training_coverage.h"

CoverageItemContextTraining::CoverageItemContextTraining(const std::string &key, CoverageContextTraining* pCoverage, bool load/*= true*/)
    : BaseContextTraining(key, (AttributeContext*)pCoverage)
	
	//Records
    , m_CoverageItemRecord(key, "PAP#", "TPRODAUS", this)
	, m_LifeLayerRecord("", "LSCH#", "TLEBENSCHICHT", this)
	, m_InsuranceRateRecord("", "VTAR#", "TVERSTARIF", this)
	, m_ProdTemplateRecord("", "PSCHABL#", "TPRODSCHABL", this)

	//Attributes
	, m_PremiumTraining (this, &m_CoverageItemRecord) //JAHRESTPR_NETTO
	, m_InsuranceDuration(this, &m_LifeLayerRecord)	  //VERSDAUER
	, m_InsRateKeyInput(this, &m_InsuranceRateRecord, "VTAR#", new Text, VTAR_ID)
	, m_ProdTemplateKey(this, &m_CoverageItemRecord, "PSCHABL#", new Text, PSCHABL_ID)

{
	if (load) {
		Load();
	}
	else {
		SetAttribute("TPRODAUS.PAP#", m_CoverageItemRecord.Key());
		SetAttribute("TPRODAUS.VERSV#", m_pCoverage->GetAttribute("TVERSVERTRAG.VERSV#"));                                                                           
	}
}

CoverageItemContextTraining::~CoverageItemContextTraining()
{
    m_pCoverage->RemoveSubContext(this);
}

void CoverageItemContextTraining::Load ()
{
	Relation relationLifeLayer(&m_CoverageItemRecord, "TLEBENSCHICHT", "LSCH#", e_Current);
	REQUIRE(relationLifeLayer.size() > 0);
	m_LifeLayerRecord.SetKey(relationLifeLayer.Value(0));

	m_ProdTemplateRecord.SetKey(m_ProdTemplateKey.Get().AsString());

	Relation relationTarifReference(&m_ProdTemplateRecord, "TTARIFREFERENZ", "VTAR#\tPSCHABL#", e_Current);
	for (size_t i = 0; i < relationTarifReference.size(); i++) {
		std::string sKeyVal = relationTarifReference.Value(i);
		std::vector<std::string> vKey;
		math::split(vKey, relationTarifReference.Value(i));
		sKeyVal = vKey[0];
		Record tarif_rec(sKeyVal, "VTAR#", "TVERSTARIF", this, false);

		const std::string art(tarif_rec.GetValue("TARIFART"));
		if (art[0] == 'H' || art[0] == 'Z') {
			if (m_InsuranceRateRecord.Key() == "") {
				m_InsuranceRateRecord.SetKey(sKeyVal);
				break;
			}
		}
	}


	Relation relationToInsuredPerson(&m_CoverageItemRecord, "TVERSPERS", "PAP#\tNP#", e_Current);
	for (int i = 0; i < relationToInsuredPerson.size(); i++) {
		m_pInsuredPerson = new InsuredPersonContextTraining(relationToInsuredPerson.Value(i), this);
	}
}

Attribute* CoverageItemContextTraining::FindAttribute(int id, bool rekursiv)
{
	REQUIRE(id >= 0);
	REQUIRE(rekursiv);

	Attribute *a = AttributeContext::FindAttribute(id, true);

	
	if (a == NULL) {
		a = m_pInsuredPerson->FindAttribute(id, false);
	}

	return a;
}
