#include <controldata.h>
#include <tcd_rbs.hpp>


void StdtDatLoader::SetStDatHash(const std::string& Pgmname, const std::string& StDatBufPos)
{
	GetGlobtcdrbs()->m_StDatHash[Pgmname] = StDatBufPos;
}

void StdtDatLoader::GetBervorid(const char * berechvorsch)
{
	int rc;	
	GetGlobtcdrbs()->getbervorid(berechvorsch, &rc);
}

void StdtDatLoader::GetTab(const char * tabname, unsigned char dim)
{
	TCD_LONG ID;
	int rc;
	GetGlobtcdrbs()->gettab(tabname, &rc, dim, &ID);
}

