#include <iomanip>
#include <boost/foreach.hpp>

#include "math_utils.h"
#include "lookup.h"

#include "training_contract.h"
#include "training_coverage.h"
#include "training_coverage_item.h"


ContractContextTraining::ContractContextTraining(const std::string & key, bool load)
	: BaseContextTraining(key, NULL)

	// Records
	, m_ContractRecord(key, "VERTR#", "TVERTRAG", this)

	//Attributes
	, m_RateClass(this, &m_ContractRecord)
	, m_HSPKey(this, &m_ContractRecord, "HSPP#", new Text, HSPP_ID)

{

	ThreadLocalInformation::Instance().setTLTarBeschrDependenciesPtr(&s_TLTarBeschrDependencies);
	ThreadLocalInformation::Instance().setTProdSchGrenzWDependenciesPtr(&s_TProdSchGrenzWDependencies);
	ThreadLocalInformation::Instance().set_tcdDependencyTablePtr(&s_TcdDependencyTableContainer);


	m_ContextType = "ContractContext";
	m_bLoad = load;

	if (!load) {
		SetAttribute(std::string("TVERTRAG.VERTR#"), m_ContractRecord.Key());
	}

}

ContractContextTraining::~ContractContextTraining()
{
}


void ContractContextTraining::Load()
{
	Relation relationToCoverage(&m_ContractRecord, "TVERSVERTRAG", "VERSV#", e_Current);
	for (int i = 0; i < relationToCoverage.size(); i++) {
		CoverageContextTraining *pCoverage = new CoverageContextTraining(relationToCoverage.Value(i), this);
		m_vCoverage.push_back(pCoverage);
	}
}


void ContractContextTraining::Compute() {
	m_vCoverage[0]->GetCoverageItem(0)->m_PremiumTraining.Get();
}


/// 
/// This method initializes the table mapping for TCD
/// Adaptions based on the respective TCD Module are required
///
void ContractContextTraining::InitTCDTableMap()
{
	TCD::setTableDependencies(MortalityTab_T2IX, "KMNX");
	TCD::setTableDependencies(CostTab_T2IX, "KSTMA");
}

/// 
/// This method checks if the searched ID is a TCD table
///
bool ContractContextTraining::IsTCDTable(int id)
{
	return TCD::hasTableDependencies(id);
}

/// 
/// This method checks if the searched Name is a TCD table
///
bool ContractContextTraining::IsTCDTable(const std::string& sTableName)
{
	return TCD::hasTableDependencies(sTableName);
}

void ContractContextTraining::Save()
{
	AttributeContext::Save();

	for (CoverageContextTraining *pCoverage : m_vCoverage) {
		pCoverage->Save();
	}
}