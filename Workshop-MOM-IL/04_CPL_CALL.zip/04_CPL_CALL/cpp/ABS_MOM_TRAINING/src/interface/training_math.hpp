#ifndef MATH_TLIFE_MATH_HPP
#define MATH_TLIFE_MATH_HPP

#include <math_base.h>

#include "training_errmg.h"
#include "training_contract.h"

#include "tcd_result_impl.h"

class mathContractTraining : public mathbase<ContractContextTraining>
{
	///
	/// Class mathContract
	/// This is the base class for the client call, the batch entry is done differently
	/// All ORBIT related functions like set up of the data buffers are triggered here
	///
public:
	typedef mathbase<ContractContextTraining> MyBase;

	///
	/// Constructor mathContract, initializes the Orbit data buffer
	///
	mathContractTraining(OrbitMath<mathContractTraining>* pOwner) : MyBase()
	{
		DataBuffer::SelectActivePool(reinterpret_cast<std::size_t>(pOwner));
		++m_instrefcount;
		SetOrbitDataBuffer(new OrbitDataBuffer("", "", "", 0, "TLIFE_ORB_DB_BUFF"));
	}
	///
	/// Destructor mathContract, removes all references
	///
	~mathContractTraining()
	{
		--m_instrefcount;
		if (m_instrefcount == 0) {
			AttributeKind::Cleanup();
		}
	}

	///
	/// Uninit, triggers the removal of contexts
	///
	virtual short uninit() override
	{
		if (m_pDatenBuffer != NULL) {
			DataBuffer::SetActualPool(m_pDatenBuffer->Pool());
		}
		return MyBase::uninit();
	}

	///
	/// Init, initializes all contexts
	///
	short init(short trace, const char * key, const char * topclass)
	{
		m_pVertrag = boost::make_shared<ContractContextTraining>(std::string(key));

		RootObjectCtx* pRoot = dynamic_cast<RootObjectCtx*>(m_pVertrag.get());
		REQUIRE(pRoot);
		pRoot->SetOrbitBuffers(m_OrbDef, m_OrbOp);

		m_pVertrag->SetTrace(trace);

		return 0;
	}

	///
	/// Compute, triggers the calculation
	///
	short compute(const char * topclass, const char * topkey, const char * attribute)
	{
		if (m_pDatenBuffer == NULL || !m_pVertrag) {
			THROW(InternalError("MathIntern", 916, ""));
		}

		DataBuffer::SetActualPool(m_pDatenBuffer->Pool());

		if (attribute && *attribute) {
			inquire(attribute);
		}
		else {
			m_pVertrag->Compute();
		}

		return 0;
	}

	///
	/// Inquire, performs an inquiry call
	///
	short inquire(const char * attribute)
	{
		m_pVertrag->Inquire(attribute);

		return 0;
	}

	///
	/// setConfiguration, sets basic configurations
	/// in here the reference to the zip file for the TCD files must be set!
	///
	short setConfiguration(const std::string& dateformat, char comma)
	{
		MyBase::setConfiguration(dateformat, comma);
		StdtDatLoader::SetZipName("TrainingControldata.zip");
		TCD_System::Connect("");
		return 0;
	}

	///
	/// disconnects from TCD
	///
	short unsetConfiguration()
	{
		TCD_System::Disconnect();
		return 0;
	}

	///
	/// setorbit defines the starting point for the calculation
	/// typically that is VERTRAG
	///
	short setorbit(OrbitDataBuffer *orbit_op,
		OrbitDataBuffer *orbit_de,
		const char *key,
		const char *topclass,
		bool doTrace)
	{
		if (stricmp(topclass, "VERTRAG") == 0)
		{
			std::string values;
			orbit_handle_t temphandle = atol(key);
			OrbitDataBufferBase::_OBJECTCONTAINER object;

			if (strlen(key) > 12) {
				orbit_op->GetObjects("VERTRAG", key, object);
			}
			else {
				object.push_back(temphandle);
			}

			orbit_op->GetAttributes(object[0], "Vertrvorgaben.Comptyp", values, "", true);

			if (strlen(key) > 12) {
				orbit_op->ForgetObjects(object);
			}
		}

		return MyBase::setorbit(orbit_op, orbit_de, key, topclass, doTrace);
	}
};

#endif // MATH_TLIFE_MATH_HPP
