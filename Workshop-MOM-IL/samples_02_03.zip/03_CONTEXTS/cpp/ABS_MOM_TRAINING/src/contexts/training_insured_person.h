#pragma once

#include "training_context.h"
#include "training_const.h"

class CoverageItemContextTraining;

class InsuredPersonContextTraining : public BaseContextTraining
{
public:
	InsuredPersonContextTraining(const std::string &key, CoverageItemContextTraining* pCoverageItem, bool load= true);
	virtual ~InsuredPersonContextTraining();
	virtual void Load() override;
	
private:
	Record m_InsuredPersonRecord;
	CoverageItemContextTraining * m_pCoverageItem;
};


