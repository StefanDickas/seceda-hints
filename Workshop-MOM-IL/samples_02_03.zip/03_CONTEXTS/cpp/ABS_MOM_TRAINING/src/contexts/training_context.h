#pragma once

#include <attributectx.h>
#include <tcdid.h>
#include <tcdsharedcontext.h>
#include <dependency.h>


class BaseContextTraining : public TcdSharedContext
{
	/// 
	/// class BaseContextTraining
	/// the BaseContextTraining Class implements the TCD integration and some basic methods which can be reused in the respective classes
	/// 
public:
	BaseContextTraining(std::string const& name, AttributeContext * parent = NULL, bool use_for_search = true);
	virtual ~BaseContextTraining();

	static TCD::DependenciesMap s_TLTarBeschrDependencies;
	static TCD::DependenciesMap s_TProdSchGrenzWDependencies;
    static TCD::TcdDependencyTableContainer s_TcdDependencyTableContainer;


	// ================================ BaseContextTraining customization ================================
private:
	Attribute* GetVRateKey(std::string const & description);
	Attribute* GetProductTemplateKey(bool bUseKlPschabl);
	Attribute* GetHsppKey();

	int Get_TAB1_ID_BASE() { return TAB1_ID_BASE; }
	int Get_TAB2_ID_BASE() { return TAB2_ID_BASE; }
	int Get_DATUM_ID_BASE() { return DATUM_ID_BASE; }

	virtual void InitTCDTableMap();
};


