/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
 /*--------------------------------------------------------------------
    Modul:        TCD_PKF.c

    Beschreibung: Funktionen C-Generator, die vom Makrogenerator
                  aufgerufen werden
    By:           BEGGI
    Datum:        16.12.2019 15:07:19
    Historie :    BEG  22.11.95      FM: 384
  MUB  21.5.96 Optimierung begonnen, Beschaffungsflags etc.
  MUB          Pr�fung, ob Ergebnis schon berechnet wurde.
  MUB 17.7.96  Abweisungen zwischen #ifdef TRACEFKT #endif korrigiert
  MUB 26.7.96  Erfolgreiche Wiederverwendung eines Ergebnisses
               ins Tracefile schreiben
---------------------------------------------------------------------*/

/* Includes */
/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDPORTAB_H)
#define TCDPORTAB_H

/*-----------------
Name        : TCDPORTAB.H

Beschreibung: externes Include File, das generierumgeungsspezifische
Informationen enthaelt (Makrovorlage).
By          : BEGGI
Datum       : 20.04.94
Historie:     BEG   17.01.95  neues Makro _TCDMEMINI anstatt memset
BEG   02.03.95  bedingte Macros TCDHUGE
BEG   22.06.95  _TCDMEMINI nur im HUGE-Modell redefiniert.
BEG   20.02.96  malloc.h wird nicht mehr inkludiert (FM 451)
RWE   21.06.96  malloc.h wird wieder includiert (aber nur
              fuers HUGE-Modell, d.h. fuer DOS/WIN-Compiler)
RWE   26.06.96  WATCHMEM-Makros eingebaut (fuer TCDALLOC etc)
MUB   17.7.96   Include mit !defined versehen
KFC   02.09.96  #define TCDHUGE vorgezogen

-------------------*/

/* #define TCDHUGE */              /* bei gro�en Tabellen einschalten*/
/* Systemincludes */                  
#include <stdlib.h>                /* atoi, ...       */
#include <stdio.h>                 /* fprintf, ...    */
#include <string.h>                /* strcpy, ...     */
#include <time.h>                  /* time_t, ...     */
#include <math.h>                  /* exp, min, max, ... */

#ifdef TCDHUGE
#include <malloc.h>
#endif

/* Defines */
#define  TCDC_EXT_NAME_LNG    8  /* maximale L�nge von externen 
                                    Bezeichnern*/
/*-----------------
  Definitionen aus standard C-Includes z.B. stdio.h
-------------------*/
#ifndef NULL
#define    NULL    (void *)0
#endif

/*-----------------
  Definitionen von Basistypen
-------------------*/
typedef    short   TCD_BOOL ;
typedef    long    TCD_LONG ;
typedef    int     TCD_INT  ;
typedef    double  TCD_DOUBLE ;


/*-----------------
  modellabhaengige Definitionen von Basistypen
-------------------*/
typedef    TCD_DOUBLE  TCDTAB ;
#ifdef TCDHUGE
typedef    TCDTAB       huge * P_TCDTAB ;
typedef    TCD_DOUBLE   huge * P_TCD_DOUBLE ;
typedef    P_TCD_DOUBLE * P_P_TCD_DOUBLE ;
typedef    char huge    * TCD_LPCHAR ;
#else
typedef    TCDTAB       * P_TCDTAB ;
typedef    TCD_DOUBLE   * P_TCD_DOUBLE ;
typedef    P_TCD_DOUBLE * P_P_TCD_DOUBLE ;
typedef    char         * TCD_LPCHAR ;
#endif

/*-----------------
  weitere (Typ-)Defines 
-------------------*/  
typedef int ERRNO_TYPE;
#define TCD_FILENAME_LNG 128

/*-----------------
  Definitionen von Makros f�r Speicherallokation
-------------------*/  

/* WATCHMEM muss im TCDHUGE-Modus abgeschaltet sein */
#ifdef TCDHUGE
#undef WATCHMEM
#endif

#undef _TCDALLOC
#undef _TCDFREE
#undef _TCDREALLOC

#ifndef WATCHMEM

#define _TCDALLOC(len,size)    malloc( (size_t)(len) * (size)) ;
#define _TCDFREE(ptr)          {free(ptr), ptr = NULL;}
#define _TCDREALLOC(ptr,size)  realloc( ptr, (size_t)(size) ) ;

#else
 
void *MallocAndProt(char *sFile_,int iLine_, size_t size);
#define _TCDALLOC(len,size)\
 MallocAndProt(__FILE__,__LINE__,(len) * (size))

void FreeAndProt(char *sFile_, int iLine_, void *p_);

#define _TCDFREE(ptr)\
       {FreeAndProt(__FILE__, __LINE__, ptr) , ptr = NULL;}

void *ReallocAndProt(char *sFile_,int iLine_, void *p_, size_t size);
#define _TCDREALLOC(ptr,size)\
 ReallocAndProt(__FILE__, __LINE__, ptr,size)

void ResumeWatchmem();

#endif

/*-----------------
  modellabh�ngige Definitionen von Makros f�r Speicherallokation
-------------------*/
#undef _TCDTABALLOC
#undef _TCDTABFREE
#undef _TCDMEMINI

#ifdef TCDHUGE

#define _TCDTABALLOC(len,size)\
  _halloc( (long)(len) , (size_t)(size)) ;
#define _TCDTABFREE(ptr)\
      { _hfree ( (void huge *)ptr); ptr = NULL;}

#else

#ifndef WATCHMEM
#define _TCDTABALLOC(len,size)\
 malloc((size_t)((long)len) * ((size_t)size)) ;
#define _TCDTABFREE(ptr)       {free(ptr), ptr = NULL;}
#else
#define _TCDTABALLOC(len,size)\
 MallocAndProt(__FILE__,__LINE__,(len) * (size))
#define _TCDTABFREE(ptr)\
       FreeAndProt(__FILE__, __LINE__, ptr)
#endif

#endif


#ifdef TCDHUGE
#define _TCDMEMINI(ptr,size,nr)\
{\
   long       j;\
   TCD_LPCHAR lp;\
   for (j= 0 , lp = (TCD_LPCHAR)ptr;\
        j < ((long)(size) * (long)(nr)); j++, lp++) \
      *lp = 0;\
}  

#else
#define _TCDMEMINI(ptr,size,nr)\
 { memset (ptr, 0, (size_t) ((size) * (nr))) ; }
#endif
/*---------------------------------
  NON-Ansi-Namen mit oder ohne "_"
----------------------------------*/

/* #define NON_ANSI_WITHOUT__ */

#ifdef NON_ANSI_WITHOUT__
#define _fcvt fcvt
#endif

/*---------------------------
  ggf. Verkuerzung der Namen
-----------------------------*/
#ifdef TCD_NAMLEN8

#define TCDIMPReleaseProcData       TCD_0001
#define TCDIMPReleaseNodeData       TCD_0002
#define TCDIMPReleaseTabImpData     TCD_0003   

#define FetchFromGlobalErgebnisPool TCD_0004

#define DelEltFromSVect             TCD_0005
#define DelEltFromSVectByIndex      TCD_0006

#define DelEltFromVect              TCD_0007
#define DelEltFromVectByIndex       TCD_0008
                                
                                
#define ReleaseGlobalErgebnisPool   TCD_0009
#define ReleaseGlobalErgebnis       TCD_0010
#define ReleaseLocalErgebnisPool    TCD_0011

#define GetPrcDataSkal              TCD_0012
#define GetPrcDataTab               TCD_0013
#define GetPrcDataDat               TCD_0014
#define GetPrcDataFrm               TCD_0015

#define GetPrcAttrSkal              TCD_0016
#define GetPrcAttrTab               TCD_0017

#define GetSSAttrSkal               TCD_0018
#define GetSSAttrTab                TCD_0019

#define ErgPoolGetFirstInfo         TCD_0020
#define ErgPoolGetNextInfo          TCD_0021

#define DConstrAttrs                TCD_0022
#define DConstrAttrsResults         TCD_0023

#define GetRelAttrs                 TCD_0024

#define GetIndexToGlobalErgPool     TCD_0025
#define GetIndexToPaarListElt       TCD_0026

#define GetIndexToSS                TCD_0027
#define GetIndexToUes               TCD_0028
#define GetFromSS                   TCD_0029
#define GetFromUes                  TCD_0030

#define TCDIMPImportTreeData        TCD_0031
#define TCDIMPNFIntl                TCD_0032
#define TCDIMPGetNodeFromID         TCD_0033
#define TCDIMPGetNodeFromPath       TCD_0034
#define compBsearch                 TCD_0035
#define TCDIMPReleaseTreeData       TCD_0036 
#define TCDIMPReleaseTabData        TCD_0037  
#define DConstrTCD_C_G              TCD_0038
#define DDestrTCD_C_G               TCD_0039 
#define SConstrTCD_C_G              TCD_0040
#define DConstrTCDRbsSS             TCD_0041
#define SConstrTCDRbsSS             TCD_0042
#define SConstrTCDISSADATA          TCD_0043
#define SDestrTCD_C_G               TCD_0044
#define DDestrTCDRbsSS              TCD_0045
#define SDestrTCDRbsSS              TCD_0046
#define SDestrTCDISSADATA           TCD_0047
#define GetRbsSSFkt                 TCD_0048
#define TCDIMPGetTabIDAndTypFromPath TCD_0049
#define TCDIMPGetPathAndTypFromID    TCD_0050
#define TCDIMPReleaseTabTreeData     TCD_0051
#define TCDIMPImportTabTreeData      TCD_0052
#endif

#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDC_H)
#define TCDC_H

#ifdef TCDV2_5
#define TCDVERS 25
#endif
#ifdef TCDV3_0
#define TCDVERS 30
#endif
#ifndef TCDVERS
#error TCD Version muss in Makefiles angegeben werden.
#endif

/*---------
Name        : TCDC.H

Beschreibung: Zentrales Include File fuer die Anwendung
TCD weit gueltig
*----------*/

#include "p09115.h" /* direkte Vektoren */

#define  TCD_TRUE                1
#define  TCD_FALSE               0

/*---------
  Definitionen Opcodes
*----------*/
#define  TCD_OPC_INIT_RBS                    1
#define  TCD_OPC_CALC_FRM                    2
#define  TCD_OPC_CALC_PRC                    3
#define  TCD_OPC_GETNUM_FRM                  4
#define  TCD_OPC_GET_ATTR_VAL                5
#define  TCD_OPC_RESET_RBS                   6
#define  TCD_OPC_SET_PRC                     7
#define  TCD_OPC_RESET_PRC                   8
#define  TCD_OPC_SET_POOLTAB                 9
#define  TCD_OPC_RESET_POOLTAB              10
#define  TCD_OPC_SET_ATTR_VAL               11
#define  TCD_OPC_GET_PRC_INFO               12
#define  TCD_OPC_SET_POOLTAB_I              13
#define  TCD_OPC_RESET_POOLTAB_I            14
#define  TCD_OPC_SET_ATTR_IN_PRC            15
#define  TCD_OPC_SET_TRACE_ON               16
#define  TCD_OPC_SET_TRACE_OFF              17
#define  TCD_OPC_REMOVE_RESULTS             18
#define  TCD_OPC_GET_FIRST_RESULTS_INFO     19
#define  TCD_OPC_GET_NEXT_RESULTS_INFO      20

/*---------
  Definitionen Returncodes
*----------*/
#define  TCD_RC_NOT_OK              0
#define  TCD_RC_OK                  1
#define  TCD_RC_ILLOPC              2
#define  TCD_RC_VERSION_CONFLICT    3
#define  TCD_RC_UNKNOWN_FORM        4
#define  TCD_RC_ILLEGAL_FORM        5
#define  TCD_RC_ILLEGAL_PARAM       6
#define  TCD_RC_UNKNOWN_ATTR        7
#define  TCD_RC_NOT_FOUND           8
#define  TCD_RC_INPUT_MISSING       9
#define  TCD_RC_ILLEGAL_DIVISION   10
#define  TCD_RC_ILLEGAL_TAB_RANGE  11
#define  TCD_RC_STACK_OVERFLOW     12
#define  TCD_RC_CONDITION_FAIL     15
#define  TCD_RC_PAR_ERROR          20
#define  TCD_RC_TAB_IN_POOL        21
#define  TCD_RC_TAB_NOT_IN_POOL    22
#define  TCD_RC_PRC_IN_POOL        23
#define  TCD_RC_PRC_NOT_IN_POOL    24
#define  TCD_RC_UNKNOWN_PROC       25
#define  TCD_RC_PAARLISTEN_ERROR   26
#define  TCD_RC_NO_VALUE_AVAIL     30
#define  TCD_RC_USER_SET_ERROR    900
#define  TCD_RC_INTERNAL_ERR      999
#define  TCD_RC_NO_RETURN         888

/*---------
  allgemeine globale Konstanten
*----------*/
#define TCD_INIT_VARSETLEVEL    9999

/*---------
  Konfigurationsangaben
*----------*/
#define TCD_POOLADMIN_SIZE        20
#define TCD_C_MIN_USER_TYPE_ID    0
#define TCD_C_TABLISTLEN          10
#define TCD_C_MAXPRCCALLNR        2147483647

/*---------
  Definitionen Laengenangaben
*----------*/
#define TCD_DATUM_LNG              9
#define TCD_FRM_DATUM_LNG         20
#define TCD_VGLOP_LNG              3
#define TCD_NAME_LNG              26

/*---------
  Definitionen Aufrufart: (Aufzaehlungstyp)
-----------*/
#define TCD_CALLTYP_ATTR        1
#define TCD_CALLTYP_STA         2
#define TCD_CALLTYP_DYN         3
#define TCD_CALLTYP_STA_UE      4

/*---------
  Definitionen Prefix
-----------*/
#define TCD_PREFIX_TAB            '&'
#define TCD_PREFIX_PRC            '$'
#define TCD_PREFIX_FRM            'F'
#define TCD_PREFIX_ATTR           'A'

/*---------
  Definitionen Formeltypen (Aufzaehlungstyp, Wertevergabe analog Cobol)
-----------*/
#define TCD_FRMTYP_SKAL        1
#define TCD_FRMTYP_TAB1        2
#define TCD_FRMTYP_TAB2        3

/*---------
  Definitionen Belegungswerte PoolEntry
-----------*/
#define  TCD_POOLENT_INIT          0
#define  TCD_POOLENT_USED          1
#define  TCD_POOLENT_I_USED        2
#define  TCD_POOLENT_E_USED        3

/*---------
  Definitionen Assigntype
*----------*/
#define  TCD_DC_USE_NOT            0
#define  TCD_DC_USE_FRM            1
#define  TCD_DC_USE_PRC            2
#define  TCD_DC_USE_TAB            3
#define  TCD_DC_USE_VAL            4

/*----------
  Definitionen Formattypen
-----------*/
#define  TCD_ATTRFMT_SKAL          1
#define  TCD_ATTRFMT_TAB1          2
#define  TCD_ATTRFMT_TAB2          3
#define  TCD_ATTRFMT_VGLO          4
#define  TCD_ATTRFMT_DATE          5

/*----------
  Struktur Bestandsattributtabelle
 ----------*/
  typedef struct tagS_TCDATAB {
        char          Name [TCD_NAME_LNG] ;
        TCD_LONG      ID         ;
        TCD_INT       Index      ;
        TCD_INT       AttrTyp    ;
  } S_TCDATAB     ;

 typedef S_TCDATAB     * P_TCDATAB     ;

/*----------
  Struktur Tabelle aller Attribute
 ----------*/
  typedef struct tagS_ATTRTAB
  {
    TCD_LONG  ID    ;
    TCD_INT   Index ;
  } S_ATTRTAB ;

  typedef S_ATTRTAB    * P_ATTRTAB     ;

/*----------
  Typdefinition systemunabhanegiger Typen
 ----------*/
   typedef  char  TCD_VGLOP [TCD_VGLOP_LNG] ;
   typedef  char  TCD_DATUM [TCD_DATUM_LNG] ;

   typedef TCD_DOUBLE TCDTAB1 ;
   typedef P_TCDTAB   P_TCDTAB1 ;

   typedef TCD_DOUBLE TCDTAB2 ;
   typedef P_TCDTAB   P_TCDTAB2 ;

   typedef P_P_TCD_DOUBLE P_P_TCDTAB ;

/*---------
  Union Attributbelegung
 ----------*/
  typedef  union tagU_TCDVALUE {
           TCD_DOUBLE        Skalar;
           P_TCDTAB1         pTab1 ;
           P_TCDTAB2         pTab2 ;
   } U_TCDVALUE ;

  typedef  union tagU_TCDGVALUE {
           TCD_DOUBLE        Skalar;
           P_TCDTAB          pTab  ;
           TCD_VGLOP         VglOp ;
           TCD_DATUM         Datum ;
   } U_TCDGVALUE ;

/* --
 MUB 2.7.96: neu eingefuehrt, weil wir die TabellenID brauchen
--  */
  typedef  union tagU_TCDWVALUE
  {
           TCD_DOUBLE        Skalar;

           TCD_LONG          TabID ;  /*  die relevanten Attribute */
           P_TCDTAB1         pTab  ;  /*  das Ergebnis */

           TCD_VGLOP         VglOp ;
           TCD_DATUM         Datum ;
   } U_TCDWVALUE ;

  typedef struct tagS_TCDPRCVAL {
          TCD_LONG   PrcID ;
          TCD_LONG   FormelNr ;
          TCD_INT    FormelIx ;
          char       FormelName [TCD_NAME_LNG] ;
          TCD_INT    PoolIx ;
#if TCDVERS > 25
/* Version der Formel zur Pruefung 
		  Formel-Generat gegen Transport-Format */
          TCD_INT    FormelVers;
#endif

 } S_TCDPRCVAL ;

  typedef union  tagU_TCDNDVALUE {
          struct   tagTabData {
             TCD_LONG  TabID ;
             TCD_INT   PoolIx ;
          } TabData  ;
          TCD_DOUBLE Skalar ;
          char       Datum [TCD_DATUM_LNG] ;
          char       VglOp [TCD_VGLOP_LNG];
 } U_TCDNDVALUE ;


  typedef struct tagS_TCDFORMEL {
           TCD_LONG  FormelNr ;
           TCD_INT  FormelIx ;
           char     FormelName [TCD_NAME_LNG] ;
           TCD_INT  IsStaRef ;                                 
#if TCDVERS > 25
/* Version der Formel zur Pruefung 
		   Formel-Generat gegen Transport-Format */
		   TCD_INT  FormelVers;
#endif
 } S_TCDFORMEL ;

  typedef union  tagU_TCDASSIGNVAL {

       S_TCDPRCVAL  Prc    ;
       U_TCDNDVALUE Val    ;
       S_TCDFORMEL  Formel  ;

 } U_TCDASSIGNVAL ;

#define TYP3_NOT_OVERWRITTEN 2

typedef struct tagS_TCDREL_ATTR
{                                 
   TCD_LONG    iBerechnungsNummer;
   /* ID des Attributs                            */
   TCD_LONG    AttrID                  ;  
   /* Typ der Belegung SKALAR, TAB, DATUM , VGLOP */
   TCD_INT     AttrType              :4;  
   /* Flag, ob ein geerbter Wert vorhanden ist    */
   TCD_INT     bGeerbterWertVorhanden:2;  
   /* Flag, ob ein geerbter Wert vorhanden ist    */
   TCD_INT     bNotOverwritten         ;
   /* GGf. Wert hierzu                            */
   U_TCDWVALUE Belegung                ;  

}  S_TCDRELATTR;

typedef S_TCDRELATTR * P_TCDRELATTR ;

/* --
   S_TCDRELATTR_IMP    Relevantes Attribut fuer den Import
--  */
typedef struct tagS_TCDREL_ATTR_IMP
{
   TCD_LONG AttrID;
   TCD_INT  AttrType               : 4;
   TCD_INT  iIndex;

}  S_TCDRELATTR_IMP;

typedef S_TCDRELATTR_IMP * P_TCDRELATTR_IMP ;

/* --
   S_PAARLISTEN_EL    Struktur fuer ein PaarlistenElement
--  */
typedef struct tagS_PAARLISTEN_EL
{
   /* Vektor der relevanten Attribute mit der aktuellen Belegung     */
   LP_VECT          pAttrs;        
   /* lfde. Nummer der aktuellen Berechnung                          */
   TCD_LONG         iBerechnungsNummer; 
   
   TCD_LONG         lTabZeilen;         
   TCD_LONG         lTabSpalten;
   
   /* Typ des Ergebnisses (kann 'NOT_OVERWRITTEN' sein)              */
   TCD_INT          iType;              
   /* Ergebnis hierzu                                                */
   U_TCDWVALUE      Ergebnis;           

}  S_PAARLISTEN_EL;

typedef S_PAARLISTEN_EL * P_PAARLISTEN_EL ;

/* --
   S_PAARLISTE     Struktur zu einem Belegknoten einer BV
   Sie enthaelt 1 sortierten Vektor, 1 Liste und eine maximale Laenge
   fuer die Anzahl Elemente der Paarliste (Belegung,Ergebnis)
--  */
typedef struct tagS_PAARLISTE
{
   TCD_INT iWiederVerwendungsTyp;   /* KnotenTyp 1/2/3     */
   TCD_INT iWiederVerwListenLaenge; /* ListenLaenge maximal */
   TCD_INT iAct ;                   /* letztes Element     */

   /* direkter Vektor von S_ATTR_EL's   */
   LP_VECT pAttrs;                  
   /* direkter Vektor von S_PAARLISTEN_EL's */
   LP_VECT pPaarListenElts;         

}  S_PAARLISTE;

typedef S_PAARLISTE * P_PAARLISTE ; 

/* --
   S_ERGEBNIS_POOL_ELT Element eines PoolErgebnisses
--  */
typedef struct tagS_ERGEBNIS_POOL_ELT
{
   TCD_LONG    ID;
   P_PAARLISTE pPaarListe;

}  S_ERGEBNIS_POOL_ELT;

typedef S_ERGEBNIS_POOL_ELT * P_ERGEBNIS_POOL_ELT ;

/*-----------
  Struktur     Belegungsknoten
------------*/
  typedef struct tagS_TCDPRCNODE
  {
      TCD_LONG         AttrID                  ;
      TCD_INT          NodeID                  ;
      TCD_INT          AttrType                ;
      TCD_INT          AssignType              ;
      U_TCDASSIGNVAL   AssignVal               ;
      TCD_INT          SuccNodeIx              ;
      TCD_INT          AnzSuccNodes            ;
      TCD_INT          Usage                   ;

      P_PAARLISTE      pPaarListe              ;
      P_PAARLISTEN_EL  pResultForGetAttr       ;

      TCD_INT          iWiederVerwendungsTyp   ;
      TCD_INT          iWiederVerwListenLaenge ;
      TCD_INT          iAnzRelAttrs            ;
      TCD_INT          iFirstRelAttrIx         ;

  }   S_TCDPRCNODE ;

 typedef S_TCDPRCNODE  * P_TCDPRCNODE ;

/*-----------
  Struktur Auspraegungs-Belegungs-Information
------------*/
  typedef struct tagS_TCDPRCINFO {
         char  Name [TCD_NAME_LNG] ;
         TCD_LONG  ID ;
         TCD_INT   Formattyp ;
         TCD_INT   Typ ;
         TCD_INT   Klasse ;
         TCD_INT   AnzBeleg ;
         TCD_INT   TabIx ;
         TCD_LONG  RefNodeId ;
 } S_TCDPRCINFO ;

 typedef S_TCDPRCINFO  * P_TCDPRCINFO ;

/*--------
  Struktur LocalData MUB 2.7.96: wird nicht mehr verwendet!
 --------*/
  typedef struct tagS_TCDPRCLOCD {
          TCD_LONG FormelNr     ;
          TCD_INT  Usage        ;
          TCD_INT  Typ          ;
          union   {
              TCD_INT    PoolIx ;
              TCD_DOUBLE Val    ;
          } Data ;
          TCD_LONG  CalcByCallNr ;
   } S_TCDPRCLOCD ;

   typedef S_TCDPRCLOCD * P_TCDPRCLOCD ;

/*---------
  Struktur Header Auspraegungsbaum
----------*/
  typedef struct tagS_TCDPRCHDR {
    TCD_LONG       PrcID        ;
    TCD_LONG       FormelNr     ;
    TCD_INT        AnzPrcTree   ;
    TCD_INT        AnzBelegInfo ;
    TCD_INT        AnzRelAttrs  ;
    TCD_BOOL       FlSetAttrSkal;
    TCD_BOOL       FlSetAttrTab ;
    TCD_BOOL       FlSetAttrVgl ;
    TCD_BOOL       FlSetAttrDat ;
    TCD_BOOL       FlPrcCompl   ;
    TCD_LONG       PrcResIx     ;
    TCD_LONG       PrcCallNr    ;

 } S_TCDPRCHDR     ;


/*---------
  Struktur Auspraegungselement
-----------*/
  typedef union  tagU_TCDPRCELEM
  {
     S_TCDPRCHDR      TreeHdr;
     S_TCDPRCNODE     Node ;
     S_TCDPRCINFO     Info ;     
  }  U_TCDPRCELEM ;

 typedef U_TCDPRCELEM  * P_TCDPRCELEM ;

#define TCDPRCSIZE(pPrc)    (pPrc ? sizeof(S_TCDRELATTR_IMP)*\
                            (TCD_LONG)pPrc->TreeHdr.AnzRelAttrs +\
                            sizeof(U_TCDPRCELEM)*\
                            ( (TCD_LONG)pPrc->TreeHdr.AnzPrcTree +\
                             (TCD_LONG)pPrc->TreeHdr.AnzBelegInfo) : 0)


/*-------
  Datenstruktur Mehrfach-Auspraegung (MultiProc)
 --------*/
  typedef struct tagS_TCDMPRCENTRY {
        TCD_INT              PrcBelegt ;
        TCD_LONG             ID ;
        P_TCDPRCELEM         pPrcData ;
 } S_TCDMPRCENTRY ;

  typedef S_TCDMPRCENTRY * P_TCDMPRCENTRY ;

  typedef struct tagS_TCDMPRCADMIN {
        TCD_INT          Anzahl  ;
        P_TCDMPRCENTRY   Data    ;
 } S_TCDMPRCADMIN ;

 typedef S_TCDMPRCADMIN * P_TCDMPRCADMIN ;

/*--------
  Datenstruktur PoolAdmin
--------*/
  typedef struct tagS_TCDPOOLENTRY {
        TCD_LONG     ID ;
        TCD_INT      Usage ;
        TCD_INT      Typ ;
        TCD_INT      Fmttyp ;
        P_TCD_DOUBLE pData ;
  } S_TCDPOOLENTRY ;

  typedef S_TCDPOOLENTRY * P_TCDPOOLENTRY ;

  typedef struct tagS_TCDPOOLADMIN {
        TCD_INT          Anzahl  ;
        TCD_INT          AnzTabs ;
        TCD_INT          AnzProcs ;
        TCD_INT          AnzTemp  ;
        S_TCDPOOLENTRY * Data    ;
 } S_TCDPOOLADMIN ;

  typedef S_TCDPOOLADMIN * P_TCDPOOLADMIN ;

/*------
  Datenstruktur Kontrollstruktur
--------*/
  typedef struct tagS_TCDRBSINFO {
       char TcdVersion [TCD_DATUM_LNG]   ;
       char TcdRelease [TCD_DATUM_LNG]   ;
       char RbsInterf  [TCD_DATUM_LNG]   ;
       TCD_LONG RbsId ;
   } S_TCDRBSINFO ;

   typedef struct tagS_TCDRCINFO {
       TCD_INT   Rc ;
       TCD_INT   Errc ;
       char FormelName [TCD_NAME_LNG] ;
       TCD_INT   FormelNr ;
       char AttrName   [TCD_NAME_LNG] ;
   } S_TCDRCINFO          ;

   typedef S_TCDRCINFO * P_TCDRCINFO ;


   typedef struct tagS_TCDCTLPAR {

/*-
  Opcode:   TCD_OPC_GET_ATTR_VAL, TCD_OPC_SET_ATTR_VAL
--*/
        struct tagS_TCDPARGA {
           TCD_LONG    ProcID;
           TCD_LONG    ID;
           TCD_LONG    TabID;
           TCD_INT     TabIx ;
           U_TCDGVALUE Val ;
           TCD_INT     Typ ;
           TCD_INT     ProcIx;
        }            GA ;

/*-
  Opcode:   TCD_OPC_SET_POOLTAB
--*/
        struct tagS_TCDPARST {
            TCD_LONG  ID;
            TCD_INT   Dim ;
            P_TCDTAB  pTab ;
            TCD_INT    TabIx ;
        }            ST ;

/*-
  Opcode:   TCD_OPC_RESET_POOLTAB
--*/
        struct tagS_TCDPARRT{
            TCD_LONG  ID;
            P_TCDTAB  pTab ;
        }            RT ;

/*-
  Opcode:   TCD_OPC_SET_PRC
--*/
        struct tagS_TCDPARSP {
            TCD_LONG      ProcID;
            P_TCDPRCELEM  pProc;
            TCD_INT       ProcIx;
        }            SP;

/*-
  Opcode:   TCD_OPC_RESET_PRC
--*/
        struct tagS_TCDPARRP {
            TCD_LONG  ProcID;
            P_TCDPRCELEM  pProc;
        }            RP;

/*-
  Opcode:   TCD_OPC_CALC_FRM , TCD_OPC_CALC_PRC
--*/
        struct tagS_TCDPARCFP {
            TCD_LONG       FormelNr ;
            TCD_LONG       ProcID;
            TCD_INT        Typ ;
            U_TCDVALUE     Value ;
            TCD_INT        ProcIx;
        }            CFP ;

/*-
  Opcode:   TCD_OPC_GETNUM_FRM
--*/
        struct tagS_TCDPARGF {
            char  Name [TCD_NAME_LNG] ;
            TCD_LONG  FormelNr ;
        }            GF ;

/*-
  Opcode:   TCD_OPC_GET_PRC_INFO
--*/
        struct tagS_TCDPRCBINFO {
            TCD_LONG        ProcID;
            TCD_INT         ProcIx;
            P_TCDPRCELEM    pProcInfo;
            TCD_INT         AnzProcInfo ;
        }            PI ;

/*-
  Opcode:   TCD_OPC_REMOVE_RESULTS,
            TCD_OPC_GET_FIRST_RESULTS_INFO,
            TCD_OPC_GET_NEXT_RESULTS_INFO
--*/
        struct tagS_TCDPAR_RESULTPOOL {
            TCD_LONG        ProcID;
            TCD_LONG        lNumOfResults;
            TCD_INT         bFinished;
        }            RESP ;

   } S_TCDCTLPAR ;

   typedef S_TCDCTLPAR * P_TCDCTLPAR ;

   typedef struct tagS_TCDRBSCTL {
          TCD_INT       Opc     ;
          S_TCDRBSINFO  RbsInfo ;
          S_TCDRCINFO   RCInfo  ;
          S_TCDCTLPAR   Par     ;
  } S_TCDRBSCTL ;

   typedef S_TCDRBSCTL * P_TCDRBSCTL ;

/*------
  Datenstruktur Rechenbausteinschnittstelle
 --------*/
   typedef struct tagS_TCDV_F_FLAGS {
         TCD_BOOL       V_In   ;
         TCD_BOOL       F_In   ;
         TCD_BOOL       V_Comp ;
         TCD_BOOL       V_Use  ;
         TCD_BOOL       F_Use  ;
         TCD_BOOL       V_Miss ;
         TCD_BOOL       F_Miss ;
   } S_TCDV_F_FLAGS ;

   typedef S_TCDV_F_FLAGS * P_TCDV_F_FLAGS ;

   typedef struct tagS_TCDV_FLAGS {
         TCD_BOOL       V_In   ;
         TCD_BOOL       V_Use  ;
         TCD_BOOL       V_Miss ;
   } S_TCDV_FLAGS ;

   typedef S_TCDV_FLAGS   * P_TCDV_FLAGS   ;

   typedef struct tagS_TCDSKAL_DATA
   {
        TCD_DOUBLE      Val    ;
        TCD_LONG        Formel ;
        S_TCDV_F_FLAGS  Flags  ;
   } S_TCDSKAL_DATA ;

   typedef S_TCDSKAL_DATA * P_TCDSKAL_DATA ;

   typedef struct tagS_TCDTAB1_DATA
   {
     TCD_LONG        TabID;
     P_TCDTAB1       pVal ;
     TCD_LONG        Formel ;
     S_TCDV_F_FLAGS  Flags ;

   } S_TCDTAB1_DATA ;
   typedef S_TCDTAB1_DATA  * P_TCDTAB1_DATA  ;

   typedef struct tagS_TCDTAB2_DATA
   {
     TCD_LONG        TabID;
     P_TCDTAB2       pVal ;
     TCD_LONG        Formel ;
     S_TCDV_F_FLAGS  Flags ;

   } S_TCDTAB2_DATA ;
   typedef S_TCDTAB2_DATA * P_TCDTAB2_DATA ;

   typedef struct tagS_TCDDAT_DATA {
        char             Val [TCD_DATUM_LNG] ;
        S_TCDV_FLAGS     Flags ;
   } S_TCDDAT_DATA ;

   typedef S_TCDDAT_DATA * P_TCDDAT_DATA ;

   typedef struct tagS_TCDVGL_DATA {
        char            Val [TCD_VGLOP_LNG] ;
        S_TCDV_FLAGS    Flags ;
   } S_TCDVGL_DATA ;

   typedef S_TCDVGL_DATA * P_TCDVGL_DATA ;

   typedef struct tagS_TCD_RBS_SSA
   {
        P_TCDSKAL_DATA    pSkal ;
        P_TCDTAB1_DATA    pTab1 ;
        P_TCDTAB2_DATA    pTab2 ;
        P_TCDDAT_DATA     pDat  ;
        P_TCDVGL_DATA     pVgl  ;
   } S_TCD_RBS_SSA ;

   typedef S_TCD_RBS_SSA  * P_TCD_RBS_SSA ;


   typedef struct tagS_TCDRBS_SS {
       S_TCDRBSCTL       RCTL ;
       S_TCD_RBS_SSA     SSAData   ;
       S_TCDPOOLADMIN    PoolAdmin ;
       S_TCDMPRCADMIN    MPrcAdmin ;
 } S_TCDRBS_SS ;

 typedef S_TCDRBS_SS  * P_TCDRBS_SS ;

  typedef struct tagS_TCDPARATTR_SK {
        TCD_INT      Level ;
        TCD_DOUBLE   Val ;
 } S_TCDPARATTR_SK   ;

 typedef S_TCDPARATTR_SK  * P_TCDPARATTR_SK ;

  typedef struct tagS_TCDPARATTR_VGL {
        TCD_INT      Level;
        char         Val  [TCD_VGLOP_LNG] ;
 } S_TCDPARATTR_VGL  ;

 typedef S_TCDPARATTR_VGL * P_TCDPARATTR_VGL ;

  typedef struct tagS_TCDPARATTR_DAT
  {
        TCD_INT      Level;
        char         Val  [TCD_DATUM_LNG] ;
 } S_TCDPARATTR_DAT  ;

 typedef S_TCDPARATTR_DAT * P_TCDPARATTR_DAT ;

/*-----------
  Struktur Schnittstellendaten (interne Sicht)
-----------*/
  typedef struct tagS_TCDISSADATA
  {
     TCD_INT      AnzSSASkal ;
     TCD_INT      AnzSSATab1 ;
     TCD_INT      AnzSSATab2 ;
     TCD_INT      AnzSSADat ;
     TCD_INT      AnzSSAVgl ;
     TCD_INT      AnzParSkal;
     TCD_INT      AnzParVgl ;
     TCD_INT      AnzParDat ;
     TCD_INT      AnzZeilen ;
     TCD_INT      AnzSpalten ;
     P_TCDSKAL_DATA    pSkal ;
     P_TCDTAB1_DATA    pTab1 ;
     P_TCDTAB2_DATA    pTab2 ;
     P_TCDDAT_DATA     pDat ;
     P_TCDVGL_DATA     pVgl ;
     P_TCDPARATTR_SK   pParSkal ;
     P_TCDPARATTR_VGL  pParVgl;
     P_TCDPARATTR_DAT  pParDat;

 }   S_TCDISSADATA ;
 typedef S_TCDISSADATA * P_TCDISSADATA ;



/*------
Datenstruktur globale Daten des Rechenbausteins;
diese Datenstruktur enthaelt Informationen und Teilstrukturen, die
in den programmierten Funktionen benoetigt werden.
Initialisierung dieser Daten erfolgt mehrstufig.
- beim Init: globaler Pointer pTCDTCD initialisiert (zeigt auf die Str)
pRbsSS zeigt auf die RBS-Schnittstelle
- bei auspraegungsspez. Opcodes werden die Teilstrukturen fuer die
Auspraegung initialisiert, ...
- bei einer neuen Berechnung werden die internen Aufrufschnittstellen
initialisiert
--------*/
  typedef struct tagS_TCD_C_G
  {
      P_TCDRBS_SS      pRbsSS      ;
      P_TCDPRCELEM     pPrcData    ;
      S_TCDPRCHDR *    pPrcHdr     ;
      P_TCDPRCELEM     pPrcTreeNode;
      P_TCDPRCELEM     pInfo       ;
      P_TCDRELATTR_IMP pRelAttrs   ;
      P_TCDMPRCADMIN   pMPrcAdmin  ;
      P_TCDRBSCTL      pRbsCtl     ;
      S_TCDISSADATA    SSAData     ;
      P_TCDPOOLADMIN   pPoolAdmin  ;
      TCD_INT          GlbVarSet   ;
      TCD_LONG         RBS_ID      ;
      TCD_BOOL         ValFound    ;
      TCD_BOOL         FrmFound    ;
      TCD_BOOL         V_Comp      ;
      TCD_BOOL         PrcChg      ;
      void *           pApplIf     ;
      P_TCDTAB         ResTab      ;
      TCD_DOUBLE       ResSkal     ;
      
      TCD_LONG         LastCalcPrcID;
      LP_VECT          pErgebnisPool;
      TCD_LONG         iBerechnungsNummer;
      TCD_INT          iErgPoolIteratorGl;                       
      P_PAARLISTE      pPaarListeNotToSave;
      
      TCD_BOOL         btrace_open;
      TCD_BOOL         btrace_enabled;
      
/* RWE, 10.06.1997: Neues Datenelement fuer Beobachtung
   der Wiederverwendung (ehemals WatchPol-Funktionalitaet) */
      TCD_BOOL         bProtWV;
      
  }   S_TCD_C_G ;
  typedef S_TCD_C_G   * P_TCD_C_G ;
#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDI_H)
#define TCDI_H
/*--------------
    Name        : TCDI.H

    Beschreibung: Include File intern nur f�r C- Generator
                  wird von den fest programmierten Moduln und
                  generierten Moduln benoetigt
    By          : BEGGI
    Datum       : 22.02.94
    Historie    : BEG   28.11.95   Definition Attributklassen
*--------------*/

/*-------------
  Returncodes FrmRet und ValRet (Definitionen analog Cobol) fuer
  Attributmanager
---------------*/
#define TCD_AIRC_CALLVIAFRM    4

/*-------------
  Definitionen Attributtypen (Aufzaehlungstyp)
---------------*/
#define TCD_ATTYP_TAR_SKAL      1
#define TCD_ATTYP_TAR_TAB1      2
#define TCD_ATTYP_TAR_TAB2      3
#define TCD_ATTYP_TAR_DATE      4
#define TCD_ATTYP_TAR_VGLO      5
#define TCD_ATTYP_BST_SKAL      6
#define TCD_ATTYP_BST_TAB1      7
#define TCD_ATTYP_BST_TAB2      8
#define TCD_ATTYP_BST_DATE      9
#define TCD_ATTYP_BST_VGLO     10

#define TCD_ATTRTYP_SKAL        0
#define TCD_ATTRTYP_TAB1        1
#define TCD_ATTRTYP_TAB2        2
#define TCD_ATTRTYP_DATE        3
#define TCD_ATTRTYP_VGLO        4

/*--------------
  Definitionen Attributklasse
---------------*/
#define TCD_ATTRCLASS_TAR       1
#define TCD_ATTRCLASS_BST       6

/*-------------
  Definitionen Errorcodes
---------------*/
#define TCD_UNKNOWN_OPCODE       1
#define TCD_NO_SPACE_IN_TLIST    2
#define TCD_ERR_GETMEM           3
#define TCD_GETEMPTYENTRY        4
#define TCD_NOPOOLADMIN          5
#define TCD_ILLTABFMT            6
#define TCD_UNK_ASSIGNTYP        7
#define TCD_NO_MPRCADMIN         8
#define TCD_EXPPOOLADMIN         9
#define TCD_NO_MEMORY           10
#define TCD_NO_PRCREF           11
#define TCD_ILLFRM_ID           12
#define TCD_ILLFRM_CMP          13
#define TCD_ERR_INIT_FORMEL     14
#define TCD_FRMGEN_OUT_OF_DATE	15
#define TCD_TRPFMT_OUT_OF_DATE	16

/*----------
  Datenstruktur Freigabeliste  Hilfsvariablentabellen
 ------------*/
  typedef struct tagS_TCDTABLIST    {
         TCD_INT        CallOvw ;
         TCD_LONG       CallerID ;
         TCD_LONG       CallFrmNr ;
         TCD_INT        CallType  ;
         P_TCD_DOUBLE   Adr ;
 } S_TCDTABLIST   ;

 typedef  S_TCDTABLIST  * P_TCDTABLIST  ;

/*----------
  Datenstruktur Formelparameter
 ------------*/
  typedef struct tagS_TCD_C_F1 
  {
     char         * FormelName     ;
     TCD_INT        FrmTyp         ;
     TCD_LONG       FrmNr          ;
     TCD_INT        FrmIx          ;
     char         * AttrName       ;
     TCD_INT        CallType       ;
     TCD_LONG       AttrID         ;
     TCD_INT        AttrTyp        ;
     TCD_INT        AttrIx         ;
     TCD_INT        ParIx          ;
     TCD_INT        Ret            ;
     TCD_INT        ExecCond       ;
     P_TCDPRCNODE   PrcFNode       ;
     P_TCDPRCNODE   pNode          ;
     TCD_INT        MinVarSet      ;
     TCD_INT        BegVarSet      ;
     char         * CmpTime        ;
     TCD_INT        Level          ;
     P_TCD_DOUBLE   pVarSkal       ;
     P_P_TCDTAB     pVarTab        ;
     char         * VarDatVgl      ;
     TCD_INT      * VarIndex       ;
     P_TCDTABLIST   FreeList       ;
     TCD_INT        AnzTabList     ;
     TCD_INT        AnzTabListEnt  ;
     P_TCDPRCNODE   NextFNode      ;
     TCD_INT        NextExecCond   ;
     TCD_INT        NextCallType   ;
     struct tagS_TCD_C_F1 * pPrevLevelInfo ;
     P_TCD_C_G      pTCDTCD ;
  } S_TCD_C_F1 ;

  typedef  S_TCD_C_F1 *   P_TCD_C_F1 ;

  typedef struct tagS_TCDFTAB {
        char          FrmName [TCD_NAME_LNG] ;
        void          (* pFormelFunc ) ( P_TCD_C_F1);
        TCD_LONG      FrmNr      ;
        TCD_INT       FrmTyp     ;
        char          Datum [TCD_FRM_DATUM_LNG] ;
  } S_TCDFTAB     ;

 typedef S_TCDFTAB     * P_TCDFTAB     ;

/* extern P_TCD_C_G pTCDTCD ; */

#endif


/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_POOL_H)
#define TCD_POOL_H
/*---------------------------------------------------------------------
  Datei      : TCD_POOL.h
  Generiert am 16.12.2019 15:07:18
  Historie      : 27.7.95    BEG neuer Prefix fuer Tabellenentry
---------------------------------------------------------------------*/
void    TCDPIT   (P_TCD_C_G);
void    TCDPRP   (P_TCD_C_G) ;
void    TCDPST   (P_TCD_C_G) ;
void    TCDPRT   (P_TCD_C_G) ;
void    TCDPSAT  (P_TCD_C_G) ;
void    TCDPRTA  (P_TCD_C_G) ;
TCD_INT TCDPGF   (P_TCD_C_G,P_TCD_DOUBLE Var, TCD_INT *PIndex) ;

#endif

/*---------------------------------------------------------------------------

(C) Copyright 1993-2002, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------------*/
#if !defined (TCD_ATTR_H)
#define TCD_ATTR_H
/*---------------------------------------------------------------------
  Datei:        TCD_ATTR.H
  Beschreibung: Attributmanager
---------------------------------------------------------------------*/
TCD_INT   TCDAATS (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAATT (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAABS (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAABT (P_TCD_C_F1 pF1) ;
void      TCDAATD (P_TCD_C_F1 pF1) ;
void      TCDAABD (P_TCD_C_F1 pF1) ;
void      TCDAATV (P_TCD_C_F1 pF1) ;
void      TCDAABV (P_TCD_C_F1 pF1) ;
void      TCDAFT  (P_TCD_C_F1 pF1) ;
void      TCDAFBS (P_TCD_C_F1 pF1) ;
void      TCDAFBT (P_TCD_C_F1 pF1) ;

#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_FRT_H)
#define TCD_FRT_H
/*---------------------------------------------------------------------
    Datei:        TCD_FRT.H

Beschreibung: Modul zur allgemeinen Endebehandlung einer Formelfunktion
By:           BEGGI
Datum:        30.03.94
Historie:     BEG    28.11.95  neue Funktion: TCDSetPD
---------------------------------------------------------------------*/
TCD_INT TCDInit (P_TCD_C_F1 pMyPar, TCD_INT FrmNr, char *fctl_cmptime,
				 TCD_LONG VerNr);
void    TCDFtID (P_TCD_C_F1 pMyPar, char * AttrName,
                 TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                 TCD_INT *Var) ;

void    TCDSetPS (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                 TCD_DOUBLE *Var1, TCD_INT *Var2, TCD_DOUBLE Var3) ;
void    TCDSetPV (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                  char *Var1, TCD_INT *Var2, char *Var3) ;
void    TCDSetPD (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                  char *Var1, TCD_INT *Var2, char *Var3) ;

TCD_INT TCDGetTb (P_TCD_C_F1 pMyPar, P_P_TCDTAB Var) ;
void    TCDIniPS (P_TCD_C_G) ;

void    TCDIniFC (P_TCD_C_G) ;
void    TCDIniFU (P_TCD_C_G) ;
void    TCDIniFM (P_TCD_C_G) ;

void    TCDRetSk (P_TCD_C_F1 pMyPar, P_TCD_DOUBLE  VarSkal) ;
void    TCDRetTb (P_TCD_C_F1 pF1, P_P_TCDTAB  VarTab) ;

/*-----------------
  TraceFunktionsprototypen und Trace Makros
-------------------*/
#ifdef TRACEFKT
void _TCD_TRACE( const char * ,const char * ,const char *,P_TCD_C_G );
void _TCD_TRVAL( const char * , int , double *, double,P_TCD_C_G  ) ;

#define TCD_TRACE(pack,func,text, pTCDTCD)  \
            _TCD_TRACE(pack,func,text, pTCDTCD);
#define TCD_TRVAL(text,type,val1,val2, pTCDTCD) \
            _TCD_TRVAL(text,type,val1,val2, pTCDTCD);
#endif

#define C_TRACEFILE        "CTRACE.TCD"

#endif
  
/* RWE, 10.06.1997   */
/*-----------------
  Funktionsprototypen fuer Wiederverwendungsprotokoll
-------------------*/ 
#ifdef PROTWV
void     SetProtWV             (P_TCD_C_G pIf, TCD_BOOL bProtWV);   
  /* ^Dieser Prototyp ist auch in commands.c enthalten! */
TCD_BOOL ProtWVEnabled         (P_TCD_C_G pIf);
void     ProtWV1               (P_TCD_C_F1 pMyPar); 
void     ProtWV2               (P_TCD_C_F1   pMyPar, 
                                P_TCDPRCNODE pNode,
                                P_PAARLISTE  pPaarListe, 
                                TCD_INT      iFlag);
void     ProtWVString          (char *s);
                                
#define C_PROTWVFILE       "CPROTWV.TCD"
#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_IOP_H)
#define TCD_IOP_H

#ifndef SUBSYSTEM
  #define IOP_EXPORT 
#else
  #define IOP_EXPORT
#endif
TCD_DOUBLE IOP_EXPORT   TCDABS     (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDFAK     (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDINT     (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDSIGN    (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDDIV     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDEXP     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDMIN     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDMAX     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDZDAYS   (TCD_INT    datefmt, char *val1, 
                                    char *val2);
TCD_DOUBLE IOP_EXPORT   TCDKDAYS   (TCD_INT    datefmt, char *val1, 
                                    char *val2);
TCD_DOUBLE IOP_EXPORT   TCDRND     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDCUT     (TCD_DOUBLE val1, TCD_DOUBLE val2);


#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_FCTL_H)
#define TCD_FCTL_H
/*---------------------------------------------------------------------
  Modul:   TCD_FCTL.H
  f�r RBS: LifeTemplate
---------------------------------------------------------------------*/

void  LifeTemF(P_TCD_C_G pTCDTCD) ;
void  LifeTem1(P_TCD_C_F1  pF1 ) ;
void    TCD3FES (P_TCD_C_F1 pMyPar, char * AttrName, TCD_INT Ix,
                       TCD_LONG ID, TCD_INT AttrTyp, TCD_INT ParIx,
                       P_TCD_DOUBLE Var) ;
void    TCD3FET (P_TCD_C_F1 pMyPar, char * AttrName, TCD_INT Ix,
                      TCD_LONG ID, TCD_INT AttrTyp, P_P_TCDTAB Var);
void    TCD3FED (P_TCD_C_F1 pMyPar, char * AttrName,
                      TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                      TCD_INT ParIx, char *Var) ;
void    TCD3FEV (P_TCD_C_F1 pMyPar, char * AttrName,
                      TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                      TCD_INT ParIx, char *Var) ;
TCD_INT TCD3FE1 (P_TCD_C_F1 pMyPar, TCD_BOOL option, char * Name,
                      TCD_LONG ID, TCD_INT FrmNr, P_TCD_DOUBLE Var) ;
TCD_INT TCD3FE2 (P_TCD_C_F1 pMyPar, TCD_BOOL option, char * Name,
                      TCD_LONG ID, TCD_INT FrmNr, P_P_TCDTAB  Var) ;

TCD_INT TCDChkFrm     (P_TCD_C_F1,void *);
void    ClearOverwriteStack(P_TCD_C_G pTCDTCD );

void       TCD3FESaveResult(P_TCD_C_F1);

#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_PKF_H)
#define TCD_PKF_H
/*---------------------------------------------------------------------
    Modul:        C:\dev\TCD_DB\template\db\R3FE\C\C3E9\lifet250.h

    Beschreibung: Funktionsprototypen der externen Funktionen der
                  Formelsammlungsdatei
    By:           BEGGI
    Generiert am: 16.12.2019 15:07:19
---------------------------------------------------------------------*/
   
      void LifeT128 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT129 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT130 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT131 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT132 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT133 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT134 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT135 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT136 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT137 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT138 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT139 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT140 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT141 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT142 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT143 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT144 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT145 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT146 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT147 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT148 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT149 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT150 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT151 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT152 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT153 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT154 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT155 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT156 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT157 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT158 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT159 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT160 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT161 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT162 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT163 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT164 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT165 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT166 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT167 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT168 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT169 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT170 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT171 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT172 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT173 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT174 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT175 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT176 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT177 (P_TCD_C_F1 pMyPar) ;
   

#endif



/*---------------------------------------------------------
   Externe Funktion : LifeT235
   Beschreibung: Die Funktion berechnet die Formel 
                 F_pn
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT235 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_1 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_DOUBLE  HV_5 = 0;
   TCD_DOUBLE  HV_6 = 0;
   TCD_DOUBLE  HV_7 = 0;
   TCD_DOUBLE  HV_9 = 0;
   TCD_DOUBLE  HV_10 = 0;
   TCD_DOUBLE  HV_11 = 0;
   TCD_INT     HV_0 = 0;
   TCD_INT     HV_3 = 0;
   TCD_INT     HV_4 = 0;
   TCD_INT     HV_8 = 0;
   TCD_INT     HV_12 = 1;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT235","Begin F_pn",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,235,"12.12.2019 17:29:46",
                       4);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT235",
              "Ende F_pn",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_Period", 57, 405, 1, 145, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 >= 1 ) goto l_18 ;
      goto l_63 ;
   l_18: 
      HV_11 = 1;
      if ( HV_0 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_Period", 57, 405, 1, 145, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_8: 
      for ( HV_3 = (TCD_INT) (1) ; HV_3 <= HV_1; HV_3 = HV_3 + 1 ) {
         if ( HV_4 != 0 ) goto l_11 ;
         TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_5);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_4 = 1;
      l_11: 
         HV_6 = HV_5 + HV_3;
         HV_7 = HV_6 - 1;
      TCDSetPS (pMyPar, 1, 99, &HV_9, &HV_8, HV_7);
         rc = TCD3FE1 (pMyPar, 4, "F_px", 246, 246, &HV_10);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 99, &HV_9, &HV_8, HV_7);
         HV_11 = HV_10 * HV_11;
      }
      HV_2 = HV_11;
      goto l_3 ;
   l_63: 
      HV_12 = 1;
      HV_2 = HV_12;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT235","End F_pn",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_pn", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_pn", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_pn");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT239
   Beschreibung: Die Funktion berechnet die Formel 
                 F_vn
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT239 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT239","Begin F_vn",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,239,"12.12.2019 17:29:46",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT239",
              "Ende F_vn",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_v", 243, 243, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
      if ( HV_3 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_Period", 57, 405, 1, 145, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_8: 
      HV_5 = TCDEXP ( HV_2, HV_4 ) ;
      HV_0 = HV_5;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT239","End F_vn",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_vn", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_vn", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_vn");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT241
   Beschreibung: Die Funktion berechnet die Formel 
                 F_qx
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT241 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_11 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_14 = 0;
      TCD_INT     HV_15 = 0;
      TCD_INT     HV_17 = 0;
      P_TCDTAB2   HV_12;
      P_TCDTAB2   HV_16;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT241","Begin F_qx",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,241,"12.12.2019 17:29:45",
                       10);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT241",
              "Ende F_qx",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_5 = 0;
      HV_7 = 0;
      HV_11 = 0;
      HV_15 = 0;
      HV_17 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
      HV_14 = (TCD_INT) ( HV_2) ;
      if ( HV_5 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_6);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_5 = 1;
   l_8: 
      HV_9 = (TCD_INT) ( HV_6) ;
      if ( HV_7 != 0 ) goto l_11 ;
      rc = TCD3FE1 (pMyPar, 2, "_Offset_Mortality", 641, 641, &HV_8);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_7 = 1;
   l_11: 
      HV_10 = (TCD_INT) ( HV_8) ;
      if ( HV_3 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_Offset", 12, 261, 1, 100, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_14: 
      if ( HV_11 != 0 ) goto l_17 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_12);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_11 = 1;
   l_17: 
      if ( HV_10 < 0 || HV_10 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
         1) { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_9 < 0 || HV_9 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_13 = (TCD_INT) ( HV_4 + HV_12 [ HV_9 * 110 + HV_10 ] ) ;
      if ( HV_17 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_ModifiedQx_IP1", 45, 385, 1, 133, &HV_18);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_17 = 1;
   l_20: 
      HV_19 = 1 + HV_18;
      if ( HV_15 != 0 ) goto l_23 ;
      TCD3FET (pMyPar, "MortalityTab", 3, 395, 8,  (P_TCDTAB *)
         &HV_16);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_15 = 1;
   l_23: 
      if ( HV_13 < 0 || HV_13 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
         1) { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_14 < 0 || HV_14 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_20 = HV_16 [ HV_14 * 110 + HV_13 ]  * HV_19;
      HV_0 = HV_20;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT241","End F_qx",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_qx", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_qx", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_qx");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT243
   Beschreibung: Die Funktion berechnet die Formel 
                 F_v
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT243 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT243","Begin F_v",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,243,"12.12.2019 17:29:45",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT243",
              "Ende F_v",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_InterestRate", 63, 417, 1, 151, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
      HV_3 = 1 + HV_2;
   if ( HV_3 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_4 = 1.0 / HV_3;
      HV_0 = HV_4;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT243","End F_v",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_v", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_v", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_v");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT246
   Beschreibung: Die Funktion berechnet die Formel 
                 F_px
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT246 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT246","Begin F_px",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,246,"12.12.2019 17:29:45",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT246",
              "Ende F_px",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_qx", 241, 241, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
      HV_3 = 1 - HV_2;
      HV_0 = HV_3;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT246","End F_px",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_px", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_px", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_px");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT257
   Beschreibung: Die Funktion berechnet die Formel 
                 F_ej
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT257 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_12 = 0;
      P_TCDTAB2   HV_7;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_14 = 0;
      TCD_INT     HV_15 = 1;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT257","Begin F_ej",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,257,"12.12.2019 17:29:45",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_8);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT257",
              "Ende F_ej",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_6 = 0;
      HV_10 = 0;
      HV_12 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_5: 
      HV_4 = (TCD_INT) ( HV_1) ;
      if ( HV_2 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_ej", 474, 474, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_8: 
      HV_5 = (TCD_INT) ( HV_3) ;
      if ( HV_6 != 0 ) goto l_11 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_11: 
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_4 < 0 || HV_4 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_7 [ HV_4 * 110 + HV_5 ]  == 0 ) goto l_24 ;
      goto l_30 ;
   l_24: 
      HV_9 = 0;
      HV_8 = HV_9;
      goto l_3 ;
   l_30: 
      if ( HV_10 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_14: 
      if ( HV_12 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_Period", 57, 405, 1, 145, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_17: 
      if ( HV_11 <  HV_13 ) goto l_42 ;
      goto l_48 ;
   l_42: 
      HV_14 = 0;
      HV_8 = HV_14;
      goto l_3 ;
   l_48: 
      HV_15 = 1;
      HV_8 = HV_15;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_8);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT257","End F_ej",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_ej", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_ej", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_ej");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT258
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Exn
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT258 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_DOUBLE  HV_27 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_15 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_21 = 0;
      TCD_INT     HV_14 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT258","Begin F_Exn",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,258,"12.12.2019 17:29:45",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_13);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT258",
              "Ende F_Exn",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_7 = 0;
      HV_15 = 0;
      HV_12 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
      if ( HV_3 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_8: 
      for ( HV_0 = (TCD_INT) (HV_2) ; HV_0 <= HV_4; HV_0 = HV_0 + 1 )
         {
         if ( HV_7 != 0 ) goto l_11 ;
         rc = TCD3FE1 (pMyPar, 2, "F_n", 364, 364, &HV_8);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_7 = 1;
      l_11: 
      TCDSetPS (pMyPar, 1, 108, &HV_6, &HV_5, HV_0);
      TCDSetPS (pMyPar, 1, 145, &HV_10, &HV_9, HV_8);
         rc = TCD3FE1 (pMyPar, 4, "F_ej", 257, 257, &HV_11);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_10, &HV_9, HV_8);
      TCDSetPS (pMyPar, 0, 108, &HV_6, &HV_5, HV_8);
         HV_12 = HV_11 + HV_12;
      }
      if ( HV_12 == 0 ) goto l_48 ;
      goto l_54 ;
   l_48: 
      HV_14 = 0;
      HV_13 = HV_14;
      goto l_3 ;
   l_54: 
      if ( HV_15 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_16);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_15 = 1;
   l_14: 
      if ( HV_1 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_17: 
      HV_17 = HV_16 + HV_2;
      HV_28 = 0;
      if ( HV_1 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_20: 
      if ( HV_3 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_23: 
      for ( HV_0 = (TCD_INT) (HV_2) ; HV_0 <= HV_4; HV_0 = HV_0 + 1 )
         {
         if ( HV_1 != 0 ) goto l_26 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_2);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_1 = 1;
      l_26: 
         HV_20 = HV_0 - HV_2;
      TCDSetPS (pMyPar, 1, 99, &HV_19, &HV_18, HV_17);
      TCDSetPS (pMyPar, 1, 145, &HV_22, &HV_21, HV_20);
         rc = TCD3FE1 (pMyPar, 4, "F_pn", 235, 235, &HV_23);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_22, &HV_21, HV_20);
      TCDSetPS (pMyPar, 0, 99, &HV_19, &HV_18, HV_20);
         if ( HV_1 != 0 ) goto l_29 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_2);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_1 = 1;
      l_29: 
         HV_20 = HV_0 - HV_2;
      TCDSetPS (pMyPar, 1, 145, &HV_22, &HV_21, HV_20);
         rc = TCD3FE1 (pMyPar, 4, "F_vn", 239, 239, &HV_24);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_22, &HV_21, HV_20);
         HV_25 = HV_23 * HV_24;
         if ( HV_7 != 0 ) goto l_32 ;
         rc = TCD3FE1 (pMyPar, 2, "F_n", 364, 364, &HV_8);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_7 = 1;
      l_32: 
      TCDSetPS (pMyPar, 1, 108, &HV_6, &HV_5, HV_0);
      TCDSetPS (pMyPar, 1, 145, &HV_10, &HV_9, HV_8);
         rc = TCD3FE1 (pMyPar, 4, "F_ej", 257, 257, &HV_26);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_10, &HV_9, HV_8);
      TCDSetPS (pMyPar, 0, 108, &HV_6, &HV_5, HV_8);
         HV_27 = HV_25 * HV_26;
         HV_28 = HV_27 + HV_28;
      }
      HV_13 = HV_28;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_13);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT258","End F_Exn",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Exn", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Exn", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Exn");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT266
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Pxn
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT266 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_16 = 0;
      TCD_INT     HV_19 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_12 = 0;


   /* Generierung der BeschaffungsFlags: */
      int i_i_Costs_IDBeschafft_9 = 0;
   int i_i_Costs_ValBeschafft_10 = 0;


   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT266","Begin F_Pxn",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,266,"12.12.2019 17:29:44",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT266",
              "Ende F_Pxn",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_5 = 0;
      HV_13 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 <  0 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      HV_11 = 0;
      if ( HV_5 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_8: 
      if ( HV_0 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_11: 
      for ( HV_4 = (TCD_INT) (HV_6) ; HV_4 <= HV_1; HV_4 = HV_4 + 1 )
         {
      TCDSetPS (pMyPar, 1, 108, &HV_8, &HV_7, HV_4);
          if ( !i_i_Costs_IDBeschafft_9 &&
          !i_i_Costs_ValBeschafft_10 ) {
            if (pMyPar->pTCDTCD->SSAData.pParSkal[144].Level==0) {
               TCDFtID (pMyPar, "i_Costs", 56, 404, 1, &HV_9);
               if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
                i_i_Costs_IDBeschafft_9 = 1;
            }
            if ( !i_i_Costs_IDBeschafft_9 ) {
               pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = TCD_RC_OK;
               TCD3FES (pMyPar, "i_Costs", 56, 404, 1, 144, &HV_10);
               if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
                i_i_Costs_ValBeschafft_10 = 1;
            }
             if ( !i_i_Costs_IDBeschafft_9 &&
             !i_i_Costs_ValBeschafft_10 ) goto l_ende;
         }
         if (i_i_Costs_IDBeschafft_9) {
            rc = TCD3FE1 (pMyPar, 3, "i_Costs", 404, HV_9, &HV_10);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
               l_ende;
         }
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 108, &HV_8, &HV_7, HV_4);
         HV_11 = HV_10 + HV_11;
      }
      if ( HV_11 == 0 ) goto l_57 ;
      goto l_63 ;
   l_57: 
      HV_12 = 0;
      HV_2 = HV_12;
      goto l_3 ;
   l_63: 
      if ( HV_13 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_14);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_13 = 1;
   l_14: 
      if ( HV_5 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_17: 
      HV_15 = HV_14 + HV_6;
      HV_25 = 0;
      if ( HV_5 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_20: 
      if ( HV_0 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_23: 
      for ( HV_4 = (TCD_INT) (HV_6) ; HV_4 <= HV_1; HV_4 = HV_4 + 1 )
         {
         if ( HV_5 != 0 ) goto l_26 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_6);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_5 = 1;
      l_26: 
         HV_18 = HV_4 - HV_6;
      TCDSetPS (pMyPar, 1, 99, &HV_17, &HV_16, HV_15);
      TCDSetPS (pMyPar, 1, 145, &HV_20, &HV_19, HV_18);
         rc = TCD3FE1 (pMyPar, 4, "F_pn", 235, 235, &HV_21);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_20, &HV_19, HV_18);
      TCDSetPS (pMyPar, 0, 99, &HV_17, &HV_16, HV_18);
         if ( HV_5 != 0 ) goto l_29 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_6);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_5 = 1;
      l_29: 
         HV_18 = HV_4 - HV_6;
      TCDSetPS (pMyPar, 1, 145, &HV_20, &HV_19, HV_18);
         rc = TCD3FE1 (pMyPar, 4, "F_vn", 239, 239, &HV_22);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_20, &HV_19, HV_18);
         HV_23 = HV_21 * HV_22;
      TCDSetPS (pMyPar, 1, 108, &HV_8, &HV_7, HV_4);
          if ( !i_i_Costs_IDBeschafft_9 &&
          !i_i_Costs_ValBeschafft_10 ) {
            if (pMyPar->pTCDTCD->SSAData.pParSkal[144].Level==0) {
               TCDFtID (pMyPar, "i_Costs", 56, 404, 1, &HV_9);
               if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
                i_i_Costs_IDBeschafft_9 = 1;
            }
            if ( !i_i_Costs_IDBeschafft_9 ) {
               pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = TCD_RC_OK;
               TCD3FES (pMyPar, "i_Costs", 56, 404, 1, 144, &HV_10);
               if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
                i_i_Costs_ValBeschafft_10 = 1;
            }
             if ( !i_i_Costs_IDBeschafft_9 &&
             !i_i_Costs_ValBeschafft_10 ) goto l_ende;
         }
         if (i_i_Costs_IDBeschafft_9) {
            rc = TCD3FE1 (pMyPar, 3, "i_Costs", 404, HV_9, &HV_10);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
               l_ende;
         }
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 108, &HV_8, &HV_7, HV_4);
         HV_24 = HV_23 * HV_10;
         HV_25 = HV_24 + HV_25;
      }
      HV_2 = HV_25;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT266","End F_Pxn",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Pxn", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Pxn", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Pxn");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT268
   Beschreibung: Die Funktion berechnet die Formel 
                 F_prj
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT268 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_5 = 1;
      TCD_INT     HV_6 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT268","Begin F_prj",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,268,"12.12.2019 17:29:44",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_4);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT268",
              "Ende F_prj",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_2 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_m", 4, 166, 1, 92, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_8: 
      if ( HV_1 <  HV_3 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_5 = 1;
      HV_4 = HV_5;
      goto l_3 ;
   l_24: 
      HV_6 = 0;
      HV_4 = HV_6;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_4);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT268","End F_prj",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_prj", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_prj", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_prj");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT272
   Beschreibung: Die Funktion berechnet die Formel 
                 F_a1j
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT272 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_DOUBLE  HV_29 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_14 = 0;
      TCD_INT     HV_16 = 0;
      TCD_INT     HV_20 = 0;
      TCD_INT     HV_24 = 0;
      TCD_INT     HV_27 = 0;
      TCD_INT     HV_31 = 0;
      P_TCDTAB2   HV_7;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_30 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT272","Begin F_a1j",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,272,"12.12.2019 17:29:43",
                       7);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_8);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT272",
              "Ende F_a1j",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_6 = 0;
      HV_10 = 0;
      HV_12 = 0;
      HV_14 = 0;
      HV_16 = 0;
      HV_20 = 0;
      HV_27 = 0;
      HV_31 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_5: 
      HV_4 = (TCD_INT) ( HV_1) ;
      if ( HV_2 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_aj1", 447, 447, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_8: 
      HV_5 = (TCD_INT) ( HV_3) ;
      if ( HV_6 != 0 ) goto l_11 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_11: 
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_4 < 0 || HV_4 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_7 [ HV_4 * 110 + HV_5 ]  == 0 ) goto l_24 ;
      goto l_30 ;
   l_24: 
      HV_9 = 0;
      HV_8 = HV_9;
      goto l_3 ;
   l_30: 
      if ( HV_10 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_14: 
      if ( HV_12 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_Period", 57, 405, 1, 145, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_17: 
      if ( HV_11 <  HV_13 ) goto l_42 ;
      goto l_129 ;
   l_42: 
      if ( HV_14 != 0 ) goto l_20 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Has_Decrea_SumIns", 600, 600,
         &HV_15);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_14 = 1;
   l_20: 
      if ( HV_15 == 1 ) goto l_54 ;
      goto l_72 ;
   l_54: 
      if ( HV_31 != 0 ) goto l_64 ;
      if ( HV_10 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_23: 
      if ( HV_16 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_17);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_16 = 1;
   l_26: 
   if ( HV_17 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_18 = HV_11 / HV_17;
      HV_31 = 1;
   l_64: 
      HV_19 = 1 - HV_18;
      HV_8 = HV_19;
      goto l_3 ;
   l_72: 
      if ( HV_20 != 0 ) goto l_29 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Is_TermFix", 598, 598, &HV_21);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_20 = 1;
   l_29: 
      if ( HV_21 == 1 ) goto l_84 ;
      goto l_111 ;
   l_84: 
      if ( HV_16 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_17);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_16 = 1;
   l_32: 
      if ( HV_10 != 0 ) goto l_35 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_35: 
      HV_22 = HV_17 - HV_11;
      HV_23 = HV_22 - 1;
   TCDSetPS (pMyPar, 1, 145, &HV_25, &HV_24, HV_23);
      rc = TCD3FE1 (pMyPar, 4, "F_vn", 239, 239, &HV_26);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 145, &HV_25, &HV_24, HV_23);
      HV_8 = HV_26;
      goto l_3 ;
   l_111: 
      if ( HV_31 != 0 ) goto l_118 ;
      if ( HV_10 != 0 ) goto l_38 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_38: 
      if ( HV_16 != 0 ) goto l_41 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_17);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_16 = 1;
   l_41: 
   if ( HV_17 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_18 = HV_11 / HV_17;
      HV_31 = 1;
   l_118: 
      if ( HV_27 != 0 ) goto l_44 ;
      rc = TCD3FE1 (pMyPar, 2, "F_DeathFactor", 697, 697, &HV_28);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_27 = 1;
   l_44: 
      HV_29 = TCDMAX ( HV_18, HV_28 ) ;
      HV_8 = HV_29;
      goto l_3 ;
   l_129: 
      HV_30 = 0;
      HV_8 = HV_30;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_8);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT272","End F_a1j",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_a1j", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_a1j", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_a1j");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT273
   Beschreibung: Die Funktion berechnet die Formel 
                 F_A3xn
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT273 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_12 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT273","Begin F_A3xn",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,273,"12.12.2019 17:29:43",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_11);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT273",
              "Ende F_A3xn",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_10 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
      if ( HV_3 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_8: 
      for ( HV_0 = (TCD_INT) (HV_2) ; HV_0 <= HV_4; HV_0 = HV_0 + 1 )
         {
         if ( HV_3 != 0 ) goto l_11 ;
         TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_11: 
      TCDSetPS (pMyPar, 1, 108, &HV_6, &HV_5, HV_0);
      TCDSetPS (pMyPar, 1, 145, &HV_8, &HV_7, HV_4);
         rc = TCD3FE1 (pMyPar, 4, "F_a3j", 277, 277, &HV_9);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_8, &HV_7, HV_4);
      TCDSetPS (pMyPar, 0, 108, &HV_6, &HV_5, HV_4);
         HV_10 = HV_9 + HV_10;
      }
      if ( HV_10 == 0 ) goto l_48 ;
      goto l_54 ;
   l_48: 
      HV_12 = 0;
      HV_11 = HV_12;
      goto l_3 ;
   l_54: 
      HV_16 = 0;
      if ( HV_1 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_14: 
      if ( HV_3 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_17: 
      for ( HV_0 = (TCD_INT) (HV_2) ; HV_0 <= HV_4; HV_0 = HV_0 + 1 )
         {
         if ( HV_3 != 0 ) goto l_20 ;
         TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_20: 
      TCDSetPS (pMyPar, 1, 108, &HV_6, &HV_5, HV_0);
      TCDSetPS (pMyPar, 1, 145, &HV_8, &HV_7, HV_4);
         rc = TCD3FE1 (pMyPar, 4, "F_Axn", 274, 274, &HV_13);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_8, &HV_7, HV_4);
      TCDSetPS (pMyPar, 0, 108, &HV_6, &HV_5, HV_4);
         if ( HV_3 != 0 ) goto l_23 ;
         TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_23: 
      TCDSetPS (pMyPar, 1, 108, &HV_6, &HV_5, HV_0);
      TCDSetPS (pMyPar, 1, 145, &HV_8, &HV_7, HV_4);
         rc = TCD3FE1 (pMyPar, 4, "F_a3j", 277, 277, &HV_14);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_8, &HV_7, HV_4);
      TCDSetPS (pMyPar, 0, 108, &HV_6, &HV_5, HV_4);
         HV_15 = HV_13 * HV_14;
         HV_16 = HV_15 + HV_16;
      }
      HV_11 = HV_16;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_11);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT273","End F_A3xn",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_A3xn", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_A3xn", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_A3xn");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT274
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Axn
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT274 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_11 = 0;
      TCD_INT     HV_15 = 0;
      TCD_INT     HV_21 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT274","Begin F_Axn",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,274,"12.12.2019 17:29:43",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT274",
              "Ende F_Axn",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_8 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
      if ( HV_3 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_8: 
      HV_5 = HV_2 + HV_4;
      if ( HV_8 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_9);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_8 = 1;
   l_11: 
      if ( HV_3 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_14: 
      HV_10 = HV_9 - HV_4;
   TCDSetPS (pMyPar, 1, 99, &HV_7, &HV_6, HV_5);
   TCDSetPS (pMyPar, 1, 145, &HV_12, &HV_11, HV_10);
      rc = TCD3FE1 (pMyPar, 4, "F_pn", 235, 235, &HV_13);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 145, &HV_12, &HV_11, HV_10);
   TCDSetPS (pMyPar, 0, 99, &HV_7, &HV_6, HV_10);
      if ( HV_1 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_17: 
      if ( HV_8 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_9);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_8 = 1;
   l_20: 
      HV_14 = HV_2 + HV_9;
   TCDSetPS (pMyPar, 1, 99, &HV_16, &HV_15, HV_14);
      rc = TCD3FE1 (pMyPar, 4, "F_qx", 241, 241, &HV_17);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 99, &HV_16, &HV_15, HV_14);
      HV_18 = HV_13 * HV_17;
      if ( HV_8 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_9);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_8 = 1;
   l_23: 
      if ( HV_3 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_26: 
      HV_19 = HV_9 - HV_4;
      HV_20 = HV_19 + 1;
   TCDSetPS (pMyPar, 1, 145, &HV_22, &HV_21, HV_20);
      rc = TCD3FE1 (pMyPar, 4, "F_vn", 239, 239, &HV_23);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 145, &HV_22, &HV_21, HV_20);
      HV_24 = HV_18 * HV_23;
      HV_0 = HV_24;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT274","End F_Axn",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Axn", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Axn", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Axn");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT275
   Beschreibung: Die Funktion berechnet die Formel 
                 F_A2xn_sub
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT275 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_12 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT275","Begin F_A2xn_sub",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,275,"12.12.2019 17:29:42",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_11);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT275",
              "Ende F_A2xn_sub",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_10 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
      if ( HV_3 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_8: 
      for ( HV_0 = (TCD_INT) (HV_2) ; HV_0 <= HV_4; HV_0 = HV_0 + 1 )
         {
         if ( HV_3 != 0 ) goto l_11 ;
         TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_11: 
      TCDSetPS (pMyPar, 1, 108, &HV_6, &HV_5, HV_0);
      TCDSetPS (pMyPar, 1, 145, &HV_8, &HV_7, HV_4);
         rc = TCD3FE1 (pMyPar, 4, "F_a2j_sub", 279, 279, &HV_9);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_8, &HV_7, HV_4);
      TCDSetPS (pMyPar, 0, 108, &HV_6, &HV_5, HV_4);
         HV_10 = HV_9 + HV_10;
      }
      if ( HV_10 == 0 ) goto l_48 ;
      goto l_54 ;
   l_48: 
      HV_12 = 0;
      HV_11 = HV_12;
      goto l_3 ;
   l_54: 
      HV_16 = 0;
      if ( HV_1 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_14: 
      if ( HV_3 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_17: 
      for ( HV_0 = (TCD_INT) (HV_2) ; HV_0 <= HV_4; HV_0 = HV_0 + 1 )
         {
         if ( HV_3 != 0 ) goto l_20 ;
         TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_20: 
      TCDSetPS (pMyPar, 1, 108, &HV_6, &HV_5, HV_0);
      TCDSetPS (pMyPar, 1, 145, &HV_8, &HV_7, HV_4);
         rc = TCD3FE1 (pMyPar, 4, "F_Axn", 274, 274, &HV_13);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_8, &HV_7, HV_4);
      TCDSetPS (pMyPar, 0, 108, &HV_6, &HV_5, HV_4);
         if ( HV_3 != 0 ) goto l_23 ;
         TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_23: 
      TCDSetPS (pMyPar, 1, 108, &HV_6, &HV_5, HV_0);
      TCDSetPS (pMyPar, 1, 145, &HV_8, &HV_7, HV_4);
         rc = TCD3FE1 (pMyPar, 4, "F_a2j_sub", 279, 279, &HV_14);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_8, &HV_7, HV_4);
      TCDSetPS (pMyPar, 0, 108, &HV_6, &HV_5, HV_4);
         HV_15 = HV_13 * HV_14;
         HV_16 = HV_15 + HV_16;
      }
      HV_11 = HV_16;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_11);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT275","End F_A2xn_sub",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_A2xn_sub", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_A2xn_sub", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_A2xn_sub");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT276
   Beschreibung: Die Funktion berechnet die Formel 
                 F_A3xn_sub
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT276 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT276","Begin F_A3xn_sub",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,276,"12.12.2019 17:29:42",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT276",
              "Ende F_A3xn_sub",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_A2xn_sub", 275, 275, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
      HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT276","End F_A3xn_sub",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_A3xn_sub", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_A3xn_sub", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_A3xn_sub");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT277
   Beschreibung: Die Funktion berechnet die Formel 
                 F_a3j
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT277 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_14 = 0;
      TCD_INT     HV_16 = 0;
      TCD_INT     HV_20 = 0;
      TCD_INT     HV_24 = 0;
      P_TCDTAB2   HV_7;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_27 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT277","Begin F_a3j",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,277,"12.12.2019 17:29:42",
                       5);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_8);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT277",
              "Ende F_a3j",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_6 = 0;
      HV_10 = 0;
      HV_12 = 0;
      HV_14 = 0;
      HV_16 = 0;
      HV_24 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_5: 
      HV_4 = (TCD_INT) ( HV_1) ;
      if ( HV_2 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_aj3", 467, 467, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_8: 
      HV_5 = (TCD_INT) ( HV_3) ;
      if ( HV_6 != 0 ) goto l_11 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_11: 
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_4 < 0 || HV_4 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_7 [ HV_4 * 110 + HV_5 ]  == 0 ) goto l_24 ;
      goto l_30 ;
   l_24: 
      HV_9 = 0;
      HV_8 = HV_9;
      goto l_3 ;
   l_30: 
      if ( HV_10 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_14: 
      if ( HV_12 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_Period", 57, 405, 1, 145, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_17: 
      if ( HV_11 <  HV_13 ) goto l_42 ;
      goto l_99 ;
   l_42: 
      if ( HV_14 != 0 ) goto l_20 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Is_TermFix", 598, 598, &HV_15);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_14 = 1;
   l_20: 
      if ( HV_15 == 1 ) goto l_54 ;
      goto l_81 ;
   l_54: 
      if ( HV_16 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_17);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_16 = 1;
   l_23: 
      if ( HV_10 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_26: 
      HV_18 = HV_17 - HV_11;
      HV_19 = HV_18 - 1;
   TCDSetPS (pMyPar, 1, 145, &HV_21, &HV_20, HV_19);
      rc = TCD3FE1 (pMyPar, 4, "F_vn", 239, 239, &HV_22);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 145, &HV_21, &HV_20, HV_19);
      HV_8 = HV_22;
      goto l_3 ;
   l_81: 
      if ( HV_10 != 0 ) goto l_29 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_29: 
      if ( HV_16 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_17);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_16 = 1;
   l_32: 
   if ( HV_17 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_23 = HV_11 / HV_17;
      if ( HV_24 != 0 ) goto l_35 ;
      rc = TCD3FE1 (pMyPar, 2, "F_DeathFactor", 697, 697, &HV_25);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_24 = 1;
   l_35: 
      HV_26 = TCDMAX ( HV_23, HV_25 ) ;
      HV_8 = HV_26;
      goto l_3 ;
   l_99: 
      HV_27 = 0;
      HV_8 = HV_27;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_8);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT277","End F_a3j",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_a3j", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_a3j", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_a3j");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT278
   Beschreibung: Die Funktion berechnet die Formel 
                 F_a2j
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT278 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_15 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_21 = 0;
      P_TCDTAB2   HV_7;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_14 = 0;
      TCD_INT     HV_25 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT278","Begin F_a2j",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,278,"12.12.2019 17:29:42",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_8);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT278",
              "Ende F_a2j",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_6 = 0;
      HV_10 = 0;
      HV_12 = 0;
      HV_15 = 0;
      HV_18 = 0;
      HV_21 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_5: 
      HV_4 = (TCD_INT) ( HV_1) ;
      if ( HV_2 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_aj2", 424, 424, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_8: 
      HV_5 = (TCD_INT) ( HV_3) ;
      if ( HV_6 != 0 ) goto l_11 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_11: 
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_4 < 0 || HV_4 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_7 [ HV_4 * 110 + HV_5 ]  == 0 ) goto l_24 ;
      goto l_30 ;
   l_24: 
      HV_9 = 0;
      HV_8 = HV_9;
      goto l_3 ;
   l_30: 
      if ( HV_10 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "F_PremiumRefundUntil", 699, 699,
         &HV_11);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_10 = 1;
   l_14: 
      if ( HV_11 > 0 ) goto l_45 ;
      goto l_60 ;
   l_45: 
      if ( HV_12 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_17: 
      if ( HV_10 != 0 ) goto l_20 ;
      rc = TCD3FE1 (pMyPar, 2, "F_PremiumRefundUntil", 699, 699,
         &HV_11);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_10 = 1;
   l_20: 
      if ( HV_13 >= HV_11 ) goto l_54 ;
      goto l_60 ;
   l_54: 
      HV_14 = 0;
      HV_8 = HV_14;
      goto l_3 ;
   l_60: 
      if ( HV_12 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_23: 
      if ( HV_15 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_m", 4, 166, 1, 92, &HV_16);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_15 = 1;
   l_26: 
      if ( HV_13 <  HV_16 ) goto l_72 ;
      goto l_90 ;
   l_72: 
      if ( HV_12 != 0 ) goto l_29 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_29: 
      HV_17 = HV_13 + 1;
      if ( HV_18 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_19);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_18 = 1;
   l_32: 
      HV_20 = HV_17 - HV_19;
      HV_8 = HV_20;
      goto l_3 ;
   l_90: 
      if ( HV_12 != 0 ) goto l_35 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_35: 
      if ( HV_21 != 0 ) goto l_38 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_22);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_21 = 1;
   l_38: 
      if ( HV_13 <  HV_22 ) goto l_102 ;
      goto l_120 ;
   l_102: 
      if ( HV_15 != 0 ) goto l_41 ;
      TCD3FES (pMyPar, "i_m", 4, 166, 1, 92, &HV_16);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_15 = 1;
   l_41: 
      if ( HV_18 != 0 ) goto l_44 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_19);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_18 = 1;
   l_44: 
      HV_23 = HV_16 - HV_19;
      HV_24 = TCDMAX ( 0, HV_23 ) ;
      HV_8 = HV_24;
      goto l_3 ;
   l_120: 
      HV_25 = 0;
      HV_8 = HV_25;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_8);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT278","End F_a2j",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_a2j", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_a2j", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_a2j");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT279
   Beschreibung: Die Funktion berechnet die Formel 
                 F_a2j_sub
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT279 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_14 = 0;
      P_TCDTAB2   HV_7;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_16 = 0;
      TCD_INT     HV_17 = 1;
      TCD_INT     HV_18 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT279","Begin F_a2j_sub",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,279,"12.12.2019 17:29:42",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_8);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT279",
              "Ende F_a2j_sub",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_6 = 0;
      HV_10 = 0;
      HV_12 = 0;
      HV_14 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_5: 
      HV_4 = (TCD_INT) ( HV_1) ;
      if ( HV_2 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_aj2", 424, 424, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_8: 
      HV_5 = (TCD_INT) ( HV_3) ;
      if ( HV_6 != 0 ) goto l_11 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_11: 
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_4 < 0 || HV_4 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_7 [ HV_4 * 110 + HV_5 ]  == 0 ) goto l_24 ;
      goto l_30 ;
   l_24: 
      HV_9 = 0;
      HV_8 = HV_9;
      goto l_3 ;
   l_30: 
      if ( HV_10 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_14: 
      if ( HV_12 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_17: 
      if ( HV_11 <  HV_13 ) goto l_42 ;
      goto l_78 ;
   l_42: 
      if ( HV_14 != 0 ) goto l_20 ;
      rc = TCD3FE1 (pMyPar, 2, "F_PremiumRefundUntil", 699, 699,
         &HV_15);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_14 = 1;
   l_20: 
      if ( HV_15 > 0 ) goto l_57 ;
      goto l_72 ;
   l_57: 
      if ( HV_10 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_23: 
      if ( HV_14 != 0 ) goto l_26 ;
      rc = TCD3FE1 (pMyPar, 2, "F_PremiumRefundUntil", 699, 699,
         &HV_15);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_14 = 1;
   l_26: 
      if ( HV_11 >= HV_15 ) goto l_66 ;
      goto l_72 ;
   l_66: 
      HV_16 = 0;
      HV_8 = HV_16;
      goto l_3 ;
   l_72: 
      HV_17 = 1;
      HV_8 = HV_17;
      goto l_3 ;
   l_78: 
      HV_18 = 0;
      HV_8 = HV_18;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_8);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT279","End F_a2j_sub",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_a2j_sub", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_a2j_sub", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_a2j_sub");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT280
   Beschreibung: Die Funktion berechnet die Formel 
                 F_A1xn
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT280 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_12 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT280","Begin F_A1xn",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,280,"12.12.2019 17:29:42",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_11);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT280",
              "Ende F_A1xn",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_10 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
      if ( HV_3 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_8: 
      for ( HV_0 = (TCD_INT) (HV_2) ; HV_0 <= HV_4; HV_0 = HV_0 + 1 )
         {
         if ( HV_3 != 0 ) goto l_11 ;
         TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_11: 
      TCDSetPS (pMyPar, 1, 108, &HV_6, &HV_5, HV_0);
      TCDSetPS (pMyPar, 1, 145, &HV_8, &HV_7, HV_4);
         rc = TCD3FE1 (pMyPar, 4, "F_a1j", 272, 272, &HV_9);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_8, &HV_7, HV_4);
      TCDSetPS (pMyPar, 0, 108, &HV_6, &HV_5, HV_4);
         HV_10 = HV_9 + HV_10;
      }
      if ( HV_10 == 0 ) goto l_48 ;
      goto l_54 ;
   l_48: 
      HV_12 = 0;
      HV_11 = HV_12;
      goto l_3 ;
   l_54: 
      HV_16 = 0;
      if ( HV_1 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_14: 
      if ( HV_3 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_17: 
      for ( HV_0 = (TCD_INT) (HV_2) ; HV_0 <= HV_4; HV_0 = HV_0 + 1 )
         {
         if ( HV_3 != 0 ) goto l_20 ;
         TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_20: 
      TCDSetPS (pMyPar, 1, 108, &HV_6, &HV_5, HV_0);
      TCDSetPS (pMyPar, 1, 145, &HV_8, &HV_7, HV_4);
         rc = TCD3FE1 (pMyPar, 4, "F_Axn", 274, 274, &HV_13);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_8, &HV_7, HV_4);
      TCDSetPS (pMyPar, 0, 108, &HV_6, &HV_5, HV_4);
         if ( HV_3 != 0 ) goto l_23 ;
         TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_23: 
      TCDSetPS (pMyPar, 1, 108, &HV_6, &HV_5, HV_0);
      TCDSetPS (pMyPar, 1, 145, &HV_8, &HV_7, HV_4);
         rc = TCD3FE1 (pMyPar, 4, "F_a1j", 272, 272, &HV_14);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_8, &HV_7, HV_4);
      TCDSetPS (pMyPar, 0, 108, &HV_6, &HV_5, HV_4);
         HV_15 = HV_13 * HV_14;
         HV_16 = HV_15 + HV_16;
      }
      HV_11 = HV_16;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_11);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT280","End F_A1xn",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_A1xn", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_A1xn", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_A1xn");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT281
   Beschreibung: Die Funktion berechnet die Formel 
                 F_A2xn
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT281 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_12 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT281","Begin F_A2xn",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,281,"12.12.2019 17:29:41",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_11);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT281",
              "Ende F_A2xn",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_10 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
      if ( HV_3 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_8: 
      for ( HV_0 = (TCD_INT) (HV_2) ; HV_0 <= HV_4; HV_0 = HV_0 + 1 )
         {
         if ( HV_3 != 0 ) goto l_11 ;
         TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_11: 
      TCDSetPS (pMyPar, 1, 108, &HV_6, &HV_5, HV_0);
      TCDSetPS (pMyPar, 1, 145, &HV_8, &HV_7, HV_4);
         rc = TCD3FE1 (pMyPar, 4, "F_a2j", 278, 278, &HV_9);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_8, &HV_7, HV_4);
      TCDSetPS (pMyPar, 0, 108, &HV_6, &HV_5, HV_4);
         HV_10 = HV_9 + HV_10;
      }
      if ( HV_10 == 0 ) goto l_48 ;
      goto l_54 ;
   l_48: 
      HV_12 = 0;
      HV_11 = HV_12;
      goto l_3 ;
   l_54: 
      HV_16 = 0;
      if ( HV_1 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_14: 
      if ( HV_3 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_17: 
      for ( HV_0 = (TCD_INT) (HV_2) ; HV_0 <= HV_4; HV_0 = HV_0 + 1 )
         {
         if ( HV_3 != 0 ) goto l_20 ;
         TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_20: 
      TCDSetPS (pMyPar, 1, 108, &HV_6, &HV_5, HV_0);
      TCDSetPS (pMyPar, 1, 145, &HV_8, &HV_7, HV_4);
         rc = TCD3FE1 (pMyPar, 4, "F_Axn", 274, 274, &HV_13);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_8, &HV_7, HV_4);
      TCDSetPS (pMyPar, 0, 108, &HV_6, &HV_5, HV_4);
         if ( HV_3 != 0 ) goto l_23 ;
         TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_23: 
      TCDSetPS (pMyPar, 1, 108, &HV_6, &HV_5, HV_0);
      TCDSetPS (pMyPar, 1, 145, &HV_8, &HV_7, HV_4);
         rc = TCD3FE1 (pMyPar, 4, "F_a2j", 278, 278, &HV_14);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_8, &HV_7, HV_4);
      TCDSetPS (pMyPar, 0, 108, &HV_6, &HV_5, HV_4);
         HV_15 = HV_13 * HV_14;
         HV_16 = HV_15 + HV_16;
      }
      HV_11 = HV_16;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_11);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT281","End F_A2xn",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_A2xn", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_A2xn", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_A2xn");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT296
   Beschreibung: Die Funktion berechnet die Formel 
                 F_egj
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT296 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_5 = 1;
      TCD_INT     HV_6 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT296","Begin F_egj",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,296,"12.12.2019 17:29:39",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_4);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT296",
              "Ende F_egj",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 >= 0 ) goto l_21 ;
      goto l_36 ;
   l_21: 
      if ( HV_0 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_8: 
      if ( HV_2 != 0 ) goto l_11 ;
      rc = TCD3FE1 (pMyPar, 2, "F_guaranteePeriod", 693, 693, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_11: 
      if ( HV_1 <  HV_3 ) goto l_30 ;
      goto l_36 ;
   l_30: 
      HV_5 = 1;
      HV_4 = HV_5;
      goto l_3 ;
   l_36: 
      HV_6 = 0;
      HV_4 = HV_6;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_4);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT296","End F_egj",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_egj", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_egj", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_egj");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT299
   Beschreibung: Die Funktion berechnet die Formel 
                 F_aeR
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT299 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_DOUBLE  HV_27 = 0;
      TCD_DOUBLE  HV_29 = 0;
      TCD_DOUBLE  HV_31 = 0;
      TCD_DOUBLE  HV_32 = 0;
      TCD_DOUBLE  HV_33 = 0;
      TCD_DOUBLE  HV_35 = 0;
      TCD_DOUBLE  HV_36 = 0;
      TCD_DOUBLE  HV_37 = 0;
      TCD_DOUBLE  HV_38 = 0;
      TCD_DOUBLE  HV_40 = 0;
      TCD_DOUBLE  HV_41 = 0;
      TCD_DOUBLE  HV_42 = 0;
      TCD_DOUBLE  HV_43 = 0;
      TCD_DOUBLE  HV_45 = 0;
      TCD_DOUBLE  HV_46 = 0;
      TCD_DOUBLE  HV_48 = 0;
      TCD_DOUBLE  HV_49 = 0;
      TCD_DOUBLE  HV_50 = 0;
      TCD_DOUBLE  HV_52 = 0;
      TCD_DOUBLE  HV_53 = 0;
      TCD_DOUBLE  HV_54 = 0;
      TCD_DOUBLE  HV_55 = 0;
      TCD_DOUBLE  HV_56 = 0;
      TCD_DOUBLE  HV_57 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_16 = 0;
      TCD_INT     HV_20 = 0;
      TCD_INT     HV_25 = 0;
      TCD_INT     HV_28 = 0;
      TCD_INT     HV_30 = 0;
      TCD_INT     HV_34 = 0;
      TCD_INT     HV_39 = 0;
      TCD_INT     HV_44 = 0;
      TCD_INT     HV_47 = 0;
      TCD_INT     HV_51 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT299","Begin F_aeR",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,299,"12.12.2019 17:29:39",
                       4);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT299",
              "Ende F_aeR",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_2 = 0;
      HV_4 = 0;
      HV_6 = 0;
      HV_25 = 0;
      HV_30 = 0;
      if ( HV_6 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_pa", 9, 222, 1, 97, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_5: 
      if ( HV_2 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_8: 
      HV_8 = HV_7 + HV_3;
      HV_24 = 0;
      if ( HV_2 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_11: 
      if ( HV_4 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AnnuityPeriod", 695, 695, &HV_5);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_4 = 1;
   l_14: 
      for ( HV_1 = (TCD_INT) (HV_3) ; HV_1 <= HV_5; HV_1 = HV_1 + 1 )
         {
         if ( HV_2 != 0 ) goto l_17 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_2 = 1;
      l_17: 
         HV_11 = HV_1 - HV_3;
      TCDSetPS (pMyPar, 1, 99, &HV_10, &HV_9, HV_8);
      TCDSetPS (pMyPar, 1, 145, &HV_13, &HV_12, HV_11);
         rc = TCD3FE1 (pMyPar, 4, "F_pn", 235, 235, &HV_14);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_13, &HV_12, HV_11);
      TCDSetPS (pMyPar, 0, 99, &HV_10, &HV_9, HV_11);
         if ( HV_2 != 0 ) goto l_20 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_2 = 1;
      l_20: 
         HV_15 = HV_1 - HV_3;
      TCDSetPS (pMyPar, 1, 145, &HV_17, &HV_16, HV_15);
         rc = TCD3FE1 (pMyPar, 4, "F_vn", 239, 239, &HV_18);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_17, &HV_16, HV_15);
         HV_19 = HV_14 * HV_18;
      TCDSetPS (pMyPar, 1, 108, &HV_21, &HV_20, HV_1);
         rc = TCD3FE1 (pMyPar, 4, "F_erj", 303, 303, &HV_22);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 108, &HV_21, &HV_20, HV_1);
         HV_23 = HV_19 * HV_22;
         HV_24 = HV_23 + HV_24;
      }
      if ( HV_6 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_pa", 9, 222, 1, 97, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_23: 
      if ( HV_2 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_26: 
      HV_27 = HV_7 + HV_3;
      if ( HV_30 != 0 ) goto l_29 ;
      rc = TCD3FE1 (pMyPar, 2, "F_guaranteePeriod", 693, 693, &HV_31);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_30 = 1;
   l_29: 
      if ( HV_2 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_32: 
      HV_32 = HV_31 - HV_3;
      HV_33 = TCDMAX ( 0, HV_32 ) ;
   TCDSetPS (pMyPar, 1, 99, &HV_29, &HV_28, HV_27);
   TCDSetPS (pMyPar, 1, 145, &HV_35, &HV_34, HV_33);
      rc = TCD3FE1 (pMyPar, 4, "F_pn", 235, 235, &HV_36);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 145, &HV_35, &HV_34, HV_33);
   TCDSetPS (pMyPar, 0, 99, &HV_29, &HV_28, HV_33);
      if ( HV_30 != 0 ) goto l_35 ;
      rc = TCD3FE1 (pMyPar, 2, "F_guaranteePeriod", 693, 693, &HV_31);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_30 = 1;
   l_35: 
      if ( HV_2 != 0 ) goto l_38 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_38: 
      HV_37 = HV_31 - HV_3;
      HV_38 = TCDMAX ( 0, HV_37 ) ;
   TCDSetPS (pMyPar, 1, 145, &HV_40, &HV_39, HV_38);
      rc = TCD3FE1 (pMyPar, 4, "F_vn", 239, 239, &HV_41);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 145, &HV_40, &HV_39, HV_38);
      HV_42 = HV_36 * HV_41;
      if ( HV_6 != 0 ) goto l_41 ;
      TCD3FES (pMyPar, "i_pa", 9, 222, 1, 97, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_41: 
      if ( HV_2 != 0 ) goto l_44 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_44: 
      HV_43 = HV_7 + HV_3;
      if ( HV_4 != 0 ) goto l_47 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AnnuityPeriod", 695, 695, &HV_5);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_4 = 1;
   l_47: 
      if ( HV_2 != 0 ) goto l_50 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_50: 
      HV_46 = HV_5 - HV_3;
   TCDSetPS (pMyPar, 1, 99, &HV_45, &HV_44, HV_43);
   TCDSetPS (pMyPar, 1, 145, &HV_48, &HV_47, HV_46);
      rc = TCD3FE1 (pMyPar, 4, "F_pn", 235, 235, &HV_49);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 145, &HV_48, &HV_47, HV_46);
   TCDSetPS (pMyPar, 0, 99, &HV_45, &HV_44, HV_46);
      if ( HV_4 != 0 ) goto l_53 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AnnuityPeriod", 695, 695, &HV_5);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_4 = 1;
   l_53: 
      if ( HV_2 != 0 ) goto l_56 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_56: 
      HV_50 = HV_5 - HV_3;
   TCDSetPS (pMyPar, 1, 145, &HV_52, &HV_51, HV_50);
      rc = TCD3FE1 (pMyPar, 4, "F_vn", 239, 239, &HV_53);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 145, &HV_52, &HV_51, HV_50);
      HV_54 = HV_49 * HV_53;
      HV_55 = HV_42 - HV_54;
      if ( HV_25 != 0 ) goto l_59 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AnnuityPayFreq", 694, 694, &HV_26);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_25 = 1;
   l_59: 
      HV_56 = HV_26 * HV_55;
      HV_57 = HV_24 - HV_56;
      HV_0 = HV_57;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT299","End F_aeR",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_aeR", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_aeR", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_aeR");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT303
   Beschreibung: Die Funktion berechnet die Formel 
                 F_erj
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT303 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_7 = 1;
      TCD_INT     HV_8 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT303","Begin F_erj",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,303,"12.12.2019 17:29:38",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_6);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT303",
              "Ende F_erj",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_4 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_2 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_guaranteePeriod", 693, 693, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_8: 
      if ( HV_1 >= HV_3 ) goto l_21 ;
      goto l_36 ;
   l_21: 
      if ( HV_0 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_11: 
      if ( HV_4 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AnnuityPeriod", 695, 695, &HV_5);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_4 = 1;
   l_14: 
      if ( HV_1 <  HV_5 ) goto l_30 ;
      goto l_36 ;
   l_30: 
      HV_7 = 1;
      HV_6 = HV_7;
      goto l_3 ;
   l_36: 
      HV_8 = 0;
      HV_6 = HV_8;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_6);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT303","End F_erj",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_erj", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_erj", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_erj");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT308
   Beschreibung: Die Funktion berechnet die Formel 
                 F_aeG
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT308 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_15 = 0;
      TCD_INT     HV_17 = 0;
      TCD_INT     HV_21 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT308","Begin F_aeG",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,308,"12.12.2019 17:29:38",
                       4);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT308",
              "Ende F_aeG",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_2 = 0;
      HV_4 = 0;
      HV_15 = 0;
      HV_17 = 0;
      HV_14 = 0;
      if ( HV_2 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_5: 
      if ( HV_4 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AnnuityPeriod", 695, 695, &HV_5);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_4 = 1;
   l_8: 
      for ( HV_1 = (TCD_INT) (HV_3) ; HV_1 <= HV_5; HV_1 = HV_1 + 1 )
         {
         if ( HV_2 != 0 ) goto l_11 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_2 = 1;
      l_11: 
         HV_6 = HV_1 - HV_3;
      TCDSetPS (pMyPar, 1, 145, &HV_8, &HV_7, HV_6);
         rc = TCD3FE1 (pMyPar, 4, "F_vn", 239, 239, &HV_9);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_8, &HV_7, HV_6);
      TCDSetPS (pMyPar, 1, 108, &HV_11, &HV_10, HV_1);
         rc = TCD3FE1 (pMyPar, 4, "F_egj", 296, 296, &HV_12);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 108, &HV_11, &HV_10, HV_1);
         HV_13 = HV_9 * HV_12;
         HV_14 = HV_13 + HV_14;
      }
      if ( HV_17 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "F_guaranteePeriod", 693, 693, &HV_18);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_17 = 1;
   l_14: 
      if ( HV_2 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_17: 
      HV_19 = HV_18 - HV_3;
      HV_20 = TCDMAX ( 0, HV_19 ) ;
   TCDSetPS (pMyPar, 1, 145, &HV_22, &HV_21, HV_20);
      rc = TCD3FE1 (pMyPar, 4, "F_vn", 239, 239, &HV_23);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 145, &HV_22, &HV_21, HV_20);
      HV_24 = 1 - HV_23;
      if ( HV_15 != 0 ) goto l_20 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AnnuityPayFreq", 694, 694, &HV_16);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_15 = 1;
   l_20: 
      HV_25 = HV_16 * HV_24;
      HV_26 = HV_14 - HV_25;
      HV_0 = HV_26;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT308","End F_aeG",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_aeG", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_aeG", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_aeG");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT311
   Beschreibung: Die Funktion berechnet die Formel 
                 F_k_rentezw
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT311 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_10 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT311","Begin F_k_rentezw",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,311,"12.12.2019 17:29:38",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT311",
              "Ende F_k_rentezw",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_3 = 0;
      HV_10 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_advance_arrears", 61, 415, 1, 149, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 0 ) goto l_18 ;
      goto l_42 ;
   l_18: 
      if ( HV_3 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_annuityPayment", 62, 416, 1, 150, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_8: 
      HV_5 = HV_4 - 1;
      if ( HV_10 != 0 ) goto l_34 ;
      if ( HV_3 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_annuityPayment", 62, 416, 1, 150, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_11: 
      HV_6 = 2 * HV_4;
      HV_10 = 1;
   l_34: 
   if ( HV_6 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_7 = HV_5 / HV_6;
      HV_2 = HV_7;
      goto l_3 ;
   l_42: 
      if ( HV_0 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_advance_arrears", 61, 415, 1, 149, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_14: 
      if ( HV_1 == 1 ) goto l_54 ;
      goto l_78 ;
   l_54: 
      if ( HV_3 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_annuityPayment", 62, 416, 1, 150, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_17: 
      HV_8 = HV_4 + 1;
      if ( HV_10 != 0 ) goto l_70 ;
      if ( HV_3 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_annuityPayment", 62, 416, 1, 150, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_20: 
      HV_6 = 2 * HV_4;
      HV_10 = 1;
   l_70: 
   if ( HV_6 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_9 = HV_8 / HV_6;
      HV_2 = HV_9;
      goto l_3 ;
   l_78: 
   pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 900;
   pMyPar->pTCDTCD->pRbsCtl->RCInfo.Errc = 999;
   goto l_ende ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT311","End F_k_rentezw",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_k_rentezw", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_k_rentezw", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_k_rentezw");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT313
   Beschreibung: Die Funktion berechnet die Formel 
                 F_ae_delta
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT313 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT313","Begin F_ae_delta",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,313,"12.12.2019 17:29:38",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT313",
              "Ende F_ae_delta",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      if ( HV_3 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Delta", 504, 504, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_3 = 1;
   l_5: 
      HV_5 = 1 + HV_4;
      if ( HV_1 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_ae", 314, 314, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_8: 
      HV_6 = HV_2 * HV_5;
      HV_0 = HV_6;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT313","End F_ae_delta",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_ae_delta", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_ae_delta", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_ae_delta");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT314
   Beschreibung: Die Funktion berechnet die Formel 
                 F_ae
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT314 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT314","Begin F_ae",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,314,"12.12.2019 17:29:38",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT314",
              "Ende F_ae",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_aeG", 308, 308, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
      if ( HV_3 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_aeR", 299, 299, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_3 = 1;
   l_8: 
      HV_5 = HV_2 + HV_4;
      HV_0 = HV_5;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT314","End F_ae",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_ae", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_ae", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_ae");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT315
   Beschreibung: Die Funktion berechnet die Formel 
                 F_rj
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT315 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_5 = 1;
      TCD_INT     HV_6 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT315","Begin F_rj",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,315,"12.12.2019 17:31:02",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_4);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT315",
              "Ende F_rj",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_2 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_k", 1, 163, 1, 89, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_8: 
      if ( HV_1 <  HV_3 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_5 = 1;
      HV_4 = HV_5;
      goto l_3 ;
   l_24: 
      HV_6 = 0;
      HV_4 = HV_6;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_4);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT315","End F_rj",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_rj", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_rj", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_rj");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT316
   Beschreibung: Die Funktion berechnet die Formel 
                 F_aePV
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT316 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_5 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT316","Begin F_aePV",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,316,"12.12.2019 17:31:02",
                       4);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_4);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT316",
              "Ende F_aePV",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_7 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_2 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_k", 1, 163, 1, 89, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_8: 
      if ( HV_1 >= HV_3 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_5 = 0;
      HV_4 = HV_5;
      goto l_3 ;
   l_24: 
      if ( HV_7 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_11: 
      if ( HV_0 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_14: 
      HV_9 = HV_8 + HV_1;
      HV_22 = 0;
      if ( HV_0 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_17: 
      if ( HV_2 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_k", 1, 163, 1, 89, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_20: 
      for ( HV_6 = (TCD_INT) (HV_1) ; HV_6 <= HV_3; HV_6 = HV_6 + 1 )
         {
         if ( HV_0 != 0 ) goto l_23 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_0 = 1;
      l_23: 
         HV_12 = HV_6 - HV_1;
      TCDSetPS (pMyPar, 1, 99, &HV_11, &HV_10, HV_9);
      TCDSetPS (pMyPar, 1, 145, &HV_14, &HV_13, HV_12);
         rc = TCD3FE1 (pMyPar, 4, "F_pn", 235, 235, &HV_15);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_14, &HV_13, HV_12);
      TCDSetPS (pMyPar, 0, 99, &HV_11, &HV_10, HV_12);
         if ( HV_0 != 0 ) goto l_26 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_0 = 1;
      l_26: 
         HV_12 = HV_6 - HV_1;
      TCDSetPS (pMyPar, 1, 145, &HV_14, &HV_13, HV_12);
         rc = TCD3FE1 (pMyPar, 4, "F_vn", 239, 239, &HV_16);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_14, &HV_13, HV_12);
         HV_17 = HV_15 * HV_16;
      TCDSetPS (pMyPar, 1, 108, &HV_19, &HV_18, HV_6);
         rc = TCD3FE1 (pMyPar, 4, "F_rj", 315, 315, &HV_20);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 108, &HV_19, &HV_18, HV_6);
         HV_21 = HV_17 * HV_20;
         HV_22 = HV_21 + HV_22;
      }
      HV_4 = HV_22;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_4);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT316","End F_aePV",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_aePV", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_aePV", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_aePV");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT666
   Beschreibung: Die Funktion berechnet die Formel 
                 F_AccDeathDis_xnt
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT666 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT666","Begin F_AccDeathDis_xnt",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,666,"12.12.2019 17:29:45",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT666",
              "Ende F_AccDeathDis_xnt",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_AddSurcharge", 42, 382, 1, 130, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
      HV_3 = 0.0015 + HV_2;
      HV_0 = HV_3;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT666","End F_AccDeathDis_xnt",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_AccDeathDis_xnt", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_AccDeathDis_xnt", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_AccDeathDis_xnt");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT677
   Beschreibung: Die Funktion berechnet die Formel 
                 F_YieldAnnuity
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT677 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_10 = 0;
      P_TCDTAB2   HV_7;
      TCD_INT     HV_9 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT677","Begin F_YieldAnnuity",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,677,"12.12.2019 17:29:38",
                       4);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_8);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT677",
              "Ende F_YieldAnnuity",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_6 = 0;
      HV_10 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_5: 
      HV_4 = (TCD_INT) ( HV_1) ;
      if ( HV_2 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_HasAnnuityValue", 654, 654, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_8: 
      HV_5 = (TCD_INT) ( HV_3) ;
      if ( HV_6 != 0 ) goto l_11 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_11: 
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_4 < 0 || HV_4 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_7 [ HV_4 * 110 + HV_5 ]  == 0 ) goto l_24 ;
      goto l_30 ;
   l_24: 
      HV_9 = 0;
      HV_8 = HV_9;
      goto l_3 ;
   l_30: 
      if ( HV_10 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Annuitization", 679, 679, &HV_11);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_10 = 1;
   l_14: 
      HV_8 = HV_11;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_8);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT677","End F_YieldAnnuity",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_YieldAnnuity", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_YieldAnnuity", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_YieldAnnuity");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT678
   Beschreibung: Die Funktion berechnet die Formel 
                 F_BaseAnnuity
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT678 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_10 = 0;
      P_TCDTAB2   HV_7;
      TCD_INT     HV_9 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT678","Begin F_BaseAnnuity",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,678,"12.12.2019 17:29:38",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_8);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT678",
              "Ende F_BaseAnnuity",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_6 = 0;
      HV_10 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_5: 
      HV_4 = (TCD_INT) ( HV_1) ;
      if ( HV_2 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_HasAnnuityValue", 654, 654, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_8: 
      HV_5 = (TCD_INT) ( HV_3) ;
      if ( HV_6 != 0 ) goto l_11 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_11: 
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_4 < 0 || HV_4 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_7 [ HV_4 * 110 + HV_5 ]  == 0 ) goto l_24 ;
      goto l_30 ;
   l_24: 
      HV_9 = 0;
      HV_8 = HV_9;
      goto l_3 ;
   l_30: 
      if ( HV_10 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Annuitization", 679, 679, &HV_11);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_10 = 1;
   l_14: 
      HV_8 = HV_11;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_8);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT678","End F_BaseAnnuity",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_BaseAnnuity", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_BaseAnnuity", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_BaseAnnuity");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT679
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Annuitization
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT679 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_14 = 0;
      TCD_INT     HV_16 = 0;
      TCD_INT     HV_19 = 0;
      TCD_INT     HV_22 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_18 = 1;
      TCD_INT     HV_21 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT679","Begin F_Annuitization",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,679,"12.12.2019 17:29:37",
                       9);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT679",
              "Ende F_Annuitization",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_10 = 0;
      HV_14 = 0;
      if ( HV_3 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_PensionAge_x", 692, 692, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_3 = 1;
   l_5: 
      if ( HV_10 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_advance_arrears", 681, 681, &HV_11);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_10 = 1;
   l_8: 
      if ( HV_14 != 0 ) goto l_11 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AnnuityPeriod", 695, 695, &HV_15);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_14 = 1;
   l_11: 
   TCDSetPS (pMyPar, 1, 97, &HV_6, &HV_5, HV_4);
   TCDSetPS (pMyPar, 1, 88, &HV_9, &HV_8, HV_7);
   TCDSetPS (pMyPar, 1, 149, &HV_13, &HV_12, HV_11);
   TCDSetPS (pMyPar, 1, 161, &HV_17, &HV_16, HV_15);
   TCDSetPS (pMyPar, 1, 157, &HV_20, &HV_19, HV_18);
   TCDSetPS (pMyPar, 1, 133, &HV_23, &HV_22, HV_21);
      rc = TCD3FE1 (pMyPar, 4, "F_ae_delta", 313, 313, &HV_24);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 133, &HV_23, &HV_22, HV_21);
   TCDSetPS (pMyPar, 0, 157, &HV_20, &HV_19, HV_21);
   TCDSetPS (pMyPar, 0, 161, &HV_17, &HV_16, HV_21);
   TCDSetPS (pMyPar, 0, 149, &HV_13, &HV_12, HV_21);
   TCDSetPS (pMyPar, 0, 88, &HV_9, &HV_8, HV_21);
   TCDSetPS (pMyPar, 0, 97, &HV_6, &HV_5, HV_21);
      if ( HV_1 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_AnnuityAmount", 70, 427, 1, 158, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_14: 
   if ( HV_24 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_25 = HV_2 / HV_24;
      HV_26 =   TCDRND ( HV_25, 2 ) ;
      HV_0 = HV_26;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT679","End F_Annuitization",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Annuitization", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Annuitization", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Annuitization");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT681
   Beschreibung: Die Funktion berechnet die Formel 
                 F_advance_arrears
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT681 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_3 = 1;
      TCD_INT     HV_4 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT681","Begin F_advance_arrears",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,681,"12.12.2019 17:29:37",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT681",
              "Ende F_advance_arrears",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_IsLiquidAnnuity", 769, 769, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 1 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 1;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      HV_4 = 0;
      HV_2 = HV_4;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT681","End F_advance_arrears",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_advance_arrears", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_advance_arrears", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_advance_arrears");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT692
   Beschreibung: Die Funktion berechnet die Formel 
                 F_PensionAge_x
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT692 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT692","Begin F_PensionAge_x",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,692,"12.12.2019 17:29:37",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT692",
              "Ende F_PensionAge_x",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "e_x_IP1_n", 26, 345, 6, 26, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
      if ( HV_3 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_n", 364, 364, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_3 = 1;
   l_8: 
      HV_5 = HV_2 + HV_4;
      HV_0 = HV_5;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT692","End F_PensionAge_x",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_PensionAge_x", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_PensionAge_x", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_PensionAge_x");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT694
   Beschreibung: Die Funktion berechnet die Formel 
                 F_AnnuityPayFreq
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT694 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_3 = 12;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT694","Begin F_AnnuityPayFreq",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,694,"12.12.2019 17:29:37",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT694",
              "Ende F_AnnuityPayFreq",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      HV_6 = 0;
      HV_13 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_tarif_nr", 24, 321, 1, 112, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 >= 30000 ) goto l_21 ;
      goto l_36 ;
   l_21: 
      if ( HV_0 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_tarif_nr", 24, 321, 1, 112, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_8: 
      if ( HV_1 <  35000 ) goto l_30 ;
      goto l_36 ;
   l_30: 
      HV_3 = 12;
      HV_2 = HV_3;
      goto l_3 ;
   l_36: 
      if ( HV_4 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_advance_arrears", 61, 415, 1, 149, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_11: 
      if ( HV_5 == 0 ) goto l_48 ;
      goto l_72 ;
   l_48: 
      if ( HV_6 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_annuityPayment", 62, 416, 1, 150, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_14: 
      HV_8 = HV_7 - 1;
      if ( HV_13 != 0 ) goto l_64 ;
      if ( HV_6 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_annuityPayment", 62, 416, 1, 150, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_17: 
      HV_9 = 2 * HV_7;
      HV_13 = 1;
   l_64: 
   if ( HV_9 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_10 = HV_8 / HV_9;
      HV_2 = HV_10;
      goto l_3 ;
   l_72: 
      if ( HV_4 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_advance_arrears", 61, 415, 1, 149, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_20: 
      if ( HV_5 == 1 ) goto l_84 ;
      goto l_108 ;
   l_84: 
      if ( HV_6 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_annuityPayment", 62, 416, 1, 150, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_23: 
      HV_11 = HV_7 + 1;
      if ( HV_13 != 0 ) goto l_100 ;
      if ( HV_6 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_annuityPayment", 62, 416, 1, 150, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_26: 
      HV_9 = 2 * HV_7;
      HV_13 = 1;
   l_100: 
   if ( HV_9 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_12 = HV_11 / HV_9;
      HV_2 = HV_12;
      goto l_3 ;
   l_108: 
   pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 900;
   pMyPar->pTCDTCD->pRbsCtl->RCInfo.Errc = 999;
   goto l_ende ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT694","End F_AnnuityPayFreq",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_AnnuityPayFreq", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_AnnuityPayFreq", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_AnnuityPayFreq");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT699
   Beschreibung: Die Funktion berechnet die Formel 
                 F_PremiumRefundUntil
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT699 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_7 = 0;
      P_TCDTAB2   HV_8;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT699","Begin F_PremiumRefundUntil",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,699,"12.12.2019 17:29:41",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT699",
              "Ende F_PremiumRefundUntil",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_7 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
      HV_5 = (TCD_INT) ( HV_2) ;
      if ( HV_3 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_PremRefund", 656, 656, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_3 = 1;
   l_8: 
      HV_6 = (TCD_INT) ( HV_4) ;
      if ( HV_7 != 0 ) goto l_11 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_11: 
      if ( HV_6 < 0 || HV_6 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_0 = HV_8 [ HV_5 * 110 + HV_6 ] ;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT699","End F_PremiumRefundUntil",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_PremiumRefundUntil", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_PremiumRefundUntil", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_PremiumRefundUntil");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT702
   Beschreibung: Die Funktion berechnet die Formel 
                 F_AlphaOccDis_CV
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT702 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_16 = 0;
      TCD_INT     HV_20 = 0;
      TCD_INT     HV_3 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT702","Begin F_AlphaOccDis_CV",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,702,"12.12.2019 17:29:44",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT702",
              "Ende F_AlphaOccDis_CV",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_5 = 0;
      HV_7 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 <  0 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_7 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_8: 
      if ( HV_5 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_11: 
      HV_9 = HV_8 + HV_6;
      HV_24 = 0;
      if ( HV_5 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_14: 
      if ( HV_0 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_17: 
      for ( HV_4 = (TCD_INT) (HV_6) ; HV_4 <= HV_1; HV_4 = HV_4 + 1 )
         {
         if ( HV_5 != 0 ) goto l_20 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_6);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_5 = 1;
      l_20: 
         HV_12 = HV_4 - HV_6;
      TCDSetPS (pMyPar, 1, 99, &HV_11, &HV_10, HV_9);
      TCDSetPS (pMyPar, 1, 93, &HV_14, &HV_13, HV_12);
         rc = TCD3FE1 (pMyPar, 4, "F_pna_OccDis", 712, 712, &HV_15);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 93, &HV_14, &HV_13, HV_12);
      TCDSetPS (pMyPar, 0, 99, &HV_11, &HV_10, HV_12);
         if ( HV_5 != 0 ) goto l_23 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_6);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_5 = 1;
      l_23: 
         HV_12 = HV_4 - HV_6;
      TCDSetPS (pMyPar, 1, 145, &HV_17, &HV_16, HV_12);
         rc = TCD3FE1 (pMyPar, 4, "F_vn", 239, 239, &HV_18);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_17, &HV_16, HV_12);
         HV_19 = HV_15 * HV_18;
      TCDSetPS (pMyPar, 1, 108, &HV_21, &HV_20, HV_4);
         rc = TCD3FE1 (pMyPar, 4, "F_Alpha_OccDis", 701, 701, &HV_22);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 108, &HV_21, &HV_20, HV_4);
         HV_23 = HV_19 * HV_22;
         HV_24 = HV_23 + HV_24;
      }
      HV_2 = HV_24;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT702","End F_AlphaOccDis_CV",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_AlphaOccDis_CV", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_AlphaOccDis_CV", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_AlphaOccDis_CV");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT703
   Beschreibung: Die Funktion berechnet die Formel 
                 F_BetaOccDis_CV
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT703 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_16 = 0;
      TCD_INT     HV_20 = 0;
      TCD_INT     HV_3 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT703","Begin F_BetaOccDis_CV",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,703,"12.12.2019 17:29:44",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT703",
              "Ende F_BetaOccDis_CV",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_5 = 0;
      HV_7 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 <  0 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_7 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_8: 
      if ( HV_5 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_11: 
      HV_9 = HV_8 + HV_6;
      HV_24 = 0;
      if ( HV_5 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_14: 
      if ( HV_0 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_17: 
      for ( HV_4 = (TCD_INT) (HV_6) ; HV_4 <= HV_1; HV_4 = HV_4 + 1 )
         {
         if ( HV_5 != 0 ) goto l_20 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_6);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_5 = 1;
      l_20: 
         HV_12 = HV_4 - HV_6;
      TCDSetPS (pMyPar, 1, 99, &HV_11, &HV_10, HV_9);
      TCDSetPS (pMyPar, 1, 93, &HV_14, &HV_13, HV_12);
         rc = TCD3FE1 (pMyPar, 4, "F_pna_OccDis", 712, 712, &HV_15);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 93, &HV_14, &HV_13, HV_12);
      TCDSetPS (pMyPar, 0, 99, &HV_11, &HV_10, HV_12);
         if ( HV_5 != 0 ) goto l_23 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_6);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_5 = 1;
      l_23: 
         HV_12 = HV_4 - HV_6;
      TCDSetPS (pMyPar, 1, 145, &HV_17, &HV_16, HV_12);
         rc = TCD3FE1 (pMyPar, 4, "F_vn", 239, 239, &HV_18);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_17, &HV_16, HV_12);
         HV_19 = HV_15 * HV_18;
      TCDSetPS (pMyPar, 1, 108, &HV_21, &HV_20, HV_4);
         rc = TCD3FE1 (pMyPar, 4, "F_Beta", 551, 551, &HV_22);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 108, &HV_21, &HV_20, HV_4);
         HV_23 = HV_19 * HV_22;
         HV_24 = HV_23 + HV_24;
      }
      HV_2 = HV_24;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT703","End F_BetaOccDis_CV",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_BetaOccDis_CV", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_BetaOccDis_CV", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_BetaOccDis_CV");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT704
   Beschreibung: Die Funktion berechnet die Formel 
                 F_PxnOccDis
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT704 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_16 = 0;
      TCD_INT     HV_20 = 0;
      TCD_INT     HV_3 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT704","Begin F_PxnOccDis",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,704,"12.12.2019 17:29:43",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT704",
              "Ende F_PxnOccDis",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_5 = 0;
      HV_7 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 <  0 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_7 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_8: 
      if ( HV_5 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_11: 
      HV_9 = HV_8 + HV_6;
      HV_24 = 0;
      if ( HV_5 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_14: 
      if ( HV_0 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_17: 
      for ( HV_4 = (TCD_INT) (HV_6) ; HV_4 <= HV_1; HV_4 = HV_4 + 1 )
         {
         if ( HV_5 != 0 ) goto l_20 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_6);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_5 = 1;
      l_20: 
         HV_12 = HV_4 - HV_6;
      TCDSetPS (pMyPar, 1, 99, &HV_11, &HV_10, HV_9);
      TCDSetPS (pMyPar, 1, 93, &HV_14, &HV_13, HV_12);
         rc = TCD3FE1 (pMyPar, 4, "F_pna_OccDis", 712, 712, &HV_15);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 93, &HV_14, &HV_13, HV_12);
      TCDSetPS (pMyPar, 0, 99, &HV_11, &HV_10, HV_12);
         if ( HV_5 != 0 ) goto l_23 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_6);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_5 = 1;
      l_23: 
         HV_12 = HV_4 - HV_6;
      TCDSetPS (pMyPar, 1, 145, &HV_17, &HV_16, HV_12);
         rc = TCD3FE1 (pMyPar, 4, "F_vn", 239, 239, &HV_18);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_17, &HV_16, HV_12);
         HV_19 = HV_15 * HV_18;
      TCDSetPS (pMyPar, 1, 108, &HV_21, &HV_20, HV_4);
         rc = TCD3FE1 (pMyPar, 4, "F_prj", 268, 268, &HV_22);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 108, &HV_21, &HV_20, HV_4);
         HV_23 = HV_19 * HV_22;
         HV_24 = HV_23 + HV_24;
      }
      HV_2 = HV_24;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT704","End F_PxnOccDis",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_PxnOccDis", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_PxnOccDis", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_PxnOccDis");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT705
   Beschreibung: Die Funktion berechnet die Formel 
                 F_pni_OCDis
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT705 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_14 = 0;
      TCD_INT     HV_22 = 1;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT705","Begin F_pni_OCDis",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,705,"12.12.2019 17:29:41",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT705",
              "Ende F_pni_OCDis",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      HV_7 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 >= 1 ) goto l_18 ;
      goto l_168 ;
   l_18: 
      if ( HV_0 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_8: 
      HV_6 = HV_1 - 1;
      HV_21 = 1;
      if ( HV_4 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_11: 
      for ( HV_3 = (TCD_INT) (HV_5) ; HV_3 <= HV_6; HV_3 = HV_3 + 1 )
         {
         if ( HV_7 != 0 ) goto l_14 ;
         TCD3FES (pMyPar, "i_z", 2, 164, 1, 90, &HV_8);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_7 = 1;
      l_14: 
         HV_9 = HV_8 + HV_3;
         if ( HV_7 != 0 ) goto l_17 ;
         TCD3FES (pMyPar, "i_z", 2, 164, 1, 90, &HV_8);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_7 = 1;
      l_17: 
         HV_9 = HV_8 + HV_3;
         HV_12 = TCDMIN ( HV_3, 5 ) ;
         HV_13 = HV_9 + HV_12;
      TCDSetPS (pMyPar, 1, 99, &HV_11, &HV_10, HV_9);
      TCDSetPS (pMyPar, 1, 108, &HV_15, &HV_14, HV_13);
         rc = TCD3FE1 (pMyPar, 4, "F_qi_OCDis", 707, 707, &HV_16);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 108, &HV_15, &HV_14, HV_13);
      TCDSetPS (pMyPar, 0, 99, &HV_11, &HV_10, HV_13);
         HV_17 = 1 - HV_16;
         if ( HV_7 != 0 ) goto l_20 ;
         TCD3FES (pMyPar, "i_z", 2, 164, 1, 90, &HV_8);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_7 = 1;
      l_20: 
         HV_9 = HV_8 + HV_3;
         if ( HV_7 != 0 ) goto l_23 ;
         TCD3FES (pMyPar, "i_z", 2, 164, 1, 90, &HV_8);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_7 = 1;
      l_23: 
         HV_9 = HV_8 + HV_3;
         HV_12 = TCDMIN ( HV_3, 5 ) ;
         HV_13 = HV_9 + HV_12;
      TCDSetPS (pMyPar, 1, 99, &HV_11, &HV_10, HV_9);
      TCDSetPS (pMyPar, 1, 108, &HV_15, &HV_14, HV_13);
         rc = TCD3FE1 (pMyPar, 4, "F_rea_OCDis", 706, 706, &HV_18);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 108, &HV_15, &HV_14, HV_13);
      TCDSetPS (pMyPar, 0, 99, &HV_11, &HV_10, HV_13);
         HV_19 = 1 - HV_18;
         HV_20 = HV_17 * HV_19;
         HV_21 = HV_20 * HV_21;
      }
      HV_2 = HV_21;
      goto l_3 ;
   l_168: 
      HV_22 = 1;
      HV_2 = HV_22;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT705","End F_pni_OCDis",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_pni_OCDis", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_pni_OCDis", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_pni_OCDis");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT706
   Beschreibung: Die Funktion berechnet die Formel 
                 F_rea_OCDis
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT706 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_11 = 0;
      TCD_INT     HV_12 = 0;
      P_TCDTAB2   HV_13;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT706","Begin F_rea_OCDis",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,706,"12.12.2019 17:29:41",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT706",
              "Ende F_rea_OCDis",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_6 = 0;
      HV_12 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
      HV_11 = (TCD_INT) ( HV_2) ;
      if ( HV_3 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_8: 
      HV_5 = HV_4 + 2;
      if ( HV_6 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_Offset", 12, 261, 1, 100, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_11: 
      HV_8 = HV_7 * 14;
      HV_9 = HV_5 + HV_8;
      if ( HV_1 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_14: 
      HV_10 = (TCD_INT) ( HV_9 - HV_2) ;
      if ( HV_12 != 0 ) goto l_17 ;
      TCD3FET (pMyPar, "MortalityTab", 3, 395, 8,  (P_TCDTAB *)
         &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_17: 
      if ( HV_10 < 0 || HV_10 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
         1) { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_11 < 0 || HV_11 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_0 = HV_13 [ HV_11 * 110 + HV_10 ] ;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT706","End F_rea_OCDis",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_rea_OCDis", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_rea_OCDis", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_rea_OCDis");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT707
   Beschreibung: Die Funktion berechnet die Formel 
                 F_qi_OCDis
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT707 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_11 = 0;
      TCD_INT     HV_12 = 0;
      P_TCDTAB2   HV_13;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT707","Begin F_qi_OCDis",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,707,"12.12.2019 17:29:41",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT707",
              "Ende F_qi_OCDis",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_6 = 0;
      HV_12 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
      HV_11 = (TCD_INT) ( HV_2) ;
      if ( HV_3 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_8: 
      HV_5 = HV_4 + 8;
      if ( HV_6 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_Offset", 12, 261, 1, 100, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_11: 
      HV_8 = HV_7 * 14;
      HV_9 = HV_5 + HV_8;
      if ( HV_1 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_14: 
      HV_10 = (TCD_INT) ( HV_9 - HV_2) ;
      if ( HV_12 != 0 ) goto l_17 ;
      TCD3FET (pMyPar, "MortalityTab", 3, 395, 8,  (P_TCDTAB *)
         &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_17: 
      if ( HV_10 < 0 || HV_10 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
         1) { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_11 < 0 || HV_11 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_0 = HV_13 [ HV_11 * 110 + HV_10 ] ;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT707","End F_qi_OCDis",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_qi_OCDis", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_qi_OCDis", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_qi_OCDis");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT708
   Beschreibung: Die Funktion berechnet die Formel 
                 F_aei_OCDis
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT708 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_27 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_DOUBLE  HV_29 = 0;
      TCD_DOUBLE  HV_31 = 0;
      TCD_DOUBLE  HV_32 = 0;
      TCD_DOUBLE  HV_33 = 0;
      TCD_DOUBLE  HV_34 = 0;
      TCD_DOUBLE  HV_35 = 0;
      TCD_DOUBLE  HV_36 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_17 = 0;
      TCD_INT     HV_22 = 0;
      TCD_INT     HV_24 = 0;
      TCD_INT     HV_26 = 0;
      TCD_INT     HV_30 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT708","Begin F_aei_OCDis",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,708,"12.12.2019 17:29:40",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT708",
              "Ende F_aei_OCDis",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_2 = 0;
      HV_4 = 0;
      HV_22 = 0;
      if ( HV_4 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_5: 
      HV_6 = HV_5 - 1;
      HV_21 = 0;
      if ( HV_2 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_8: 
      for ( HV_1 = (TCD_INT) (HV_3) ; HV_1 <= HV_6; HV_1 = HV_1 + 1 )
         {
         if ( HV_2 != 0 ) goto l_11 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_2 = 1;
      l_11: 
      TCDSetPS (pMyPar, 1, 93, &HV_8, &HV_7, HV_1);
      TCDSetPS (pMyPar, 1, 88, &HV_10, &HV_9, HV_3);
         rc = TCD3FE1 (pMyPar, 4, "F_pni_OCDis", 705, 705, &HV_11);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 88, &HV_10, &HV_9, HV_3);
      TCDSetPS (pMyPar, 0, 93, &HV_8, &HV_7, HV_3);
         if ( HV_2 != 0 ) goto l_14 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_2 = 1;
      l_14: 
         HV_12 = HV_1 - HV_3;
      TCDSetPS (pMyPar, 1, 145, &HV_14, &HV_13, HV_12);
         rc = TCD3FE1 (pMyPar, 4, "F_vn", 239, 239, &HV_15);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_14, &HV_13, HV_12);
         HV_16 = HV_11 * HV_15;
      TCDSetPS (pMyPar, 1, 108, &HV_18, &HV_17, HV_1);
         rc = TCD3FE1 (pMyPar, 4, "F_rj_OCDis", 709, 709, &HV_19);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 108, &HV_18, &HV_17, HV_1);
         HV_20 = HV_16 * HV_19;
         HV_21 = HV_20 + HV_21;
      }
      if ( HV_4 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_17: 
      if ( HV_2 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_20: 
   TCDSetPS (pMyPar, 1, 93, &HV_25, &HV_24, HV_5);
   TCDSetPS (pMyPar, 1, 88, &HV_27, &HV_26, HV_3);
      rc = TCD3FE1 (pMyPar, 4, "F_pni_OCDis", 705, 705, &HV_28);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 88, &HV_27, &HV_26, HV_3);
   TCDSetPS (pMyPar, 0, 93, &HV_25, &HV_24, HV_3);
      if ( HV_4 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_23: 
      if ( HV_2 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_26: 
      HV_29 = HV_5 - HV_3;
   TCDSetPS (pMyPar, 1, 145, &HV_31, &HV_30, HV_29);
      rc = TCD3FE1 (pMyPar, 4, "F_vn", 239, 239, &HV_32);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 145, &HV_31, &HV_30, HV_29);
      HV_33 = HV_28 * HV_32;
      HV_34 = 1 - HV_33;
      if ( HV_22 != 0 ) goto l_29 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AnnuityPayFreq", 694, 694, &HV_23);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_22 = 1;
   l_29: 
      HV_35 = HV_23 * HV_34;
      HV_36 = HV_21 - HV_35;
      HV_0 = HV_36;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT708","End F_aei_OCDis",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_aei_OCDis", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_aei_OCDis", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_aei_OCDis");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT709
   Beschreibung: Die Funktion berechnet die Formel 
                 F_rj_OCDis
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT709 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_5 = 1;
      TCD_INT     HV_6 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT709","Begin F_rj_OCDis",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,709,"12.12.2019 17:29:40",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_4);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT709",
              "Ende F_rj_OCDis",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_2 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_8: 
      if ( HV_1 <  HV_3 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_5 = 1;
      HV_4 = HV_5;
      goto l_3 ;
   l_24: 
      HV_6 = 0;
      HV_4 = HV_6;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_4);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT709","End F_rj_OCDis",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_rj_OCDis", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_rj_OCDis", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_rj_OCDis");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT710
   Beschreibung: Die Funktion berechnet die Formel 
                 F_i_OccDis
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT710 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_8 = 0;
      P_TCDTAB2   HV_9;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT710","Begin F_i_OccDis",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,710,"12.12.2019 17:29:40",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT710",
              "Ende F_i_OccDis",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_8 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
      HV_7 = (TCD_INT) ( HV_2) ;
      if ( HV_3 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_Offset", 12, 261, 1, 100, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_8: 
      HV_5 = HV_4 * 14;
      HV_6 = (TCD_INT) ( HV_5 + 1) ;
      if ( HV_8 != 0 ) goto l_11 ;
      TCD3FET (pMyPar, "MortalityTab", 3, 395, 8,  (P_TCDTAB *)
         &HV_9);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_8 = 1;
   l_11: 
      if ( HV_6 < 0 || HV_6 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_7 < 0 || HV_7 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_0 = HV_9 [ HV_7 * 110 + HV_6 ] ;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT710","End F_i_OccDis",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_i_OccDis", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_i_OccDis", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_i_OccDis");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT711
   Beschreibung: Die Funktion berechnet die Formel 
                 F_paa_OccDis
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT711 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT711","Begin F_paa_OccDis",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,711,"12.12.2019 17:29:40",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT711",
              "Ende F_paa_OccDis",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_qaa_OccDis", 713, 713, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
      HV_3 = 1 - HV_2;
      HV_0 = HV_3;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT711","End F_paa_OccDis",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_paa_OccDis", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_paa_OccDis", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_paa_OccDis");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT712
   Beschreibung: Die Funktion berechnet die Formel 
                 F_pna_OccDis
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT712 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_15 = 1;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT712","Begin F_pna_OccDis",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,712,"12.12.2019 17:29:40",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT712",
              "Ende F_pna_OccDis",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 >= 1 ) goto l_18 ;
      goto l_105 ;
   l_18: 
      HV_14 = 1;
      if ( HV_0 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_8: 
      for ( HV_3 = (TCD_INT) (1) ; HV_3 <= HV_1; HV_3 = HV_3 + 1 ) {
         if ( HV_4 != 0 ) goto l_11 ;
         TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_5);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_4 = 1;
      l_11: 
         HV_6 = HV_5 + HV_3;
         HV_7 = HV_6 - 1;
      TCDSetPS (pMyPar, 1, 99, &HV_9, &HV_8, HV_7);
         rc = TCD3FE1 (pMyPar, 4, "F_paa_OccDis", 711, 711, &HV_10);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 99, &HV_9, &HV_8, HV_7);
         if ( HV_4 != 0 ) goto l_14 ;
         TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_5);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_4 = 1;
      l_14: 
         HV_6 = HV_5 + HV_3;
         HV_7 = HV_6 - 1;
      TCDSetPS (pMyPar, 1, 99, &HV_9, &HV_8, HV_7);
         rc = TCD3FE1 (pMyPar, 4, "F_i_OccDis", 710, 710, &HV_11);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 99, &HV_9, &HV_8, HV_7);
         HV_12 = 1 - HV_11;
         HV_13 = HV_10 * HV_12;
         HV_14 = HV_13 * HV_14;
      }
      HV_2 = HV_14;
      goto l_3 ;
   l_105: 
      HV_15 = 1;
      HV_2 = HV_15;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT712","End F_pna_OccDis",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_pna_OccDis", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_pna_OccDis", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_pna_OccDis");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT713
   Beschreibung: Die Funktion berechnet die Formel 
                 F_qaa_OccDis
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT713 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_7 = 0;
      P_TCDTAB2   HV_8;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT713","Begin F_qaa_OccDis",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,713,"12.12.2019 17:29:40",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT713",
              "Ende F_qaa_OccDis",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_7 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
      HV_6 = (TCD_INT) ( HV_2) ;
      if ( HV_3 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_Offset", 12, 261, 1, 100, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_8: 
      HV_5 = (TCD_INT) ( HV_4 * 14) ;
      if ( HV_7 != 0 ) goto l_11 ;
      TCD3FET (pMyPar, "MortalityTab", 3, 395, 8,  (P_TCDTAB *)
         &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_11: 
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_6 < 0 || HV_6 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_0 = HV_8 [ HV_6 * 110 + HV_5 ] ;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT713","End F_qaa_OccDis",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_qaa_OccDis", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_qaa_OccDis", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_qaa_OccDis");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT714
   Beschreibung: Die Funktion berechnet die Formel 
                 F_b_OccDis
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT714 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_11 = 0;
      TCD_INT     HV_15 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_20 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT714","Begin F_b_OccDis",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,714,"12.12.2019 17:29:40",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT714",
              "Ende F_b_OccDis",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_5 = 0;
      HV_9 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_z", 2, 164, 1, 90, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
      if ( HV_5 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_benefitPeriod", 72, 429, 1, 160, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_8: 
      if ( HV_9 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_10);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_9 = 1;
   l_11: 
   TCDSetPS (pMyPar, 1, 90, &HV_4, &HV_3, HV_2);
   TCDSetPS (pMyPar, 1, 93, &HV_8, &HV_7, HV_6);
   TCDSetPS (pMyPar, 1, 88, &HV_12, &HV_11, HV_10);
      rc = TCD3FE1 (pMyPar, 4, "F_aei_OCDis", 708, 708, &HV_13);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 88, &HV_12, &HV_11, HV_10);
   TCDSetPS (pMyPar, 0, 93, &HV_8, &HV_7, HV_10);
   TCDSetPS (pMyPar, 0, 90, &HV_4, &HV_3, HV_10);
      if ( HV_1 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_z", 2, 164, 1, 90, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_14: 
      HV_14 = HV_2 + 1;
      if ( HV_5 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_benefitPeriod", 72, 429, 1, 160, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_17: 
      HV_17 = HV_6 - 1;
      if ( HV_9 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_10);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_9 = 1;
   l_20: 
   TCDSetPS (pMyPar, 1, 90, &HV_16, &HV_15, HV_14);
   TCDSetPS (pMyPar, 1, 93, &HV_19, &HV_18, HV_17);
   TCDSetPS (pMyPar, 1, 88, &HV_21, &HV_20, HV_10);
      rc = TCD3FE1 (pMyPar, 4, "F_aei_OCDis", 708, 708, &HV_22);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 88, &HV_21, &HV_20, HV_10);
   TCDSetPS (pMyPar, 0, 93, &HV_19, &HV_18, HV_10);
   TCDSetPS (pMyPar, 0, 90, &HV_16, &HV_15, HV_10);
      HV_23 = HV_13 + HV_22;
      HV_24 = 0.5 * HV_23;
      HV_0 = HV_24;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT714","End F_b_OccDis",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_b_OccDis", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_b_OccDis", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_b_OccDis");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT715
   Beschreibung: Die Funktion berechnet die Formel 
                 F_CashValue_OccDis
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT715 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_DOUBLE  HV_29 = 0;
      TCD_DOUBLE  HV_30 = 0;
      TCD_DOUBLE  HV_31 = 0;
      TCD_DOUBLE  HV_32 = 0;
      TCD_DOUBLE  HV_33 = 0;
      TCD_DOUBLE  HV_35 = 0;
      TCD_DOUBLE  HV_37 = 0;
      TCD_DOUBLE  HV_38 = 0;
      TCD_DOUBLE  HV_40 = 0;
      TCD_DOUBLE  HV_43 = 0;
      TCD_DOUBLE  HV_44 = 0;
      TCD_DOUBLE  HV_45 = 0;
      TCD_DOUBLE  HV_47 = 0;
      TCD_DOUBLE  HV_48 = 0;
      TCD_DOUBLE  HV_49 = 0;
      TCD_DOUBLE  HV_51 = 0;
      TCD_DOUBLE  HV_52 = 0;
      TCD_DOUBLE  HV_53 = 0;
      TCD_DOUBLE  HV_54 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_17 = 0;
      TCD_INT     HV_22 = 0;
      TCD_INT     HV_27 = 0;
      TCD_INT     HV_34 = 0;
      TCD_INT     HV_36 = 0;
      TCD_INT     HV_39 = 0;
      TCD_INT     HV_42 = 0;
      TCD_INT     HV_46 = 0;
      TCD_INT     HV_50 = 0;
      TCD_INT     HV_41 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT715","Begin F_CashValue_OccDis",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,715,"12.12.2019 17:29:39",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT715",
              "Ende F_CashValue_OccDis",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_2 = 0;
      HV_4 = 0;
      HV_7 = 0;
      HV_36 = 0;
      HV_46 = 0;
      HV_50 = 0;
      if ( HV_4 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_5: 
      HV_6 = HV_5 - 1;
      if ( HV_7 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_8: 
      if ( HV_2 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_11: 
      HV_9 = HV_8 + HV_3;
      if ( HV_46 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Delta", 504, 504, &HV_47);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_46 = 1;
   l_14: 
      HV_48 = 1 + HV_47;
      if ( HV_50 != 0 ) goto l_17 ;
      rc = TCD3FE1 (pMyPar, 2, "F_v", 243, 243, &HV_51);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_50 = 1;
   l_17: 
      HV_52 = TCDEXP ( HV_51, 0.5 ) ;
      HV_54 = 0;
      if ( HV_2 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_20: 
      for ( HV_1 = (TCD_INT) (HV_3) ; HV_1 <= HV_6; HV_1 = HV_1 + 1 )
         {
         if ( HV_2 != 0 ) goto l_23 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_2 = 1;
      l_23: 
         HV_12 = HV_1 - HV_3;
      TCDSetPS (pMyPar, 1, 99, &HV_11, &HV_10, HV_9);
      TCDSetPS (pMyPar, 1, 93, &HV_14, &HV_13, HV_12);
         rc = TCD3FE1 (pMyPar, 4, "F_pna_OccDis", 712, 712, &HV_15);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 93, &HV_14, &HV_13, HV_12);
      TCDSetPS (pMyPar, 0, 99, &HV_11, &HV_10, HV_12);
         if ( HV_2 != 0 ) goto l_26 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_2 = 1;
      l_26: 
         HV_16 = HV_1 - HV_3;
      TCDSetPS (pMyPar, 1, 145, &HV_18, &HV_17, HV_16);
         rc = TCD3FE1 (pMyPar, 4, "F_vn", 239, 239, &HV_19);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 145, &HV_18, &HV_17, HV_16);
         HV_20 = HV_15 * HV_19;
         if ( HV_7 != 0 ) goto l_29 ;
         TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_8);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_7 = 1;
      l_29: 
         HV_21 = HV_8 + HV_1;
      TCDSetPS (pMyPar, 1, 99, &HV_23, &HV_22, HV_21);
         rc = TCD3FE1 (pMyPar, 4, "F_i_OccDis", 710, 710, &HV_24);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 99, &HV_23, &HV_22, HV_21);
         HV_25 = HV_20 * HV_24;
         if ( HV_7 != 0 ) goto l_32 ;
         TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_8);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_7 = 1;
      l_32: 
         HV_26 = HV_8 + HV_1;
      TCDSetPS (pMyPar, 1, 99, &HV_28, &HV_27, HV_26);
         rc = TCD3FE1 (pMyPar, 4, "F_qaa_OccDis", 713, 713, &HV_29);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 99, &HV_28, &HV_27, HV_26);
      if ( 2 == 0) { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
         goto l_ende ;
       } ;
         HV_30 = HV_29 / 2;
         HV_31 = 1 - HV_30;
         HV_32 = HV_25 * HV_31;
         if ( HV_7 != 0 ) goto l_35 ;
         TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_8);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_7 = 1;
      l_35: 
         HV_33 = HV_8 + HV_1;
         if ( HV_36 != 0 ) goto l_38 ;
         TCD3FES (pMyPar, "i_benefitPeriod", 72, 429, 1, 160, &HV_37);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_36 = 1;
      l_38: 
         HV_38 = HV_37 - HV_1;
      TCDSetPS (pMyPar, 1, 90, &HV_35, &HV_34, HV_33);
      TCDSetPS (pMyPar, 1, 160, &HV_40, &HV_39, HV_38);
      TCDSetPS (pMyPar, 1, 88, &HV_43, &HV_42, HV_41);
         rc = TCD3FE1 (pMyPar, 4, "F_b_OccDis", 714, 714, &HV_44);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 88, &HV_43, &HV_42, HV_41);
      TCDSetPS (pMyPar, 0, 160, &HV_40, &HV_39, HV_41);
      TCDSetPS (pMyPar, 0, 90, &HV_35, &HV_34, HV_41);
         HV_45 = HV_32 * HV_44;
         HV_49 = HV_45 * HV_48;
         HV_53 = HV_49 * HV_52;
         HV_54 = HV_53 + HV_54;
      }
      HV_0 = HV_54;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT715","End F_CashValue_OccDis",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_CashValue_OccDis", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_CashValue_OccDis", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_CashValue_OccDis");
   }                                         
   return ;

   }
}

