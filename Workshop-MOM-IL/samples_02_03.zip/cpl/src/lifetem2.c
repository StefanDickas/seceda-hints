/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
/*---------------------------------------------------------------------
Modul:   TCD_FCTL.C
f�r RBS: LifeTemplate
Historie:
BEG   17.01.95  neues Makro _TCDMEMINI anstatt memset
RWE   21.06.96  #include <stdio.h> und <memory.h> gel�scht
MUB   02.07.96  LocData insgesamt ausgebaut
MUB   22.07.96  Modul Watchpol mit bedingter �bersetzung herein-
genommen.
Wiederverwendungslistenlaenge darf jetzt auch 0 sein.
In diesem Fall wird immer berechnet ...
KFC   12.08.96  CALLTYP_STA_UE (�berschriebene Formel)
eingebaut
MUB    14.8.96  GetActSettings() pr�ft jetzt bei Knotentyp 3 noch 
Schnittstelle
und Baum, wenn auf dem �berschreibungsstack f�r ein relevantes
Attribut nichts steht. D.h., die Funktion besorgt sich unter allen
Umstaenden die aktuelle Belegung eines relevanten Attributes

28.8.96 MUB     neues Makro ATTR.n f�r Generierung einer Tabelle
aller Attribute mit Index eingef�gt.
(Wird ben�tigt f�r die Indizierung in den �berschreibungsstack

28.8.96  MUB   Neues Suchen des Index in den �berschreibungsstack 
(GetIndexToUes()),
Nicht �berschriebene relevante Attribute an Typ3-Knoten erhalten 
jetzt in
'bNotOverwritten' ein TYP3_NOT_OVERWRITTEN  und es wird nicht 
weitergesucht.

24.10.96 MUB   Aenderung des 2. Parameter des Listmakros ATTR von 
ATTR.11 auf ATTR.9

6.11.96  MUB   Aenderung vom 24.10.96 wieder r�ckgaengig gemacht!
6.11.96  MUB   Suchen in der Schnittstelle jetzt doch wieder �ber die 
regulaere AttributTabelle
                 aus TCD_ATTX.H
---------------------------------------------------------------------*/


/* defines */
#define SUCHE_IN_PAARLISTE       -1
#define SUCHE_NICHT_IN_PAARLISTE  0
/*---------------------------------------------------------------------
   Includes
---------------------------------------------------------------------*/
#include <search.h>                            /* bsearch in AttrTab */

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDPORTAB_H)
#define TCDPORTAB_H

/*-----------------
Name        : TCDPORTAB.H

Beschreibung: externes Include File, das generierumgeungsspezifische
Informationen enthaelt (Makrovorlage).
By          : BEGGI
Datum       : 20.04.94
Historie:     BEG   17.01.95  neues Makro _TCDMEMINI anstatt memset
BEG   02.03.95  bedingte Macros TCDHUGE
BEG   22.06.95  _TCDMEMINI nur im HUGE-Modell redefiniert.
BEG   20.02.96  malloc.h wird nicht mehr inkludiert (FM 451)
RWE   21.06.96  malloc.h wird wieder includiert (aber nur
              fuers HUGE-Modell, d.h. fuer DOS/WIN-Compiler)
RWE   26.06.96  WATCHMEM-Makros eingebaut (fuer TCDALLOC etc)
MUB   17.7.96   Include mit !defined versehen
KFC   02.09.96  #define TCDHUGE vorgezogen

-------------------*/

/* #define TCDHUGE */              /* bei gro�en Tabellen einschalten*/
/* Systemincludes */                  
#include <stdlib.h>                /* atoi, ...       */
#include <stdio.h>                 /* fprintf, ...    */
#include <string.h>                /* strcpy, ...     */
#include <time.h>                  /* time_t, ...     */
#include <math.h>                  /* exp, min, max, ... */

#ifdef TCDHUGE
#include <malloc.h>
#endif

/* Defines */
#define  TCDC_EXT_NAME_LNG    8  /* maximale L�nge von externen 
                                    Bezeichnern*/
/*-----------------
  Definitionen aus standard C-Includes z.B. stdio.h
-------------------*/
#ifndef NULL
#define    NULL    (void *)0
#endif

/*-----------------
  Definitionen von Basistypen
-------------------*/
typedef    short   TCD_BOOL ;
typedef    long    TCD_LONG ;
typedef    int     TCD_INT  ;
typedef    double  TCD_DOUBLE ;


/*-----------------
  modellabhaengige Definitionen von Basistypen
-------------------*/
typedef    TCD_DOUBLE  TCDTAB ;
#ifdef TCDHUGE
typedef    TCDTAB       huge * P_TCDTAB ;
typedef    TCD_DOUBLE   huge * P_TCD_DOUBLE ;
typedef    P_TCD_DOUBLE * P_P_TCD_DOUBLE ;
typedef    char huge    * TCD_LPCHAR ;
#else
typedef    TCDTAB       * P_TCDTAB ;
typedef    TCD_DOUBLE   * P_TCD_DOUBLE ;
typedef    P_TCD_DOUBLE * P_P_TCD_DOUBLE ;
typedef    char         * TCD_LPCHAR ;
#endif

/*-----------------
  weitere (Typ-)Defines 
-------------------*/  
typedef int ERRNO_TYPE;
#define TCD_FILENAME_LNG 128

/*-----------------
  Definitionen von Makros f�r Speicherallokation
-------------------*/  

/* WATCHMEM muss im TCDHUGE-Modus abgeschaltet sein */
#ifdef TCDHUGE
#undef WATCHMEM
#endif

#undef _TCDALLOC
#undef _TCDFREE
#undef _TCDREALLOC

#ifndef WATCHMEM

#define _TCDALLOC(len,size)    malloc( (size_t)(len) * (size)) ;
#define _TCDFREE(ptr)          {free(ptr), ptr = NULL;}
#define _TCDREALLOC(ptr,size)  realloc( ptr, (size_t)(size) ) ;

#else
 
void *MallocAndProt(char *sFile_,int iLine_, size_t size);
#define _TCDALLOC(len,size)\
 MallocAndProt(__FILE__,__LINE__,(len) * (size))

void FreeAndProt(char *sFile_, int iLine_, void *p_);

#define _TCDFREE(ptr)\
       {FreeAndProt(__FILE__, __LINE__, ptr) , ptr = NULL;}

void *ReallocAndProt(char *sFile_,int iLine_, void *p_, size_t size);
#define _TCDREALLOC(ptr,size)\
 ReallocAndProt(__FILE__, __LINE__, ptr,size)

void ResumeWatchmem();

#endif

/*-----------------
  modellabh�ngige Definitionen von Makros f�r Speicherallokation
-------------------*/
#undef _TCDTABALLOC
#undef _TCDTABFREE
#undef _TCDMEMINI

#ifdef TCDHUGE

#define _TCDTABALLOC(len,size)\
  _halloc( (long)(len) , (size_t)(size)) ;
#define _TCDTABFREE(ptr)\
      { _hfree ( (void huge *)ptr); ptr = NULL;}

#else

#ifndef WATCHMEM
#define _TCDTABALLOC(len,size)\
 malloc((size_t)((long)len) * ((size_t)size)) ;
#define _TCDTABFREE(ptr)       {free(ptr), ptr = NULL;}
#else
#define _TCDTABALLOC(len,size)\
 MallocAndProt(__FILE__,__LINE__,(len) * (size))
#define _TCDTABFREE(ptr)\
       FreeAndProt(__FILE__, __LINE__, ptr)
#endif

#endif


#ifdef TCDHUGE
#define _TCDMEMINI(ptr,size,nr)\
{\
   long       j;\
   TCD_LPCHAR lp;\
   for (j= 0 , lp = (TCD_LPCHAR)ptr;\
        j < ((long)(size) * (long)(nr)); j++, lp++) \
      *lp = 0;\
}  

#else
#define _TCDMEMINI(ptr,size,nr)\
 { memset (ptr, 0, (size_t) ((size) * (nr))) ; }
#endif
/*---------------------------------
  NON-Ansi-Namen mit oder ohne "_"
----------------------------------*/

/* #define NON_ANSI_WITHOUT__ */

#ifdef NON_ANSI_WITHOUT__
#define _fcvt fcvt
#endif

/*---------------------------
  ggf. Verkuerzung der Namen
-----------------------------*/
#ifdef TCD_NAMLEN8

#define TCDIMPReleaseProcData       TCD_0001
#define TCDIMPReleaseNodeData       TCD_0002
#define TCDIMPReleaseTabImpData     TCD_0003   

#define FetchFromGlobalErgebnisPool TCD_0004

#define DelEltFromSVect             TCD_0005
#define DelEltFromSVectByIndex      TCD_0006

#define DelEltFromVect              TCD_0007
#define DelEltFromVectByIndex       TCD_0008
                                
                                
#define ReleaseGlobalErgebnisPool   TCD_0009
#define ReleaseGlobalErgebnis       TCD_0010
#define ReleaseLocalErgebnisPool    TCD_0011

#define GetPrcDataSkal              TCD_0012
#define GetPrcDataTab               TCD_0013
#define GetPrcDataDat               TCD_0014
#define GetPrcDataFrm               TCD_0015

#define GetPrcAttrSkal              TCD_0016
#define GetPrcAttrTab               TCD_0017

#define GetSSAttrSkal               TCD_0018
#define GetSSAttrTab                TCD_0019

#define ErgPoolGetFirstInfo         TCD_0020
#define ErgPoolGetNextInfo          TCD_0021

#define DConstrAttrs                TCD_0022
#define DConstrAttrsResults         TCD_0023

#define GetRelAttrs                 TCD_0024

#define GetIndexToGlobalErgPool     TCD_0025
#define GetIndexToPaarListElt       TCD_0026

#define GetIndexToSS                TCD_0027
#define GetIndexToUes               TCD_0028
#define GetFromSS                   TCD_0029
#define GetFromUes                  TCD_0030

#define TCDIMPImportTreeData        TCD_0031
#define TCDIMPNFIntl                TCD_0032
#define TCDIMPGetNodeFromID         TCD_0033
#define TCDIMPGetNodeFromPath       TCD_0034
#define compBsearch                 TCD_0035
#define TCDIMPReleaseTreeData       TCD_0036 
#define TCDIMPReleaseTabData        TCD_0037  
#define DConstrTCD_C_G              TCD_0038
#define DDestrTCD_C_G               TCD_0039 
#define SConstrTCD_C_G              TCD_0040
#define DConstrTCDRbsSS             TCD_0041
#define SConstrTCDRbsSS             TCD_0042
#define SConstrTCDISSADATA          TCD_0043
#define SDestrTCD_C_G               TCD_0044
#define DDestrTCDRbsSS              TCD_0045
#define SDestrTCDRbsSS              TCD_0046
#define SDestrTCDISSADATA           TCD_0047
#define GetRbsSSFkt                 TCD_0048
#define TCDIMPGetTabIDAndTypFromPath TCD_0049
#define TCDIMPGetPathAndTypFromID    TCD_0050
#define TCDIMPReleaseTabTreeData     TCD_0051
#define TCDIMPImportTabTreeData      TCD_0052
#endif

#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDC_H)
#define TCDC_H

#ifdef TCDV2_5
#define TCDVERS 25
#endif
#ifdef TCDV3_0
#define TCDVERS 30
#endif
#ifndef TCDVERS
#error TCD Version muss in Makefiles angegeben werden.
#endif

/*---------
Name        : TCDC.H

Beschreibung: Zentrales Include File fuer die Anwendung
TCD weit gueltig
*----------*/

#include "p09115.h" /* direkte Vektoren */

#define  TCD_TRUE                1
#define  TCD_FALSE               0

/*---------
  Definitionen Opcodes
*----------*/
#define  TCD_OPC_INIT_RBS                    1
#define  TCD_OPC_CALC_FRM                    2
#define  TCD_OPC_CALC_PRC                    3
#define  TCD_OPC_GETNUM_FRM                  4
#define  TCD_OPC_GET_ATTR_VAL                5
#define  TCD_OPC_RESET_RBS                   6
#define  TCD_OPC_SET_PRC                     7
#define  TCD_OPC_RESET_PRC                   8
#define  TCD_OPC_SET_POOLTAB                 9
#define  TCD_OPC_RESET_POOLTAB              10
#define  TCD_OPC_SET_ATTR_VAL               11
#define  TCD_OPC_GET_PRC_INFO               12
#define  TCD_OPC_SET_POOLTAB_I              13
#define  TCD_OPC_RESET_POOLTAB_I            14
#define  TCD_OPC_SET_ATTR_IN_PRC            15
#define  TCD_OPC_SET_TRACE_ON               16
#define  TCD_OPC_SET_TRACE_OFF              17
#define  TCD_OPC_REMOVE_RESULTS             18
#define  TCD_OPC_GET_FIRST_RESULTS_INFO     19
#define  TCD_OPC_GET_NEXT_RESULTS_INFO      20

/*---------
  Definitionen Returncodes
*----------*/
#define  TCD_RC_NOT_OK              0
#define  TCD_RC_OK                  1
#define  TCD_RC_ILLOPC              2
#define  TCD_RC_VERSION_CONFLICT    3
#define  TCD_RC_UNKNOWN_FORM        4
#define  TCD_RC_ILLEGAL_FORM        5
#define  TCD_RC_ILLEGAL_PARAM       6
#define  TCD_RC_UNKNOWN_ATTR        7
#define  TCD_RC_NOT_FOUND           8
#define  TCD_RC_INPUT_MISSING       9
#define  TCD_RC_ILLEGAL_DIVISION   10
#define  TCD_RC_ILLEGAL_TAB_RANGE  11
#define  TCD_RC_STACK_OVERFLOW     12
#define  TCD_RC_CONDITION_FAIL     15
#define  TCD_RC_PAR_ERROR          20
#define  TCD_RC_TAB_IN_POOL        21
#define  TCD_RC_TAB_NOT_IN_POOL    22
#define  TCD_RC_PRC_IN_POOL        23
#define  TCD_RC_PRC_NOT_IN_POOL    24
#define  TCD_RC_UNKNOWN_PROC       25
#define  TCD_RC_PAARLISTEN_ERROR   26
#define  TCD_RC_NO_VALUE_AVAIL     30
#define  TCD_RC_USER_SET_ERROR    900
#define  TCD_RC_INTERNAL_ERR      999
#define  TCD_RC_NO_RETURN         888

/*---------
  allgemeine globale Konstanten
*----------*/
#define TCD_INIT_VARSETLEVEL    9999

/*---------
  Konfigurationsangaben
*----------*/
#define TCD_POOLADMIN_SIZE        20
#define TCD_C_MIN_USER_TYPE_ID    0
#define TCD_C_TABLISTLEN          10
#define TCD_C_MAXPRCCALLNR        2147483647

/*---------
  Definitionen Laengenangaben
*----------*/
#define TCD_DATUM_LNG              9
#define TCD_FRM_DATUM_LNG         20
#define TCD_VGLOP_LNG              3
#define TCD_NAME_LNG              26

/*---------
  Definitionen Aufrufart: (Aufzaehlungstyp)
-----------*/
#define TCD_CALLTYP_ATTR        1
#define TCD_CALLTYP_STA         2
#define TCD_CALLTYP_DYN         3
#define TCD_CALLTYP_STA_UE      4

/*---------
  Definitionen Prefix
-----------*/
#define TCD_PREFIX_TAB            '&'
#define TCD_PREFIX_PRC            '$'
#define TCD_PREFIX_FRM            'F'
#define TCD_PREFIX_ATTR           'A'

/*---------
  Definitionen Formeltypen (Aufzaehlungstyp, Wertevergabe analog Cobol)
-----------*/
#define TCD_FRMTYP_SKAL        1
#define TCD_FRMTYP_TAB1        2
#define TCD_FRMTYP_TAB2        3

/*---------
  Definitionen Belegungswerte PoolEntry
-----------*/
#define  TCD_POOLENT_INIT          0
#define  TCD_POOLENT_USED          1
#define  TCD_POOLENT_I_USED        2
#define  TCD_POOLENT_E_USED        3

/*---------
  Definitionen Assigntype
*----------*/
#define  TCD_DC_USE_NOT            0
#define  TCD_DC_USE_FRM            1
#define  TCD_DC_USE_PRC            2
#define  TCD_DC_USE_TAB            3
#define  TCD_DC_USE_VAL            4

/*----------
  Definitionen Formattypen
-----------*/
#define  TCD_ATTRFMT_SKAL          1
#define  TCD_ATTRFMT_TAB1          2
#define  TCD_ATTRFMT_TAB2          3
#define  TCD_ATTRFMT_VGLO          4
#define  TCD_ATTRFMT_DATE          5

/*----------
  Struktur Bestandsattributtabelle
 ----------*/
  typedef struct tagS_TCDATAB {
        char          Name [TCD_NAME_LNG] ;
        TCD_LONG      ID         ;
        TCD_INT       Index      ;
        TCD_INT       AttrTyp    ;
  } S_TCDATAB     ;

 typedef S_TCDATAB     * P_TCDATAB     ;

/*----------
  Struktur Tabelle aller Attribute
 ----------*/
  typedef struct tagS_ATTRTAB
  {
    TCD_LONG  ID    ;
    TCD_INT   Index ;
  } S_ATTRTAB ;

  typedef S_ATTRTAB    * P_ATTRTAB     ;

/*----------
  Typdefinition systemunabhanegiger Typen
 ----------*/
   typedef  char  TCD_VGLOP [TCD_VGLOP_LNG] ;
   typedef  char  TCD_DATUM [TCD_DATUM_LNG] ;

   typedef TCD_DOUBLE TCDTAB1 ;
   typedef P_TCDTAB   P_TCDTAB1 ;

   typedef TCD_DOUBLE TCDTAB2 ;
   typedef P_TCDTAB   P_TCDTAB2 ;

   typedef P_P_TCD_DOUBLE P_P_TCDTAB ;

/*---------
  Union Attributbelegung
 ----------*/
  typedef  union tagU_TCDVALUE {
           TCD_DOUBLE        Skalar;
           P_TCDTAB1         pTab1 ;
           P_TCDTAB2         pTab2 ;
   } U_TCDVALUE ;

  typedef  union tagU_TCDGVALUE {
           TCD_DOUBLE        Skalar;
           P_TCDTAB          pTab  ;
           TCD_VGLOP         VglOp ;
           TCD_DATUM         Datum ;
   } U_TCDGVALUE ;

/* --
 MUB 2.7.96: neu eingefuehrt, weil wir die TabellenID brauchen
--  */
  typedef  union tagU_TCDWVALUE
  {
           TCD_DOUBLE        Skalar;

           TCD_LONG          TabID ;  /*  die relevanten Attribute */
           P_TCDTAB1         pTab  ;  /*  das Ergebnis */

           TCD_VGLOP         VglOp ;
           TCD_DATUM         Datum ;
   } U_TCDWVALUE ;

  typedef struct tagS_TCDPRCVAL {
          TCD_LONG   PrcID ;
          TCD_LONG   FormelNr ;
          TCD_INT    FormelIx ;
          char       FormelName [TCD_NAME_LNG] ;
          TCD_INT    PoolIx ;
#if TCDVERS > 25
/* Version der Formel zur Pruefung 
		  Formel-Generat gegen Transport-Format */
          TCD_INT    FormelVers;
#endif

 } S_TCDPRCVAL ;

  typedef union  tagU_TCDNDVALUE {
          struct   tagTabData {
             TCD_LONG  TabID ;
             TCD_INT   PoolIx ;
          } TabData  ;
          TCD_DOUBLE Skalar ;
          char       Datum [TCD_DATUM_LNG] ;
          char       VglOp [TCD_VGLOP_LNG];
 } U_TCDNDVALUE ;


  typedef struct tagS_TCDFORMEL {
           TCD_LONG  FormelNr ;
           TCD_INT  FormelIx ;
           char     FormelName [TCD_NAME_LNG] ;
           TCD_INT  IsStaRef ;                                 
#if TCDVERS > 25
/* Version der Formel zur Pruefung 
		   Formel-Generat gegen Transport-Format */
		   TCD_INT  FormelVers;
#endif
 } S_TCDFORMEL ;

  typedef union  tagU_TCDASSIGNVAL {

       S_TCDPRCVAL  Prc    ;
       U_TCDNDVALUE Val    ;
       S_TCDFORMEL  Formel  ;

 } U_TCDASSIGNVAL ;

#define TYP3_NOT_OVERWRITTEN 2

typedef struct tagS_TCDREL_ATTR
{                                 
   TCD_LONG    iBerechnungsNummer;
   /* ID des Attributs                            */
   TCD_LONG    AttrID                  ;  
   /* Typ der Belegung SKALAR, TAB, DATUM , VGLOP */
   TCD_INT     AttrType              :4;  
   /* Flag, ob ein geerbter Wert vorhanden ist    */
   TCD_INT     bGeerbterWertVorhanden:2;  
   /* Flag, ob ein geerbter Wert vorhanden ist    */
   TCD_INT     bNotOverwritten         ;
   /* GGf. Wert hierzu                            */
   U_TCDWVALUE Belegung                ;  

}  S_TCDRELATTR;

typedef S_TCDRELATTR * P_TCDRELATTR ;

/* --
   S_TCDRELATTR_IMP    Relevantes Attribut fuer den Import
--  */
typedef struct tagS_TCDREL_ATTR_IMP
{
   TCD_LONG AttrID;
   TCD_INT  AttrType               : 4;
   TCD_INT  iIndex;

}  S_TCDRELATTR_IMP;

typedef S_TCDRELATTR_IMP * P_TCDRELATTR_IMP ;

/* --
   S_PAARLISTEN_EL    Struktur fuer ein PaarlistenElement
--  */
typedef struct tagS_PAARLISTEN_EL
{
   /* Vektor der relevanten Attribute mit der aktuellen Belegung     */
   LP_VECT          pAttrs;        
   /* lfde. Nummer der aktuellen Berechnung                          */
   TCD_LONG         iBerechnungsNummer; 
   
   TCD_LONG         lTabZeilen;         
   TCD_LONG         lTabSpalten;
   
   /* Typ des Ergebnisses (kann 'NOT_OVERWRITTEN' sein)              */
   TCD_INT          iType;              
   /* Ergebnis hierzu                                                */
   U_TCDWVALUE      Ergebnis;           

}  S_PAARLISTEN_EL;

typedef S_PAARLISTEN_EL * P_PAARLISTEN_EL ;

/* --
   S_PAARLISTE     Struktur zu einem Belegknoten einer BV
   Sie enthaelt 1 sortierten Vektor, 1 Liste und eine maximale Laenge
   fuer die Anzahl Elemente der Paarliste (Belegung,Ergebnis)
--  */
typedef struct tagS_PAARLISTE
{
   TCD_INT iWiederVerwendungsTyp;   /* KnotenTyp 1/2/3     */
   TCD_INT iWiederVerwListenLaenge; /* ListenLaenge maximal */
   TCD_INT iAct ;                   /* letztes Element     */

   /* direkter Vektor von S_ATTR_EL's   */
   LP_VECT pAttrs;                  
   /* direkter Vektor von S_PAARLISTEN_EL's */
   LP_VECT pPaarListenElts;         

}  S_PAARLISTE;

typedef S_PAARLISTE * P_PAARLISTE ; 

/* --
   S_ERGEBNIS_POOL_ELT Element eines PoolErgebnisses
--  */
typedef struct tagS_ERGEBNIS_POOL_ELT
{
   TCD_LONG    ID;
   P_PAARLISTE pPaarListe;

}  S_ERGEBNIS_POOL_ELT;

typedef S_ERGEBNIS_POOL_ELT * P_ERGEBNIS_POOL_ELT ;

/*-----------
  Struktur     Belegungsknoten
------------*/
  typedef struct tagS_TCDPRCNODE
  {
      TCD_LONG         AttrID                  ;
      TCD_INT          NodeID                  ;
      TCD_INT          AttrType                ;
      TCD_INT          AssignType              ;
      U_TCDASSIGNVAL   AssignVal               ;
      TCD_INT          SuccNodeIx              ;
      TCD_INT          AnzSuccNodes            ;
      TCD_INT          Usage                   ;

      P_PAARLISTE      pPaarListe              ;
      P_PAARLISTEN_EL  pResultForGetAttr       ;

      TCD_INT          iWiederVerwendungsTyp   ;
      TCD_INT          iWiederVerwListenLaenge ;
      TCD_INT          iAnzRelAttrs            ;
      TCD_INT          iFirstRelAttrIx         ;

  }   S_TCDPRCNODE ;

 typedef S_TCDPRCNODE  * P_TCDPRCNODE ;

/*-----------
  Struktur Auspraegungs-Belegungs-Information
------------*/
  typedef struct tagS_TCDPRCINFO {
         char  Name [TCD_NAME_LNG] ;
         TCD_LONG  ID ;
         TCD_INT   Formattyp ;
         TCD_INT   Typ ;
         TCD_INT   Klasse ;
         TCD_INT   AnzBeleg ;
         TCD_INT   TabIx ;
         TCD_LONG  RefNodeId ;
 } S_TCDPRCINFO ;

 typedef S_TCDPRCINFO  * P_TCDPRCINFO ;

/*--------
  Struktur LocalData MUB 2.7.96: wird nicht mehr verwendet!
 --------*/
  typedef struct tagS_TCDPRCLOCD {
          TCD_LONG FormelNr     ;
          TCD_INT  Usage        ;
          TCD_INT  Typ          ;
          union   {
              TCD_INT    PoolIx ;
              TCD_DOUBLE Val    ;
          } Data ;
          TCD_LONG  CalcByCallNr ;
   } S_TCDPRCLOCD ;

   typedef S_TCDPRCLOCD * P_TCDPRCLOCD ;

/*---------
  Struktur Header Auspraegungsbaum
----------*/
  typedef struct tagS_TCDPRCHDR {
    TCD_LONG       PrcID        ;
    TCD_LONG       FormelNr     ;
    TCD_INT        AnzPrcTree   ;
    TCD_INT        AnzBelegInfo ;
    TCD_INT        AnzRelAttrs  ;
    TCD_BOOL       FlSetAttrSkal;
    TCD_BOOL       FlSetAttrTab ;
    TCD_BOOL       FlSetAttrVgl ;
    TCD_BOOL       FlSetAttrDat ;
    TCD_BOOL       FlPrcCompl   ;
    TCD_LONG       PrcResIx     ;
    TCD_LONG       PrcCallNr    ;

 } S_TCDPRCHDR     ;


/*---------
  Struktur Auspraegungselement
-----------*/
  typedef union  tagU_TCDPRCELEM
  {
     S_TCDPRCHDR      TreeHdr;
     S_TCDPRCNODE     Node ;
     S_TCDPRCINFO     Info ;     
  }  U_TCDPRCELEM ;

 typedef U_TCDPRCELEM  * P_TCDPRCELEM ;

#define TCDPRCSIZE(pPrc)    (pPrc ? sizeof(S_TCDRELATTR_IMP)*\
                            (TCD_LONG)pPrc->TreeHdr.AnzRelAttrs +\
                            sizeof(U_TCDPRCELEM)*\
                            ( (TCD_LONG)pPrc->TreeHdr.AnzPrcTree +\
                             (TCD_LONG)pPrc->TreeHdr.AnzBelegInfo) : 0)


/*-------
  Datenstruktur Mehrfach-Auspraegung (MultiProc)
 --------*/
  typedef struct tagS_TCDMPRCENTRY {
        TCD_INT              PrcBelegt ;
        TCD_LONG             ID ;
        P_TCDPRCELEM         pPrcData ;
 } S_TCDMPRCENTRY ;

  typedef S_TCDMPRCENTRY * P_TCDMPRCENTRY ;

  typedef struct tagS_TCDMPRCADMIN {
        TCD_INT          Anzahl  ;
        P_TCDMPRCENTRY   Data    ;
 } S_TCDMPRCADMIN ;

 typedef S_TCDMPRCADMIN * P_TCDMPRCADMIN ;

/*--------
  Datenstruktur PoolAdmin
--------*/
  typedef struct tagS_TCDPOOLENTRY {
        TCD_LONG     ID ;
        TCD_INT      Usage ;
        TCD_INT      Typ ;
        TCD_INT      Fmttyp ;
        P_TCD_DOUBLE pData ;
  } S_TCDPOOLENTRY ;

  typedef S_TCDPOOLENTRY * P_TCDPOOLENTRY ;

  typedef struct tagS_TCDPOOLADMIN {
        TCD_INT          Anzahl  ;
        TCD_INT          AnzTabs ;
        TCD_INT          AnzProcs ;
        TCD_INT          AnzTemp  ;
        S_TCDPOOLENTRY * Data    ;
 } S_TCDPOOLADMIN ;

  typedef S_TCDPOOLADMIN * P_TCDPOOLADMIN ;

/*------
  Datenstruktur Kontrollstruktur
--------*/
  typedef struct tagS_TCDRBSINFO {
       char TcdVersion [TCD_DATUM_LNG]   ;
       char TcdRelease [TCD_DATUM_LNG]   ;
       char RbsInterf  [TCD_DATUM_LNG]   ;
       TCD_LONG RbsId ;
   } S_TCDRBSINFO ;

   typedef struct tagS_TCDRCINFO {
       TCD_INT   Rc ;
       TCD_INT   Errc ;
       char FormelName [TCD_NAME_LNG] ;
       TCD_INT   FormelNr ;
       char AttrName   [TCD_NAME_LNG] ;
   } S_TCDRCINFO          ;

   typedef S_TCDRCINFO * P_TCDRCINFO ;


   typedef struct tagS_TCDCTLPAR {

/*-
  Opcode:   TCD_OPC_GET_ATTR_VAL, TCD_OPC_SET_ATTR_VAL
--*/
        struct tagS_TCDPARGA {
           TCD_LONG    ProcID;
           TCD_LONG    ID;
           TCD_LONG    TabID;
           TCD_INT     TabIx ;
           U_TCDGVALUE Val ;
           TCD_INT     Typ ;
           TCD_INT     ProcIx;
        }            GA ;

/*-
  Opcode:   TCD_OPC_SET_POOLTAB
--*/
        struct tagS_TCDPARST {
            TCD_LONG  ID;
            TCD_INT   Dim ;
            P_TCDTAB  pTab ;
            TCD_INT    TabIx ;
        }            ST ;

/*-
  Opcode:   TCD_OPC_RESET_POOLTAB
--*/
        struct tagS_TCDPARRT{
            TCD_LONG  ID;
            P_TCDTAB  pTab ;
        }            RT ;

/*-
  Opcode:   TCD_OPC_SET_PRC
--*/
        struct tagS_TCDPARSP {
            TCD_LONG      ProcID;
            P_TCDPRCELEM  pProc;
            TCD_INT       ProcIx;
        }            SP;

/*-
  Opcode:   TCD_OPC_RESET_PRC
--*/
        struct tagS_TCDPARRP {
            TCD_LONG  ProcID;
            P_TCDPRCELEM  pProc;
        }            RP;

/*-
  Opcode:   TCD_OPC_CALC_FRM , TCD_OPC_CALC_PRC
--*/
        struct tagS_TCDPARCFP {
            TCD_LONG       FormelNr ;
            TCD_LONG       ProcID;
            TCD_INT        Typ ;
            U_TCDVALUE     Value ;
            TCD_INT        ProcIx;
        }            CFP ;

/*-
  Opcode:   TCD_OPC_GETNUM_FRM
--*/
        struct tagS_TCDPARGF {
            char  Name [TCD_NAME_LNG] ;
            TCD_LONG  FormelNr ;
        }            GF ;

/*-
  Opcode:   TCD_OPC_GET_PRC_INFO
--*/
        struct tagS_TCDPRCBINFO {
            TCD_LONG        ProcID;
            TCD_INT         ProcIx;
            P_TCDPRCELEM    pProcInfo;
            TCD_INT         AnzProcInfo ;
        }            PI ;

/*-
  Opcode:   TCD_OPC_REMOVE_RESULTS,
            TCD_OPC_GET_FIRST_RESULTS_INFO,
            TCD_OPC_GET_NEXT_RESULTS_INFO
--*/
        struct tagS_TCDPAR_RESULTPOOL {
            TCD_LONG        ProcID;
            TCD_LONG        lNumOfResults;
            TCD_INT         bFinished;
        }            RESP ;

   } S_TCDCTLPAR ;

   typedef S_TCDCTLPAR * P_TCDCTLPAR ;

   typedef struct tagS_TCDRBSCTL {
          TCD_INT       Opc     ;
          S_TCDRBSINFO  RbsInfo ;
          S_TCDRCINFO   RCInfo  ;
          S_TCDCTLPAR   Par     ;
  } S_TCDRBSCTL ;

   typedef S_TCDRBSCTL * P_TCDRBSCTL ;

/*------
  Datenstruktur Rechenbausteinschnittstelle
 --------*/
   typedef struct tagS_TCDV_F_FLAGS {
         TCD_BOOL       V_In   ;
         TCD_BOOL       F_In   ;
         TCD_BOOL       V_Comp ;
         TCD_BOOL       V_Use  ;
         TCD_BOOL       F_Use  ;
         TCD_BOOL       V_Miss ;
         TCD_BOOL       F_Miss ;
   } S_TCDV_F_FLAGS ;

   typedef S_TCDV_F_FLAGS * P_TCDV_F_FLAGS ;

   typedef struct tagS_TCDV_FLAGS {
         TCD_BOOL       V_In   ;
         TCD_BOOL       V_Use  ;
         TCD_BOOL       V_Miss ;
   } S_TCDV_FLAGS ;

   typedef S_TCDV_FLAGS   * P_TCDV_FLAGS   ;

   typedef struct tagS_TCDSKAL_DATA
   {
        TCD_DOUBLE      Val    ;
        TCD_LONG        Formel ;
        S_TCDV_F_FLAGS  Flags  ;
   } S_TCDSKAL_DATA ;

   typedef S_TCDSKAL_DATA * P_TCDSKAL_DATA ;

   typedef struct tagS_TCDTAB1_DATA
   {
     TCD_LONG        TabID;
     P_TCDTAB1       pVal ;
     TCD_LONG        Formel ;
     S_TCDV_F_FLAGS  Flags ;

   } S_TCDTAB1_DATA ;
   typedef S_TCDTAB1_DATA  * P_TCDTAB1_DATA  ;

   typedef struct tagS_TCDTAB2_DATA
   {
     TCD_LONG        TabID;
     P_TCDTAB2       pVal ;
     TCD_LONG        Formel ;
     S_TCDV_F_FLAGS  Flags ;

   } S_TCDTAB2_DATA ;
   typedef S_TCDTAB2_DATA * P_TCDTAB2_DATA ;

   typedef struct tagS_TCDDAT_DATA {
        char             Val [TCD_DATUM_LNG] ;
        S_TCDV_FLAGS     Flags ;
   } S_TCDDAT_DATA ;

   typedef S_TCDDAT_DATA * P_TCDDAT_DATA ;

   typedef struct tagS_TCDVGL_DATA {
        char            Val [TCD_VGLOP_LNG] ;
        S_TCDV_FLAGS    Flags ;
   } S_TCDVGL_DATA ;

   typedef S_TCDVGL_DATA * P_TCDVGL_DATA ;

   typedef struct tagS_TCD_RBS_SSA
   {
        P_TCDSKAL_DATA    pSkal ;
        P_TCDTAB1_DATA    pTab1 ;
        P_TCDTAB2_DATA    pTab2 ;
        P_TCDDAT_DATA     pDat  ;
        P_TCDVGL_DATA     pVgl  ;
   } S_TCD_RBS_SSA ;

   typedef S_TCD_RBS_SSA  * P_TCD_RBS_SSA ;


   typedef struct tagS_TCDRBS_SS {
       S_TCDRBSCTL       RCTL ;
       S_TCD_RBS_SSA     SSAData   ;
       S_TCDPOOLADMIN    PoolAdmin ;
       S_TCDMPRCADMIN    MPrcAdmin ;
 } S_TCDRBS_SS ;

 typedef S_TCDRBS_SS  * P_TCDRBS_SS ;

  typedef struct tagS_TCDPARATTR_SK {
        TCD_INT      Level ;
        TCD_DOUBLE   Val ;
 } S_TCDPARATTR_SK   ;

 typedef S_TCDPARATTR_SK  * P_TCDPARATTR_SK ;

  typedef struct tagS_TCDPARATTR_VGL {
        TCD_INT      Level;
        char         Val  [TCD_VGLOP_LNG] ;
 } S_TCDPARATTR_VGL  ;

 typedef S_TCDPARATTR_VGL * P_TCDPARATTR_VGL ;

  typedef struct tagS_TCDPARATTR_DAT
  {
        TCD_INT      Level;
        char         Val  [TCD_DATUM_LNG] ;
 } S_TCDPARATTR_DAT  ;

 typedef S_TCDPARATTR_DAT * P_TCDPARATTR_DAT ;

/*-----------
  Struktur Schnittstellendaten (interne Sicht)
-----------*/
  typedef struct tagS_TCDISSADATA
  {
     TCD_INT      AnzSSASkal ;
     TCD_INT      AnzSSATab1 ;
     TCD_INT      AnzSSATab2 ;
     TCD_INT      AnzSSADat ;
     TCD_INT      AnzSSAVgl ;
     TCD_INT      AnzParSkal;
     TCD_INT      AnzParVgl ;
     TCD_INT      AnzParDat ;
     TCD_INT      AnzZeilen ;
     TCD_INT      AnzSpalten ;
     P_TCDSKAL_DATA    pSkal ;
     P_TCDTAB1_DATA    pTab1 ;
     P_TCDTAB2_DATA    pTab2 ;
     P_TCDDAT_DATA     pDat ;
     P_TCDVGL_DATA     pVgl ;
     P_TCDPARATTR_SK   pParSkal ;
     P_TCDPARATTR_VGL  pParVgl;
     P_TCDPARATTR_DAT  pParDat;

 }   S_TCDISSADATA ;
 typedef S_TCDISSADATA * P_TCDISSADATA ;



/*------
Datenstruktur globale Daten des Rechenbausteins;
diese Datenstruktur enthaelt Informationen und Teilstrukturen, die
in den programmierten Funktionen benoetigt werden.
Initialisierung dieser Daten erfolgt mehrstufig.
- beim Init: globaler Pointer pTCDTCD initialisiert (zeigt auf die Str)
pRbsSS zeigt auf die RBS-Schnittstelle
- bei auspraegungsspez. Opcodes werden die Teilstrukturen fuer die
Auspraegung initialisiert, ...
- bei einer neuen Berechnung werden die internen Aufrufschnittstellen
initialisiert
--------*/
  typedef struct tagS_TCD_C_G
  {
      P_TCDRBS_SS      pRbsSS      ;
      P_TCDPRCELEM     pPrcData    ;
      S_TCDPRCHDR *    pPrcHdr     ;
      P_TCDPRCELEM     pPrcTreeNode;
      P_TCDPRCELEM     pInfo       ;
      P_TCDRELATTR_IMP pRelAttrs   ;
      P_TCDMPRCADMIN   pMPrcAdmin  ;
      P_TCDRBSCTL      pRbsCtl     ;
      S_TCDISSADATA    SSAData     ;
      P_TCDPOOLADMIN   pPoolAdmin  ;
      TCD_INT          GlbVarSet   ;
      TCD_LONG         RBS_ID      ;
      TCD_BOOL         ValFound    ;
      TCD_BOOL         FrmFound    ;
      TCD_BOOL         V_Comp      ;
      TCD_BOOL         PrcChg      ;
      void *           pApplIf     ;
      P_TCDTAB         ResTab      ;
      TCD_DOUBLE       ResSkal     ;
      
      TCD_LONG         LastCalcPrcID;
      LP_VECT          pErgebnisPool;
      TCD_LONG         iBerechnungsNummer;
      TCD_INT          iErgPoolIteratorGl;                       
      P_PAARLISTE      pPaarListeNotToSave;
      
      TCD_BOOL         btrace_open;
      TCD_BOOL         btrace_enabled;
      
/* RWE, 10.06.1997: Neues Datenelement fuer Beobachtung
   der Wiederverwendung (ehemals WatchPol-Funktionalitaet) */
      TCD_BOOL         bProtWV;
      
  }   S_TCD_C_G ;
  typedef S_TCD_C_G   * P_TCD_C_G ;
#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDI_H)
#define TCDI_H
/*--------------
    Name        : TCDI.H

    Beschreibung: Include File intern nur f�r C- Generator
                  wird von den fest programmierten Moduln und
                  generierten Moduln benoetigt
    By          : BEGGI
    Datum       : 22.02.94
    Historie    : BEG   28.11.95   Definition Attributklassen
*--------------*/

/*-------------
  Returncodes FrmRet und ValRet (Definitionen analog Cobol) fuer
  Attributmanager
---------------*/
#define TCD_AIRC_CALLVIAFRM    4

/*-------------
  Definitionen Attributtypen (Aufzaehlungstyp)
---------------*/
#define TCD_ATTYP_TAR_SKAL      1
#define TCD_ATTYP_TAR_TAB1      2
#define TCD_ATTYP_TAR_TAB2      3
#define TCD_ATTYP_TAR_DATE      4
#define TCD_ATTYP_TAR_VGLO      5
#define TCD_ATTYP_BST_SKAL      6
#define TCD_ATTYP_BST_TAB1      7
#define TCD_ATTYP_BST_TAB2      8
#define TCD_ATTYP_BST_DATE      9
#define TCD_ATTYP_BST_VGLO     10

#define TCD_ATTRTYP_SKAL        0
#define TCD_ATTRTYP_TAB1        1
#define TCD_ATTRTYP_TAB2        2
#define TCD_ATTRTYP_DATE        3
#define TCD_ATTRTYP_VGLO        4

/*--------------
  Definitionen Attributklasse
---------------*/
#define TCD_ATTRCLASS_TAR       1
#define TCD_ATTRCLASS_BST       6

/*-------------
  Definitionen Errorcodes
---------------*/
#define TCD_UNKNOWN_OPCODE       1
#define TCD_NO_SPACE_IN_TLIST    2
#define TCD_ERR_GETMEM           3
#define TCD_GETEMPTYENTRY        4
#define TCD_NOPOOLADMIN          5
#define TCD_ILLTABFMT            6
#define TCD_UNK_ASSIGNTYP        7
#define TCD_NO_MPRCADMIN         8
#define TCD_EXPPOOLADMIN         9
#define TCD_NO_MEMORY           10
#define TCD_NO_PRCREF           11
#define TCD_ILLFRM_ID           12
#define TCD_ILLFRM_CMP          13
#define TCD_ERR_INIT_FORMEL     14
#define TCD_FRMGEN_OUT_OF_DATE	15
#define TCD_TRPFMT_OUT_OF_DATE	16

/*----------
  Datenstruktur Freigabeliste  Hilfsvariablentabellen
 ------------*/
  typedef struct tagS_TCDTABLIST    {
         TCD_INT        CallOvw ;
         TCD_LONG       CallerID ;
         TCD_LONG       CallFrmNr ;
         TCD_INT        CallType  ;
         P_TCD_DOUBLE   Adr ;
 } S_TCDTABLIST   ;

 typedef  S_TCDTABLIST  * P_TCDTABLIST  ;

/*----------
  Datenstruktur Formelparameter
 ------------*/
  typedef struct tagS_TCD_C_F1 
  {
     char         * FormelName     ;
     TCD_INT        FrmTyp         ;
     TCD_LONG       FrmNr          ;
     TCD_INT        FrmIx          ;
     char         * AttrName       ;
     TCD_INT        CallType       ;
     TCD_LONG       AttrID         ;
     TCD_INT        AttrTyp        ;
     TCD_INT        AttrIx         ;
     TCD_INT        ParIx          ;
     TCD_INT        Ret            ;
     TCD_INT        ExecCond       ;
     P_TCDPRCNODE   PrcFNode       ;
     P_TCDPRCNODE   pNode          ;
     TCD_INT        MinVarSet      ;
     TCD_INT        BegVarSet      ;
     char         * CmpTime        ;
     TCD_INT        Level          ;
     P_TCD_DOUBLE   pVarSkal       ;
     P_P_TCDTAB     pVarTab        ;
     char         * VarDatVgl      ;
     TCD_INT      * VarIndex       ;
     P_TCDTABLIST   FreeList       ;
     TCD_INT        AnzTabList     ;
     TCD_INT        AnzTabListEnt  ;
     P_TCDPRCNODE   NextFNode      ;
     TCD_INT        NextExecCond   ;
     TCD_INT        NextCallType   ;
     struct tagS_TCD_C_F1 * pPrevLevelInfo ;
     P_TCD_C_G      pTCDTCD ;
  } S_TCD_C_F1 ;

  typedef  S_TCD_C_F1 *   P_TCD_C_F1 ;

  typedef struct tagS_TCDFTAB {
        char          FrmName [TCD_NAME_LNG] ;
        void          (* pFormelFunc ) ( P_TCD_C_F1);
        TCD_LONG      FrmNr      ;
        TCD_INT       FrmTyp     ;
        char          Datum [TCD_FRM_DATUM_LNG] ;
  } S_TCDFTAB     ;

 typedef S_TCDFTAB     * P_TCDFTAB     ;

/* extern P_TCD_C_G pTCDTCD ; */

#endif


/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_FCTL_H)
#define TCD_FCTL_H
/*---------------------------------------------------------------------
  Modul:   TCD_FCTL.H
  f�r RBS: LifeTemplate
---------------------------------------------------------------------*/

void  LifeTemF(P_TCD_C_G pTCDTCD) ;
void  LifeTem1(P_TCD_C_F1  pF1 ) ;
void    TCD3FES (P_TCD_C_F1 pMyPar, char * AttrName, TCD_INT Ix,
                       TCD_LONG ID, TCD_INT AttrTyp, TCD_INT ParIx,
                       P_TCD_DOUBLE Var) ;
void    TCD3FET (P_TCD_C_F1 pMyPar, char * AttrName, TCD_INT Ix,
                      TCD_LONG ID, TCD_INT AttrTyp, P_P_TCDTAB Var);
void    TCD3FED (P_TCD_C_F1 pMyPar, char * AttrName,
                      TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                      TCD_INT ParIx, char *Var) ;
void    TCD3FEV (P_TCD_C_F1 pMyPar, char * AttrName,
                      TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                      TCD_INT ParIx, char *Var) ;
TCD_INT TCD3FE1 (P_TCD_C_F1 pMyPar, TCD_BOOL option, char * Name,
                      TCD_LONG ID, TCD_INT FrmNr, P_TCD_DOUBLE Var) ;
TCD_INT TCD3FE2 (P_TCD_C_F1 pMyPar, TCD_BOOL option, char * Name,
                      TCD_LONG ID, TCD_INT FrmNr, P_P_TCDTAB  Var) ;

TCD_INT TCDChkFrm     (P_TCD_C_F1,void *);
void    ClearOverwriteStack(P_TCD_C_G pTCDTCD );

void       TCD3FESaveResult(P_TCD_C_F1);

#endif

/*---------------------------------------------------------------------------

(C) Copyright 1993-2002, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------------*/
#if !defined (TCD_ATTR_H)
#define TCD_ATTR_H
/*---------------------------------------------------------------------
  Datei:        TCD_ATTR.H
  Beschreibung: Attributmanager
---------------------------------------------------------------------*/
TCD_INT   TCDAATS (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAATT (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAABS (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAABT (P_TCD_C_F1 pF1) ;
void      TCDAATD (P_TCD_C_F1 pF1) ;
void      TCDAABD (P_TCD_C_F1 pF1) ;
void      TCDAATV (P_TCD_C_F1 pF1) ;
void      TCDAABV (P_TCD_C_F1 pF1) ;
void      TCDAFT  (P_TCD_C_F1 pF1) ;
void      TCDAFBS (P_TCD_C_F1 pF1) ;
void      TCDAFBT (P_TCD_C_F1 pF1) ;

#endif

#ifndef TCD6_H
#define TCD6_H
/*---------------------------------------------------------------------------

(C) Copyright 1993-2002, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------
  Modul:   TCD_ATTX.h
  TCD-Version: 1
  RBS-Name   : LifeTemplate
  Generiert am 16.12.2019 15:07:18
  Beschreibung: Defines f�r indizierten Zugriff auf die 
                Bestandsattribute des Rechenbausteins
---------------------------------------------------------------------*/



/*  Definition der Attributtabelle */
#include "c90.h"
#ifdef INCL_S_TCDATAB
S_TCDATAB  s_LifeTemp_AttrTab [] = {
 {"e_n_n", 4, 0, 0 },
 {"e_m_n", 8, 1, 0 },
 {"e_TBeg_n", 19, 2, 0 },
 {"e_tarif_nr_n", 20, 3, 0 },
 {"e_tarsumme_ges_n", 27, 4, 0 },
 {"e_tarsumme_pfr_n", 33, 5, 0 },
 {"e_m_o", 103, 6, 0 },
 {"e_n_o", 104, 7, 0 },
 {"e_tarif_nr_o", 121, 8, 0 },
 {"e_TBeg_o", 122, 9, 0 },
 {"e_reserve_o", 125, 10, 0 },
 {"e_tarsumme_ges_o", 134, 11, 0 },
 {"e_NumberOfInsPers_n", 323, 12, 0 },
 {"e_BirthDate_IP1_n", 330, 13, 0 },
 {"e_ea_IP1_n", 332, 14, 0 },
 {"e_ea_IP2_n", 333, 15, 0 },
 {"e_gender_IP1_n", 334, 16, 0 },
 {"e_gender_IP2_n", 335, 17, 0 },
 {"e_BirthDate_IP1_o", 336, 18, 0 },
 {"e_RiskGroup_IP1_n", 338, 19, 0 },
 {"e_RiskGroup_IP2_n", 339, 20, 0 },
 {"e_RiskGroup_IP1_o", 340, 21, 0 },
 {"e_RiskGroup_IP2_o", 341, 22, 0 },
 {"e_NumberOfInsPers_o", 342, 23, 0 },
 {"e_x_IP1_o", 343, 24, 0 },
 {"e_x_IP2_o", 344, 25, 0 },
 {"e_x_IP1_n", 345, 26, 0 },
 {"e_x_IP2_n", 346, 27, 0 },
 {"e_currentDate_n", 348, 28, 0 },
 {"e_CalcDate", 351, 29, 0 },
 {"e_BackOffice", 352, 30, 0 },
 {"CostTab", 357, 0, 2 },
 {"e_AddContrib_n", 359, 31, 0 },
 {"e_PartSurrender_n", 360, 32, 0 },
 {"e_RateClass_n", 361, 33, 0 },
 {"e_RateClass_o", 362, 34, 0 },
 {"e_OccuClass_n", 364, 35, 0 },
 {"e_OccuSurcha_IP1_n", 367, 36, 0 },
 {"e_SportsSurcha_IP1_n", 368, 37, 0 },
 {"e_SportsSurcha_IP1_o", 369, 38, 0 },
 {"e_OccuSurcha_IP1_o", 370, 39, 0 },
 {"e_AddSurcharge_IP1_n", 371, 40, 0 },
 {"e_AddSurcharge_IP2_n", 372, 41, 0 },
 {"e_AddSurcharge_IP1_o", 373, 42, 0 },
 {"e_AddSurcharge_IP2_o", 374, 43, 0 },
 {"e_wo_examination_n", 379, 44, 0 },
 {"e_wo_examination_o", 380, 45, 0 },
 {"e_HealthClass_IP1_n", 381, 46, 0 },
 {"e_HealthSurch_IP1_n", 388, 47, 0 },
 {"e_HealthSurch_IP1_o", 389, 48, 0 },
 {"e_SpecialDiscount_n", 390, 49, 0 },
 {"e_SumDiscount_n", 391, 50, 0 },
 {"AlphaCostMatrix", 393, 1, 2 },
 {"YieldFactorTab", 394, 2, 2 },
 {"MortalityTab", 395, 3, 2 },
 {"e_CommReduction_n", 407, 51, 0 },
 {"e_CommReduction_o", 408, 52, 0 },
 {"e_method", 409, 53, 0 },
 {"e_SumRelation", 410, 54, 0 },
 {"e_manual_reserve_n", 411, 55, 0 },
 {"e_state_n", 423, 56, 0 },
 {"e_StateDetail_n", 424, 57, 0 },
 {"e_DeathBenFactor_n", 425, 58, 0 },
 {"e_benefitPeriod_n", 432, 59, 0 },
 {"e_annutyPayFreq_n", 433, 60, 0 },
 {"e_state_o", 434, 61, 0 },
 {"e_StateDetail_o", 435, 62, 0 },
 {"e_benefitPeriod_o", 436, 63, 0 },
 {"e_annutyPayFreq_o", 437, 64, 0 },
 {"e_DeathBenFactor_o", 438, 65, 0 },
 {"e_guaranteePeriod_n", 439, 66, 0 },
 {"e_guaranteePeriod_o", 440, 67, 0 },
 {"e_SumOfPremiums_o", 442, 68, 0 },
 {"e_SumOfPremiums_n", 443, 69, 0 },
 {"e_manualSumsOfPrem", 444, 70, 0 },
 {"e_manual_LEBK_BWS_n", 445, 71, 0 },
 {"e_manual_LEBK_MON_n", 446, 72, 0 },
 {"e_SpecialDiscount_o", 447, 73, 0 },
 {"e_SumDiscount_o", 448, 74, 0 },
 {"e_GrossPremium_o", 449, 75, 0 },
 {"e_InterestRate", 451, 76, 0 },
 {"e_pfs_n", 452, 77, 0 },
 {"e_pst_n", 453, 78, 0 },
 {"e_pst_o", 454, 79, 0 },
 {"e_StartDateYield_n", 455, 80, 0 },
 {"e_YieldValue_o", 458, 81, 0 },
 {"e_YieldDate_o", 459, 82, 0 },
 {"e_StartDateYield_o", 460, 83, 0 },
 {"e_GrossPremium_n", 461, 84, 0 },
 {"e_YieldValue_n", 462, 85, 0 },
 {"e_YieldDate_n", 463, 86, 0 },
 {"e_AnnuityAmount_n", 475, 87, 0 },
 { "", 0, 0, 0 }
} ;
#else
extern S_TCDATAB  s_LifeTemp_AttrTab [];
#endif

#define LifeTemp_ATAB_SIZE 93

/* Definition der Attributindizes */
/* skalare Attribute */
 #define e_n_n_SKIX 0
 #define e_m_n_SKIX 1
 #define e_TBeg_n_SKIX 2
 #define e_tarif_nr_n_SKIX 3
 #define e_tarsumme_ges_n_SKIX 4
 #define e_tarsumme_pfr_n_SKIX 5
 #define e_m_o_SKIX 6
 #define e_n_o_SKIX 7
 #define e_tarif_nr_o_SKIX 8
 #define e_TBeg_o_SKIX 9
 #define e_reserve_o_SKIX 10
 #define e_tarsumme_ges_o_SKIX 11
 #define e_NumberOfInsPers_n_SKIX 12
 #define e_BirthDate_IP1_n_SKIX 13
 #define e_ea_IP1_n_SKIX 14
 #define e_ea_IP2_n_SKIX 15
 #define e_gender_IP1_n_SKIX 16
 #define e_gender_IP2_n_SKIX 17
 #define e_BirthDate_IP1_o_SKIX 18
 #define e_RiskGroup_IP1_n_SKIX 19
 #define e_RiskGroup_IP2_n_SKIX 20
 #define e_RiskGroup_IP1_o_SKIX 21
 #define e_RiskGroup_IP2_o_SKIX 22
 #define e_NumberOfInsPers_o_SKIX 23
 #define e_x_IP1_o_SKIX 24
 #define e_x_IP2_o_SKIX 25
 #define e_x_IP1_n_SKIX 26
 #define e_x_IP2_n_SKIX 27
 #define e_currentDate_n_SKIX 28
 #define e_CalcDate_SKIX 29
 #define e_BackOffice_SKIX 30
 #define e_AddContrib_n_SKIX 31
 #define e_PartSurrender_n_SKIX 32
 #define e_RateClass_n_SKIX 33
 #define e_RateClass_o_SKIX 34
 #define e_OccuClass_n_SKIX 35
 #define e_OccuSurcha_IP1_n_SKIX 36
 #define e_SportsSurcha_IP1_n_SKIX 37
 #define e_SportsSurcha_IP1_o_SKIX 38
 #define e_OccuSurcha_IP1_o_SKIX 39
 #define e_AddSurcharge_IP1_n_SKIX 40
 #define e_AddSurcharge_IP2_n_SKIX 41
 #define e_AddSurcharge_IP1_o_SKIX 42
 #define e_AddSurcharge_IP2_o_SKIX 43
 #define e_wo_examination_n_SKIX 44
 #define e_wo_examination_o_SKIX 45
 #define e_HealthClass_IP1_n_SKIX 46
 #define e_HealthSurch_IP1_n_SKIX 47
 #define e_HealthSurch_IP1_o_SKIX 48
 #define e_SpecialDiscount_n_SKIX 49
 #define e_SumDiscount_n_SKIX 50
 #define e_CommReduction_n_SKIX 51
 #define e_CommReduction_o_SKIX 52
 #define e_method_SKIX 53
 #define e_SumRelation_SKIX 54
 #define e_manual_reserve_n_SKIX 55
 #define e_state_n_SKIX 56
 #define e_StateDetail_n_SKIX 57
 #define e_DeathBenFactor_n_SKIX 58
 #define e_benefitPeriod_n_SKIX 59
 #define e_annutyPayFreq_n_SKIX 60
 #define e_state_o_SKIX 61
 #define e_StateDetail_o_SKIX 62
 #define e_benefitPeriod_o_SKIX 63
 #define e_annutyPayFreq_o_SKIX 64
 #define e_DeathBenFactor_o_SKIX 65
 #define e_guaranteePeriod_n_SKIX 66
 #define e_guaranteePeriod_o_SKIX 67
 #define e_SumOfPremiums_o_SKIX 68
 #define e_SumOfPremiums_n_SKIX 69
 #define e_manualSumsOfPrem_SKIX 70
 #define e_manual_LEBK_BWS_n_SKIX 71
 #define e_manual_LEBK_MON_n_SKIX 72
 #define e_SpecialDiscount_o_SKIX 73
 #define e_SumDiscount_o_SKIX 74
 #define e_GrossPremium_o_SKIX 75
 #define e_InterestRate_SKIX 76
 #define e_pfs_n_SKIX 77
 #define e_pst_n_SKIX 78
 #define e_pst_o_SKIX 79
 #define e_StartDateYield_n_SKIX 80
 #define e_YieldValue_o_SKIX 81
 #define e_YieldDate_o_SKIX 82
 #define e_StartDateYield_o_SKIX 83
 #define e_GrossPremium_n_SKIX 84
 #define e_YieldValue_n_SKIX 85
 #define e_YieldDate_n_SKIX 86
 #define e_AnnuityAmount_n_SKIX 87

/* Tab1 Attribute */

/* Tab2 Attribute */
 #define CostTab_T2IX 0
 #define AlphaCostMatrix_T2IX 1
 #define YieldFactorTab_T2IX 2
 #define MortalityTab_T2IX 3

/* Datum Attribute */

/* Vgl- Attribute */


/* Konstante f�r Anzahlen */
#define ANZSKALAR 88
#define ANZTAB1 0
#define ANZTAB2 4
#define ANZDATUM 0
#define ANZVERGL 0
#endif //ifndef TCD6_H

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_FRT_H)
#define TCD_FRT_H
/*---------------------------------------------------------------------
    Datei:        TCD_FRT.H

Beschreibung: Modul zur allgemeinen Endebehandlung einer Formelfunktion
By:           BEGGI
Datum:        30.03.94
Historie:     BEG    28.11.95  neue Funktion: TCDSetPD
---------------------------------------------------------------------*/
TCD_INT TCDInit (P_TCD_C_F1 pMyPar, TCD_INT FrmNr, char *fctl_cmptime,
				 TCD_LONG VerNr);
void    TCDFtID (P_TCD_C_F1 pMyPar, char * AttrName,
                 TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                 TCD_INT *Var) ;

void    TCDSetPS (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                 TCD_DOUBLE *Var1, TCD_INT *Var2, TCD_DOUBLE Var3) ;
void    TCDSetPV (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                  char *Var1, TCD_INT *Var2, char *Var3) ;
void    TCDSetPD (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                  char *Var1, TCD_INT *Var2, char *Var3) ;

TCD_INT TCDGetTb (P_TCD_C_F1 pMyPar, P_P_TCDTAB Var) ;
void    TCDIniPS (P_TCD_C_G) ;

void    TCDIniFC (P_TCD_C_G) ;
void    TCDIniFU (P_TCD_C_G) ;
void    TCDIniFM (P_TCD_C_G) ;

void    TCDRetSk (P_TCD_C_F1 pMyPar, P_TCD_DOUBLE  VarSkal) ;
void    TCDRetTb (P_TCD_C_F1 pF1, P_P_TCDTAB  VarTab) ;

/*-----------------
  TraceFunktionsprototypen und Trace Makros
-------------------*/
#ifdef TRACEFKT
void _TCD_TRACE( const char * ,const char * ,const char *,P_TCD_C_G );
void _TCD_TRVAL( const char * , int , double *, double,P_TCD_C_G  ) ;

#define TCD_TRACE(pack,func,text, pTCDTCD)  \
            _TCD_TRACE(pack,func,text, pTCDTCD);
#define TCD_TRVAL(text,type,val1,val2, pTCDTCD) \
            _TCD_TRVAL(text,type,val1,val2, pTCDTCD);
#endif

#define C_TRACEFILE        "CTRACE.TCD"

#endif
  
/* RWE, 10.06.1997   */
/*-----------------
  Funktionsprototypen fuer Wiederverwendungsprotokoll
-------------------*/ 
#ifdef PROTWV
void     SetProtWV             (P_TCD_C_G pIf, TCD_BOOL bProtWV);   
  /* ^Dieser Prototyp ist auch in commands.c enthalten! */
TCD_BOOL ProtWVEnabled         (P_TCD_C_G pIf);
void     ProtWV1               (P_TCD_C_F1 pMyPar); 
void     ProtWV2               (P_TCD_C_F1   pMyPar, 
                                P_TCDPRCNODE pNode,
                                P_PAARLISTE  pPaarListe, 
                                TCD_INT      iFlag);
void     ProtWVString          (char *s);
                                
#define C_PROTWVFILE       "CPROTWV.TCD"
#endif


#include "p09201.h"


void LifeTem1 ( P_TCD_C_F1 pF1 ) ;
void LifeTem5 ( P_TCD_C_F1 pF1 ) ;
void LifeTe15 ( P_TCD_C_F1 pF1 ) ;
void LifeTe16 ( P_TCD_C_F1 pF1 ) ;
void LifeTe23 ( P_TCD_C_F1 pF1 ) ;
void LifeTe29 ( P_TCD_C_F1 pF1 ) ;
void LifeTe83 ( P_TCD_C_F1 pF1 ) ;
void LifeTe84 ( P_TCD_C_F1 pF1 ) ;
void LifeTe99 ( P_TCD_C_F1 pF1 ) ;
void LifeT100 ( P_TCD_C_F1 pF1 ) ;
void LifeT103 ( P_TCD_C_F1 pF1 ) ;
void LifeT112 ( P_TCD_C_F1 pF1 ) ;
void LifeT131 ( P_TCD_C_F1 pF1 ) ;
void LifeT158 ( P_TCD_C_F1 pF1 ) ;
void LifeT235 ( P_TCD_C_F1 pF1 ) ;
void LifeT239 ( P_TCD_C_F1 pF1 ) ;
void LifeT241 ( P_TCD_C_F1 pF1 ) ;
void LifeT243 ( P_TCD_C_F1 pF1 ) ;
void LifeT246 ( P_TCD_C_F1 pF1 ) ;
void LifeT257 ( P_TCD_C_F1 pF1 ) ;
void LifeT258 ( P_TCD_C_F1 pF1 ) ;
void LifeT266 ( P_TCD_C_F1 pF1 ) ;
void LifeT268 ( P_TCD_C_F1 pF1 ) ;
void LifeT272 ( P_TCD_C_F1 pF1 ) ;
void LifeT273 ( P_TCD_C_F1 pF1 ) ;
void LifeT274 ( P_TCD_C_F1 pF1 ) ;
void LifeT275 ( P_TCD_C_F1 pF1 ) ;
void LifeT276 ( P_TCD_C_F1 pF1 ) ;
void LifeT277 ( P_TCD_C_F1 pF1 ) ;
void LifeT278 ( P_TCD_C_F1 pF1 ) ;
void LifeT279 ( P_TCD_C_F1 pF1 ) ;
void LifeT280 ( P_TCD_C_F1 pF1 ) ;
void LifeT281 ( P_TCD_C_F1 pF1 ) ;
void LifeT296 ( P_TCD_C_F1 pF1 ) ;
void LifeT299 ( P_TCD_C_F1 pF1 ) ;
void LifeT303 ( P_TCD_C_F1 pF1 ) ;
void LifeT308 ( P_TCD_C_F1 pF1 ) ;
void LifeT311 ( P_TCD_C_F1 pF1 ) ;
void LifeT313 ( P_TCD_C_F1 pF1 ) ;
void LifeT314 ( P_TCD_C_F1 pF1 ) ;
void LifeT315 ( P_TCD_C_F1 pF1 ) ;
void LifeT316 ( P_TCD_C_F1 pF1 ) ;
void LifeT332 ( P_TCD_C_F1 pF1 ) ;
void LifeT333 ( P_TCD_C_F1 pF1 ) ;
void LifeT340 ( P_TCD_C_F1 pF1 ) ;
void LifeT350 ( P_TCD_C_F1 pF1 ) ;
void LifeT355 ( P_TCD_C_F1 pF1 ) ;
void LifeT364 ( P_TCD_C_F1 pF1 ) ;
void LifeT366 ( P_TCD_C_F1 pF1 ) ;
void LifeT373 ( P_TCD_C_F1 pF1 ) ;
void LifeT388 ( P_TCD_C_F1 pF1 ) ;
void LifeT389 ( P_TCD_C_F1 pF1 ) ;
void LifeT419 ( P_TCD_C_F1 pF1 ) ;
void LifeT424 ( P_TCD_C_F1 pF1 ) ;
void LifeT425 ( P_TCD_C_F1 pF1 ) ;
void LifeT439 ( P_TCD_C_F1 pF1 ) ;
void LifeT442 ( P_TCD_C_F1 pF1 ) ;
void LifeT447 ( P_TCD_C_F1 pF1 ) ;
void LifeT455 ( P_TCD_C_F1 pF1 ) ;
void LifeT464 ( P_TCD_C_F1 pF1 ) ;
void LifeT467 ( P_TCD_C_F1 pF1 ) ;
void LifeT468 ( P_TCD_C_F1 pF1 ) ;
void LifeT474 ( P_TCD_C_F1 pF1 ) ;
void LifeT504 ( P_TCD_C_F1 pF1 ) ;
void LifeT512 ( P_TCD_C_F1 pF1 ) ;
void LifeT524 ( P_TCD_C_F1 pF1 ) ;
void LifeT545 ( P_TCD_C_F1 pF1 ) ;
void LifeT551 ( P_TCD_C_F1 pF1 ) ;
void LifeT552 ( P_TCD_C_F1 pF1 ) ;
void LifeT553 ( P_TCD_C_F1 pF1 ) ;
void LifeT554 ( P_TCD_C_F1 pF1 ) ;
void LifeT555 ( P_TCD_C_F1 pF1 ) ;
void LifeT557 ( P_TCD_C_F1 pF1 ) ;
void LifeT558 ( P_TCD_C_F1 pF1 ) ;
void LifeT559 ( P_TCD_C_F1 pF1 ) ;
void LifeT560 ( P_TCD_C_F1 pF1 ) ;
void LifeT561 ( P_TCD_C_F1 pF1 ) ;
void LifeT563 ( P_TCD_C_F1 pF1 ) ;
void LifeT564 ( P_TCD_C_F1 pF1 ) ;
void LifeT565 ( P_TCD_C_F1 pF1 ) ;
void LifeT566 ( P_TCD_C_F1 pF1 ) ;
void LifeT567 ( P_TCD_C_F1 pF1 ) ;
void LifeT568 ( P_TCD_C_F1 pF1 ) ;
void LifeT569 ( P_TCD_C_F1 pF1 ) ;
void LifeT570 ( P_TCD_C_F1 pF1 ) ;
void LifeT571 ( P_TCD_C_F1 pF1 ) ;
void LifeT572 ( P_TCD_C_F1 pF1 ) ;
void LifeT573 ( P_TCD_C_F1 pF1 ) ;
void LifeT574 ( P_TCD_C_F1 pF1 ) ;
void LifeT575 ( P_TCD_C_F1 pF1 ) ;
void LifeT576 ( P_TCD_C_F1 pF1 ) ;
void LifeT577 ( P_TCD_C_F1 pF1 ) ;
void LifeT578 ( P_TCD_C_F1 pF1 ) ;
void LifeT579 ( P_TCD_C_F1 pF1 ) ;
void LifeT580 ( P_TCD_C_F1 pF1 ) ;
void LifeT581 ( P_TCD_C_F1 pF1 ) ;
void LifeT582 ( P_TCD_C_F1 pF1 ) ;
void LifeT583 ( P_TCD_C_F1 pF1 ) ;
void LifeT584 ( P_TCD_C_F1 pF1 ) ;
void LifeT585 ( P_TCD_C_F1 pF1 ) ;
void LifeT588 ( P_TCD_C_F1 pF1 ) ;
void LifeT589 ( P_TCD_C_F1 pF1 ) ;
void LifeT591 ( P_TCD_C_F1 pF1 ) ;
void LifeT592 ( P_TCD_C_F1 pF1 ) ;
void LifeT593 ( P_TCD_C_F1 pF1 ) ;
void LifeT594 ( P_TCD_C_F1 pF1 ) ;
void LifeT595 ( P_TCD_C_F1 pF1 ) ;
void LifeT596 ( P_TCD_C_F1 pF1 ) ;
void LifeT597 ( P_TCD_C_F1 pF1 ) ;
void LifeT598 ( P_TCD_C_F1 pF1 ) ;
void LifeT599 ( P_TCD_C_F1 pF1 ) ;
void LifeT600 ( P_TCD_C_F1 pF1 ) ;
void LifeT603 ( P_TCD_C_F1 pF1 ) ;
void LifeT604 ( P_TCD_C_F1 pF1 ) ;
void LifeT605 ( P_TCD_C_F1 pF1 ) ;
void LifeT606 ( P_TCD_C_F1 pF1 ) ;
void LifeT607 ( P_TCD_C_F1 pF1 ) ;
void LifeT608 ( P_TCD_C_F1 pF1 ) ;
void LifeT609 ( P_TCD_C_F1 pF1 ) ;
void LifeT610 ( P_TCD_C_F1 pF1 ) ;
void LifeT611 ( P_TCD_C_F1 pF1 ) ;
void LifeT612 ( P_TCD_C_F1 pF1 ) ;
void LifeT613 ( P_TCD_C_F1 pF1 ) ;
void LifeT614 ( P_TCD_C_F1 pF1 ) ;
void LifeT615 ( P_TCD_C_F1 pF1 ) ;
void LifeT616 ( P_TCD_C_F1 pF1 ) ;
void LifeT617 ( P_TCD_C_F1 pF1 ) ;
void LifeT619 ( P_TCD_C_F1 pF1 ) ;
void LifeT620 ( P_TCD_C_F1 pF1 ) ;
void LifeT621 ( P_TCD_C_F1 pF1 ) ;
void LifeT622 ( P_TCD_C_F1 pF1 ) ;
void LifeT623 ( P_TCD_C_F1 pF1 ) ;
void LifeT624 ( P_TCD_C_F1 pF1 ) ;
void LifeT625 ( P_TCD_C_F1 pF1 ) ;
void LifeT626 ( P_TCD_C_F1 pF1 ) ;
void LifeT627 ( P_TCD_C_F1 pF1 ) ;
void LifeT628 ( P_TCD_C_F1 pF1 ) ;
void LifeT629 ( P_TCD_C_F1 pF1 ) ;
void LifeT630 ( P_TCD_C_F1 pF1 ) ;
void LifeT632 ( P_TCD_C_F1 pF1 ) ;
void LifeT633 ( P_TCD_C_F1 pF1 ) ;
void LifeT634 ( P_TCD_C_F1 pF1 ) ;
void LifeT635 ( P_TCD_C_F1 pF1 ) ;
void LifeT636 ( P_TCD_C_F1 pF1 ) ;
void LifeT637 ( P_TCD_C_F1 pF1 ) ;
void LifeT638 ( P_TCD_C_F1 pF1 ) ;
void LifeT639 ( P_TCD_C_F1 pF1 ) ;
void LifeT640 ( P_TCD_C_F1 pF1 ) ;
void LifeT641 ( P_TCD_C_F1 pF1 ) ;
void LifeT642 ( P_TCD_C_F1 pF1 ) ;
void LifeT643 ( P_TCD_C_F1 pF1 ) ;
void LifeT644 ( P_TCD_C_F1 pF1 ) ;
void LifeT645 ( P_TCD_C_F1 pF1 ) ;
void LifeT646 ( P_TCD_C_F1 pF1 ) ;
void LifeT647 ( P_TCD_C_F1 pF1 ) ;
void LifeT648 ( P_TCD_C_F1 pF1 ) ;
void LifeT649 ( P_TCD_C_F1 pF1 ) ;
void LifeT650 ( P_TCD_C_F1 pF1 ) ;
void LifeT651 ( P_TCD_C_F1 pF1 ) ;
void LifeT652 ( P_TCD_C_F1 pF1 ) ;
void LifeT653 ( P_TCD_C_F1 pF1 ) ;
void LifeT654 ( P_TCD_C_F1 pF1 ) ;
void LifeT655 ( P_TCD_C_F1 pF1 ) ;
void LifeT656 ( P_TCD_C_F1 pF1 ) ;
void LifeT657 ( P_TCD_C_F1 pF1 ) ;
void LifeT658 ( P_TCD_C_F1 pF1 ) ;
void LifeT659 ( P_TCD_C_F1 pF1 ) ;
void LifeT660 ( P_TCD_C_F1 pF1 ) ;
void LifeT661 ( P_TCD_C_F1 pF1 ) ;
void LifeT662 ( P_TCD_C_F1 pF1 ) ;
void LifeT663 ( P_TCD_C_F1 pF1 ) ;
void LifeT664 ( P_TCD_C_F1 pF1 ) ;
void LifeT665 ( P_TCD_C_F1 pF1 ) ;
void LifeT666 ( P_TCD_C_F1 pF1 ) ;
void LifeT667 ( P_TCD_C_F1 pF1 ) ;
void LifeT668 ( P_TCD_C_F1 pF1 ) ;
void LifeT669 ( P_TCD_C_F1 pF1 ) ;
void LifeT670 ( P_TCD_C_F1 pF1 ) ;
void LifeT671 ( P_TCD_C_F1 pF1 ) ;
void LifeT672 ( P_TCD_C_F1 pF1 ) ;
void LifeT673 ( P_TCD_C_F1 pF1 ) ;
void LifeT674 ( P_TCD_C_F1 pF1 ) ;
void LifeT675 ( P_TCD_C_F1 pF1 ) ;
void LifeT676 ( P_TCD_C_F1 pF1 ) ;
void LifeT677 ( P_TCD_C_F1 pF1 ) ;
void LifeT678 ( P_TCD_C_F1 pF1 ) ;
void LifeT679 ( P_TCD_C_F1 pF1 ) ;
void LifeT680 ( P_TCD_C_F1 pF1 ) ;
void LifeT681 ( P_TCD_C_F1 pF1 ) ;
void LifeT682 ( P_TCD_C_F1 pF1 ) ;
void LifeT683 ( P_TCD_C_F1 pF1 ) ;
void LifeT684 ( P_TCD_C_F1 pF1 ) ;
void LifeT685 ( P_TCD_C_F1 pF1 ) ;
void LifeT686 ( P_TCD_C_F1 pF1 ) ;
void LifeT687 ( P_TCD_C_F1 pF1 ) ;
void LifeT688 ( P_TCD_C_F1 pF1 ) ;
void LifeT689 ( P_TCD_C_F1 pF1 ) ;
void LifeT690 ( P_TCD_C_F1 pF1 ) ;
void LifeT691 ( P_TCD_C_F1 pF1 ) ;
void LifeT692 ( P_TCD_C_F1 pF1 ) ;
void LifeT693 ( P_TCD_C_F1 pF1 ) ;
void LifeT694 ( P_TCD_C_F1 pF1 ) ;
void LifeT695 ( P_TCD_C_F1 pF1 ) ;
void LifeT697 ( P_TCD_C_F1 pF1 ) ;
void LifeT699 ( P_TCD_C_F1 pF1 ) ;
void LifeT700 ( P_TCD_C_F1 pF1 ) ;
void LifeT701 ( P_TCD_C_F1 pF1 ) ;
void LifeT702 ( P_TCD_C_F1 pF1 ) ;
void LifeT703 ( P_TCD_C_F1 pF1 ) ;
void LifeT704 ( P_TCD_C_F1 pF1 ) ;
void LifeT705 ( P_TCD_C_F1 pF1 ) ;
void LifeT706 ( P_TCD_C_F1 pF1 ) ;
void LifeT707 ( P_TCD_C_F1 pF1 ) ;
void LifeT708 ( P_TCD_C_F1 pF1 ) ;
void LifeT709 ( P_TCD_C_F1 pF1 ) ;
void LifeT710 ( P_TCD_C_F1 pF1 ) ;
void LifeT711 ( P_TCD_C_F1 pF1 ) ;
void LifeT712 ( P_TCD_C_F1 pF1 ) ;
void LifeT713 ( P_TCD_C_F1 pF1 ) ;
void LifeT714 ( P_TCD_C_F1 pF1 ) ;
void LifeT715 ( P_TCD_C_F1 pF1 ) ;
void LifeT716 ( P_TCD_C_F1 pF1 ) ;
void LifeT717 ( P_TCD_C_F1 pF1 ) ;
void LifeT718 ( P_TCD_C_F1 pF1 ) ;
void LifeT719 ( P_TCD_C_F1 pF1 ) ;
void LifeT720 ( P_TCD_C_F1 pF1 ) ;
void LifeT721 ( P_TCD_C_F1 pF1 ) ;
void LifeT722 ( P_TCD_C_F1 pF1 ) ;
void LifeT723 ( P_TCD_C_F1 pF1 ) ;
void LifeT724 ( P_TCD_C_F1 pF1 ) ;
void LifeT725 ( P_TCD_C_F1 pF1 ) ;
void LifeT726 ( P_TCD_C_F1 pF1 ) ;
void LifeT727 ( P_TCD_C_F1 pF1 ) ;
void LifeT729 ( P_TCD_C_F1 pF1 ) ;
void LifeT730 ( P_TCD_C_F1 pF1 ) ;
void LifeT731 ( P_TCD_C_F1 pF1 ) ;
void LifeT732 ( P_TCD_C_F1 pF1 ) ;
void LifeT733 ( P_TCD_C_F1 pF1 ) ;
void LifeT734 ( P_TCD_C_F1 pF1 ) ;
void LifeT735 ( P_TCD_C_F1 pF1 ) ;
void LifeT736 ( P_TCD_C_F1 pF1 ) ;
void LifeT737 ( P_TCD_C_F1 pF1 ) ;
void LifeT738 ( P_TCD_C_F1 pF1 ) ;
void LifeT739 ( P_TCD_C_F1 pF1 ) ;
void LifeT740 ( P_TCD_C_F1 pF1 ) ;
void LifeT741 ( P_TCD_C_F1 pF1 ) ;
void LifeT742 ( P_TCD_C_F1 pF1 ) ;
void LifeT743 ( P_TCD_C_F1 pF1 ) ;
void LifeT744 ( P_TCD_C_F1 pF1 ) ;
void LifeT745 ( P_TCD_C_F1 pF1 ) ;
void LifeT746 ( P_TCD_C_F1 pF1 ) ;
void LifeT747 ( P_TCD_C_F1 pF1 ) ;
void LifeT748 ( P_TCD_C_F1 pF1 ) ;
void LifeT749 ( P_TCD_C_F1 pF1 ) ;
void LifeT750 ( P_TCD_C_F1 pF1 ) ;
void LifeT751 ( P_TCD_C_F1 pF1 ) ;
void LifeT752 ( P_TCD_C_F1 pF1 ) ;
void LifeT753 ( P_TCD_C_F1 pF1 ) ;
void LifeT754 ( P_TCD_C_F1 pF1 ) ;
void LifeT755 ( P_TCD_C_F1 pF1 ) ;
void LifeT756 ( P_TCD_C_F1 pF1 ) ;
void LifeT757 ( P_TCD_C_F1 pF1 ) ;
void LifeT758 ( P_TCD_C_F1 pF1 ) ;
void LifeT759 ( P_TCD_C_F1 pF1 ) ;
void LifeT760 ( P_TCD_C_F1 pF1 ) ;
void LifeT761 ( P_TCD_C_F1 pF1 ) ;
void LifeT762 ( P_TCD_C_F1 pF1 ) ;
void LifeT763 ( P_TCD_C_F1 pF1 ) ;
void LifeT764 ( P_TCD_C_F1 pF1 ) ;
void LifeT765 ( P_TCD_C_F1 pF1 ) ;
void LifeT766 ( P_TCD_C_F1 pF1 ) ;
void LifeT767 ( P_TCD_C_F1 pF1 ) ;
void LifeT768 ( P_TCD_C_F1 pF1 ) ;
void LifeT769 ( P_TCD_C_F1 pF1 ) ;
void LifeT770 ( P_TCD_C_F1 pF1 ) ;
void LifeT771 ( P_TCD_C_F1 pF1 ) ;
void LifeT772 ( P_TCD_C_F1 pF1 ) ;
void LifeT773 ( P_TCD_C_F1 pF1 ) ;
void LifeT774 ( P_TCD_C_F1 pF1 ) ;
void LifeT775 ( P_TCD_C_F1 pF1 ) ;
void LifeT776 ( P_TCD_C_F1 pF1 ) ;
void LifeT777 ( P_TCD_C_F1 pF1 ) ;
void LifeT778 ( P_TCD_C_F1 pF1 ) ;
void LifeT779 ( P_TCD_C_F1 pF1 ) ;
void LifeT780 ( P_TCD_C_F1 pF1 ) ;
void LifeT781 ( P_TCD_C_F1 pF1 ) ;
void LifeT782 ( P_TCD_C_F1 pF1 ) ;


const S_ATTRTAB  AllAttrTab_LifeTemp[] =
{
 { 4, 0},
 { 8, 1},
 { 19, 2},
 { 20, 3},
 { 27, 4},
 { 33, 5},
 { 103, 6},
 { 104, 7},
 { 121, 8},
 { 122, 9},
 { 125, 10},
 { 134, 11},
 { 158, 88},
 { 163, 89},
 { 164, 90},
 { 165, 91},
 { 166, 92},
 { 169, 93},
 { 170, 94},
 { 205, 95},
 { 218, 96},
 { 222, 97},
 { 223, 98},
 { 233, 99},
 { 261, 100},
 { 275, 101},
 { 278, 102},
 { 280, 103},
 { 282, 104},
 { 283, 105},
 { 286, 106},
 { 309, 107},
 { 311, 108},
 { 315, 109},
 { 316, 110},
 { 318, 111},
 { 321, 112},
 { 323, 12},
 { 324, 113},
 { 325, 114},
 { 327, 115},
 { 328, 116},
 { 329, 117},
 { 330, 13},
 { 332, 14},
 { 333, 15},
 { 334, 16},
 { 335, 17},
 { 336, 18},
 { 338, 19},
 { 339, 20},
 { 340, 21},
 { 341, 22},
 { 342, 23},
 { 343, 24},
 { 344, 25},
 { 345, 26},
 { 346, 27},
 { 347, 118},
 { 348, 28},
 { 349, 119},
 { 350, 120},
 { 351, 29},
 { 352, 30},
 { 355, 121},
 { 356, 122},
 { 357, 0},
 { 359, 31},
 { 360, 32},
 { 361, 33},
 { 362, 34},
 { 363, 123},
 { 364, 35},
 { 365, 124},
 { 366, 125},
 { 367, 36},
 { 368, 37},
 { 369, 38},
 { 370, 39},
 { 371, 40},
 { 372, 41},
 { 373, 42},
 { 374, 43},
 { 375, 126},
 { 376, 127},
 { 377, 128},
 { 378, 129},
 { 379, 44},
 { 380, 45},
 { 381, 46},
 { 382, 130},
 { 383, 131},
 { 384, 132},
 { 385, 133},
 { 386, 134},
 { 387, 135},
 { 388, 47},
 { 389, 48},
 { 390, 49},
 { 391, 50},
 { 393, 0},
 { 394, 0},
 { 395, 0},
 { 396, 136},
 { 397, 137},
 { 398, 138},
 { 399, 139},
 { 400, 140},
 { 401, 141},
 { 402, 142},
 { 403, 143},
 { 404, 144},
 { 405, 145},
 { 406, 146},
 { 407, 51},
 { 408, 52},
 { 409, 53},
 { 410, 54},
 { 411, 55},
 { 412, 147},
 { 413, 148},
 { 415, 149},
 { 416, 150},
 { 417, 151},
 { 418, 152},
 { 419, 153},
 { 420, 154},
 { 421, 155},
 { 422, 156},
 { 423, 56},
 { 424, 57},
 { 425, 58},
 { 426, 157},
 { 427, 158},
 { 428, 159},
 { 429, 160},
 { 431, 161},
 { 432, 59},
 { 433, 60},
 { 434, 61},
 { 435, 62},
 { 436, 63},
 { 437, 64},
 { 438, 65},
 { 439, 66},
 { 440, 67},
 { 441, 162},
 { 442, 68},
 { 443, 69},
 { 444, 70},
 { 445, 71},
 { 446, 72},
 { 447, 73},
 { 448, 74},
 { 449, 75},
 { 451, 76},
 { 452, 77},
 { 453, 78},
 { 454, 79},
 { 455, 80},
 { 456, 163},
 { 457, 164},
 { 458, 81},
 { 459, 82},
 { 460, 83},
 { 461, 84},
 { 462, 85},
 { 463, 86},
 { 464, 165},
 { 465, 166},
 { 466, 167},
 { 468, 168},
 { 469, 169},
 { 470, 170},
 { 471, 171},
 { 472, 172},
 { 475, 87},
 { 0, 0 }
} ;
      
#define ALLATTR_SIZE_LifeTemp 178
#define ALLATTR_MAXID_LifeTemp 475
/*---------------------------------------------------------------------
   Prototypen der internen Funktionen
---------------------------------------------------------------------*/
P_TCDFTAB         FindFrmNr        (P_TCD_C_G pTCDTCD,char * FName);
P_TCDFTAB         FindFrminTab     (TCD_LONG FrmNr, TCD_INT * FTabIx);

P_TCD_C_F1        GetMemFPar       () ;
void              FCall            (P_TCD_C_F1 pF1) ;
int               GetActSettings   (P_TCD_C_F1,P_PAARLISTE);

int               GetFromSS        (P_TCD_C_F1,P_TCDRELATTR);
int               GetIndexToSS     (TCD_LONG);

int               GetFromUeS       (P_TCD_C_F1,P_TCDRELATTR);
int               GetIndexToUeS    (TCD_LONG);

int               FindAttrInTree   (P_TCD_C_F1,P_TCDRELATTR);
int               cmpgle           (const void * , const void *);
void              ClearOverwriteStack(P_TCD_C_G pTCDTCD );

/*---------------------------------------------------------------------
   Modulglobale Daten
---------------------------------------------------------------------*/
/*GENPRCINFO*/
void LifeTem1 ( P_TCD_C_F1 pF1 ) ;
void LifeTem5 ( P_TCD_C_F1 pF1 ) ;
void LifeTe15 ( P_TCD_C_F1 pF1 ) ;
void LifeTe16 ( P_TCD_C_F1 pF1 ) ;
void LifeTe23 ( P_TCD_C_F1 pF1 ) ;
void LifeTe29 ( P_TCD_C_F1 pF1 ) ;
void LifeTe83 ( P_TCD_C_F1 pF1 ) ;
void LifeTe84 ( P_TCD_C_F1 pF1 ) ;
void LifeTe99 ( P_TCD_C_F1 pF1 ) ;
void LifeT100 ( P_TCD_C_F1 pF1 ) ;
void LifeT103 ( P_TCD_C_F1 pF1 ) ;
void LifeT112 ( P_TCD_C_F1 pF1 ) ;
void LifeT131 ( P_TCD_C_F1 pF1 ) ;
void LifeT158 ( P_TCD_C_F1 pF1 ) ;
void LifeT235 ( P_TCD_C_F1 pF1 ) ;
void LifeT239 ( P_TCD_C_F1 pF1 ) ;
void LifeT241 ( P_TCD_C_F1 pF1 ) ;
void LifeT243 ( P_TCD_C_F1 pF1 ) ;
void LifeT246 ( P_TCD_C_F1 pF1 ) ;
void LifeT257 ( P_TCD_C_F1 pF1 ) ;
void LifeT258 ( P_TCD_C_F1 pF1 ) ;
void LifeT266 ( P_TCD_C_F1 pF1 ) ;
void LifeT268 ( P_TCD_C_F1 pF1 ) ;
void LifeT272 ( P_TCD_C_F1 pF1 ) ;
void LifeT273 ( P_TCD_C_F1 pF1 ) ;
void LifeT274 ( P_TCD_C_F1 pF1 ) ;
void LifeT275 ( P_TCD_C_F1 pF1 ) ;
void LifeT276 ( P_TCD_C_F1 pF1 ) ;
void LifeT277 ( P_TCD_C_F1 pF1 ) ;
void LifeT278 ( P_TCD_C_F1 pF1 ) ;
void LifeT279 ( P_TCD_C_F1 pF1 ) ;
void LifeT280 ( P_TCD_C_F1 pF1 ) ;
void LifeT281 ( P_TCD_C_F1 pF1 ) ;
void LifeT296 ( P_TCD_C_F1 pF1 ) ;
void LifeT299 ( P_TCD_C_F1 pF1 ) ;
void LifeT303 ( P_TCD_C_F1 pF1 ) ;
void LifeT308 ( P_TCD_C_F1 pF1 ) ;
void LifeT311 ( P_TCD_C_F1 pF1 ) ;
void LifeT313 ( P_TCD_C_F1 pF1 ) ;
void LifeT314 ( P_TCD_C_F1 pF1 ) ;
void LifeT315 ( P_TCD_C_F1 pF1 ) ;
void LifeT316 ( P_TCD_C_F1 pF1 ) ;
void LifeT332 ( P_TCD_C_F1 pF1 ) ;
void LifeT333 ( P_TCD_C_F1 pF1 ) ;
void LifeT340 ( P_TCD_C_F1 pF1 ) ;
void LifeT350 ( P_TCD_C_F1 pF1 ) ;
void LifeT355 ( P_TCD_C_F1 pF1 ) ;
void LifeT364 ( P_TCD_C_F1 pF1 ) ;
void LifeT366 ( P_TCD_C_F1 pF1 ) ;
void LifeT373 ( P_TCD_C_F1 pF1 ) ;
void LifeT388 ( P_TCD_C_F1 pF1 ) ;
void LifeT389 ( P_TCD_C_F1 pF1 ) ;
void LifeT419 ( P_TCD_C_F1 pF1 ) ;
void LifeT424 ( P_TCD_C_F1 pF1 ) ;
void LifeT425 ( P_TCD_C_F1 pF1 ) ;
void LifeT439 ( P_TCD_C_F1 pF1 ) ;
void LifeT442 ( P_TCD_C_F1 pF1 ) ;
void LifeT447 ( P_TCD_C_F1 pF1 ) ;
void LifeT455 ( P_TCD_C_F1 pF1 ) ;
void LifeT464 ( P_TCD_C_F1 pF1 ) ;
void LifeT467 ( P_TCD_C_F1 pF1 ) ;
void LifeT468 ( P_TCD_C_F1 pF1 ) ;
void LifeT474 ( P_TCD_C_F1 pF1 ) ;
void LifeT504 ( P_TCD_C_F1 pF1 ) ;
void LifeT512 ( P_TCD_C_F1 pF1 ) ;
void LifeT524 ( P_TCD_C_F1 pF1 ) ;
void LifeT545 ( P_TCD_C_F1 pF1 ) ;
void LifeT551 ( P_TCD_C_F1 pF1 ) ;
void LifeT552 ( P_TCD_C_F1 pF1 ) ;
void LifeT553 ( P_TCD_C_F1 pF1 ) ;
void LifeT554 ( P_TCD_C_F1 pF1 ) ;
void LifeT555 ( P_TCD_C_F1 pF1 ) ;
void LifeT557 ( P_TCD_C_F1 pF1 ) ;
void LifeT558 ( P_TCD_C_F1 pF1 ) ;
void LifeT559 ( P_TCD_C_F1 pF1 ) ;
void LifeT560 ( P_TCD_C_F1 pF1 ) ;
void LifeT561 ( P_TCD_C_F1 pF1 ) ;
void LifeT563 ( P_TCD_C_F1 pF1 ) ;
void LifeT564 ( P_TCD_C_F1 pF1 ) ;
void LifeT565 ( P_TCD_C_F1 pF1 ) ;
void LifeT566 ( P_TCD_C_F1 pF1 ) ;
void LifeT567 ( P_TCD_C_F1 pF1 ) ;
void LifeT568 ( P_TCD_C_F1 pF1 ) ;
void LifeT569 ( P_TCD_C_F1 pF1 ) ;
void LifeT570 ( P_TCD_C_F1 pF1 ) ;
void LifeT571 ( P_TCD_C_F1 pF1 ) ;
void LifeT572 ( P_TCD_C_F1 pF1 ) ;
void LifeT573 ( P_TCD_C_F1 pF1 ) ;
void LifeT574 ( P_TCD_C_F1 pF1 ) ;
void LifeT575 ( P_TCD_C_F1 pF1 ) ;
void LifeT576 ( P_TCD_C_F1 pF1 ) ;
void LifeT577 ( P_TCD_C_F1 pF1 ) ;
void LifeT578 ( P_TCD_C_F1 pF1 ) ;
void LifeT579 ( P_TCD_C_F1 pF1 ) ;
void LifeT580 ( P_TCD_C_F1 pF1 ) ;
void LifeT581 ( P_TCD_C_F1 pF1 ) ;
void LifeT582 ( P_TCD_C_F1 pF1 ) ;
void LifeT583 ( P_TCD_C_F1 pF1 ) ;
void LifeT584 ( P_TCD_C_F1 pF1 ) ;
void LifeT585 ( P_TCD_C_F1 pF1 ) ;
void LifeT588 ( P_TCD_C_F1 pF1 ) ;
void LifeT589 ( P_TCD_C_F1 pF1 ) ;
void LifeT591 ( P_TCD_C_F1 pF1 ) ;
void LifeT592 ( P_TCD_C_F1 pF1 ) ;
void LifeT593 ( P_TCD_C_F1 pF1 ) ;
void LifeT594 ( P_TCD_C_F1 pF1 ) ;
void LifeT595 ( P_TCD_C_F1 pF1 ) ;
void LifeT596 ( P_TCD_C_F1 pF1 ) ;
void LifeT597 ( P_TCD_C_F1 pF1 ) ;
void LifeT598 ( P_TCD_C_F1 pF1 ) ;
void LifeT599 ( P_TCD_C_F1 pF1 ) ;
void LifeT600 ( P_TCD_C_F1 pF1 ) ;
void LifeT603 ( P_TCD_C_F1 pF1 ) ;
void LifeT604 ( P_TCD_C_F1 pF1 ) ;
void LifeT605 ( P_TCD_C_F1 pF1 ) ;
void LifeT606 ( P_TCD_C_F1 pF1 ) ;
void LifeT607 ( P_TCD_C_F1 pF1 ) ;
void LifeT608 ( P_TCD_C_F1 pF1 ) ;
void LifeT609 ( P_TCD_C_F1 pF1 ) ;
void LifeT610 ( P_TCD_C_F1 pF1 ) ;
void LifeT611 ( P_TCD_C_F1 pF1 ) ;
void LifeT612 ( P_TCD_C_F1 pF1 ) ;
void LifeT613 ( P_TCD_C_F1 pF1 ) ;
void LifeT614 ( P_TCD_C_F1 pF1 ) ;
void LifeT615 ( P_TCD_C_F1 pF1 ) ;
void LifeT616 ( P_TCD_C_F1 pF1 ) ;
void LifeT617 ( P_TCD_C_F1 pF1 ) ;
void LifeT619 ( P_TCD_C_F1 pF1 ) ;
void LifeT620 ( P_TCD_C_F1 pF1 ) ;
void LifeT621 ( P_TCD_C_F1 pF1 ) ;
void LifeT622 ( P_TCD_C_F1 pF1 ) ;
void LifeT623 ( P_TCD_C_F1 pF1 ) ;
void LifeT624 ( P_TCD_C_F1 pF1 ) ;
void LifeT625 ( P_TCD_C_F1 pF1 ) ;
void LifeT626 ( P_TCD_C_F1 pF1 ) ;
void LifeT627 ( P_TCD_C_F1 pF1 ) ;
void LifeT628 ( P_TCD_C_F1 pF1 ) ;
void LifeT629 ( P_TCD_C_F1 pF1 ) ;
void LifeT630 ( P_TCD_C_F1 pF1 ) ;
void LifeT632 ( P_TCD_C_F1 pF1 ) ;
void LifeT633 ( P_TCD_C_F1 pF1 ) ;
void LifeT634 ( P_TCD_C_F1 pF1 ) ;
void LifeT635 ( P_TCD_C_F1 pF1 ) ;
void LifeT636 ( P_TCD_C_F1 pF1 ) ;
void LifeT637 ( P_TCD_C_F1 pF1 ) ;
void LifeT638 ( P_TCD_C_F1 pF1 ) ;
void LifeT639 ( P_TCD_C_F1 pF1 ) ;
void LifeT640 ( P_TCD_C_F1 pF1 ) ;
void LifeT641 ( P_TCD_C_F1 pF1 ) ;
void LifeT642 ( P_TCD_C_F1 pF1 ) ;
void LifeT643 ( P_TCD_C_F1 pF1 ) ;
void LifeT644 ( P_TCD_C_F1 pF1 ) ;
void LifeT645 ( P_TCD_C_F1 pF1 ) ;
void LifeT646 ( P_TCD_C_F1 pF1 ) ;
void LifeT647 ( P_TCD_C_F1 pF1 ) ;
void LifeT648 ( P_TCD_C_F1 pF1 ) ;
void LifeT649 ( P_TCD_C_F1 pF1 ) ;
void LifeT650 ( P_TCD_C_F1 pF1 ) ;
void LifeT651 ( P_TCD_C_F1 pF1 ) ;
void LifeT652 ( P_TCD_C_F1 pF1 ) ;
void LifeT653 ( P_TCD_C_F1 pF1 ) ;
void LifeT654 ( P_TCD_C_F1 pF1 ) ;
void LifeT655 ( P_TCD_C_F1 pF1 ) ;
void LifeT656 ( P_TCD_C_F1 pF1 ) ;
void LifeT657 ( P_TCD_C_F1 pF1 ) ;
void LifeT658 ( P_TCD_C_F1 pF1 ) ;
void LifeT659 ( P_TCD_C_F1 pF1 ) ;
void LifeT660 ( P_TCD_C_F1 pF1 ) ;
void LifeT661 ( P_TCD_C_F1 pF1 ) ;
void LifeT662 ( P_TCD_C_F1 pF1 ) ;
void LifeT663 ( P_TCD_C_F1 pF1 ) ;
void LifeT664 ( P_TCD_C_F1 pF1 ) ;
void LifeT665 ( P_TCD_C_F1 pF1 ) ;
void LifeT666 ( P_TCD_C_F1 pF1 ) ;
void LifeT667 ( P_TCD_C_F1 pF1 ) ;
void LifeT668 ( P_TCD_C_F1 pF1 ) ;
void LifeT669 ( P_TCD_C_F1 pF1 ) ;
void LifeT670 ( P_TCD_C_F1 pF1 ) ;
void LifeT671 ( P_TCD_C_F1 pF1 ) ;
void LifeT672 ( P_TCD_C_F1 pF1 ) ;
void LifeT673 ( P_TCD_C_F1 pF1 ) ;
void LifeT674 ( P_TCD_C_F1 pF1 ) ;
void LifeT675 ( P_TCD_C_F1 pF1 ) ;
void LifeT676 ( P_TCD_C_F1 pF1 ) ;
void LifeT677 ( P_TCD_C_F1 pF1 ) ;
void LifeT678 ( P_TCD_C_F1 pF1 ) ;
void LifeT679 ( P_TCD_C_F1 pF1 ) ;
void LifeT680 ( P_TCD_C_F1 pF1 ) ;
void LifeT681 ( P_TCD_C_F1 pF1 ) ;
void LifeT682 ( P_TCD_C_F1 pF1 ) ;
void LifeT683 ( P_TCD_C_F1 pF1 ) ;
void LifeT684 ( P_TCD_C_F1 pF1 ) ;
void LifeT685 ( P_TCD_C_F1 pF1 ) ;
void LifeT686 ( P_TCD_C_F1 pF1 ) ;
void LifeT687 ( P_TCD_C_F1 pF1 ) ;
void LifeT688 ( P_TCD_C_F1 pF1 ) ;
void LifeT689 ( P_TCD_C_F1 pF1 ) ;
void LifeT690 ( P_TCD_C_F1 pF1 ) ;
void LifeT691 ( P_TCD_C_F1 pF1 ) ;
void LifeT692 ( P_TCD_C_F1 pF1 ) ;
void LifeT693 ( P_TCD_C_F1 pF1 ) ;
void LifeT694 ( P_TCD_C_F1 pF1 ) ;
void LifeT695 ( P_TCD_C_F1 pF1 ) ;
void LifeT697 ( P_TCD_C_F1 pF1 ) ;
void LifeT699 ( P_TCD_C_F1 pF1 ) ;
void LifeT700 ( P_TCD_C_F1 pF1 ) ;
void LifeT701 ( P_TCD_C_F1 pF1 ) ;
void LifeT702 ( P_TCD_C_F1 pF1 ) ;
void LifeT703 ( P_TCD_C_F1 pF1 ) ;
void LifeT704 ( P_TCD_C_F1 pF1 ) ;
void LifeT705 ( P_TCD_C_F1 pF1 ) ;
void LifeT706 ( P_TCD_C_F1 pF1 ) ;
void LifeT707 ( P_TCD_C_F1 pF1 ) ;
void LifeT708 ( P_TCD_C_F1 pF1 ) ;
void LifeT709 ( P_TCD_C_F1 pF1 ) ;
void LifeT710 ( P_TCD_C_F1 pF1 ) ;
void LifeT711 ( P_TCD_C_F1 pF1 ) ;
void LifeT712 ( P_TCD_C_F1 pF1 ) ;
void LifeT713 ( P_TCD_C_F1 pF1 ) ;
void LifeT714 ( P_TCD_C_F1 pF1 ) ;
void LifeT715 ( P_TCD_C_F1 pF1 ) ;
void LifeT716 ( P_TCD_C_F1 pF1 ) ;
void LifeT717 ( P_TCD_C_F1 pF1 ) ;
void LifeT718 ( P_TCD_C_F1 pF1 ) ;
void LifeT719 ( P_TCD_C_F1 pF1 ) ;
void LifeT720 ( P_TCD_C_F1 pF1 ) ;
void LifeT721 ( P_TCD_C_F1 pF1 ) ;
void LifeT722 ( P_TCD_C_F1 pF1 ) ;
void LifeT723 ( P_TCD_C_F1 pF1 ) ;
void LifeT724 ( P_TCD_C_F1 pF1 ) ;
void LifeT725 ( P_TCD_C_F1 pF1 ) ;
void LifeT726 ( P_TCD_C_F1 pF1 ) ;
void LifeT727 ( P_TCD_C_F1 pF1 ) ;
void LifeT729 ( P_TCD_C_F1 pF1 ) ;
void LifeT730 ( P_TCD_C_F1 pF1 ) ;
void LifeT731 ( P_TCD_C_F1 pF1 ) ;
void LifeT732 ( P_TCD_C_F1 pF1 ) ;
void LifeT733 ( P_TCD_C_F1 pF1 ) ;
void LifeT734 ( P_TCD_C_F1 pF1 ) ;
void LifeT735 ( P_TCD_C_F1 pF1 ) ;
void LifeT736 ( P_TCD_C_F1 pF1 ) ;
void LifeT737 ( P_TCD_C_F1 pF1 ) ;
void LifeT738 ( P_TCD_C_F1 pF1 ) ;
void LifeT739 ( P_TCD_C_F1 pF1 ) ;
void LifeT740 ( P_TCD_C_F1 pF1 ) ;
void LifeT741 ( P_TCD_C_F1 pF1 ) ;
void LifeT742 ( P_TCD_C_F1 pF1 ) ;
void LifeT743 ( P_TCD_C_F1 pF1 ) ;
void LifeT744 ( P_TCD_C_F1 pF1 ) ;
void LifeT745 ( P_TCD_C_F1 pF1 ) ;
void LifeT746 ( P_TCD_C_F1 pF1 ) ;
void LifeT747 ( P_TCD_C_F1 pF1 ) ;
void LifeT748 ( P_TCD_C_F1 pF1 ) ;
void LifeT749 ( P_TCD_C_F1 pF1 ) ;
void LifeT750 ( P_TCD_C_F1 pF1 ) ;
void LifeT751 ( P_TCD_C_F1 pF1 ) ;
void LifeT752 ( P_TCD_C_F1 pF1 ) ;
void LifeT753 ( P_TCD_C_F1 pF1 ) ;
void LifeT754 ( P_TCD_C_F1 pF1 ) ;
void LifeT755 ( P_TCD_C_F1 pF1 ) ;
void LifeT756 ( P_TCD_C_F1 pF1 ) ;
void LifeT757 ( P_TCD_C_F1 pF1 ) ;
void LifeT758 ( P_TCD_C_F1 pF1 ) ;
void LifeT759 ( P_TCD_C_F1 pF1 ) ;
void LifeT760 ( P_TCD_C_F1 pF1 ) ;
void LifeT761 ( P_TCD_C_F1 pF1 ) ;
void LifeT762 ( P_TCD_C_F1 pF1 ) ;
void LifeT763 ( P_TCD_C_F1 pF1 ) ;
void LifeT764 ( P_TCD_C_F1 pF1 ) ;
void LifeT765 ( P_TCD_C_F1 pF1 ) ;
void LifeT766 ( P_TCD_C_F1 pF1 ) ;
void LifeT767 ( P_TCD_C_F1 pF1 ) ;
void LifeT768 ( P_TCD_C_F1 pF1 ) ;
void LifeT769 ( P_TCD_C_F1 pF1 ) ;
void LifeT770 ( P_TCD_C_F1 pF1 ) ;
void LifeT771 ( P_TCD_C_F1 pF1 ) ;
void LifeT772 ( P_TCD_C_F1 pF1 ) ;
void LifeT773 ( P_TCD_C_F1 pF1 ) ;
void LifeT774 ( P_TCD_C_F1 pF1 ) ;
void LifeT775 ( P_TCD_C_F1 pF1 ) ;
void LifeT776 ( P_TCD_C_F1 pF1 ) ;
void LifeT777 ( P_TCD_C_F1 pF1 ) ;
void LifeT778 ( P_TCD_C_F1 pF1 ) ;
void LifeT779 ( P_TCD_C_F1 pF1 ) ;
void LifeT780 ( P_TCD_C_F1 pF1 ) ;
void LifeT781 ( P_TCD_C_F1 pF1 ) ;
void LifeT782 ( P_TCD_C_F1 pF1 ) ;
/*GENPRCINFO*/


const S_TCDFTAB  s_formel_tabelle [] =
{
   
   { "asgn_e_n_n",LifeTem1,1,
      1,"12.12.2019 17:29:55"},
   { "asgn_e_m_n",LifeTem5,5,
      1,"12.12.2019 17:29:55"},
   { "asgn_e_TBeg_n",LifeTe15,15,
      1,"12.12.2019 17:29:55"},
   { "asgn_e_tarif_nr_n",LifeTe16,16,
      1,"12.12.2019 17:29:55"},
   { "asgn_e_tarsumme_ges_n",LifeTe23,23,
      1,"12.12.2019 17:29:55"},
   { "asgn_e_tarsumme_pfr_n",LifeTe29,29,
      1,"12.12.2019 17:29:56"},
   { "asgn_e_m_o",LifeTe83,83,
      1,"12.12.2019 17:29:56"},
   { "asgn_e_n_o",LifeTe84,84,
      1,"12.12.2019 17:29:56"},
   { "asgn_e_tarif_nr_o",LifeTe99,99,
      1,"12.12.2019 17:29:56"},
   { "asgn_e_TBeg_o",LifeT100,100,
      1,"12.12.2019 17:29:56"},
   { "asgn_e_reserve_o",LifeT103,103,
      1,"12.12.2019 17:29:56"},
   { "asgn_e_tarsumme_ges_o",LifeT112,112,
      1,"12.12.2019 17:29:56"},
   { "asgn_i_Wert",LifeT131,131,
      1,"12.12.2019 17:29:56"},
   { "F_PBxn",LifeT158,158,
      1,"12.12.2019 17:29:53"},
   { "F_pn",LifeT235,235,
      1,"12.12.2019 17:29:46"},
   { "F_vn",LifeT239,239,
      1,"12.12.2019 17:29:46"},
   { "F_qx",LifeT241,241,
      1,"12.12.2019 17:29:45"},
   { "F_v",LifeT243,243,
      1,"12.12.2019 17:29:45"},
   { "F_px",LifeT246,246,
      1,"12.12.2019 17:29:45"},
   { "F_ej",LifeT257,257,
      1,"12.12.2019 17:29:45"},
   { "F_Exn",LifeT258,258,
      1,"12.12.2019 17:29:45"},
   { "F_Pxn",LifeT266,266,
      1,"12.12.2019 17:29:44"},
   { "F_prj",LifeT268,268,
      1,"12.12.2019 17:29:44"},
   { "F_a1j",LifeT272,272,
      1,"12.12.2019 17:29:43"},
   { "F_A3xn",LifeT273,273,
      1,"12.12.2019 17:29:43"},
   { "F_Axn",LifeT274,274,
      1,"12.12.2019 17:29:43"},
   { "F_A2xn_sub",LifeT275,275,
      1,"12.12.2019 17:29:42"},
   { "F_A3xn_sub",LifeT276,276,
      1,"12.12.2019 17:29:42"},
   { "F_a3j",LifeT277,277,
      1,"12.12.2019 17:29:42"},
   { "F_a2j",LifeT278,278,
      1,"12.12.2019 17:29:42"},
   { "F_a2j_sub",LifeT279,279,
      1,"12.12.2019 17:29:42"},
   { "F_A1xn",LifeT280,280,
      1,"12.12.2019 17:29:42"},
   { "F_A2xn",LifeT281,281,
      1,"12.12.2019 17:29:41"},
   { "F_egj",LifeT296,296,
      1,"12.12.2019 17:29:39"},
   { "F_aeR",LifeT299,299,
      1,"12.12.2019 17:29:39"},
   { "F_erj",LifeT303,303,
      1,"12.12.2019 17:29:38"},
   { "F_aeG",LifeT308,308,
      1,"12.12.2019 17:29:38"},
   { "F_k_rentezw",LifeT311,311,
      1,"12.12.2019 17:29:38"},
   { "F_ae_delta",LifeT313,313,
      1,"12.12.2019 17:29:38"},
   { "F_ae",LifeT314,314,
      1,"12.12.2019 17:29:38"},
   { "F_rj",LifeT315,315,
      1,"12.12.2019 17:31:02"},
   { "F_aePV",LifeT316,316,
      1,"12.12.2019 17:31:02"},
   { "F_Vxnt",LifeT332,332,
      1,"12.12.2019 17:29:36"},
   { "F_Bxnt",LifeT333,333,
      1,"12.12.2019 17:29:36"},
   { "F_Benefit_AccDeath",LifeT340,340,
      1,"12.12.2019 17:29:34"},
   { "F_Benefit_Invalidity",LifeT350,350,
      1,"12.12.2019 17:29:34"},
   { "F_DB_Init",LifeT355,355,
      1,"12.12.2019 17:29:32"},
   { "F_n",LifeT364,364,
      1,"12.12.2019 17:29:31"},
   { "F_m",LifeT366,366,
      1,"12.12.2019 17:29:31"},
   { "F_k",LifeT373,373,
      1,"12.12.2019 17:29:31"},
   { "F_Version",LifeT388,388,
      1,"12.12.2019 17:29:29"},
   { "F_Interpolation",LifeT389,389,
      1,"12.12.2019 17:29:20"},
   { "_Beta",LifeT419,419,
      1,"12.12.2019 17:29:27"},
   { "_aj2",LifeT424,424,
      1,"12.12.2019 17:29:27"},
   { "_Alpha1",LifeT425,425,
      1,"12.12.2019 17:29:27"},
   { "_Gamma2",LifeT439,439,
      1,"12.12.2019 17:29:27"},
   { "_Alpha3",LifeT442,442,
      1,"12.12.2019 17:29:27"},
   { "_aj1",LifeT447,447,
      1,"12.12.2019 17:29:27"},
   { "_Delta",LifeT455,455,
      1,"12.12.2019 17:29:27"},
   { "_Gamma1",LifeT464,464,
      1,"12.12.2019 17:29:27"},
   { "_aj3",LifeT467,467,
      1,"12.12.2019 17:29:27"},
   { "_Alpha2",LifeT468,468,
      1,"12.12.2019 17:29:27"},
   { "_ej",LifeT474,474,
      1,"12.12.2019 17:29:27"},
   { "F_Delta",LifeT504,504,
      1,"12.12.2019 17:29:27"},
   { "F_Gamma3",LifeT512,512,
      1,"12.12.2019 17:29:26"},
   { "F_Gamma",LifeT524,524,
      1,"12.12.2019 17:29:26"},
   { "F_Alpha",LifeT545,545,
      1,"12.12.2019 17:29:26"},
   { "F_Beta",LifeT551,551,
      1,"12.12.2019 17:29:26"},
   { "asgn_e_NumberOfInsPers_n",LifeT552,552,
      1,"12.12.2019 17:29:56"},
   { "F_DifYears",LifeT553,553,
      1,"12.12.2019 17:29:22"},
   { "F_Year",LifeT554,554,
      1,"12.12.2019 17:29:22"},
   { "asgn_e_BirthDate_IP1_n",LifeT555,555,
      1,"12.12.2019 17:29:56"},
   { "asgn_e_ea_IP1_n",LifeT557,557,
      1,"12.12.2019 17:29:57"},
   { "asgn_e_ea_IP2_n",LifeT558,558,
      1,"12.12.2019 17:29:57"},
   { "asgn_e_gender_IP1_n",LifeT559,559,
      1,"12.12.2019 17:29:57"},
   { "asgn_e_gender_IP2_n",LifeT560,560,
      1,"12.12.2019 17:29:57"},
   { "asgn_e_BirthDate_IP1_o",LifeT561,561,
      1,"12.12.2019 17:29:57"},
   { "asgn_e_RiskGroup_IP1_n",LifeT563,563,
      1,"12.12.2019 17:29:57"},
   { "asgn_e_RiskGroup_IP2_n",LifeT564,564,
      1,"12.12.2019 17:29:57"},
   { "asgn_e_RiskGroup_IP1_o",LifeT565,565,
      1,"12.12.2019 17:29:57"},
   { "asgn_e_RiskGroup_IP2_o",LifeT566,566,
      1,"12.12.2019 17:29:57"},
   { "asgn_e_NumberOfInsPers_o",LifeT567,567,
      1,"12.12.2019 17:29:57"},
   { "asgn_e_x_IP1_o",LifeT568,568,
      1,"12.12.2019 17:29:57"},
   { "asgn_e_x_IP2_o",LifeT569,569,
      1,"12.12.2019 17:29:58"},
   { "asgn_e_x_IP1_n",LifeT570,570,
      1,"12.12.2019 17:29:58"},
   { "asgn_e_x_IP2_n",LifeT571,571,
      1,"12.12.2019 17:29:58"},
   { "F_Reserve",LifeT572,572,
      1,"12.12.2019 17:29:36"},
   { "F_RateClass",LifeT573,573,
      1,"12.12.2019 17:29:53"},
   { "asgn_e_currentDate_n",LifeT574,574,
      1,"12.12.2019 17:29:58"},
   { "F_delta_Years",LifeT575,575,
      1,"12.12.2019 17:29:22"},
   { "F_Years",LifeT576,576,
      1,"12.12.2019 17:29:22"},
   { "F_Months",LifeT577,577,
      1,"12.12.2019 17:29:22"},
   { "F_Month",LifeT578,578,
      1,"12.12.2019 17:29:21"},
   { "F_DDMMYYYY_plus_i_t",LifeT579,579,
      1,"12.12.2019 17:29:21"},
   { "F_DDMMYYYY",LifeT580,580,
      1,"12.12.2019 17:29:21"},
   { "F_Calc_Allowed",LifeT581,581,
      1,"12.12.2019 17:29:53"},
   { "F_YYYYMMDD",LifeT582,582,
      1,"12.12.2019 17:29:21"},
   { "F_Day",LifeT583,583,
      1,"12.12.2019 17:29:21"},
   { "asgn_e_CalcDate",LifeT584,584,
      1,"12.12.2019 17:29:58"},
   { "asgn_e_BackOffice",LifeT585,585,
      1,"12.12.2019 17:29:58"},
   { "_Calc_NonBackOffice",LifeT588,588,
      1,"12.12.2019 17:29:27"},
   { "asgn_CostTab",LifeT589,589,
      3,"12.12.2019 17:29:58"},
   { "F_RowIndex",LifeT591,591,
      1,"12.12.2019 17:29:25"},
   { "asgn_e_AddContrib_n",LifeT592,592,
      1,"12.12.2019 17:29:58"},
   { "asgn_e_PartSurrender_n",LifeT593,593,
      1,"12.12.2019 17:29:59"},
   { "asgn_e_RateClass_n",LifeT594,594,
      1,"12.12.2019 17:29:59"},
   { "asgn_e_RateClass_o",LifeT595,595,
      1,"12.12.2019 17:29:59"},
   { "_Has_Factor_Demise",LifeT596,596,
      1,"12.12.2019 17:29:27"},
   { "_Has_Decrea_SumIns",LifeT597,597,
      1,"12.12.2019 17:29:27"},
   { "F_Is_TermFix",LifeT598,598,
      1,"12.12.2019 17:29:25"},
   { "_Is_TermFix",LifeT599,599,
      1,"12.12.2019 17:29:28"},
   { "F_Has_Decrea_SumIns",LifeT600,600,
      1,"12.12.2019 17:29:34"},
   { "F_OccupSurcharge",LifeT603,603,
      1,"12.12.2019 17:29:36"},
   { "F_SportsSurcharge",LifeT604,604,
      1,"12.12.2019 17:29:37"},
   { "asgn_e_OccuClass_n",LifeT605,605,
      1,"12.12.2019 17:29:59"},
   { "asgn_e_OccuSurcha_IP1_n",LifeT606,606,
      1,"12.12.2019 17:29:59"},
   { "asgn_e_SportsSurcha_IP1_n",LifeT607,607,
      1,"12.12.2019 17:29:59"},
   { "asgn_e_SportsSurcha_IP1_o",LifeT608,608,
      1,"12.12.2019 17:29:59"},
   { "asgn_e_OccuSurcha_IP1_o",LifeT609,609,
      1,"12.12.2019 17:29:59"},
   { "asgn_e_AddSurcharge_IP1_n",LifeT610,610,
      1,"12.12.2019 17:29:59"},
   { "asgn_e_AddSurcharge_IP2_n",LifeT611,611,
      1,"12.12.2019 17:29:59"},
   { "asgn_e_wo_examination_n",LifeT612,612,
      1,"12.12.2019 17:30:00"},
   { "asgn_e_wo_examination_o",LifeT613,613,
      1,"12.12.2019 17:30:00"},
   { "F_HealthSurcharge",LifeT614,614,
      1,"12.12.2019 17:29:54"},
   { "F_ModifiedQx",LifeT615,615,
      1,"12.12.2019 17:29:55"},
   { "asgn_e_HealthClass_IP1_n",LifeT616,616,
      1,"12.12.2019 17:30:00"},
   { "F_AddSurcharges",LifeT617,617,
      1,"12.12.2019 17:29:55"},
   { "asgn_e_HealthSurch_IP1_o",LifeT619,619,
      1,"12.12.2019 17:30:00"},
   { "asgn_e_SpecialDiscount_n",LifeT620,620,
      1,"12.12.2019 17:29:58"},
   { "asgn_e_SumDiscount_n",LifeT621,621,
      1,"12.12.2019 17:29:58"},
   { "asgn_e_HealthSurch_IP1_n",LifeT622,622,
      1,"12.12.2019 17:29:58"},
   { "asgn_AlphaCostMatrix",LifeT623,623,
      3,"12.12.2019 17:30:00"},
   { "asgn_YieldFactorTab",LifeT624,624,
      3,"12.12.2019 17:30:00"},
   { "asgn_MortalityTab",LifeT625,625,
      3,"12.12.2019 17:30:00"},
   { "F_FlagOCDisBenefit",LifeT626,626,
      1,"12.12.2019 17:29:25"},
   { "_OCDisBenefit",LifeT627,627,
      1,"12.12.2019 17:29:28"},
   { "F_OCDisBenfit",LifeT628,628,
      1,"12.12.2019 17:29:34"},
   { "F_year_plus_x",LifeT629,629,
      1,"12.12.2019 17:29:21"},
   { "F_INT_From_Year",LifeT630,630,
      1,"12.12.2019 17:29:21"},
   { "F_CommReduction_n",LifeT632,632,
      1,"12.12.2019 17:29:29"},
   { "F_CommReduction_o",LifeT633,633,
      1,"12.12.2019 17:29:29"},
   { "asgn_e_CommReduction_o",LifeT634,634,
      1,"12.12.2019 17:30:00"},
   { "asgn_e_CommReduction_n",LifeT635,635,
      1,"12.12.2019 17:30:00"},
   { "F_CommReductionFact",LifeT636,636,
      1,"12.12.2019 17:29:29"},
   { "F_Commission",LifeT637,637,
      2,"12.12.2019 17:29:30"},
   { "F_FirstYieldAlloc",LifeT638,638,
      1,"12.12.2019 17:29:49"},
   { "_FirstYieldAlloc",LifeT639,639,
      1,"12.12.2019 17:29:28"},
   { "_Gamma3",LifeT640,640,
      1,"12.12.2019 17:29:28"},
   { "_Offset_Mortality",LifeT641,641,
      1,"12.12.2019 17:29:28"},
   { "_wo_examination",LifeT642,642,
      1,"12.12.2019 17:29:28"},
   { "_MinPremFreeSum",LifeT643,643,
      1,"12.12.2019 17:29:28"},
   { "_MinSurrenderValue",LifeT644,644,
      1,"12.12.2019 17:29:28"},
   { "_Alpha_Distribution",LifeT645,645,
      1,"12.12.2019 17:29:28"},
   { "_lifelong",LifeT646,646,
      1,"12.12.2019 17:29:28"},
   { "_InterestRate",LifeT647,647,
      1,"12.12.2019 17:29:28"},
   { "_premFree",LifeT648,648,
      1,"12.12.2019 17:29:28"},
   { "_regularPremium",LifeT649,649,
      1,"12.12.2019 17:29:28"},
   { "_HasSumDiscount",LifeT650,650,
      1,"12.12.2019 17:29:28"},
   { "_CancFac_to",LifeT651,651,
      1,"12.12.2019 17:29:29"},
   { "_CancFac_from",LifeT652,652,
      1,"12.12.2019 17:29:29"},
   { "_SecurityLoading",LifeT653,653,
      1,"12.12.2019 17:29:29"},
   { "_HasAnnuityValue",LifeT654,654,
      1,"12.12.2019 17:29:29"},
   { "_RecurringComm",LifeT655,655,
      1,"12.12.2019 17:29:29"},
   { "_PremRefund",LifeT656,656,
      1,"12.12.2019 17:29:29"},
   { "F_Comm_Percentage",LifeT657,657,
      1,"12.12.2019 17:29:25"},
   { "_CommPercent",LifeT658,658,
      1,"12.12.2019 17:29:29"},
   { "_CommAddConPercent",LifeT659,659,
      1,"12.12.2019 17:29:29"},
   { "F_CommAddContrib",LifeT660,660,
      1,"12.12.2019 17:29:25"},
   { "asgn_e_method",LifeT661,661,
      1,"12.12.2019 17:30:01"},
   { "F_IsProlongation",LifeT662,662,
      1,"12.12.2019 17:29:30"},
   { "F_Alpha_Distribution",LifeT663,663,
      1,"12.12.2019 17:29:25"},
   { "F_PBxn_AccDeath_Dis",LifeT664,664,
      1,"12.12.2019 17:29:53"},
   { "F_PBxn_OccDis",LifeT665,665,
      1,"12.12.2019 17:29:52"},
   { "F_AccDeathDis_xnt",LifeT666,666,
      1,"12.12.2019 17:29:45"},
   { "asgn_e_SumRelation",LifeT667,667,
      1,"12.12.2019 17:30:01"},
   { "F_AuxiliaryNumber",LifeT668,668,
      2,"12.12.2019 17:29:54"},
   { "F_AuxNrAccDeathDis",LifeT669,669,
      2,"12.12.2019 17:29:54"},
   { "F_CreditableReserve",LifeT670,670,
      1,"12.12.2019 17:29:35"},
   { "F_Alpha1_Permille",LifeT671,671,
      1,"12.12.2019 17:29:25"},
   { "F_Alpha2_Permille",LifeT672,672,
      1,"12.12.2019 17:29:24"},
   { "F_SecurityLoading",LifeT673,673,
      1,"12.12.2019 17:29:24"},
   { "F_PremCashValue",LifeT674,674,
      1,"12.12.2019 17:29:52"},
   { "F_Benefit_Death",LifeT675,675,
      1,"12.12.2019 17:29:34"},
   { "F_Benefit_Endowment",LifeT676,676,
      1,"12.12.2019 17:29:34"},
   { "F_YieldAnnuity",LifeT677,677,
      1,"12.12.2019 17:29:38"},
   { "F_BaseAnnuity",LifeT678,678,
      1,"12.12.2019 17:29:38"},
   { "F_Annuitization",LifeT679,679,
      1,"12.12.2019 17:29:37"},
   { "asgn_i_MaturityAmount",LifeT680,680,
      1,"12.12.2019 17:30:01"},
   { "F_advance_arrears",LifeT681,681,
      1,"12.12.2019 17:29:37"},
   { "_Accrual",LifeT682,682,
      1,"12.12.2019 17:29:29"},
   { "F_Reduction",LifeT683,683,
      1,"12.12.2019 17:29:31"},
   { "F_SurrenderFactor",LifeT684,684,
      1,"12.12.2019 17:29:31"},
   { "F_SurrenderValue",LifeT685,685,
      1,"12.12.2019 17:29:32"},
   { "F_Interpol_Surrender",LifeT686,686,
      1,"12.12.2019 17:29:21"},
   { "F_Interpol_Reduction",LifeT687,687,
      1,"12.12.2019 17:29:21"},
   { "F_Interest",LifeT688,688,
      1,"12.12.2019 17:29:24"},
   { "asgn_e_state_n",LifeT689,689,
      1,"12.12.2019 17:30:01"},
   { "asgn_e_StateDetail_n",LifeT690,690,
      1,"12.12.2019 17:30:01"},
   { "asgn_e_DeathBenFactor_n",LifeT691,691,
      1,"12.12.2019 17:30:01"},
   { "F_PensionAge_x",LifeT692,692,
      1,"12.12.2019 17:29:37"},
   { "F_guaranteePeriod",LifeT693,693,
      1,"12.12.2019 17:29:30"},
   { "F_AnnuityPayFreq",LifeT694,694,
      1,"12.12.2019 17:29:37"},
   { "F_AnnuityPeriod",LifeT695,695,
      1,"12.12.2019 17:29:30"},
   { "F_DeathFactor",LifeT697,697,
      1,"12.12.2019 17:29:33"},
   { "F_PremiumRefundUntil",LifeT699,699,
      1,"12.12.2019 17:29:41"},
   { "F_TotalMatAmount",LifeT700,700,
      1,"12.12.2019 17:29:33"},
   { "F_Alpha_OccDis",LifeT701,701,
      1,"12.12.2019 17:29:24"},
   { "F_AlphaOccDis_CV",LifeT702,702,
      1,"12.12.2019 17:29:44"},
   { "F_BetaOccDis_CV",LifeT703,703,
      1,"12.12.2019 17:29:44"},
   { "F_PxnOccDis",LifeT704,704,
      1,"12.12.2019 17:29:43"},
   { "F_pni_OCDis",LifeT705,705,
      1,"12.12.2019 17:29:41"},
   { "F_rea_OCDis",LifeT706,706,
      1,"12.12.2019 17:29:41"},
   { "F_qi_OCDis",LifeT707,707,
      1,"12.12.2019 17:29:41"},
   { "F_aei_OCDis",LifeT708,708,
      1,"12.12.2019 17:29:40"},
   { "F_rj_OCDis",LifeT709,709,
      1,"12.12.2019 17:29:40"},
   { "F_i_OccDis",LifeT710,710,
      1,"12.12.2019 17:29:40"},
   { "F_paa_OccDis",LifeT711,711,
      1,"12.12.2019 17:29:40"},
   { "F_pna_OccDis",LifeT712,712,
      1,"12.12.2019 17:29:40"},
   { "F_qaa_OccDis",LifeT713,713,
      1,"12.12.2019 17:29:40"},
   { "F_b_OccDis",LifeT714,714,
      1,"12.12.2019 17:29:40"},
   { "F_CashValue_OccDis",LifeT715,715,
      1,"12.12.2019 17:29:39"},
   { "F_Vxnt_OCDis",LifeT716,716,
      1,"12.12.2019 17:29:35"},
   { "F_Bxnt_OCDis",LifeT717,717,
      1,"12.12.2019 17:29:35"},
   { "F_benefitPeriod",LifeT718,718,
      1,"12.12.2019 17:29:30"},
   { "asgn_e_benefitPeriod_n",LifeT719,719,
      1,"12.12.2019 17:30:01"},
   { "asgn_e_annutyPayFreq_n",LifeT720,720,
      1,"12.12.2019 17:30:01"},
   { "F_GrossPrem_wo_SD_n",LifeT721,721,
      1,"12.12.2019 17:29:52"},
   { "asgn_e_state_o",LifeT722,722,
      1,"12.12.2019 17:30:01"},
   { "asgn_e_StateDetail_o",LifeT723,723,
      1,"12.12.2019 17:30:01"},
   { "F_GrossPrem_wo_SD_o",LifeT724,724,
      1,"12.12.2019 17:29:52"},
   { "asgn_e_benefitPeriod_o",LifeT725,725,
      1,"12.12.2019 17:30:02"},
   { "asgn_e_annutyPayFreq_o",LifeT726,726,
      1,"12.12.2019 17:30:02"},
   { "asgn_e_DeathBenFactor_o",LifeT727,727,
      1,"12.12.2019 17:30:02"},
   { "asgn_e_guaranteePeriod_o",LifeT729,729,
      1,"12.12.2019 17:30:02"},
   { "asgn_e_guaranteePeriod_n",LifeT730,730,
      1,"12.12.2019 17:30:02"},
   { "asgn_e_SumOfPremiums_o",LifeT731,731,
      1,"12.12.2019 17:30:02"},
   { "asgn_e_SumOfPremiums_n",LifeT732,732,
      1,"12.12.2019 17:30:01"},
   { "F_WO_Examination",LifeT733,733,
      1,"12.12.2019 17:29:24"},
   { "F_SumDiscount",LifeT734,734,
      1,"12.12.2019 17:29:24"},
   { "F_SumsOfPrem_o",LifeT735,735,
      1,"12.12.2019 17:29:33"},
   { "F_SumOfPremPortfolio",LifeT736,736,
      1,"12.12.2019 17:29:32"},
   { "F_t_allocDate",LifeT737,737,
      1,"12.12.2019 17:29:49"},
   { "asgn_e_manual_LEBK_BWS_n",LifeT738,738,
      1,"12.12.2019 17:30:02"},
   { "asgn_e_manual_LEBK_MON_n",LifeT739,739,
      1,"12.12.2019 17:30:02"},
   { "asgn_e_SpecialDiscount_o",LifeT740,740,
      1,"12.12.2019 17:30:02"},
   { "asgn_e_SumDiscount_o",LifeT741,741,
      1,"12.12.2019 17:30:02"},
   { "asgn_e_GrossPremium_o",LifeT742,742,
      1,"12.12.2019 17:30:02"},
   { "asgn_e_pfs_n",LifeT743,743,
      1,"12.12.2019 17:30:03"},
   { "asgn_e_pst_n",LifeT744,744,
      1,"12.12.2019 17:30:03"},
   { "asgn_e_pst_o",LifeT745,745,
      1,"12.12.2019 17:30:03"},
   { "asgn_e_StartDateYield_n",LifeT746,746,
      1,"12.12.2019 17:30:03"},
   { "asgn_e_YieldDate_o",LifeT747,747,
      1,"12.12.2019 17:30:03"},
   { "asgn_e_YieldValue_o",LifeT748,748,
      1,"12.12.2019 17:30:03"},
   { "asgn_e_StartDateYield_o",LifeT749,749,
      1,"12.12.2019 17:30:03"},
   { "asgn_e_GrossPremium_n",LifeT750,750,
      1,"12.12.2019 17:30:03"},
   { "asgn_e_YieldDate_n",LifeT751,751,
      1,"12.12.2019 17:30:03"},
   { "asgn_e_YieldValue_n",LifeT752,752,
      1,"12.12.2019 17:30:03"},
   { "F_AddYieldFactors",LifeT753,753,
      2,"12.12.2019 17:29:49"},
   { "F_AddYieldFactor",LifeT754,754,
      1,"12.12.2019 17:29:49"},
   { "F_AddYield",LifeT755,755,
      1,"12.12.2019 17:29:49"},
   { "F_InterestYFactors",LifeT756,756,
      2,"12.12.2019 17:29:48"},
   { "F_InterestYFactor",LifeT757,757,
      1,"12.12.2019 17:29:48"},
   { "F_InterestYield",LifeT758,758,
      1,"12.12.2019 17:29:48"},
   { "F_TotalYieldAmount",LifeT759,759,
      1,"12.12.2019 17:29:48"},
   { "F_YieldCalculation",LifeT760,760,
      2,"12.12.2019 17:29:47"},
   { "F_GetYieldFromVector",LifeT761,761,
      1,"12.12.2019 17:29:47"},
   { "F_AccruedInt_CurrY",LifeT762,762,
      1,"12.12.2019 17:29:47"},
   { "F_AccruedInt_PrevY",LifeT763,763,
      1,"12.12.2019 17:29:47"},
   { "F_AccruedInt_MidYear",LifeT764,764,
      1,"12.12.2019 17:29:46"},
   { "F_AccruedInt_Interp",LifeT765,765,
      1,"12.12.2019 17:29:46"},
   { "F_AccruedInt_FromMM",LifeT766,766,
      1,"12.12.2019 17:29:46"},
   { "F_AccruedInt_ToMM",LifeT767,767,
      1,"12.12.2019 17:29:46"},
   { "F_GrossPrem_General",LifeT768,768,
      1,"12.12.2019 17:29:51"},
   { "F_IsLiquidAnnuity",LifeT769,769,
      1,"12.12.2019 17:29:32"},
   { "F_CostPremium",LifeT770,770,
      1,"12.12.2019 17:29:51"},
   { "F_CostPremiumSum",LifeT771,771,
      1,"12.12.2019 17:29:51"},
   { "F_RiskPremium",LifeT772,772,
      1,"12.12.2019 17:29:50"},
   { "F_RiskPremiumSum",LifeT773,773,
      1,"12.12.2019 17:29:50"},
   { "F_SavingsPremiumSum",LifeT774,774,
      1,"12.12.2019 17:29:50"},
   { "F_SavingsPremium",LifeT775,775,
      1,"12.12.2019 17:29:50"},
   { "F_PremiumSplit",LifeT776,776,
      2,"12.12.2019 17:29:49"},
   { "F_AC_Original",LifeT777,777,
      1,"12.12.2019 17:29:23"},
   { "F_AC_Layer_Original",LifeT778,778,
      2,"12.12.2019 17:29:23"},
   { "F_AC_CashValue",LifeT779,779,
      1,"12.12.2019 17:29:23"},
   { "F_AC_Layer_CashValue",LifeT780,780,
      2,"12.12.2019 17:29:23"},
   { "F_AC_total",LifeT781,781,
      1,"12.12.2019 17:29:22"},
   { "asgn_e_AnnuityAmount_n",LifeT782,782,
      1,"16.12.2019 15:07:02"},
   { "", 0, 0, 0 }
} ;

#define TCD_FTABSIZE sizeof(s_formel_tabelle)/sizeof(S_TCDFTAB) ;

/*---------------------------------------------------------------------
   Externe Funktion: LifeTemF
   Beschreibung  :   Formelaufrufsteuerung
   Parameter     : pTCDTCD->IFctl  Kontrollstruktur Formelsteuerung

   Returnwerte   :

---------------------------------------------------------------------*/
void  LifeTemF ( P_TCD_C_G pTCDTCD )
{
   P_TCDFTAB      pTab ;
   S_TCD_C_F1     sF1;
   P_TCD_C_F1     pF1 = &sF1;
   int            size = sizeof(S_TCD_C_F1) ;
   P_TCDCTLPAR    pTcdPar    = &(pTCDTCD->pRbsSS->RCTL.Par) ;
   P_TCDRCINFO    pTcdRcInfo = &(pTCDTCD->pRbsSS->RCTL.RCInfo) ;

   pTcdRcInfo->Rc = TCD_RC_OK ;

   switch ( pTCDTCD->pRbsCtl->Opc)
   {
      case TCD_OPC_CALC_PRC :
      case TCD_OPC_CALC_FRM :
		  memset (pF1, 0, size) ;
		  pF1->FrmIx = -1 ;
		  if ( pTCDTCD->pPrcTreeNode != 0 ) {
			  P_TCDPRCNODE pMyNode = &pTCDTCD->pPrcTreeNode->Node;
			  if ( pTCDTCD->pRbsCtl->Opc != TCD_OPC_CALC_FRM ) {
				  pF1->FrmIx = pMyNode->AssignVal.Formel.FormelIx ;
			  }
		  }
		  pF1->FrmNr   = pTcdPar->CFP.FormelNr ;
		  pF1->pTCDTCD = pTCDTCD;
		  pF1->Level   = 1 ;

		  FCall (pF1) ;

		  if ( pTcdRcInfo->Rc  == TCD_RC_OK ) {
              pTcdPar->CFP.Typ = pF1->FrmTyp ;

              switch (pF1->FrmTyp) {
			  case TCD_FRMTYP_SKAL :
				  pTcdPar->CFP.Value.Skalar = * pF1->pVarSkal ;
				  break ;

			  case TCD_FRMTYP_TAB1 :
				  pTcdPar->CFP.Value.pTab1 = * pF1->pVarTab ;
				  break ;

			  case TCD_FRMTYP_TAB2 :
				  pTcdPar->CFP.Value.pTab2 = * pF1->pVarTab ;
				  break ;
              }
          }
		  return ;

      case TCD_OPC_GETNUM_FRM:
           pTab = FindFrmNr (pTCDTCD, pTcdPar->GF.Name) ;
           if (pTcdRcInfo->Rc  == TCD_RC_OK)
           {
               pTcdPar->GF.FormelNr = pTab->FrmNr ;
           }
           return ;

     default:
           pTcdRcInfo->Rc   = TCD_RC_INTERNAL_ERR ;
           pTcdRcInfo->Errc = TCD_UNKNOWN_OPCODE ;
           return ;
     }
}

/*-----------------------------------------------------------------
Externe Funktion: LifeTem1
Beschreibung:     besorgt die Wertebelegung f�r ein skalares Attribut
             Falls eine Formel zur Berechnung des Attributs
             aufgerufen werden mu�, wird die Formel aufgerufen.
             Schnittstelle zu Attributmanager: besorgt Attributwert
Parameter:        pMyPar: Formelparameter der Formel
             AttrName: Name des Attributs f�r das der Wert zu holen ist
             Ix:       lfd. Nummer in Attributschnittstelle
             ID:       Attr. ID
             Typ       Attr. typ (Format und Klasse)
             ParIx     lfd. Nummer in der Parameterschnittstelle
             *Var      Zeiger auf Var. in der der Wert hinterlegt wird
Returnwert:
             TCD_RC_OK : sonst
---------------------------------------------------------------------*/
void    TCD3FES         ( P_TCD_C_F1  pMyPar,
                                char *       AttrName,
                                TCD_INT      Ix,
                                TCD_LONG     ID,
                                TCD_INT      AttrTyp,
                                TCD_INT      ParIx,
                                P_TCD_DOUBLE Var)

{
   S_TCD_C_F1     sF1;
   P_TCD_C_F1     pF1 = &sF1;
   int            size = sizeof(S_TCD_C_F1) ;
   int        rc = TCD_RC_OK ;

   pMyPar->pVarSkal = Var ;
   pMyPar->AttrIx   = Ix ;
   pMyPar->AttrID   = ID ;
   pMyPar->ParIx    = ParIx;
   pMyPar->AttrName = AttrName ;
   pMyPar->AttrTyp  = AttrTyp ;

   if (AttrTyp < TCD_ATTYP_BST_SKAL)
   {
       if ((rc = TCDAATS (pMyPar)) == TCD_RC_OK)
          return  ;
   }
   else
   {
       if ((rc = TCDAABS (pMyPar)) == TCD_RC_OK)
          return ;
   }
   if (rc == TCD_AIRC_CALLVIAFRM && 
       pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
       memset (pF1, 0, size) ;
	   pF1->FrmIx = -1 ;
       pF1->pPrevLevelInfo = pMyPar ;
       pF1->CallType       = TCD_CALLTYP_ATTR ;
       pF1->FrmNr          = pMyPar->FrmNr    ;
       pF1->FrmIx          = pMyPar->FrmIx ;
       pF1->AttrName       = pMyPar->AttrName  ;
       pF1->AttrID         = pMyPar->AttrID ;
       pF1->ExecCond       = pMyPar->NextExecCond ;
       pF1->Level          = pMyPar->Level + 1 ;
       pF1->pTCDTCD        = pMyPar->pTCDTCD;
       FCall (pF1) ;
   }
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK)
	   if (strcmp(pMyPar->pTCDTCD->pRbsCtl->RCInfo.AttrName,"")==0)
		strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.AttrName, AttrName);
}

/*-----------------------------------------------------------------
   Externe Funktion: LifeTem2
   Beschreibung:     besorgt die Wertebelegung f�r ein Tabellenattribut
                 Falls eine Formel zur Berechnung des Attributs
                 aufgerufen werden mu�, wird die Formel aufgerufen.
                 Schnittstelle zu Attributmanager: besorgt Attributwert
   Parameter:        pMyPar: Formelparameter der Formel
             AttrName: Name des Attributs f�r das der Wert zu holen ist
             Ix:       lfd. Nummer in Attributschnittstelle
             ID:       Attr. ID
             Typ       Attr. typ (Format und Klasse)
             *Var      Zeiger auf Var. in der der Wert hinterlegt wird
   Returnwert:
                     TCD_RC_OK : sonst
---------------------------------------------------------------------*/
void    TCD3FET         (P_TCD_C_F1  pMyPar,
                                char *     AttrName,
                                TCD_INT    Ix,
                                TCD_LONG   ID,
                                TCD_INT    AttrTyp,
                                P_P_TCDTAB Var)

{
   int        rc = TCD_RC_OK ;
   S_TCD_C_F1     sF1;
   P_TCD_C_F1     pF1 = &sF1;
   int            size = sizeof(S_TCD_C_F1) ;

   pMyPar->pVarTab  = Var ;
   pMyPar->AttrIx   = Ix ;
   pMyPar->AttrID   = ID ;
   pMyPar->AttrName = AttrName ;
   pMyPar->AttrTyp  = AttrTyp ;

   if (AttrTyp < TCD_ATTYP_BST_SKAL)
   {
       if ((rc = TCDAATT (pMyPar)) == TCD_RC_OK)
          return  ;
   }
   else
   {
       if ((rc = TCDAABT (pMyPar)) == TCD_RC_OK)
          return ;
   }

   if (rc == TCD_AIRC_CALLVIAFRM && 
       pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
       memset (pF1, 0, size) ;
	   pF1->FrmIx = -1 ;
	   pF1->pPrevLevelInfo = pMyPar;
       pF1->CallType       = TCD_CALLTYP_ATTR;
       pF1->FrmNr          = pMyPar->FrmNr;
       pF1->FrmIx          = pMyPar->FrmIx;
       pF1->AttrName       = pMyPar->AttrName;
       pF1->AttrID         = pMyPar->AttrID;
       pF1->ExecCond       = pMyPar->NextExecCond;
       pF1->Level          = pMyPar->Level + 1;
       pF1->pTCDTCD        = pMyPar->pTCDTCD;
       FCall (pF1) ;
	   
   }
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK)
       strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.AttrName, AttrName) ;
}

/*-----------------------------------------------------------------
   Externe Funktion: LifeTem3
   Beschreibung:     besorgt die Wertebelegung f�r ein Datumsattribut
             Schnittstelle zu Attributmanager: besorgt Attributwert
   Parameter:        pMyPar: Formelparameter der Formel
         AttrName: Name des Attributs f�r das der Wert zu holen ist
         Ix:       lfd. Nummer in Attributschnittstelle
         ID:       Attr. ID
         Typ       Attr. typ (Format und Klasse)
         ParIx     lfd. Nummer in der Parameterschnittstelle
         *Var      Zeiger auf Var. in der der Wert hinterlegt wird
   Returnwert:
                     TCD_RC_OK : sonst
---------------------------------------------------------------------*/
void    TCD3FED         (P_TCD_C_F1  pMyPar,
                                char *     AttrName,
                                TCD_INT    Ix,
                                TCD_LONG   ID,
                                TCD_INT    AttrTyp,
                                TCD_INT    ParIx,
                                char *     Var)

{
   pMyPar->VarDatVgl= Var ;
   pMyPar->AttrName = AttrName ;
   pMyPar->AttrIx   = Ix ;
   pMyPar->AttrID   = ID ;
   pMyPar->ParIx    = ParIx;
   pMyPar->AttrTyp  = AttrTyp ;

   if (AttrTyp < TCD_ATTYP_BST_SKAL)

        TCDAATD (pMyPar) ;
   else TCDAABD (pMyPar) ;

   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK)
       strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.AttrName, AttrName) ;

   return ;
}


/*---------------------------------------------------------------------
   Externe Funktion: TCD3FEV
Beschreibung:     besorgt die Wertebelegung f�r ein Datumsattribut
             Schnittstelle zu Attributmanager: besorgt Attributwert
   Parameter:        pMyPar: Formelparameter der Formel
         AttrName: Name des Attributs f�r das der Wert zu holen ist
         Ix:       lfd. Nummer in Attributschnittstelle
         ID:       Attr. ID
         Typ       Attr. typ (Format und Klasse)
         ParIx     lfd. Nummer in der Parameterschnittstelle
         *Var      Zeiger auf Var. in der der Wert hinterlegt wird
   Returnwert:
                     TCD_RC_OK : sonst
---------------------------------------------------------------------*/
void    TCD3FEV         (P_TCD_C_F1  pMyPar,
                                char *     AttrName,
                                TCD_INT    Ix,
                                TCD_LONG   ID,
                                TCD_INT    AttrTyp,
                                TCD_INT    ParIx,
                                char *     Var)

{
   pMyPar->VarDatVgl = Var ;
   pMyPar->AttrIx    = Ix ;
   pMyPar->AttrID    = ID ;
   pMyPar->AttrName  = AttrName ;
   pMyPar->ParIx     = ParIx;
   pMyPar->AttrTyp   = AttrTyp ;

   if (AttrTyp < TCD_ATTYP_BST_SKAL)

        TCDAATV (pMyPar) ;
   else TCDAABV (pMyPar) ;

   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK)
       strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.AttrName, AttrName) ;

   return ;
}


/*-----------------------------------------------------------------
   Externe Funktion: LifeTem5
   Beschreibung:     Diese Funktion behandelt einen Funktionsaufruf
                     (dyn, statisch) einer skalaren  Formel
   Parameter:        option: formelaufruftyp (sta, dyn)
             Name : Name des Attributs bei dyn- Call
                    Name der aufgerufenen Formel bei
                    statischem Call
             ID:    ID des Attributs (das die Formelnummer enth,lt)
                    bei statischem Aufruf
         ??  AIx :  Index des Attributs in der Formel
                    bei dynamischem Aufruf
             FrmNr : Formelnummer (bei statischem Aufruf)
                     Hilfsvariable (vom typ TCD_INT), die
                     die Formelnummer enth,lt
             Var :   Hilfsvariable f�rs Resultat
---------------------------------------------------------------------*/
TCD_INT TCD3FE1         (P_TCD_C_F1  pMyPar,
                                TCD_BOOL     option,
                                char *       Name,
                                TCD_LONG     ID,
                                TCD_INT      FrmNr,
                                P_TCD_DOUBLE Var)

{
  
   S_TCD_C_F1     sF1;
   P_TCD_C_F1     pF1 = &sF1;
   int            size = sizeof(S_TCD_C_F1) ;

  memset (pF1, 0, size) ;
  pF1->FrmIx = -1 ;	
  pF1->pPrevLevelInfo = pMyPar;
  pF1->FrmNr          = FrmNr;
  pF1->AttrID         = ID;
  pF1->AttrIx         = 0;
  pF1->CallType       = option;
  pF1->Level          = pF1->pPrevLevelInfo->Level + 1;
  pMyPar->pVarSkal    = Var;

  /* KFC 12.08.96 */
  if (pF1->CallType == TCD_CALLTYP_STA || 
      pF1->CallType == TCD_CALLTYP_STA_UE )

       pF1->FormelName = Name ;
  else pF1->AttrName = Name  ;
  
  pF1->pTCDTCD = pMyPar->pTCDTCD;
  FCall (pF1) ;

  return (pMyPar->pTCDTCD->pRbsSS->RCTL.RCInfo.Rc) ;
}


/*---------------------------------------------------------------------
   Interne Funktion: TCDFCT
   Beschreibung:     Diese Funktion behandelt einen Funktionsaufruf
                     (dyn, statisch) einer Tabellen Formel
   Parameter:        option: formelaufruftyp (sta, dyn)
             Name : Name des Attributs bei dyn- Call
                    Name der aufgerufenen Formel bei
                    statischem Call
             ID:    ID des Attributs (das die Formelnummer enth,lt)
                    bei statischem Aufruf
         ??  AIx :  Index des Attributs in der Formel
                    bei dynamischem Aufruf
             FrmNr : Formelnummer (bei statischem Aufruf)
                     Hilfsvariable (vom typ TCD_INT), die
                     die Formelnummer enth,lt
             Var :   Hilfsvariable f�rs Resultat
---------------------------------------------------------------------*/
TCD_INT TCD3FE2         (P_TCD_C_F1  pMyPar,
                                TCD_BOOL   option,
                                char *     Name,
                                TCD_LONG   ID,
                                TCD_INT    FrmNr,
                                P_P_TCDTAB Var)

{
   S_TCD_C_F1     sF1;
   P_TCD_C_F1     pF1 = &sF1;
   int            size = sizeof(S_TCD_C_F1); 

  memset ((void *)pF1, 0, size) ;
  pF1->FrmIx = -1 ;	
  pF1->pPrevLevelInfo = pMyPar;
  pF1->FrmNr          = FrmNr;
  pF1->AttrID         = ID;
  pF1->CallType       = option;
  pF1->Level          = pF1->pPrevLevelInfo->Level + 1;
  pMyPar->pVarTab     = Var;

  /* KFC 12.08.96 */
  if (pF1->CallType == TCD_CALLTYP_STA || 
      pF1->CallType == TCD_CALLTYP_STA_UE)

       pF1->FormelName = Name ;
  else pF1->AttrName   = Name ;
  
  pF1->pTCDTCD = pMyPar->pTCDTCD;
  FCall (pF1) ;

  return (pMyPar->pTCDTCD->pRbsSS->RCTL.RCInfo.Rc) ;
}


/* Funktionen zur Wiederverwendung */
void TCD3FESaveResult(P_TCD_C_F1  pMyPar)
{
   P_PAARLISTE         pPaarListe ;
   P_ERGEBNIS_POOL_ELT pErgPoolElt   ;
   TCD_LONG            ID = 0;

   if (!pMyPar || !pMyPar->PrcFNode) return;
   ID = pMyPar->PrcFNode->AssignVal.Prc.PrcID;

/* Optimierung:
           Sichern von Ergebnissen kann man sich sparen, wenn die
           iWiederVerwListenLaenge eh Null ist ... */

   if ( !pMyPar->PrcFNode->iWiederVerwListenLaenge )
      return;

   switch ( pMyPar->PrcFNode->iWiederVerwendungsTyp )
   {
      case 1:
         /* Bei Typ 1 ID mit der obersten ProcID �berschreiben */
         ID = pMyPar->pTCDTCD->pPrcData->TreeHdr.PrcID;

      case 2:

        /* Im Pool nachschauuen */
        if ( (pErgPoolElt=(P_ERGEBNIS_POOL_ELT)
              GetErgPoolElt(pMyPar->pTCDTCD,ID)) == NULL )
        {                                              
             pMyPar->pTCDTCD->pRbsSS->RCTL.RCInfo.Rc = 
                TCD_RC_PAARLISTEN_ERROR;
             return;                                                   
        }     
        else pPaarListe = pErgPoolElt->pPaarListe;

        break;

      case 3:

         pPaarListe = pMyPar->PrcFNode->pPaarListe;
         break;

      default :
         pPaarListe = NULL;
   }

   if ( !pPaarListe )
   {
      pMyPar->pTCDTCD->pRbsSS->RCTL.RCInfo.Rc = 
          TCD_RC_PAARLISTEN_ERROR;
      return;
   }
   /* Dieses Ergebnis nicht speichern, weil sich mindestens ein 
      relevantes Attribut (durch �berschreibung) geaendert hat */

   if ( pPaarListe == pMyPar->pTCDTCD->pPaarListeNotToSave )
   {
      pMyPar->pTCDTCD->pPaarListeNotToSave = NULL;
      return;
   }

   /* Ergebnis eintragen */
   {
       S_PAARLISTEN_EL pPaarListenElt;
       memset((void *)&pPaarListenElt,0,sizeof(S_PAARLISTEN_EL));

       pPaarListenElt.pAttrs             = pPaarListe->pAttrs;
       pPaarListenElt.iBerechnungsNummer = 
             pMyPar->pTCDTCD->iBerechnungsNummer;
       
       pPaarListenElt.lTabZeilen         = 
             pMyPar->pTCDTCD->SSAData.AnzZeilen ;
       pPaarListenElt.lTabSpalten        = 
             pMyPar->pTCDTCD->SSAData.AnzSpalten;
       
       pPaarListenElt.iType              = 
            pMyPar->PrcFNode->AttrType;

       switch ( pPaarListenElt.iType )
       {
          case TCD_ATTRFMT_SKAL :

             pPaarListenElt.Ergebnis.Skalar = *pMyPar->pVarSkal ;
             break;

          case TCD_ATTRFMT_TAB1 :
          case TCD_ATTRFMT_TAB2 :

             pPaarListenElt.Ergebnis.pTab = *pMyPar->pVarTab ;
             break;

          case TCD_ATTRFMT_VGLO :
          case TCD_ATTRFMT_DATE :
             break;
       }
       /* --nicht �berschriebene Ergebnisse gesondert behandeln----- */
       {
          TCD_INT iIndex = InsertPaarListElt( pMyPar->pTCDTCD,
                           pPaarListe, &pPaarListenElt);
          switch( iIndex )
          {                
             case   0 :
             case  -1 :     
                /* Zeiger pForGetAttr wird nicht mehr versorgt
                   wg. der Problematik mit gemerkten Adressen! */
                
                break; 
             
             case -9 : /* Speicherprobleme ?             */
                pMyPar->pTCDTCD->pRbsSS->RCTL.RCInfo.Rc = 
                     TCD_RC_STACK_OVERFLOW;
                break;
          }
       }
   }
}

TCD_INT TCDChkFrm             (P_TCD_C_F1  pMyPar , void * HV_0 )
{
   P_ERGEBNIS_POOL_ELT pPoolElt = NULL;
   P_PAARLISTE     pPaarListe   = NULL;
   P_PAARLISTEN_EL p            = NULL;

   P_TCDPRCNODE    pNode        = NULL;
   TCD_LONG        ID           = 0;
#ifdef TRACEFKT
   char *              pName;
#endif
                                   
   if (!pMyPar || !pMyPar->PrcFNode) return 0;
                                                   
   pNode        = pMyPar->PrcFNode;
   ID           = pNode->AssignVal.Prc.PrcID;
                                                      
#ifdef TRACEFKT
   pNode->AssignType == 1 ? (pName=pNode->AssignVal.Formel.FormelName):
                            (pName=pNode->AssignVal.Prc.FormelName   );
#endif
#ifdef PROTWV
   if (ProtWVEnabled(pMyPar->pTCDTCD))
      ProtWV2(pMyPar,pNode,pPaarListe,0);
#endif

   /* Anlegen von Speicherbereichen etc. nicht notwendig, wenn die
      iWiederVerwListenLaenge Null ist ... */

   if ( !pNode->iWiederVerwListenLaenge ) 
   {
      return 0;
   }

   switch ( pNode->iWiederVerwendungsTyp )
   {
      case 1:

         /* Bei Typ 1 ID mit der obersten ProcID �berschreiben */
         ID = pMyPar->pTCDTCD->pPrcData->TreeHdr.PrcID;

      case 2:

        /* PoolElement exisitert noch nicht ... */
        if ( (pPoolElt=(P_ERGEBNIS_POOL_ELT)
             GetErgPoolElt(pMyPar->pTCDTCD,ID)) == NULL )
        {
           /* demgemaess neu erzeugen */
           pPaarListe = NewAttrsResults(pMyPar->pTCDTCD,pNode,ID);
           if ( pPaarListe == NULL ) /* SpeicherFehler ? */
           {
              pMyPar->pTCDTCD->pRbsSS->RCTL.RCInfo.Rc = 
                  TCD_RC_PAARLISTEN_ERROR;
              return TCD_RC_PAARLISTEN_ERROR;
           }  
        }   
        else pPaarListe = pPoolElt->pPaarListe;

        break;

      case 3:

        if ( pNode->pPaarListe == NULL )
        {   
           pNode->pPaarListe = 
                NewAttrsResults(pMyPar->pTCDTCD,pNode,ID);
           if ( pNode->pPaarListe == NULL ) /* SpeicherFehler ? */
           {
              pMyPar->pTCDTCD->pRbsSS->RCTL.RCInfo.Rc = 
                   TCD_RC_PAARLISTEN_ERROR;
              return TCD_RC_PAARLISTEN_ERROR;
           }  
        }
        pPaarListe = pNode->pPaarListe;
        break;

        default :
          return 0;
   }

   /* MUB 22.7.96: Die Wiederverwendungslistenlaenge darf jetzt 
                   auch 0 sein. */
   /* in diesem Fall bleibt pPaarListe==NULL und es wird 
      immer berechnet */
   if ( !pPaarListe )
      return 0;

#ifdef PROTWV
   if (ProtWVEnabled(pMyPar->pTCDTCD))
      ProtWV2(pMyPar,pNode,pPaarListe,1);
#endif

/* 
Suchen nach der aktuellen Belegung und ggf. Abgrasen der 
PaarListen 
diese Suchart wird benutzt, wenn es keine relevanten Attribute gibt,
was bedeutet, dass das Ergebnis immer wiederverwendet werden kann 
es wird dann immer das 0te Element genommen, wenn es vorhanden ist 
*/
   {
      int iSuchArt = SUCHE_NICHT_IN_PAARLISTE; /*  -1 */

      /* Wenn es �berhaupt relevante Attribute gibt ... */
      if ( pPaarListe->pAttrs )
      {
         TCD_BOOL bGetActSettingsSuccess;
/* Zusammensuchen der aktuellen Belegung aller relevanten Attribute 
   des Knotens unabhaengig davon, ob in der PaarListe gesucht wird 
   oder nicht */                     
         bGetActSettingsSuccess = 
            (TCD_BOOL)GetActSettings(pMyPar,pPaarListe);
#ifdef PROTWV                                      
         if (ProtWVEnabled(pMyPar->pTCDTCD))
            ProtWV2(pMyPar,pNode,pPaarListe,2);
#endif                                      
         if ( !bGetActSettingsSuccess )
         {
            pMyPar->pTCDTCD->pPaarListeNotToSave = pPaarListe;
            return 0;
         }

         iSuchArt = SUCHE_IN_PAARLISTE; /* 0 */
      }
      /* Wenn's noch nix gibt, dann braucht man auch nicht suchen */
      if ( pPaarListe->pPaarListenElts->iLenOccupied == 0 )
      {
         return 0;
      }
      /* ansonsten schon ... */
      else
      {
         if ( (p = FindPaarListElt(pPaarListe,iSuchArt)) == NULL )
            return 0;
      }
   }
   /* es gibt einen PaarListenEintrag mit �bereinstimmender Belegung 
     der relevanten  Attribute. Daher das Ergebnis holen */

   switch ( p->iType )
   {
      case TCD_ATTRFMT_SKAL :
      {
         TCD_DOUBLE * f = (TCD_DOUBLE *)HV_0;
         *f = p->Ergebnis.Skalar ;

         break;
      }
      case TCD_ATTRFMT_TAB1 :
      case TCD_ATTRFMT_TAB2 :
      {
         TCD_LONG   i;
         TCD_LONG   lCopyLen;
         P_P_TCDTAB t = (P_P_TCDTAB)HV_0;

         if ( p->iType == TCD_ATTRFMT_TAB1 )

              lCopyLen = pMyPar->pTCDTCD->SSAData.AnzZeilen;
         else lCopyLen = (pMyPar->pTCDTCD->SSAData.AnzZeilen * 
                          pMyPar->pTCDTCD->SSAData.AnzSpalten);

         for ( i=0; i < lCopyLen; i++ )
             *(*t+i) = *(p->Ergebnis.pTab+i);

         break;
      }

      case TCD_ATTRFMT_VGLO :
      {
         TCD_VGLOP * v = (TCD_VGLOP *)HV_0;
         strcpy(*v,p->Ergebnis.VglOp);
         break;
      }
      case TCD_ATTRFMT_DATE :
      {
         TCD_DATUM * d = (TCD_DATUM *)HV_0;
         strcpy(*d,p->Ergebnis.Datum);
         break;
      }
      /* Uhps ... */
      default               :
         return 0;
   }
   return 1;
}

int     GetActSettings        (P_TCD_C_F1  pMyPar , 
                               P_PAARLISTE pPaarListe)
{
   P_TCDPRCNODE        pNode       = pMyPar->PrcFNode;
   P_TCDRELATTR        pRelAttr;
   P_TCDRELATTR_IMP    pRelAttrImp;
   
   TCD_INT             n;
   TCD_INT             i;
   TCD_INT             iCount = VectLen(pPaarListe->pAttrs);

   /* Schleife �ber die relevanten Attribute  */
   for ( i=0; i < VectLen(pPaarListe->pAttrs); i++ )
   {
      /* relevantes Attribut (i) lesen und initialisieren */
      pRelAttr = (P_TCDRELATTR) GetRelAttr( pPaarListe->pAttrs,i);
      memset((void *)&pRelAttr->Belegung,0,sizeof(U_TCDWVALUE));

      pRelAttr->bNotOverwritten    = 1;
      pRelAttr->iBerechnungsNummer = 
             pMyPar->pTCDTCD->iBerechnungsNummer;
      
      switch ( pNode->iWiederVerwendungsTyp )
      {
         case 1:

            /* RootKnoten, Belegung aus der Schnittstelle */
            if ( GetFromSS (pMyPar,pRelAttr) )
            {
               iCount--;
               break;
            }

         case 2:

            /* 1. gibt es einen �berschreibungsWert ? */
            if ( (GetFromUeS (pMyPar,pRelAttr)) )
            {
               pRelAttr->bNotOverwritten = 0;
               iCount--;
               break;
            }

            /* 2. gibt es einen hineingeerbten Wert ? */
            pRelAttrImp = 
                &pMyPar->pTCDTCD->pRelAttrs[pNode->iFirstRelAttrIx];

            pRelAttr->bGeerbterWertVorhanden = 0;
            for ( n=0; n < pNode->iAnzRelAttrs; n++ )
            {
               if ( pRelAttrImp->AttrID == pRelAttr->AttrID && 
                    pRelAttrImp->iIndex >= 0                 )
               {
                  if ( GetValueFromNode(pMyPar->pTCDTCD,pRelAttr,
                                        pRelAttrImp->iIndex))
                  {
                     pRelAttr->bGeerbterWertVorhanden = 1;
                     break;
                  }
                  else return 0;   
               }   
               pRelAttrImp++;
            }
            if ( pRelAttr->bGeerbterWertVorhanden )
            {
                iCount--;
                break;
            }       

            /* 3. Es muss einen Wert in der BestandsSchnittstelle 
                  geben  */
            if ( GetFromSS ( pMyPar,pRelAttr ))
            {
               iCount--;
               break;
            }

         case 3:

            /* 1. gibt es einen �berschreibungsWert ? */
            /* wenn nicht, den Wert aus der BestandsSchnittstelle 
               nehmen*/

            if ( GetFromUeS(pMyPar,pRelAttr) )
                 pRelAttr->bNotOverwritten = 0;
            else pRelAttr->bNotOverwritten = TYP3_NOT_OVERWRITTEN ;

            iCount--;
            break;
      }
   }

   /* --Alle relevanten Attribute muessen belegt sein  */
   if ( iCount == 0 )
        return 1;
   else return 0;
}

int     GetFromSS             (P_TCD_C_F1  pMyPar , 
                               P_TCDRELATTR pRelAttr)
{
   int iIndex = GetIndexToSS(pRelAttr->AttrID);

   if ( iIndex == -1 )
      return 0;

   switch ( pRelAttr->AttrType )
   {
      case TCD_ATTRFMT_SKAL :

         pRelAttr->Belegung.Skalar = 
               pMyPar->pTCDTCD->SSAData.pSkal[iIndex].Val;

         break;

      case TCD_ATTRFMT_TAB1 :
       pRelAttr->Belegung.TabID = 
            pMyPar->pTCDTCD->SSAData.pTab1[iIndex].TabID;


/* ------------------------------------------------------------------
Ist das relevante Attribut tabellenwertig und ist die TabellenID == 0
(AnwenderTabelle, keine Wiederverwendung eines damit entstandenen 
Ergebnisses), dann ist das damit erzielte Ergebnis auch 
'nicht sch�tzenswert'!
------------------------------------------------------------------  */
       if ( pRelAttr->Belegung.TabID == 0 )
          pRelAttr->bNotOverwritten = 0;

       break;

      case TCD_ATTRFMT_TAB2 :
       pRelAttr->Belegung.TabID = 
          pMyPar->pTCDTCD->SSAData.pTab2[iIndex].TabID;


       if ( pRelAttr->Belegung.TabID == 0 )
          pRelAttr->bNotOverwritten = 0;
       break;

      case TCD_ATTRFMT_VGLO :
         memcpy((void *)pRelAttr->Belegung.VglOp,
                (void *)pMyPar->pTCDTCD->SSAData.pVgl[iIndex].Val,
                sizeof(pMyPar->pTCDTCD->SSAData.pVgl[iIndex].Val));

         break;

      case TCD_ATTRFMT_DATE :
         memcpy((void *)pRelAttr->Belegung.Datum,
                (void *)pMyPar->pTCDTCD->SSAData.pDat[iIndex].Val,
                sizeof(pMyPar->pTCDTCD->SSAData.pDat[iIndex].Val));

         break;
   }
   return 1;
}


int     GetFromUeS    (P_TCD_C_F1  pMyPar, P_TCDRELATTR pRelAttr)
{
   int iIndex = GetIndexToUeS(pRelAttr->AttrID);

   if ( iIndex == -1 )
      return 0;

   switch ( pRelAttr->AttrType )
   {
      case TCD_ATTRFMT_SKAL :

         if ( pMyPar->pTCDTCD->SSAData.pParSkal[iIndex].Level > 0 )
         {
            pRelAttr->Belegung.Skalar = 
                pMyPar->pTCDTCD->SSAData.pParSkal[iIndex].Val;
            return 1;
         }
         break;

      case TCD_ATTRFMT_VGLO :

         if ( pMyPar->pTCDTCD->SSAData.pParSkal[iIndex].Level > 0 )
         {
            memcpy((void *)pRelAttr->Belegung.VglOp,
               (void *)pMyPar->pTCDTCD->SSAData.pParVgl[iIndex].Val,
                sizeof(pMyPar->pTCDTCD->SSAData.pParVgl[iIndex].Val));
            return 1;
         }
         break;

      case TCD_ATTRFMT_DATE :

         if ( pMyPar->pTCDTCD->SSAData.pParSkal[iIndex].Level > 0 )
         {
            memcpy((void *)pRelAttr->Belegung.Datum,
               (void *)pMyPar->pTCDTCD->SSAData.pParDat[iIndex].Val,
                sizeof(pMyPar->pTCDTCD->SSAData.pParDat[iIndex].Val));
            return 1;
         }
         break;
   }
   return 0;
}

int     FindAttrInTree     (P_TCD_C_F1  pMyPar , P_TCDRELATTR pRelAttr)
{
  P_TCDPRCNODE  PrcFNode = pMyPar->PrcFNode;
  P_TCDPRCELEM  pNode;
  int           i1;
  int           imax;

  if (PrcFNode != 0)
  {
      for (i1   = PrcFNode->SuccNodeIx,
           imax = PrcFNode->AnzSuccNodes,
           pNode = &(pMyPar->pTCDTCD->pPrcTreeNode [i1]) ;
           imax > 0;
           pNode ++, imax --)
           {
              if (pNode->Node.AttrID == pRelAttr->AttrID)
              {
                  if ( pNode->Node.AttrType != pRelAttr->AttrType )
                  {
                     /* --Ueberschreibung eines Formel/BV-Knotens mit 
                          was Anderem */
                     return -1;
                  }
                  switch ( pRelAttr->AttrType )
                  {
                     case TCD_ATTRFMT_SKAL :
                        pRelAttr->Belegung.Skalar = 
                            pNode->Node.AssignVal.Val.Skalar ;
                        break;

                     case TCD_ATTRFMT_TAB1 :
                     case TCD_ATTRFMT_TAB2 :
                        pRelAttr->Belegung.TabID  = 
                            pNode->Node.AssignVal.Val.TabData.TabID;
                        break;

                     case TCD_ATTRFMT_VGLO :
                     case TCD_ATTRFMT_DATE :
                        break;
                  }
                  return 1;
              }
      }
  }
  return 0;
}


/*---------------------------------------------------------------------
Interne Funktion: FindFrmNr
Beschreibung  :   sucht zu einem gegebenen Formelnamen die Formelnummer
Parameter:        FName
Returnwerte   :   zeiger auf den Tabelleneintrag, wenn die Formel dort 
                  ist andernfalls wird die RC Info gesetzt und 0 
                  returniert
---------------------------------------------------------------------*/
 P_TCDFTAB   FindFrmNr (P_TCD_C_G pTCDTCD, char * FName)
{
   TCD_INT    index = 0;
   P_TCDFTAB  pTab  = 0;

   if (FName)
   {
      while ( * s_formel_tabelle[index].FrmName != '\0' )
      {
          if ( strcmp( s_formel_tabelle[index].FrmName, FName ) == 0 ) 
          {
              pTab = (P_TCDFTAB)&s_formel_tabelle[index] ;
              return (pTab) ;
          }
          index ++;
      }
   }

   pTCDTCD->pRbsSS->RCTL.RCInfo.Rc = TCD_RC_UNKNOWN_FORM ;
   strcpy ( pTCDTCD->pRbsSS->RCTL.RCInfo.FormelName, FName) ;
   return (pTab) ;
}


/*---------------------------------------------------------------------
Interne Funktion: FindFrminTab
Beschreibung  :   sucht den Formeleintrag einer Formel �ber die Formel-
                 nummer und gibt den Zeiger auf den Eintrag in der
                 Tabelle zur�ck, wenn die Formel fgefunden wird
Parameter:        pFCTL->Formelname
Returnwerte   :   zeiger auf den Tabelleneintrag, wenn die Formel dort 
                ist andernfalls wird die RC Info gesetzt und 0 
                returniert
---------------------------------------------------------------------*/
 P_TCDFTAB   FindFrminTab (TCD_LONG FrmNr, TCD_INT *FTabIx)
{
   TCD_INT    start = 0 ;
   TCD_INT    end = TCD_FTABSIZE ;

   end -= 2 ;

   while ( start <= end)
   {
       *FTabIx = (start + end) /2 ;
       if (FrmNr < s_formel_tabelle[*FTabIx].FrmNr)
          end = *FTabIx - 1 ;
       else if (FrmNr > s_formel_tabelle[*FTabIx].FrmNr)
          start = *FTabIx  + 1 ;
       else
          return (P_TCDFTAB)&s_formel_tabelle[*FTabIx];
   }
/* pTCDTCD->pRbsSS->RCTL.RCInfo.Rc = TCD_RC_UNKNOWN_FORM ; */
   return (0);
}


/*---------------------------------------------------------------------
   Interne Funktion: GetMemFPar
   Beschreibung  :   Funktion liefert den Speicherplatz f�r den Formel-
                     parameter
   Parameter     :   pPoolCtl:           Zeiger auf Poolstruktur
                     pTCDTCD->PoolCtl.PoolAdmin:Adresse der PoolAdmin

   Returnwerte   :   pTCDTCD->PoolCtl.Rc:
                     OK,        Daten zu Objekt sind in der PoolAdmin
                                abgelegt
                        pTCDTCD->PoolCtl.PoolIx :Index in der PoolAdmin

                     NOT_FOUND, keine Belegung gefunden
---------------------------------------------------------------------*/
 P_TCD_C_F1  GetMemFPar ()
{
  P_TCD_C_F1 pF1;
  int  size ;

  size = sizeof(S_TCD_C_F1) ;
  pF1 = (P_TCD_C_F1) _TCDALLOC(1, size) ;
  if (pF1 == NULL)
     return (0) ;

  memset (pF1, 0, size) ;
  pF1->FrmIx = -1 ;
  return (pF1) ;
}


int       GetIndexToUeS         (TCD_LONG ID)
{
    	
   static int IndexAttrTab[ALLATTR_MAXID_LifeTemp + 1] = {-1};
   static int FlagFirst = 1;
   int iIndexinAttrTab;
   int MaxAnzAttr = ALLATTR_SIZE_LifeTemp; 
   if (FlagFirst == 1) 
   {
	FlagFirst = 0;

	for ( iIndexinAttrTab = 0; iIndexinAttrTab < MaxAnzAttr; 
			iIndexinAttrTab++ )
	{
		IndexAttrTab[AllAttrTab_LifeTemp[ iIndexinAttrTab].ID] = 
			AllAttrTab_LifeTemp   [iIndexinAttrTab].Index;
	}
   }  

    return IndexAttrTab[ID];
}

int     GetIndexToSS         (TCD_LONG    ID)
{
   int i;
   for ( i=0; i < (int)LifeTemp_ATAB_SIZE; i++ )
      if ( s_LifeTemp_AttrTab[i].ID == ID )
         return s_LifeTemp_AttrTab[i].Index;

   return -1;
}
/* CompareFunktion fuer bsearch */
int     cmpgle  (const void * key, const void * CurrentEntry)
{
    P_ATTRTAB  pKey = (P_ATTRTAB)key;
    P_ATTRTAB  pTab = (P_ATTRTAB)CurrentEntry;

    if ( pTab->ID < pKey->ID )
         return 1;
    else if ( pTab->ID > pKey->ID )
         return -1;
    else return 0;
}

/*---------------------------------------------------------------------
   Interne Funktion: FCall
   Beschreibung  :   Formelaufrufsteuerung
   Parameter     :   Formelparameter
   Returnwerte   :
---------------------------------------------------------------------*/
 void FCall ( P_TCD_C_F1 pF1 )
{
  P_TCDFTAB   pFTab ;
  if (pF1->FrmIx >= 0)
  {
      pFTab = (P_TCDFTAB)&s_formel_tabelle[pF1->FrmIx] ;
  }
  else
  {
      pFTab = FindFrminTab (pF1->FrmNr, &pF1->FrmIx) ;
  }

  if (pFTab)
  {

      pF1->FrmTyp = pFTab->FrmTyp ;
      pF1->CmpTime = pFTab->Datum ;
      pF1->FormelName = pFTab->FrmName ;
      pFTab->pFormelFunc ( pF1 );
      return ;
  }
  else
  {
      pF1->pTCDTCD->pRbsSS->RCTL.RCInfo.Rc = TCD_RC_ILLEGAL_FORM ;
      return ;
  }
}

/* falls pTCDTCD->GlbVarSet <> 0 ist, mu� der Ueberschreibungsstack
   aufger�umt werden ...*/
void ClearOverwriteStack(P_TCD_C_G pTCDTCD )
{
    int i;
    if ( pTCDTCD->GlbVarSet )
    {
        for ( i=0; i < pTCDTCD->SSAData.AnzParSkal; i++ )
        {                                   
            pTCDTCD->SSAData.pParSkal[i].Level  = 0;
            pTCDTCD->SSAData.pParSkal[i].Val    = 0;
        }            
        for ( i=0; i < pTCDTCD->SSAData.AnzParVgl; i++ )
        {                                   
            pTCDTCD->SSAData.pParVgl [i].Level  =   0;
            pTCDTCD->SSAData.pParVgl [i].Val[0] = '\0';
        }
        for ( i=0; i < pTCDTCD->SSAData.AnzParDat; i++ )
        {                                   
            pTCDTCD->SSAData.pParDat [i].Level  =   0;      
            pTCDTCD->SSAData.pParDat [i].Val[0] = '\0';
        }    
        pTCDTCD->GlbVarSet = 0;     
    }   
}           
