/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_PKF_H)
#define TCD_PKF_H
/*---------------------------------------------------------------------
    Modul:        C:\dev\TCD_DB\template\db\R3FE\C\C3E9\lifete10.h

    Beschreibung: Funktionsprototypen der externen Funktionen der
                  Formelsammlungsdatei
    By:           BEGGI
    Generiert am: 16.12.2019 15:07:19
---------------------------------------------------------------------*/
   
      void LifeTem1 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTem2 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTem3 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTem4 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTem5 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTem6 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTem7 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTem8 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTem9 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe10 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe11 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe12 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe13 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe14 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe15 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe16 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe17 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe18 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe19 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe20 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe21 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe22 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe23 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe24 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe25 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe26 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe27 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe28 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe29 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe30 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe31 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe32 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe33 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe34 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe35 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe36 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe37 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe38 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe39 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe40 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe41 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe42 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe43 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe44 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe45 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe46 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe47 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe48 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe49 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe50 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe51 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe52 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe53 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe54 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe55 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe56 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe57 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe58 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe59 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe60 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe61 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe62 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe63 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe64 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe65 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe66 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe67 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe68 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe69 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe70 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe71 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe72 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe73 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe74 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe75 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe76 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe77 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe78 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe79 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe80 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe81 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe82 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe83 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe84 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe85 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe86 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe87 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe88 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe89 (P_TCD_C_F1 pMyPar) ;
   

#endif
