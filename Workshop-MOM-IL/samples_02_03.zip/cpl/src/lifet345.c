/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
 /*--------------------------------------------------------------------
    Modul:        TCD_PKF.c

    Beschreibung: Funktionen C-Generator, die vom Makrogenerator
                  aufgerufen werden
    By:           BEGGI
    Datum:        16.12.2019 15:07:19
    Historie :    BEG  22.11.95      FM: 384
  MUB  21.5.96 Optimierung begonnen, Beschaffungsflags etc.
  MUB          Pr�fung, ob Ergebnis schon berechnet wurde.
  MUB 17.7.96  Abweisungen zwischen #ifdef TRACEFKT #endif korrigiert
  MUB 26.7.96  Erfolgreiche Wiederverwendung eines Ergebnisses
               ins Tracefile schreiben
---------------------------------------------------------------------*/

/* Includes */
/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDPORTAB_H)
#define TCDPORTAB_H

/*-----------------
Name        : TCDPORTAB.H

Beschreibung: externes Include File, das generierumgeungsspezifische
Informationen enthaelt (Makrovorlage).
By          : BEGGI
Datum       : 20.04.94
Historie:     BEG   17.01.95  neues Makro _TCDMEMINI anstatt memset
BEG   02.03.95  bedingte Macros TCDHUGE
BEG   22.06.95  _TCDMEMINI nur im HUGE-Modell redefiniert.
BEG   20.02.96  malloc.h wird nicht mehr inkludiert (FM 451)
RWE   21.06.96  malloc.h wird wieder includiert (aber nur
              fuers HUGE-Modell, d.h. fuer DOS/WIN-Compiler)
RWE   26.06.96  WATCHMEM-Makros eingebaut (fuer TCDALLOC etc)
MUB   17.7.96   Include mit !defined versehen
KFC   02.09.96  #define TCDHUGE vorgezogen

-------------------*/

/* #define TCDHUGE */              /* bei gro�en Tabellen einschalten*/
/* Systemincludes */                  
#include <stdlib.h>                /* atoi, ...       */
#include <stdio.h>                 /* fprintf, ...    */
#include <string.h>                /* strcpy, ...     */
#include <time.h>                  /* time_t, ...     */
#include <math.h>                  /* exp, min, max, ... */

#ifdef TCDHUGE
#include <malloc.h>
#endif

/* Defines */
#define  TCDC_EXT_NAME_LNG    8  /* maximale L�nge von externen 
                                    Bezeichnern*/
/*-----------------
  Definitionen aus standard C-Includes z.B. stdio.h
-------------------*/
#ifndef NULL
#define    NULL    (void *)0
#endif

/*-----------------
  Definitionen von Basistypen
-------------------*/
typedef    short   TCD_BOOL ;
typedef    long    TCD_LONG ;
typedef    int     TCD_INT  ;
typedef    double  TCD_DOUBLE ;


/*-----------------
  modellabhaengige Definitionen von Basistypen
-------------------*/
typedef    TCD_DOUBLE  TCDTAB ;
#ifdef TCDHUGE
typedef    TCDTAB       huge * P_TCDTAB ;
typedef    TCD_DOUBLE   huge * P_TCD_DOUBLE ;
typedef    P_TCD_DOUBLE * P_P_TCD_DOUBLE ;
typedef    char huge    * TCD_LPCHAR ;
#else
typedef    TCDTAB       * P_TCDTAB ;
typedef    TCD_DOUBLE   * P_TCD_DOUBLE ;
typedef    P_TCD_DOUBLE * P_P_TCD_DOUBLE ;
typedef    char         * TCD_LPCHAR ;
#endif

/*-----------------
  weitere (Typ-)Defines 
-------------------*/  
typedef int ERRNO_TYPE;
#define TCD_FILENAME_LNG 128

/*-----------------
  Definitionen von Makros f�r Speicherallokation
-------------------*/  

/* WATCHMEM muss im TCDHUGE-Modus abgeschaltet sein */
#ifdef TCDHUGE
#undef WATCHMEM
#endif

#undef _TCDALLOC
#undef _TCDFREE
#undef _TCDREALLOC

#ifndef WATCHMEM

#define _TCDALLOC(len,size)    malloc( (size_t)(len) * (size)) ;
#define _TCDFREE(ptr)          {free(ptr), ptr = NULL;}
#define _TCDREALLOC(ptr,size)  realloc( ptr, (size_t)(size) ) ;

#else
 
void *MallocAndProt(char *sFile_,int iLine_, size_t size);
#define _TCDALLOC(len,size)\
 MallocAndProt(__FILE__,__LINE__,(len) * (size))

void FreeAndProt(char *sFile_, int iLine_, void *p_);

#define _TCDFREE(ptr)\
       {FreeAndProt(__FILE__, __LINE__, ptr) , ptr = NULL;}

void *ReallocAndProt(char *sFile_,int iLine_, void *p_, size_t size);
#define _TCDREALLOC(ptr,size)\
 ReallocAndProt(__FILE__, __LINE__, ptr,size)

void ResumeWatchmem();

#endif

/*-----------------
  modellabh�ngige Definitionen von Makros f�r Speicherallokation
-------------------*/
#undef _TCDTABALLOC
#undef _TCDTABFREE
#undef _TCDMEMINI

#ifdef TCDHUGE

#define _TCDTABALLOC(len,size)\
  _halloc( (long)(len) , (size_t)(size)) ;
#define _TCDTABFREE(ptr)\
      { _hfree ( (void huge *)ptr); ptr = NULL;}

#else

#ifndef WATCHMEM
#define _TCDTABALLOC(len,size)\
 malloc((size_t)((long)len) * ((size_t)size)) ;
#define _TCDTABFREE(ptr)       {free(ptr), ptr = NULL;}
#else
#define _TCDTABALLOC(len,size)\
 MallocAndProt(__FILE__,__LINE__,(len) * (size))
#define _TCDTABFREE(ptr)\
       FreeAndProt(__FILE__, __LINE__, ptr)
#endif

#endif


#ifdef TCDHUGE
#define _TCDMEMINI(ptr,size,nr)\
{\
   long       j;\
   TCD_LPCHAR lp;\
   for (j= 0 , lp = (TCD_LPCHAR)ptr;\
        j < ((long)(size) * (long)(nr)); j++, lp++) \
      *lp = 0;\
}  

#else
#define _TCDMEMINI(ptr,size,nr)\
 { memset (ptr, 0, (size_t) ((size) * (nr))) ; }
#endif
/*---------------------------------
  NON-Ansi-Namen mit oder ohne "_"
----------------------------------*/

/* #define NON_ANSI_WITHOUT__ */

#ifdef NON_ANSI_WITHOUT__
#define _fcvt fcvt
#endif

/*---------------------------
  ggf. Verkuerzung der Namen
-----------------------------*/
#ifdef TCD_NAMLEN8

#define TCDIMPReleaseProcData       TCD_0001
#define TCDIMPReleaseNodeData       TCD_0002
#define TCDIMPReleaseTabImpData     TCD_0003   

#define FetchFromGlobalErgebnisPool TCD_0004

#define DelEltFromSVect             TCD_0005
#define DelEltFromSVectByIndex      TCD_0006

#define DelEltFromVect              TCD_0007
#define DelEltFromVectByIndex       TCD_0008
                                
                                
#define ReleaseGlobalErgebnisPool   TCD_0009
#define ReleaseGlobalErgebnis       TCD_0010
#define ReleaseLocalErgebnisPool    TCD_0011

#define GetPrcDataSkal              TCD_0012
#define GetPrcDataTab               TCD_0013
#define GetPrcDataDat               TCD_0014
#define GetPrcDataFrm               TCD_0015

#define GetPrcAttrSkal              TCD_0016
#define GetPrcAttrTab               TCD_0017

#define GetSSAttrSkal               TCD_0018
#define GetSSAttrTab                TCD_0019

#define ErgPoolGetFirstInfo         TCD_0020
#define ErgPoolGetNextInfo          TCD_0021

#define DConstrAttrs                TCD_0022
#define DConstrAttrsResults         TCD_0023

#define GetRelAttrs                 TCD_0024

#define GetIndexToGlobalErgPool     TCD_0025
#define GetIndexToPaarListElt       TCD_0026

#define GetIndexToSS                TCD_0027
#define GetIndexToUes               TCD_0028
#define GetFromSS                   TCD_0029
#define GetFromUes                  TCD_0030

#define TCDIMPImportTreeData        TCD_0031
#define TCDIMPNFIntl                TCD_0032
#define TCDIMPGetNodeFromID         TCD_0033
#define TCDIMPGetNodeFromPath       TCD_0034
#define compBsearch                 TCD_0035
#define TCDIMPReleaseTreeData       TCD_0036 
#define TCDIMPReleaseTabData        TCD_0037  
#define DConstrTCD_C_G              TCD_0038
#define DDestrTCD_C_G               TCD_0039 
#define SConstrTCD_C_G              TCD_0040
#define DConstrTCDRbsSS             TCD_0041
#define SConstrTCDRbsSS             TCD_0042
#define SConstrTCDISSADATA          TCD_0043
#define SDestrTCD_C_G               TCD_0044
#define DDestrTCDRbsSS              TCD_0045
#define SDestrTCDRbsSS              TCD_0046
#define SDestrTCDISSADATA           TCD_0047
#define GetRbsSSFkt                 TCD_0048
#define TCDIMPGetTabIDAndTypFromPath TCD_0049
#define TCDIMPGetPathAndTypFromID    TCD_0050
#define TCDIMPReleaseTabTreeData     TCD_0051
#define TCDIMPImportTabTreeData      TCD_0052
#endif

#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDC_H)
#define TCDC_H

#ifdef TCDV2_5
#define TCDVERS 25
#endif
#ifdef TCDV3_0
#define TCDVERS 30
#endif
#ifndef TCDVERS
#error TCD Version muss in Makefiles angegeben werden.
#endif

/*---------
Name        : TCDC.H

Beschreibung: Zentrales Include File fuer die Anwendung
TCD weit gueltig
*----------*/

#include "p09115.h" /* direkte Vektoren */

#define  TCD_TRUE                1
#define  TCD_FALSE               0

/*---------
  Definitionen Opcodes
*----------*/
#define  TCD_OPC_INIT_RBS                    1
#define  TCD_OPC_CALC_FRM                    2
#define  TCD_OPC_CALC_PRC                    3
#define  TCD_OPC_GETNUM_FRM                  4
#define  TCD_OPC_GET_ATTR_VAL                5
#define  TCD_OPC_RESET_RBS                   6
#define  TCD_OPC_SET_PRC                     7
#define  TCD_OPC_RESET_PRC                   8
#define  TCD_OPC_SET_POOLTAB                 9
#define  TCD_OPC_RESET_POOLTAB              10
#define  TCD_OPC_SET_ATTR_VAL               11
#define  TCD_OPC_GET_PRC_INFO               12
#define  TCD_OPC_SET_POOLTAB_I              13
#define  TCD_OPC_RESET_POOLTAB_I            14
#define  TCD_OPC_SET_ATTR_IN_PRC            15
#define  TCD_OPC_SET_TRACE_ON               16
#define  TCD_OPC_SET_TRACE_OFF              17
#define  TCD_OPC_REMOVE_RESULTS             18
#define  TCD_OPC_GET_FIRST_RESULTS_INFO     19
#define  TCD_OPC_GET_NEXT_RESULTS_INFO      20

/*---------
  Definitionen Returncodes
*----------*/
#define  TCD_RC_NOT_OK              0
#define  TCD_RC_OK                  1
#define  TCD_RC_ILLOPC              2
#define  TCD_RC_VERSION_CONFLICT    3
#define  TCD_RC_UNKNOWN_FORM        4
#define  TCD_RC_ILLEGAL_FORM        5
#define  TCD_RC_ILLEGAL_PARAM       6
#define  TCD_RC_UNKNOWN_ATTR        7
#define  TCD_RC_NOT_FOUND           8
#define  TCD_RC_INPUT_MISSING       9
#define  TCD_RC_ILLEGAL_DIVISION   10
#define  TCD_RC_ILLEGAL_TAB_RANGE  11
#define  TCD_RC_STACK_OVERFLOW     12
#define  TCD_RC_CONDITION_FAIL     15
#define  TCD_RC_PAR_ERROR          20
#define  TCD_RC_TAB_IN_POOL        21
#define  TCD_RC_TAB_NOT_IN_POOL    22
#define  TCD_RC_PRC_IN_POOL        23
#define  TCD_RC_PRC_NOT_IN_POOL    24
#define  TCD_RC_UNKNOWN_PROC       25
#define  TCD_RC_PAARLISTEN_ERROR   26
#define  TCD_RC_NO_VALUE_AVAIL     30
#define  TCD_RC_USER_SET_ERROR    900
#define  TCD_RC_INTERNAL_ERR      999
#define  TCD_RC_NO_RETURN         888

/*---------
  allgemeine globale Konstanten
*----------*/
#define TCD_INIT_VARSETLEVEL    9999

/*---------
  Konfigurationsangaben
*----------*/
#define TCD_POOLADMIN_SIZE        20
#define TCD_C_MIN_USER_TYPE_ID    0
#define TCD_C_TABLISTLEN          10
#define TCD_C_MAXPRCCALLNR        2147483647

/*---------
  Definitionen Laengenangaben
*----------*/
#define TCD_DATUM_LNG              9
#define TCD_FRM_DATUM_LNG         20
#define TCD_VGLOP_LNG              3
#define TCD_NAME_LNG              26

/*---------
  Definitionen Aufrufart: (Aufzaehlungstyp)
-----------*/
#define TCD_CALLTYP_ATTR        1
#define TCD_CALLTYP_STA         2
#define TCD_CALLTYP_DYN         3
#define TCD_CALLTYP_STA_UE      4

/*---------
  Definitionen Prefix
-----------*/
#define TCD_PREFIX_TAB            '&'
#define TCD_PREFIX_PRC            '$'
#define TCD_PREFIX_FRM            'F'
#define TCD_PREFIX_ATTR           'A'

/*---------
  Definitionen Formeltypen (Aufzaehlungstyp, Wertevergabe analog Cobol)
-----------*/
#define TCD_FRMTYP_SKAL        1
#define TCD_FRMTYP_TAB1        2
#define TCD_FRMTYP_TAB2        3

/*---------
  Definitionen Belegungswerte PoolEntry
-----------*/
#define  TCD_POOLENT_INIT          0
#define  TCD_POOLENT_USED          1
#define  TCD_POOLENT_I_USED        2
#define  TCD_POOLENT_E_USED        3

/*---------
  Definitionen Assigntype
*----------*/
#define  TCD_DC_USE_NOT            0
#define  TCD_DC_USE_FRM            1
#define  TCD_DC_USE_PRC            2
#define  TCD_DC_USE_TAB            3
#define  TCD_DC_USE_VAL            4

/*----------
  Definitionen Formattypen
-----------*/
#define  TCD_ATTRFMT_SKAL          1
#define  TCD_ATTRFMT_TAB1          2
#define  TCD_ATTRFMT_TAB2          3
#define  TCD_ATTRFMT_VGLO          4
#define  TCD_ATTRFMT_DATE          5

/*----------
  Struktur Bestandsattributtabelle
 ----------*/
  typedef struct tagS_TCDATAB {
        char          Name [TCD_NAME_LNG] ;
        TCD_LONG      ID         ;
        TCD_INT       Index      ;
        TCD_INT       AttrTyp    ;
  } S_TCDATAB     ;

 typedef S_TCDATAB     * P_TCDATAB     ;

/*----------
  Struktur Tabelle aller Attribute
 ----------*/
  typedef struct tagS_ATTRTAB
  {
    TCD_LONG  ID    ;
    TCD_INT   Index ;
  } S_ATTRTAB ;

  typedef S_ATTRTAB    * P_ATTRTAB     ;

/*----------
  Typdefinition systemunabhanegiger Typen
 ----------*/
   typedef  char  TCD_VGLOP [TCD_VGLOP_LNG] ;
   typedef  char  TCD_DATUM [TCD_DATUM_LNG] ;

   typedef TCD_DOUBLE TCDTAB1 ;
   typedef P_TCDTAB   P_TCDTAB1 ;

   typedef TCD_DOUBLE TCDTAB2 ;
   typedef P_TCDTAB   P_TCDTAB2 ;

   typedef P_P_TCD_DOUBLE P_P_TCDTAB ;

/*---------
  Union Attributbelegung
 ----------*/
  typedef  union tagU_TCDVALUE {
           TCD_DOUBLE        Skalar;
           P_TCDTAB1         pTab1 ;
           P_TCDTAB2         pTab2 ;
   } U_TCDVALUE ;

  typedef  union tagU_TCDGVALUE {
           TCD_DOUBLE        Skalar;
           P_TCDTAB          pTab  ;
           TCD_VGLOP         VglOp ;
           TCD_DATUM         Datum ;
   } U_TCDGVALUE ;

/* --
 MUB 2.7.96: neu eingefuehrt, weil wir die TabellenID brauchen
--  */
  typedef  union tagU_TCDWVALUE
  {
           TCD_DOUBLE        Skalar;

           TCD_LONG          TabID ;  /*  die relevanten Attribute */
           P_TCDTAB1         pTab  ;  /*  das Ergebnis */

           TCD_VGLOP         VglOp ;
           TCD_DATUM         Datum ;
   } U_TCDWVALUE ;

  typedef struct tagS_TCDPRCVAL {
          TCD_LONG   PrcID ;
          TCD_LONG   FormelNr ;
          TCD_INT    FormelIx ;
          char       FormelName [TCD_NAME_LNG] ;
          TCD_INT    PoolIx ;
#if TCDVERS > 25
/* Version der Formel zur Pruefung 
		  Formel-Generat gegen Transport-Format */
          TCD_INT    FormelVers;
#endif

 } S_TCDPRCVAL ;

  typedef union  tagU_TCDNDVALUE {
          struct   tagTabData {
             TCD_LONG  TabID ;
             TCD_INT   PoolIx ;
          } TabData  ;
          TCD_DOUBLE Skalar ;
          char       Datum [TCD_DATUM_LNG] ;
          char       VglOp [TCD_VGLOP_LNG];
 } U_TCDNDVALUE ;


  typedef struct tagS_TCDFORMEL {
           TCD_LONG  FormelNr ;
           TCD_INT  FormelIx ;
           char     FormelName [TCD_NAME_LNG] ;
           TCD_INT  IsStaRef ;                                 
#if TCDVERS > 25
/* Version der Formel zur Pruefung 
		   Formel-Generat gegen Transport-Format */
		   TCD_INT  FormelVers;
#endif
 } S_TCDFORMEL ;

  typedef union  tagU_TCDASSIGNVAL {

       S_TCDPRCVAL  Prc    ;
       U_TCDNDVALUE Val    ;
       S_TCDFORMEL  Formel  ;

 } U_TCDASSIGNVAL ;

#define TYP3_NOT_OVERWRITTEN 2

typedef struct tagS_TCDREL_ATTR
{                                 
   TCD_LONG    iBerechnungsNummer;
   /* ID des Attributs                            */
   TCD_LONG    AttrID                  ;  
   /* Typ der Belegung SKALAR, TAB, DATUM , VGLOP */
   TCD_INT     AttrType              :4;  
   /* Flag, ob ein geerbter Wert vorhanden ist    */
   TCD_INT     bGeerbterWertVorhanden:2;  
   /* Flag, ob ein geerbter Wert vorhanden ist    */
   TCD_INT     bNotOverwritten         ;
   /* GGf. Wert hierzu                            */
   U_TCDWVALUE Belegung                ;  

}  S_TCDRELATTR;

typedef S_TCDRELATTR * P_TCDRELATTR ;

/* --
   S_TCDRELATTR_IMP    Relevantes Attribut fuer den Import
--  */
typedef struct tagS_TCDREL_ATTR_IMP
{
   TCD_LONG AttrID;
   TCD_INT  AttrType               : 4;
   TCD_INT  iIndex;

}  S_TCDRELATTR_IMP;

typedef S_TCDRELATTR_IMP * P_TCDRELATTR_IMP ;

/* --
   S_PAARLISTEN_EL    Struktur fuer ein PaarlistenElement
--  */
typedef struct tagS_PAARLISTEN_EL
{
   /* Vektor der relevanten Attribute mit der aktuellen Belegung     */
   LP_VECT          pAttrs;        
   /* lfde. Nummer der aktuellen Berechnung                          */
   TCD_LONG         iBerechnungsNummer; 
   
   TCD_LONG         lTabZeilen;         
   TCD_LONG         lTabSpalten;
   
   /* Typ des Ergebnisses (kann 'NOT_OVERWRITTEN' sein)              */
   TCD_INT          iType;              
   /* Ergebnis hierzu                                                */
   U_TCDWVALUE      Ergebnis;           

}  S_PAARLISTEN_EL;

typedef S_PAARLISTEN_EL * P_PAARLISTEN_EL ;

/* --
   S_PAARLISTE     Struktur zu einem Belegknoten einer BV
   Sie enthaelt 1 sortierten Vektor, 1 Liste und eine maximale Laenge
   fuer die Anzahl Elemente der Paarliste (Belegung,Ergebnis)
--  */
typedef struct tagS_PAARLISTE
{
   TCD_INT iWiederVerwendungsTyp;   /* KnotenTyp 1/2/3     */
   TCD_INT iWiederVerwListenLaenge; /* ListenLaenge maximal */
   TCD_INT iAct ;                   /* letztes Element     */

   /* direkter Vektor von S_ATTR_EL's   */
   LP_VECT pAttrs;                  
   /* direkter Vektor von S_PAARLISTEN_EL's */
   LP_VECT pPaarListenElts;         

}  S_PAARLISTE;

typedef S_PAARLISTE * P_PAARLISTE ; 

/* --
   S_ERGEBNIS_POOL_ELT Element eines PoolErgebnisses
--  */
typedef struct tagS_ERGEBNIS_POOL_ELT
{
   TCD_LONG    ID;
   P_PAARLISTE pPaarListe;

}  S_ERGEBNIS_POOL_ELT;

typedef S_ERGEBNIS_POOL_ELT * P_ERGEBNIS_POOL_ELT ;

/*-----------
  Struktur     Belegungsknoten
------------*/
  typedef struct tagS_TCDPRCNODE
  {
      TCD_LONG         AttrID                  ;
      TCD_INT          NodeID                  ;
      TCD_INT          AttrType                ;
      TCD_INT          AssignType              ;
      U_TCDASSIGNVAL   AssignVal               ;
      TCD_INT          SuccNodeIx              ;
      TCD_INT          AnzSuccNodes            ;
      TCD_INT          Usage                   ;

      P_PAARLISTE      pPaarListe              ;
      P_PAARLISTEN_EL  pResultForGetAttr       ;

      TCD_INT          iWiederVerwendungsTyp   ;
      TCD_INT          iWiederVerwListenLaenge ;
      TCD_INT          iAnzRelAttrs            ;
      TCD_INT          iFirstRelAttrIx         ;

  }   S_TCDPRCNODE ;

 typedef S_TCDPRCNODE  * P_TCDPRCNODE ;

/*-----------
  Struktur Auspraegungs-Belegungs-Information
------------*/
  typedef struct tagS_TCDPRCINFO {
         char  Name [TCD_NAME_LNG] ;
         TCD_LONG  ID ;
         TCD_INT   Formattyp ;
         TCD_INT   Typ ;
         TCD_INT   Klasse ;
         TCD_INT   AnzBeleg ;
         TCD_INT   TabIx ;
         TCD_LONG  RefNodeId ;
 } S_TCDPRCINFO ;

 typedef S_TCDPRCINFO  * P_TCDPRCINFO ;

/*--------
  Struktur LocalData MUB 2.7.96: wird nicht mehr verwendet!
 --------*/
  typedef struct tagS_TCDPRCLOCD {
          TCD_LONG FormelNr     ;
          TCD_INT  Usage        ;
          TCD_INT  Typ          ;
          union   {
              TCD_INT    PoolIx ;
              TCD_DOUBLE Val    ;
          } Data ;
          TCD_LONG  CalcByCallNr ;
   } S_TCDPRCLOCD ;

   typedef S_TCDPRCLOCD * P_TCDPRCLOCD ;

/*---------
  Struktur Header Auspraegungsbaum
----------*/
  typedef struct tagS_TCDPRCHDR {
    TCD_LONG       PrcID        ;
    TCD_LONG       FormelNr     ;
    TCD_INT        AnzPrcTree   ;
    TCD_INT        AnzBelegInfo ;
    TCD_INT        AnzRelAttrs  ;
    TCD_BOOL       FlSetAttrSkal;
    TCD_BOOL       FlSetAttrTab ;
    TCD_BOOL       FlSetAttrVgl ;
    TCD_BOOL       FlSetAttrDat ;
    TCD_BOOL       FlPrcCompl   ;
    TCD_LONG       PrcResIx     ;
    TCD_LONG       PrcCallNr    ;

 } S_TCDPRCHDR     ;


/*---------
  Struktur Auspraegungselement
-----------*/
  typedef union  tagU_TCDPRCELEM
  {
     S_TCDPRCHDR      TreeHdr;
     S_TCDPRCNODE     Node ;
     S_TCDPRCINFO     Info ;     
  }  U_TCDPRCELEM ;

 typedef U_TCDPRCELEM  * P_TCDPRCELEM ;

#define TCDPRCSIZE(pPrc)    (pPrc ? sizeof(S_TCDRELATTR_IMP)*\
                            (TCD_LONG)pPrc->TreeHdr.AnzRelAttrs +\
                            sizeof(U_TCDPRCELEM)*\
                            ( (TCD_LONG)pPrc->TreeHdr.AnzPrcTree +\
                             (TCD_LONG)pPrc->TreeHdr.AnzBelegInfo) : 0)


/*-------
  Datenstruktur Mehrfach-Auspraegung (MultiProc)
 --------*/
  typedef struct tagS_TCDMPRCENTRY {
        TCD_INT              PrcBelegt ;
        TCD_LONG             ID ;
        P_TCDPRCELEM         pPrcData ;
 } S_TCDMPRCENTRY ;

  typedef S_TCDMPRCENTRY * P_TCDMPRCENTRY ;

  typedef struct tagS_TCDMPRCADMIN {
        TCD_INT          Anzahl  ;
        P_TCDMPRCENTRY   Data    ;
 } S_TCDMPRCADMIN ;

 typedef S_TCDMPRCADMIN * P_TCDMPRCADMIN ;

/*--------
  Datenstruktur PoolAdmin
--------*/
  typedef struct tagS_TCDPOOLENTRY {
        TCD_LONG     ID ;
        TCD_INT      Usage ;
        TCD_INT      Typ ;
        TCD_INT      Fmttyp ;
        P_TCD_DOUBLE pData ;
  } S_TCDPOOLENTRY ;

  typedef S_TCDPOOLENTRY * P_TCDPOOLENTRY ;

  typedef struct tagS_TCDPOOLADMIN {
        TCD_INT          Anzahl  ;
        TCD_INT          AnzTabs ;
        TCD_INT          AnzProcs ;
        TCD_INT          AnzTemp  ;
        S_TCDPOOLENTRY * Data    ;
 } S_TCDPOOLADMIN ;

  typedef S_TCDPOOLADMIN * P_TCDPOOLADMIN ;

/*------
  Datenstruktur Kontrollstruktur
--------*/
  typedef struct tagS_TCDRBSINFO {
       char TcdVersion [TCD_DATUM_LNG]   ;
       char TcdRelease [TCD_DATUM_LNG]   ;
       char RbsInterf  [TCD_DATUM_LNG]   ;
       TCD_LONG RbsId ;
   } S_TCDRBSINFO ;

   typedef struct tagS_TCDRCINFO {
       TCD_INT   Rc ;
       TCD_INT   Errc ;
       char FormelName [TCD_NAME_LNG] ;
       TCD_INT   FormelNr ;
       char AttrName   [TCD_NAME_LNG] ;
   } S_TCDRCINFO          ;

   typedef S_TCDRCINFO * P_TCDRCINFO ;


   typedef struct tagS_TCDCTLPAR {

/*-
  Opcode:   TCD_OPC_GET_ATTR_VAL, TCD_OPC_SET_ATTR_VAL
--*/
        struct tagS_TCDPARGA {
           TCD_LONG    ProcID;
           TCD_LONG    ID;
           TCD_LONG    TabID;
           TCD_INT     TabIx ;
           U_TCDGVALUE Val ;
           TCD_INT     Typ ;
           TCD_INT     ProcIx;
        }            GA ;

/*-
  Opcode:   TCD_OPC_SET_POOLTAB
--*/
        struct tagS_TCDPARST {
            TCD_LONG  ID;
            TCD_INT   Dim ;
            P_TCDTAB  pTab ;
            TCD_INT    TabIx ;
        }            ST ;

/*-
  Opcode:   TCD_OPC_RESET_POOLTAB
--*/
        struct tagS_TCDPARRT{
            TCD_LONG  ID;
            P_TCDTAB  pTab ;
        }            RT ;

/*-
  Opcode:   TCD_OPC_SET_PRC
--*/
        struct tagS_TCDPARSP {
            TCD_LONG      ProcID;
            P_TCDPRCELEM  pProc;
            TCD_INT       ProcIx;
        }            SP;

/*-
  Opcode:   TCD_OPC_RESET_PRC
--*/
        struct tagS_TCDPARRP {
            TCD_LONG  ProcID;
            P_TCDPRCELEM  pProc;
        }            RP;

/*-
  Opcode:   TCD_OPC_CALC_FRM , TCD_OPC_CALC_PRC
--*/
        struct tagS_TCDPARCFP {
            TCD_LONG       FormelNr ;
            TCD_LONG       ProcID;
            TCD_INT        Typ ;
            U_TCDVALUE     Value ;
            TCD_INT        ProcIx;
        }            CFP ;

/*-
  Opcode:   TCD_OPC_GETNUM_FRM
--*/
        struct tagS_TCDPARGF {
            char  Name [TCD_NAME_LNG] ;
            TCD_LONG  FormelNr ;
        }            GF ;

/*-
  Opcode:   TCD_OPC_GET_PRC_INFO
--*/
        struct tagS_TCDPRCBINFO {
            TCD_LONG        ProcID;
            TCD_INT         ProcIx;
            P_TCDPRCELEM    pProcInfo;
            TCD_INT         AnzProcInfo ;
        }            PI ;

/*-
  Opcode:   TCD_OPC_REMOVE_RESULTS,
            TCD_OPC_GET_FIRST_RESULTS_INFO,
            TCD_OPC_GET_NEXT_RESULTS_INFO
--*/
        struct tagS_TCDPAR_RESULTPOOL {
            TCD_LONG        ProcID;
            TCD_LONG        lNumOfResults;
            TCD_INT         bFinished;
        }            RESP ;

   } S_TCDCTLPAR ;

   typedef S_TCDCTLPAR * P_TCDCTLPAR ;

   typedef struct tagS_TCDRBSCTL {
          TCD_INT       Opc     ;
          S_TCDRBSINFO  RbsInfo ;
          S_TCDRCINFO   RCInfo  ;
          S_TCDCTLPAR   Par     ;
  } S_TCDRBSCTL ;

   typedef S_TCDRBSCTL * P_TCDRBSCTL ;

/*------
  Datenstruktur Rechenbausteinschnittstelle
 --------*/
   typedef struct tagS_TCDV_F_FLAGS {
         TCD_BOOL       V_In   ;
         TCD_BOOL       F_In   ;
         TCD_BOOL       V_Comp ;
         TCD_BOOL       V_Use  ;
         TCD_BOOL       F_Use  ;
         TCD_BOOL       V_Miss ;
         TCD_BOOL       F_Miss ;
   } S_TCDV_F_FLAGS ;

   typedef S_TCDV_F_FLAGS * P_TCDV_F_FLAGS ;

   typedef struct tagS_TCDV_FLAGS {
         TCD_BOOL       V_In   ;
         TCD_BOOL       V_Use  ;
         TCD_BOOL       V_Miss ;
   } S_TCDV_FLAGS ;

   typedef S_TCDV_FLAGS   * P_TCDV_FLAGS   ;

   typedef struct tagS_TCDSKAL_DATA
   {
        TCD_DOUBLE      Val    ;
        TCD_LONG        Formel ;
        S_TCDV_F_FLAGS  Flags  ;
   } S_TCDSKAL_DATA ;

   typedef S_TCDSKAL_DATA * P_TCDSKAL_DATA ;

   typedef struct tagS_TCDTAB1_DATA
   {
     TCD_LONG        TabID;
     P_TCDTAB1       pVal ;
     TCD_LONG        Formel ;
     S_TCDV_F_FLAGS  Flags ;

   } S_TCDTAB1_DATA ;
   typedef S_TCDTAB1_DATA  * P_TCDTAB1_DATA  ;

   typedef struct tagS_TCDTAB2_DATA
   {
     TCD_LONG        TabID;
     P_TCDTAB2       pVal ;
     TCD_LONG        Formel ;
     S_TCDV_F_FLAGS  Flags ;

   } S_TCDTAB2_DATA ;
   typedef S_TCDTAB2_DATA * P_TCDTAB2_DATA ;

   typedef struct tagS_TCDDAT_DATA {
        char             Val [TCD_DATUM_LNG] ;
        S_TCDV_FLAGS     Flags ;
   } S_TCDDAT_DATA ;

   typedef S_TCDDAT_DATA * P_TCDDAT_DATA ;

   typedef struct tagS_TCDVGL_DATA {
        char            Val [TCD_VGLOP_LNG] ;
        S_TCDV_FLAGS    Flags ;
   } S_TCDVGL_DATA ;

   typedef S_TCDVGL_DATA * P_TCDVGL_DATA ;

   typedef struct tagS_TCD_RBS_SSA
   {
        P_TCDSKAL_DATA    pSkal ;
        P_TCDTAB1_DATA    pTab1 ;
        P_TCDTAB2_DATA    pTab2 ;
        P_TCDDAT_DATA     pDat  ;
        P_TCDVGL_DATA     pVgl  ;
   } S_TCD_RBS_SSA ;

   typedef S_TCD_RBS_SSA  * P_TCD_RBS_SSA ;


   typedef struct tagS_TCDRBS_SS {
       S_TCDRBSCTL       RCTL ;
       S_TCD_RBS_SSA     SSAData   ;
       S_TCDPOOLADMIN    PoolAdmin ;
       S_TCDMPRCADMIN    MPrcAdmin ;
 } S_TCDRBS_SS ;

 typedef S_TCDRBS_SS  * P_TCDRBS_SS ;

  typedef struct tagS_TCDPARATTR_SK {
        TCD_INT      Level ;
        TCD_DOUBLE   Val ;
 } S_TCDPARATTR_SK   ;

 typedef S_TCDPARATTR_SK  * P_TCDPARATTR_SK ;

  typedef struct tagS_TCDPARATTR_VGL {
        TCD_INT      Level;
        char         Val  [TCD_VGLOP_LNG] ;
 } S_TCDPARATTR_VGL  ;

 typedef S_TCDPARATTR_VGL * P_TCDPARATTR_VGL ;

  typedef struct tagS_TCDPARATTR_DAT
  {
        TCD_INT      Level;
        char         Val  [TCD_DATUM_LNG] ;
 } S_TCDPARATTR_DAT  ;

 typedef S_TCDPARATTR_DAT * P_TCDPARATTR_DAT ;

/*-----------
  Struktur Schnittstellendaten (interne Sicht)
-----------*/
  typedef struct tagS_TCDISSADATA
  {
     TCD_INT      AnzSSASkal ;
     TCD_INT      AnzSSATab1 ;
     TCD_INT      AnzSSATab2 ;
     TCD_INT      AnzSSADat ;
     TCD_INT      AnzSSAVgl ;
     TCD_INT      AnzParSkal;
     TCD_INT      AnzParVgl ;
     TCD_INT      AnzParDat ;
     TCD_INT      AnzZeilen ;
     TCD_INT      AnzSpalten ;
     P_TCDSKAL_DATA    pSkal ;
     P_TCDTAB1_DATA    pTab1 ;
     P_TCDTAB2_DATA    pTab2 ;
     P_TCDDAT_DATA     pDat ;
     P_TCDVGL_DATA     pVgl ;
     P_TCDPARATTR_SK   pParSkal ;
     P_TCDPARATTR_VGL  pParVgl;
     P_TCDPARATTR_DAT  pParDat;

 }   S_TCDISSADATA ;
 typedef S_TCDISSADATA * P_TCDISSADATA ;



/*------
Datenstruktur globale Daten des Rechenbausteins;
diese Datenstruktur enthaelt Informationen und Teilstrukturen, die
in den programmierten Funktionen benoetigt werden.
Initialisierung dieser Daten erfolgt mehrstufig.
- beim Init: globaler Pointer pTCDTCD initialisiert (zeigt auf die Str)
pRbsSS zeigt auf die RBS-Schnittstelle
- bei auspraegungsspez. Opcodes werden die Teilstrukturen fuer die
Auspraegung initialisiert, ...
- bei einer neuen Berechnung werden die internen Aufrufschnittstellen
initialisiert
--------*/
  typedef struct tagS_TCD_C_G
  {
      P_TCDRBS_SS      pRbsSS      ;
      P_TCDPRCELEM     pPrcData    ;
      S_TCDPRCHDR *    pPrcHdr     ;
      P_TCDPRCELEM     pPrcTreeNode;
      P_TCDPRCELEM     pInfo       ;
      P_TCDRELATTR_IMP pRelAttrs   ;
      P_TCDMPRCADMIN   pMPrcAdmin  ;
      P_TCDRBSCTL      pRbsCtl     ;
      S_TCDISSADATA    SSAData     ;
      P_TCDPOOLADMIN   pPoolAdmin  ;
      TCD_INT          GlbVarSet   ;
      TCD_LONG         RBS_ID      ;
      TCD_BOOL         ValFound    ;
      TCD_BOOL         FrmFound    ;
      TCD_BOOL         V_Comp      ;
      TCD_BOOL         PrcChg      ;
      void *           pApplIf     ;
      P_TCDTAB         ResTab      ;
      TCD_DOUBLE       ResSkal     ;
      
      TCD_LONG         LastCalcPrcID;
      LP_VECT          pErgebnisPool;
      TCD_LONG         iBerechnungsNummer;
      TCD_INT          iErgPoolIteratorGl;                       
      P_PAARLISTE      pPaarListeNotToSave;
      
      TCD_BOOL         btrace_open;
      TCD_BOOL         btrace_enabled;
      
/* RWE, 10.06.1997: Neues Datenelement fuer Beobachtung
   der Wiederverwendung (ehemals WatchPol-Funktionalitaet) */
      TCD_BOOL         bProtWV;
      
  }   S_TCD_C_G ;
  typedef S_TCD_C_G   * P_TCD_C_G ;
#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDI_H)
#define TCDI_H
/*--------------
    Name        : TCDI.H

    Beschreibung: Include File intern nur f�r C- Generator
                  wird von den fest programmierten Moduln und
                  generierten Moduln benoetigt
    By          : BEGGI
    Datum       : 22.02.94
    Historie    : BEG   28.11.95   Definition Attributklassen
*--------------*/

/*-------------
  Returncodes FrmRet und ValRet (Definitionen analog Cobol) fuer
  Attributmanager
---------------*/
#define TCD_AIRC_CALLVIAFRM    4

/*-------------
  Definitionen Attributtypen (Aufzaehlungstyp)
---------------*/
#define TCD_ATTYP_TAR_SKAL      1
#define TCD_ATTYP_TAR_TAB1      2
#define TCD_ATTYP_TAR_TAB2      3
#define TCD_ATTYP_TAR_DATE      4
#define TCD_ATTYP_TAR_VGLO      5
#define TCD_ATTYP_BST_SKAL      6
#define TCD_ATTYP_BST_TAB1      7
#define TCD_ATTYP_BST_TAB2      8
#define TCD_ATTYP_BST_DATE      9
#define TCD_ATTYP_BST_VGLO     10

#define TCD_ATTRTYP_SKAL        0
#define TCD_ATTRTYP_TAB1        1
#define TCD_ATTRTYP_TAB2        2
#define TCD_ATTRTYP_DATE        3
#define TCD_ATTRTYP_VGLO        4

/*--------------
  Definitionen Attributklasse
---------------*/
#define TCD_ATTRCLASS_TAR       1
#define TCD_ATTRCLASS_BST       6

/*-------------
  Definitionen Errorcodes
---------------*/
#define TCD_UNKNOWN_OPCODE       1
#define TCD_NO_SPACE_IN_TLIST    2
#define TCD_ERR_GETMEM           3
#define TCD_GETEMPTYENTRY        4
#define TCD_NOPOOLADMIN          5
#define TCD_ILLTABFMT            6
#define TCD_UNK_ASSIGNTYP        7
#define TCD_NO_MPRCADMIN         8
#define TCD_EXPPOOLADMIN         9
#define TCD_NO_MEMORY           10
#define TCD_NO_PRCREF           11
#define TCD_ILLFRM_ID           12
#define TCD_ILLFRM_CMP          13
#define TCD_ERR_INIT_FORMEL     14
#define TCD_FRMGEN_OUT_OF_DATE	15
#define TCD_TRPFMT_OUT_OF_DATE	16

/*----------
  Datenstruktur Freigabeliste  Hilfsvariablentabellen
 ------------*/
  typedef struct tagS_TCDTABLIST    {
         TCD_INT        CallOvw ;
         TCD_LONG       CallerID ;
         TCD_LONG       CallFrmNr ;
         TCD_INT        CallType  ;
         P_TCD_DOUBLE   Adr ;
 } S_TCDTABLIST   ;

 typedef  S_TCDTABLIST  * P_TCDTABLIST  ;

/*----------
  Datenstruktur Formelparameter
 ------------*/
  typedef struct tagS_TCD_C_F1 
  {
     char         * FormelName     ;
     TCD_INT        FrmTyp         ;
     TCD_LONG       FrmNr          ;
     TCD_INT        FrmIx          ;
     char         * AttrName       ;
     TCD_INT        CallType       ;
     TCD_LONG       AttrID         ;
     TCD_INT        AttrTyp        ;
     TCD_INT        AttrIx         ;
     TCD_INT        ParIx          ;
     TCD_INT        Ret            ;
     TCD_INT        ExecCond       ;
     P_TCDPRCNODE   PrcFNode       ;
     P_TCDPRCNODE   pNode          ;
     TCD_INT        MinVarSet      ;
     TCD_INT        BegVarSet      ;
     char         * CmpTime        ;
     TCD_INT        Level          ;
     P_TCD_DOUBLE   pVarSkal       ;
     P_P_TCDTAB     pVarTab        ;
     char         * VarDatVgl      ;
     TCD_INT      * VarIndex       ;
     P_TCDTABLIST   FreeList       ;
     TCD_INT        AnzTabList     ;
     TCD_INT        AnzTabListEnt  ;
     P_TCDPRCNODE   NextFNode      ;
     TCD_INT        NextExecCond   ;
     TCD_INT        NextCallType   ;
     struct tagS_TCD_C_F1 * pPrevLevelInfo ;
     P_TCD_C_G      pTCDTCD ;
  } S_TCD_C_F1 ;

  typedef  S_TCD_C_F1 *   P_TCD_C_F1 ;

  typedef struct tagS_TCDFTAB {
        char          FrmName [TCD_NAME_LNG] ;
        void          (* pFormelFunc ) ( P_TCD_C_F1);
        TCD_LONG      FrmNr      ;
        TCD_INT       FrmTyp     ;
        char          Datum [TCD_FRM_DATUM_LNG] ;
  } S_TCDFTAB     ;

 typedef S_TCDFTAB     * P_TCDFTAB     ;

/* extern P_TCD_C_G pTCDTCD ; */

#endif


/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_POOL_H)
#define TCD_POOL_H
/*---------------------------------------------------------------------
  Datei      : TCD_POOL.h
  Generiert am 16.12.2019 15:07:18
  Historie      : 27.7.95    BEG neuer Prefix fuer Tabellenentry
---------------------------------------------------------------------*/
void    TCDPIT   (P_TCD_C_G);
void    TCDPRP   (P_TCD_C_G) ;
void    TCDPST   (P_TCD_C_G) ;
void    TCDPRT   (P_TCD_C_G) ;
void    TCDPSAT  (P_TCD_C_G) ;
void    TCDPRTA  (P_TCD_C_G) ;
TCD_INT TCDPGF   (P_TCD_C_G,P_TCD_DOUBLE Var, TCD_INT *PIndex) ;

#endif

/*---------------------------------------------------------------------------

(C) Copyright 1993-2002, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------------*/
#if !defined (TCD_ATTR_H)
#define TCD_ATTR_H
/*---------------------------------------------------------------------
  Datei:        TCD_ATTR.H
  Beschreibung: Attributmanager
---------------------------------------------------------------------*/
TCD_INT   TCDAATS (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAATT (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAABS (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAABT (P_TCD_C_F1 pF1) ;
void      TCDAATD (P_TCD_C_F1 pF1) ;
void      TCDAABD (P_TCD_C_F1 pF1) ;
void      TCDAATV (P_TCD_C_F1 pF1) ;
void      TCDAABV (P_TCD_C_F1 pF1) ;
void      TCDAFT  (P_TCD_C_F1 pF1) ;
void      TCDAFBS (P_TCD_C_F1 pF1) ;
void      TCDAFBT (P_TCD_C_F1 pF1) ;

#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_FRT_H)
#define TCD_FRT_H
/*---------------------------------------------------------------------
    Datei:        TCD_FRT.H

Beschreibung: Modul zur allgemeinen Endebehandlung einer Formelfunktion
By:           BEGGI
Datum:        30.03.94
Historie:     BEG    28.11.95  neue Funktion: TCDSetPD
---------------------------------------------------------------------*/
TCD_INT TCDInit (P_TCD_C_F1 pMyPar, TCD_INT FrmNr, char *fctl_cmptime,
				 TCD_LONG VerNr);
void    TCDFtID (P_TCD_C_F1 pMyPar, char * AttrName,
                 TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                 TCD_INT *Var) ;

void    TCDSetPS (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                 TCD_DOUBLE *Var1, TCD_INT *Var2, TCD_DOUBLE Var3) ;
void    TCDSetPV (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                  char *Var1, TCD_INT *Var2, char *Var3) ;
void    TCDSetPD (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                  char *Var1, TCD_INT *Var2, char *Var3) ;

TCD_INT TCDGetTb (P_TCD_C_F1 pMyPar, P_P_TCDTAB Var) ;
void    TCDIniPS (P_TCD_C_G) ;

void    TCDIniFC (P_TCD_C_G) ;
void    TCDIniFU (P_TCD_C_G) ;
void    TCDIniFM (P_TCD_C_G) ;

void    TCDRetSk (P_TCD_C_F1 pMyPar, P_TCD_DOUBLE  VarSkal) ;
void    TCDRetTb (P_TCD_C_F1 pF1, P_P_TCDTAB  VarTab) ;

/*-----------------
  TraceFunktionsprototypen und Trace Makros
-------------------*/
#ifdef TRACEFKT
void _TCD_TRACE( const char * ,const char * ,const char *,P_TCD_C_G );
void _TCD_TRVAL( const char * , int , double *, double,P_TCD_C_G  ) ;

#define TCD_TRACE(pack,func,text, pTCDTCD)  \
            _TCD_TRACE(pack,func,text, pTCDTCD);
#define TCD_TRVAL(text,type,val1,val2, pTCDTCD) \
            _TCD_TRVAL(text,type,val1,val2, pTCDTCD);
#endif

#define C_TRACEFILE        "CTRACE.TCD"

#endif
  
/* RWE, 10.06.1997   */
/*-----------------
  Funktionsprototypen fuer Wiederverwendungsprotokoll
-------------------*/ 
#ifdef PROTWV
void     SetProtWV             (P_TCD_C_G pIf, TCD_BOOL bProtWV);   
  /* ^Dieser Prototyp ist auch in commands.c enthalten! */
TCD_BOOL ProtWVEnabled         (P_TCD_C_G pIf);
void     ProtWV1               (P_TCD_C_F1 pMyPar); 
void     ProtWV2               (P_TCD_C_F1   pMyPar, 
                                P_TCDPRCNODE pNode,
                                P_PAARLISTE  pPaarListe, 
                                TCD_INT      iFlag);
void     ProtWVString          (char *s);
                                
#define C_PROTWVFILE       "CPROTWV.TCD"
#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_IOP_H)
#define TCD_IOP_H

#ifndef SUBSYSTEM
  #define IOP_EXPORT 
#else
  #define IOP_EXPORT
#endif
TCD_DOUBLE IOP_EXPORT   TCDABS     (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDFAK     (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDINT     (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDSIGN    (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDDIV     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDEXP     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDMIN     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDMAX     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDZDAYS   (TCD_INT    datefmt, char *val1, 
                                    char *val2);
TCD_DOUBLE IOP_EXPORT   TCDKDAYS   (TCD_INT    datefmt, char *val1, 
                                    char *val2);
TCD_DOUBLE IOP_EXPORT   TCDRND     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDCUT     (TCD_DOUBLE val1, TCD_DOUBLE val2);


#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_FCTL_H)
#define TCD_FCTL_H
/*---------------------------------------------------------------------
  Modul:   TCD_FCTL.H
  f�r RBS: LifeTemplate
---------------------------------------------------------------------*/

void  LifeTemF(P_TCD_C_G pTCDTCD) ;
void  LifeTem1(P_TCD_C_F1  pF1 ) ;
void    TCD3FES (P_TCD_C_F1 pMyPar, char * AttrName, TCD_INT Ix,
                       TCD_LONG ID, TCD_INT AttrTyp, TCD_INT ParIx,
                       P_TCD_DOUBLE Var) ;
void    TCD3FET (P_TCD_C_F1 pMyPar, char * AttrName, TCD_INT Ix,
                      TCD_LONG ID, TCD_INT AttrTyp, P_P_TCDTAB Var);
void    TCD3FED (P_TCD_C_F1 pMyPar, char * AttrName,
                      TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                      TCD_INT ParIx, char *Var) ;
void    TCD3FEV (P_TCD_C_F1 pMyPar, char * AttrName,
                      TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                      TCD_INT ParIx, char *Var) ;
TCD_INT TCD3FE1 (P_TCD_C_F1 pMyPar, TCD_BOOL option, char * Name,
                      TCD_LONG ID, TCD_INT FrmNr, P_TCD_DOUBLE Var) ;
TCD_INT TCD3FE2 (P_TCD_C_F1 pMyPar, TCD_BOOL option, char * Name,
                      TCD_LONG ID, TCD_INT FrmNr, P_P_TCDTAB  Var) ;

TCD_INT TCDChkFrm     (P_TCD_C_F1,void *);
void    ClearOverwriteStack(P_TCD_C_G pTCDTCD );

void       TCD3FESaveResult(P_TCD_C_F1);

#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_PKF_H)
#define TCD_PKF_H
/*---------------------------------------------------------------------
    Modul:        C:\dev\TCD_DB\template\db\R3FE\C\C3E9\lifet345.h

    Beschreibung: Funktionsprototypen der externen Funktionen der
                  Formelsammlungsdatei
    By:           BEGGI
    Generiert am: 16.12.2019 15:07:19
---------------------------------------------------------------------*/
   
      void LifeT178 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT179 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT180 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT181 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT182 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT183 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT184 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT185 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT186 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT187 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT188 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT189 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT190 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT191 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT192 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT193 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT194 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT195 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT196 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT197 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT198 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT199 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT200 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT201 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT202 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT203 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT204 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT205 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT206 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT207 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT208 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT209 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT210 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT211 (P_TCD_C_F1 pMyPar) ;
   

#endif



/*---------------------------------------------------------
   Externe Funktion : LifeT332
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Vxnt
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT332 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_1 = 0;
   TCD_DOUBLE  HV_3 = 0;
   TCD_DOUBLE  HV_4 = 0;
   TCD_DOUBLE  HV_7 = 0;
   TCD_DOUBLE  HV_9 = 0;
   TCD_DOUBLE  HV_11 = 0;
   TCD_DOUBLE  HV_12 = 0;
   TCD_DOUBLE  HV_14 = 0;
   TCD_DOUBLE  HV_16 = 0;
   TCD_DOUBLE  HV_17 = 0;
   TCD_DOUBLE  HV_18 = 0;
   TCD_DOUBLE  HV_19 = 0;
   TCD_INT     HV_0 = 0;
   TCD_INT     HV_2 = 0;
   TCD_INT     HV_6 = 0;
   TCD_INT     HV_8 = 0;
   TCD_INT     HV_10 = 0;
   TCD_INT     HV_13 = 0;
   TCD_INT     HV_15 = 0;
   TCD_INT     HV_5 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT332","Begin F_Vxnt",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,332,"12.12.2019 17:29:36",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_4);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT332",
              "Ende F_Vxnt",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_6 = 0;
      HV_8 = 0;
      HV_10 = 0;
      HV_13 = 0;
      HV_15 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_2 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_8: 
      if ( HV_1 > HV_3 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_5 = 0;
      HV_4 = HV_5;
      goto l_3 ;
   l_24: 
      if ( HV_6 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_State", 67, 421, 1, 155, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_11: 
      if ( HV_8 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "_premFree", 648, 648, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_8 = 1;
   l_14: 
      if ( HV_7 == HV_9 ) goto l_36 ;
      goto l_48 ;
   l_36: 
      if ( HV_10 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_Bxnt", 15, 280, 1, 103, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_17: 
      HV_12 =   TCDRND ( HV_11, 2 ) ;
      HV_4 = HV_12;
      goto l_3 ;
   l_48: 
      if ( HV_13 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_PBxn", 13, 275, 1, 101, &HV_14);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_13 = 1;
   l_20: 
      if ( HV_15 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_Pxnt", 17, 283, 1, 105, &HV_16);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_15 = 1;
   l_23: 
      HV_17 = HV_14 * HV_16;
      if ( HV_10 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_Bxnt", 15, 280, 1, 103, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_26: 
      HV_18 = HV_11 - HV_17;
      HV_19 =   TCDRND ( HV_18, 2 ) ;
      HV_4 = HV_19;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_4);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT332","End F_Vxnt",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Vxnt", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Vxnt", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Vxnt");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT333
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Bxnt
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT333 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_DOUBLE  HV_29 = 0;
      TCD_DOUBLE  HV_30 = 0;
      TCD_DOUBLE  HV_32 = 0;
      TCD_DOUBLE  HV_34 = 0;
      TCD_DOUBLE  HV_35 = 0;
      TCD_DOUBLE  HV_37 = 0;
      TCD_DOUBLE  HV_40 = 0;
      TCD_DOUBLE  HV_42 = 0;
      TCD_DOUBLE  HV_44 = 0;
      TCD_DOUBLE  HV_45 = 0;
      TCD_DOUBLE  HV_46 = 0;
      TCD_DOUBLE  HV_47 = 0;
      TCD_DOUBLE  HV_48 = 0;
      TCD_DOUBLE  HV_49 = 0;
      TCD_DOUBLE  HV_50 = 0;
      TCD_DOUBLE  HV_52 = 0;
      TCD_DOUBLE  HV_54 = 0;
      TCD_DOUBLE  HV_55 = 0;
      TCD_DOUBLE  HV_56 = 0;
      TCD_DOUBLE  HV_57 = 0;
      TCD_DOUBLE  HV_59 = 0;
      TCD_DOUBLE  HV_60 = 0;
      TCD_DOUBLE  HV_62 = 0;
      TCD_DOUBLE  HV_63 = 0;
      TCD_DOUBLE  HV_64 = 0;
      TCD_DOUBLE  HV_65 = 0;
      TCD_DOUBLE  HV_67 = 0;
      TCD_DOUBLE  HV_68 = 0;
      TCD_DOUBLE  HV_69 = 0;
      TCD_DOUBLE  HV_70 = 0;
      TCD_DOUBLE  HV_71 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_11 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_21 = 0;
      TCD_INT     HV_25 = 0;
      TCD_INT     HV_27 = 0;
      TCD_INT     HV_31 = 0;
      TCD_INT     HV_33 = 0;
      TCD_INT     HV_36 = 0;
      TCD_INT     HV_38 = 0;
      TCD_INT     HV_39 = 0;
      TCD_INT     HV_41 = 0;
      TCD_INT     HV_43 = 0;
      TCD_INT     HV_51 = 0;
      TCD_INT     HV_53 = 0;
      TCD_INT     HV_58 = 0;
      TCD_INT     HV_61 = 0;
      TCD_INT     HV_66 = 0;
      TCD_INT     HV_72 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT333","Begin F_Bxnt",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,333,"12.12.2019 17:29:36",
                       15);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_8);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT333",
              "Ende F_Bxnt",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_4 = 0;
      HV_6 = 0;
      HV_9 = 0;
      HV_11 = 0;
      HV_13 = 0;
      HV_18 = 0;
      HV_21 = 0;
      HV_25 = 0;
      HV_27 = 0;
      HV_31 = 0;
      HV_33 = 0;
      HV_36 = 0;
      HV_39 = 0;
      HV_41 = 0;
      HV_51 = 0;
      HV_53 = 0;
      HV_58 = 0;
      HV_61 = 0;
      HV_66 = 0;
      HV_72 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_State", 67, 421, 1, 155, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_2 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_regularPremium", 649, 649, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_8: 
      if ( HV_1 == HV_3 ) goto l_42 ;
      goto l_24 ;
   l_24: 
      if ( HV_0 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_State", 67, 421, 1, 155, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_11: 
      if ( HV_4 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "_premFree", 648, 648, &HV_5);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_4 = 1;
   l_14: 
      if ( HV_1 == HV_5 ) goto l_33 ;
      goto l_171 ;
   l_33: 
      if ( HV_6 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_StateDetail", 68, 422, 1, 156, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_17: 
      if ( HV_7 == 2 ) goto l_42 ;
      goto l_171 ;
   l_42: 
      if ( HV_72 != 0 ) goto l_76 ;
      if ( HV_13 != 0 ) goto l_20 ;
      rc = TCD3FE1 (pMyPar, 2, "F_SecurityLoading", 673, 673, &HV_14);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_13 = 1;
   l_20: 
      HV_15 = 1 + HV_14;
      HV_72 = 1;
   l_76: 
      if ( HV_11 != 0 ) goto l_23 ;
      rc = TCD3FE1 (pMyPar, 2, "F_A1xn", 280, 280, &HV_12);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_11 = 1;
   l_23: 
      HV_16 = HV_12 * HV_15;
      if ( HV_9 != 0 ) goto l_26 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Exn", 258, 258, &HV_10);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_9 = 1;
   l_26: 
      HV_17 = HV_10 + HV_16;
      if ( HV_18 != 0 ) goto l_29 ;
      TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_19);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_18 = 1;
   l_29: 
      HV_20 = HV_17 * HV_19;
      if ( HV_21 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "i_Gamma1", 52, 400, 1, 140, &HV_22);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_21 = 1;
   l_32: 
      if ( HV_18 != 0 ) goto l_35 ;
      TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_19);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_18 = 1;
   l_35: 
      HV_23 = HV_22 * HV_19;
      HV_24 = HV_20 + HV_23;
      if ( HV_25 != 0 ) goto l_38 ;
      rc = TCD3FE1 (pMyPar, 2, "F_A2xn", 281, 281, &HV_26);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_25 = 1;
   l_38: 
      if ( HV_27 != 0 ) goto l_41 ;
      TCD3FES (pMyPar, "i_PBxn", 13, 275, 1, 101, &HV_28);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_27 = 1;
   l_41: 
      HV_29 = HV_26 * HV_28;
      HV_30 = HV_24 + HV_29;
      if ( HV_31 != 0 ) goto l_44 ;
      TCD3FES (pMyPar, "i_Alpha3", 50, 398, 1, 138, &HV_32);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_31 = 1;
   l_44: 
      if ( HV_33 != 0 ) goto l_47 ;
      TCD3FES (pMyPar, "i_Beta", 51, 399, 1, 139, &HV_34);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_33 = 1;
   l_47: 
      HV_35 = HV_32 + HV_34;
      HV_46 = 0;
      if ( HV_39 != 0 ) goto l_50 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_40);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_39 = 1;
   l_50: 
      if ( HV_41 != 0 ) goto l_53 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_42);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_41 = 1;
   l_53: 
      for ( HV_38 = (TCD_INT) (HV_40) ; HV_38 <= HV_42; HV_38 = HV_38 +
         1 ) {
      TCDSetPS (pMyPar, 1, 108, &HV_44, &HV_43, HV_38);
         rc = TCD3FE1 (pMyPar, 4, "F_prj", 268, 268, &HV_45);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 108, &HV_44, &HV_43, HV_38);
         HV_46 = HV_45 + HV_46;
      }
      if ( HV_36 != 0 ) goto l_56 ;
      TCD3FES (pMyPar, "i_Gamma2", 53, 401, 1, 141, &HV_37);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_36 = 1;
   l_56: 
      HV_47 = HV_37 * HV_46;
      HV_48 = HV_35 + HV_47;
      if ( HV_27 != 0 ) goto l_59 ;
      TCD3FES (pMyPar, "i_PBxn", 13, 275, 1, 101, &HV_28);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_27 = 1;
   l_59: 
      HV_49 = HV_48 * HV_28;
      HV_50 = HV_30 + HV_49;
      if ( HV_53 != 0 ) goto l_62 ;
      rc = TCD3FE1 (pMyPar, 2, "F_A2xn_sub", 275, 275, &HV_54);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_53 = 1;
   l_62: 
      if ( HV_36 != 0 ) goto l_65 ;
      TCD3FES (pMyPar, "i_Gamma2", 53, 401, 1, 141, &HV_37);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_36 = 1;
   l_65: 
      HV_55 = HV_54 + HV_37;
      if ( HV_51 != 0 ) goto l_68 ;
      TCD3FES (pMyPar, "i_SumOfPremium", 64, 418, 1, 152, &HV_52);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_51 = 1;
   l_68: 
      HV_56 = HV_52 * HV_55;
      HV_57 = HV_50 + HV_56;
      if ( HV_58 != 0 ) goto l_71 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AC_CashValue", 779, 779, &HV_59);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_58 = 1;
   l_71: 
      HV_60 = HV_57 + HV_59;
      HV_8 = HV_60;
      goto l_3 ;
   l_171: 
      if ( HV_72 != 0 ) goto l_196 ;
      if ( HV_13 != 0 ) goto l_74 ;
      rc = TCD3FE1 (pMyPar, 2, "F_SecurityLoading", 673, 673, &HV_14);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_13 = 1;
   l_74: 
      HV_15 = 1 + HV_14;
      HV_72 = 1;
   l_196: 
      if ( HV_61 != 0 ) goto l_77 ;
      rc = TCD3FE1 (pMyPar, 2, "F_A3xn", 273, 273, &HV_62);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_61 = 1;
   l_77: 
      HV_63 = HV_62 * HV_15;
      if ( HV_9 != 0 ) goto l_80 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Exn", 258, 258, &HV_10);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_9 = 1;
   l_80: 
      HV_64 = HV_10 + HV_63;
      if ( HV_18 != 0 ) goto l_83 ;
      TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_19);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_18 = 1;
   l_83: 
      HV_65 = HV_64 * HV_19;
      if ( HV_66 != 0 ) goto l_86 ;
      TCD3FES (pMyPar, "i_Gamma3", 54, 402, 1, 142, &HV_67);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_66 = 1;
   l_86: 
      if ( HV_18 != 0 ) goto l_89 ;
      TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_19);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_18 = 1;
   l_89: 
      HV_68 = HV_67 * HV_19;
      HV_69 = HV_65 + HV_68;
      if ( HV_51 != 0 ) goto l_92 ;
      TCD3FES (pMyPar, "i_SumOfPremium", 64, 418, 1, 152, &HV_52);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_51 = 1;
   l_92: 
      if ( HV_53 != 0 ) goto l_95 ;
      rc = TCD3FE1 (pMyPar, 2, "F_A2xn_sub", 275, 275, &HV_54);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_53 = 1;
   l_95: 
      HV_70 = HV_52 * HV_54;
      HV_71 = HV_69 + HV_70;
      HV_8 = HV_71;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_8);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT333","End F_Bxnt",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Bxnt", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Bxnt", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Bxnt");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT340
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Benefit_AccDeath
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT340 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_10 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT340","Begin F_Benefit_AccDeath",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,340,"12.12.2019 17:29:34",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_6);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT340",
              "Ende F_Benefit_AccDeath",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_4 = 0;
      HV_7 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_tarif_nr", 24, 321, 1, 112, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 50000 ) goto l_18 ;
      goto l_42 ;
   l_18: 
      if ( HV_2 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_8: 
      if ( HV_4 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_11: 
      if ( HV_3 <= HV_5 ) goto l_30 ;
      goto l_36 ;
   l_30: 
      if ( HV_7 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_14: 
      HV_6 = HV_8;
      goto l_3 ;
   l_36: 
      HV_9 = 0;
      HV_6 = HV_9;
      goto l_3 ;
   l_42: 
      HV_10 = 0;
      HV_6 = HV_10;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_6);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT340","End F_Benefit_AccDeath",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Benefit_AccDeath", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Benefit_AccDeath", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Benefit_AccDeath");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT350
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Benefit_Invalidity
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT350 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_10 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT350","Begin F_Benefit_Invalidity",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,350,"12.12.2019 17:29:34",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_6);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT350",
              "Ende F_Benefit_Invalidity",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_4 = 0;
      HV_7 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_tarif_nr", 24, 321, 1, 112, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 50500 ) goto l_18 ;
      goto l_42 ;
   l_18: 
      if ( HV_2 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_8: 
      if ( HV_4 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_11: 
      if ( HV_3 <= HV_5 ) goto l_30 ;
      goto l_36 ;
   l_30: 
      if ( HV_7 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_14: 
      HV_6 = HV_8;
      goto l_3 ;
   l_36: 
      HV_9 = 0;
      HV_6 = HV_9;
      goto l_3 ;
   l_42: 
      HV_10 = 0;
      HV_6 = HV_10;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_6);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT350","End F_Benefit_Invalidity",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Benefit_Invalidity", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Benefit_Invalidity", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Benefit_Invalidity");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT355
   Beschreibung: Die Funktion berechnet die Formel 
                 F_DB_Init
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT355 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_DOUBLE  HV_29 = 0;
      TCD_DOUBLE  HV_31 = 0;
      TCD_DOUBLE  HV_32 = 0;
      TCD_DOUBLE  HV_34 = 0;
      TCD_DOUBLE  HV_35 = 0;
      TCD_DOUBLE  HV_36 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_15 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_21 = 0;
      TCD_INT     HV_24 = 0;
      TCD_INT     HV_27 = 0;
      TCD_INT     HV_30 = 0;
      TCD_INT     HV_33 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT355","Begin F_DB_Init",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,355,"12.12.2019 17:29:32",
                       11);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT355",
              "Ende F_DB_Init",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_6 = 0;
      HV_9 = 0;
      HV_12 = 0;
      HV_15 = 0;
      HV_18 = 0;
      HV_21 = 0;
      HV_24 = 0;
      HV_27 = 0;
      HV_30 = 0;
      HV_33 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "e_benefitPeriod_n", 59, 432, 6, 59, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
      if ( HV_3 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "e_StartDateYield_n", 80, 455, 6, 80, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_8: 
      HV_5 = HV_2 + HV_4;
      if ( HV_6 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "e_pst_n", 78, 453, 6, 78, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_11: 
      HV_8 = HV_5 + HV_7;
      if ( HV_9 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "e_tarsumme_pfr_n", 5, 33, 6, 5, &HV_10);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_9 = 1;
   l_14: 
      HV_11 = HV_8 + HV_10;
      if ( HV_12 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "e_RiskGroup_IP1_n", 19, 338, 6, 19, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_17: 
      HV_14 = HV_11 + HV_13;
      if ( HV_15 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "e_ea_IP1_n", 14, 332, 6, 14, &HV_16);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_15 = 1;
   l_20: 
      HV_17 = HV_14 + HV_16;
      if ( HV_18 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "e_RiskGroup_IP2_n", 20, 339, 6, 20, &HV_19);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_18 = 1;
   l_23: 
      HV_20 = HV_17 + HV_19;
      if ( HV_21 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "e_x_IP1_n", 26, 345, 6, 26, &HV_22);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_21 = 1;
   l_26: 
      HV_23 = HV_20 + HV_22;
      if ( HV_24 != 0 ) goto l_29 ;
      TCD3FES (pMyPar, "e_x_IP2_n", 27, 346, 6, 27, &HV_25);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_24 = 1;
   l_29: 
      HV_26 = HV_23 + HV_25;
      if ( HV_27 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "e_SumOfPremiums_n", 69, 443, 6, 69, &HV_28);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_27 = 1;
   l_32: 
      HV_29 = HV_26 + HV_28;
      if ( HV_30 != 0 ) goto l_35 ;
      TCD3FES (pMyPar, "e_YieldValue_n", 85, 462, 6, 85, &HV_31);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_30 = 1;
   l_35: 
      HV_32 = HV_29 + HV_31;
      if ( HV_33 != 0 ) goto l_38 ;
      TCD3FES (pMyPar, "e_InterestRate", 76, 451, 6, 76, &HV_34);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_33 = 1;
   l_38: 
      HV_35 = HV_32 + HV_34;
      HV_36 = 0 * HV_35;
      HV_0 = HV_36;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT355","End F_DB_Init",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_DB_Init", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_DB_Init", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_DB_Init");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT364
   Beschreibung: Die Funktion berechnet die Formel 
                 F_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT364 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT364","Begin F_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,364,"12.12.2019 17:29:31",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT364",
              "Ende F_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_e_n", 6, 170, 1, 94, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
   if ( 12 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_3 = HV_2 / 12;
      HV_4 = TCDINT ( HV_3 ) ;
      HV_0 = HV_4;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT364","End F_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT366
   Beschreibung: Die Funktion berechnet die Formel 
                 F_m
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT366 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_3 = 1;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT366","Begin F_m",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,366,"12.12.2019 17:29:31",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT366",
              "Ende F_m",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_e_m", 3, 165, 1, 91, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 0 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 1;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_0 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_e_m", 3, 165, 1, 91, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_8: 
   if ( 12 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_4 = HV_1 / 12;
      HV_5 = TCDINT ( HV_4 ) ;
      HV_2 = HV_5;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT366","End F_m",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_m", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_m", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_m");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT373
   Beschreibung: Die Funktion berechnet die Formel 
                 F_k
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT373 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT373","Begin F_k",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,373,"12.12.2019 17:29:31",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT373",
              "Ende F_k",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Alpha_Distribution", 663, 663,
         &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
      if ( HV_3 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_n", 364, 364, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_3 = 1;
   l_8: 
      HV_5 = TCDMIN ( HV_2, HV_4 ) ;
      HV_6 = TCDMAX ( 1, HV_5 ) ;
      HV_0 = HV_6;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT373","End F_k",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_k", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_k", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_k");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT572
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Reserve
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT572 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT572","Begin F_Reserve",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,572,"12.12.2019 17:29:36",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT572",
              "Ende F_Reserve",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_Vxnt", 14, 278, 1, 102, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
      HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT572","End F_Reserve",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Reserve", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Reserve", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Reserve");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT600
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Has_Decrea_SumIns
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT600 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_7 = 0;
      P_TCDTAB2   HV_8;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT600","Begin F_Has_Decrea_SumIns",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,600,"12.12.2019 17:29:34",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT600",
              "Ende F_Has_Decrea_SumIns",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_7 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
      HV_5 = (TCD_INT) ( HV_2) ;
      if ( HV_3 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_Has_Decrea_SumIns", 597, 597, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_3 = 1;
   l_8: 
      HV_6 = (TCD_INT) ( HV_4) ;
      if ( HV_7 != 0 ) goto l_11 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_11: 
      if ( HV_6 < 0 || HV_6 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_0 = HV_8 [ HV_5 * 110 + HV_6 ] ;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT600","End F_Has_Decrea_SumIns",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Has_Decrea_SumIns", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Has_Decrea_SumIns", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Has_Decrea_SumIns");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT603
   Beschreibung: Die Funktion berechnet die Formel 
                 F_OccupSurcharge
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT603 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_6 = 70;
      TCD_INT     HV_7 = 140;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT603","Begin F_OccupSurcharge",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,603,"12.12.2019 17:29:36",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT603",
              "Ende F_OccupSurcharge",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_OccuClass", 35, 363, 1, 123, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 1 ) goto l_18 ;
      goto l_30 ;
   l_18: 
      HV_3 = 0 - 60;
      HV_2 = HV_3;
      goto l_3 ;
   l_30: 
      if ( HV_0 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_OccuClass", 35, 363, 1, 123, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_8: 
      if ( HV_1 == 2 ) goto l_42 ;
      goto l_54 ;
   l_42: 
      HV_4 = 0 - 30;
      HV_2 = HV_4;
      goto l_3 ;
   l_54: 
      if ( HV_0 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_OccuClass", 35, 363, 1, 123, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_11: 
      if ( HV_1 == 3 ) goto l_66 ;
      goto l_72 ;
   l_66: 
      HV_5 = 0;
      HV_2 = HV_5;
      goto l_3 ;
   l_72: 
      if ( HV_0 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_OccuClass", 35, 363, 1, 123, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_14: 
      if ( HV_1 == 4 ) goto l_84 ;
      goto l_90 ;
   l_84: 
      HV_6 = 70;
      HV_2 = HV_6;
      goto l_3 ;
   l_90: 
      if ( HV_0 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_OccuClass", 35, 363, 1, 123, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_17: 
      if ( HV_1 == 5 ) goto l_102 ;
      goto l_108 ;
   l_102: 
      HV_7 = 140;
      HV_2 = HV_7;
      goto l_3 ;
   l_108: 
   pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 900;
   pMyPar->pTCDTCD->pRbsCtl->RCInfo.Errc = 199;
   goto l_ende ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT603","End F_OccupSurcharge",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_OccupSurcharge", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_OccupSurcharge", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_OccupSurcharge");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT604
   Beschreibung: Die Funktion berechnet die Formel 
                 F_SportsSurcharge
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT604 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_3 = 60;
      TCD_INT     HV_4 = 50;
      TCD_INT     HV_5 = 40;
      TCD_INT     HV_6 = 30;
      TCD_INT     HV_7 = 50;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT604","Begin F_SportsSurcharge",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,604,"12.12.2019 17:29:37",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT604",
              "Ende F_SportsSurcharge",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_OccuClass", 35, 363, 1, 123, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 1 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 60;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_0 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_OccuClass", 35, 363, 1, 123, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_8: 
      if ( HV_1 == 2 ) goto l_36 ;
      goto l_42 ;
   l_36: 
      HV_4 = 50;
      HV_2 = HV_4;
      goto l_3 ;
   l_42: 
      if ( HV_0 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_OccuClass", 35, 363, 1, 123, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_11: 
      if ( HV_1 == 3 ) goto l_54 ;
      goto l_60 ;
   l_54: 
      HV_5 = 40;
      HV_2 = HV_5;
      goto l_3 ;
   l_60: 
      if ( HV_0 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_OccuClass", 35, 363, 1, 123, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_14: 
      if ( HV_1 == 4 ) goto l_72 ;
      goto l_78 ;
   l_72: 
      HV_6 = 30;
      HV_2 = HV_6;
      goto l_3 ;
   l_78: 
      if ( HV_0 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_OccuClass", 35, 363, 1, 123, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_17: 
      if ( HV_1 == 5 ) goto l_90 ;
      goto l_96 ;
   l_90: 
      HV_7 = 50;
      HV_2 = HV_7;
      goto l_3 ;
   l_96: 
   pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 900;
   pMyPar->pTCDTCD->pRbsCtl->RCInfo.Errc = 199;
   goto l_ende ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT604","End F_SportsSurcharge",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_SportsSurcharge", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_SportsSurcharge", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_SportsSurcharge");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT628
   Beschreibung: Die Funktion berechnet die Formel 
                 F_OCDisBenfit
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT628 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_10 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT628","Begin F_OCDisBenfit",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,628,"12.12.2019 17:29:34",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_6);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT628",
              "Ende F_OCDisBenfit",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_4 = 0;
      HV_7 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_FlagOCDisBenefit", 626, 626, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 1 ) goto l_18 ;
      goto l_42 ;
   l_18: 
      if ( HV_2 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_8: 
      if ( HV_4 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_11: 
      if ( HV_3 <= HV_5 ) goto l_30 ;
      goto l_36 ;
   l_30: 
      if ( HV_7 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_14: 
      HV_6 = HV_8;
      goto l_3 ;
   l_36: 
      HV_9 = 0;
      HV_6 = HV_9;
      goto l_3 ;
   l_42: 
      HV_10 = 0;
      HV_6 = HV_10;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_6);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT628","End F_OCDisBenfit",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_OCDisBenfit", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_OCDisBenfit", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_OCDisBenfit");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT632
   Beschreibung: Die Funktion berechnet die Formel 
                 F_CommReduction_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT632 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_3 = 100;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT632","Begin F_CommReduction_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,632,"12.12.2019 17:29:29",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT632",
              "Ende F_CommReduction_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "e_RateClass_n", 33, 361, 6, 33, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 2 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 100;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_4 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "e_CommReduction_n", 51, 407, 6, 51, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_8: 
      HV_2 = HV_5;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT632","End F_CommReduction_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_CommReduction_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_CommReduction_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_CommReduction_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT633
   Beschreibung: Die Funktion berechnet die Formel 
                 F_CommReduction_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT633 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_3 = 100;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT633","Begin F_CommReduction_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,633,"12.12.2019 17:29:29",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT633",
              "Ende F_CommReduction_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "e_RateClass_o", 34, 362, 6, 34, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 2 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 100;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_4 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "e_CommReduction_o", 52, 408, 6, 52, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_8: 
      HV_2 = HV_5;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT633","End F_CommReduction_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_CommReduction_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_CommReduction_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_CommReduction_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT636
   Beschreibung: Die Funktion berechnet die Formel 
                 F_CommReductionFact
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT636 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT636","Begin F_CommReductionFact",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,636,"12.12.2019 17:29:29",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT636",
              "Ende F_CommReductionFact",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_reductComm", 58, 406, 1, 146, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
   if ( 100 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_3 = HV_2 / 100;
      HV_4 = 1 - HV_3;
      HV_0 = HV_4;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT636","End F_CommReductionFact",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_CommReductionFact", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_CommReductionFact", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_CommReductionFact");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT637
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Commission
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT637 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_DOUBLE  HV_30 = 0;
      TCD_DOUBLE  HV_32 = 0;
      TCD_DOUBLE  HV_34 = 0;
      TCD_DOUBLE  HV_35 = 0;
      TCD_DOUBLE  HV_36 = 0;
      TCD_DOUBLE  HV_37 = 0;
      TCD_DOUBLE  HV_38 = 0;
      TCD_DOUBLE  HV_40 = 0;
      TCD_DOUBLE  HV_44 = 0;
      TCD_DOUBLE  HV_45 = 0;
      TCD_DOUBLE  HV_46 = 0;
      TCD_DOUBLE  HV_48 = 0;
      TCD_DOUBLE  HV_49 = 0;
      TCD_DOUBLE  HV_51 = 0;
      TCD_DOUBLE  HV_52 = 0;
      TCD_DOUBLE  HV_54 = 0;
      TCD_DOUBLE  HV_55 = 0;
      TCD_DOUBLE  HV_56 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_11 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_15 = 0;
      TCD_INT     HV_17 = 0;
      TCD_INT     HV_23 = 0;
      TCD_INT     HV_27 = 0;
      TCD_INT     HV_29 = 0;
      TCD_INT     HV_31 = 0;
      TCD_INT     HV_33 = 0;
      TCD_INT     HV_39 = 0;
      TCD_INT     HV_41 = 0;
      TCD_INT     HV_42 = 0;
      TCD_INT     HV_47 = 0;
      TCD_INT     HV_50 = 0;
      TCD_INT     HV_53 = 0;
      TCD_INT     HV_59 = 0;
      TCD_INT     HV_60 = 0;
      TCD_INT     HV_61 = 0;
      TCD_INT     HV_62 = 0;
      P_TCDTAB1   HV_3;
      P_TCDTAB2   HV_12;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_26 = 0;
      TCD_INT     HV_43 = 0;
      TCD_INT     HV_57 = 0;
      TCD_INT     HV_58 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT637","Begin F_Commission",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,637,"12.12.2019 17:29:30",
                       12);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Besorgen einer freien Tabelle, falls Formel vom Typ TAB1/TAB2 */
   rc =    TCDGetTb (pMyPar, &HV_3);


   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_3);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT637",
              "Ende F_Commission",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_5 = 0;
      HV_7 = 0;
      HV_11 = 0;
      HV_13 = 0;
      HV_15 = 0;
      HV_17 = 0;
      HV_23 = 0;
      HV_27 = 0;
      HV_29 = 0;
      HV_31 = 0;
      HV_33 = 0;
      HV_39 = 0;
      HV_47 = 0;
      HV_50 = 0;
      HV_53 = 0;
      HV_59 = 0;
      HV_60 = 0;
      HV_61 = 0;
      HV_62 = 0;
      for ( HV_0 = (TCD_INT) (0) ; HV_0 <= 199; HV_0 = HV_0 + 1 ) {
         if ( HV_1 != 0 ) goto l_5 ;
         TCD3FES (pMyPar, "i_RateClass", 30, 347, 1, 118, &HV_2);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_1 = 1;
      l_5: 
         if ( HV_2 == 2 ) goto l_18 ;
         goto l_27 ;
      l_18: 
         HV_4 = 0;
         HV_3 [ HV_0 ]  = HV_4;
         continue ;
      l_27: 
         if ( HV_0 > 7 ) goto l_39 ;
         goto l_42 ;
      l_39: 
      goto l_ende ;
      l_42: 
         if ( HV_0 == 0 ) goto l_54 ;
         goto l_120 ;
      l_54: 
         if ( HV_5 != 0 ) goto l_8 ;
         rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_6);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_5 = 1;
      l_8: 
         HV_9 = (TCD_INT) ( HV_6) ;
         if ( HV_7 != 0 ) goto l_11 ;
         rc = TCD3FE1 (pMyPar, 2, "_RecurringComm", 655, 655, &HV_8);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_7 = 1;
      l_11: 
         HV_10 = (TCD_INT) ( HV_8) ;
         if ( HV_11 != 0 ) goto l_14 ;
         TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_12);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_11 = 1;
      l_14: 
         if ( HV_10 < 0 || HV_10 > pMyPar->pTCDTCD->SSAData.AnzSpalten
            - 1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         if ( HV_9 < 0 || HV_9 > pMyPar->pTCDTCD->SSAData.AnzZeilen -
            1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         if ( HV_12 [ HV_9 * 110 + HV_10 ]  == 0 ) goto l_72 ;
         goto l_111 ;
      l_72: 
         if ( HV_59 != 0 ) goto l_100 ;
         if ( HV_17 != 0 ) goto l_17 ;
         rc = TCD3FE1 (pMyPar, 2, "F_IsProlongation", 662, 662,
            &HV_18);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_17 = 1;
      l_17: 
         HV_19 = 1 - HV_18;
         HV_59 = 1;
      l_100: 
         if ( HV_60 != 0 ) goto l_94 ;
         if ( HV_15 != 0 ) goto l_20 ;
         rc = TCD3FE1 (pMyPar, 2, "F_GrossPrem_wo_SD_o", 724, 724,
            &HV_16);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_15 = 1;
      l_20: 
         HV_20 = HV_16 * HV_19;
         HV_60 = 1;
      l_94: 
         if ( HV_61 != 0 ) goto l_88 ;
         if ( HV_13 != 0 ) goto l_23 ;
         rc = TCD3FE1 (pMyPar, 2, "F_GrossPrem_wo_SD_n", 721, 721,
            &HV_14);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_13 = 1;
      l_23: 
         HV_21 = HV_14 - HV_20;
         HV_61 = 1;
      l_88: 
         HV_22 = TCDMAX ( 0, HV_21 ) ;
         if ( HV_23 != 0 ) goto l_26 ;
         rc = TCD3FE1 (pMyPar, 2, "F_CommReductionFact", 636, 636,
            &HV_24);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_23 = 1;
      l_26: 
         HV_25 = HV_22 * HV_24;
         HV_3 [ HV_0 ]  = HV_25;
         continue ;
      l_111: 
         HV_26 = 0;
         HV_3 [ HV_0 ]  = HV_26;
         continue ;
      l_120: 
         if ( HV_0 == 1 ) goto l_132 ;
         goto l_186 ;
      l_132: 
         if ( HV_27 != 0 ) goto l_29 ;
         TCD3FES (pMyPar, "e_manual_LEBK_MON_n", 72, 446, 6, 72,
            &HV_28);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_27 = 1;
      l_29: 
         if ( HV_28 != 0 ) goto l_144 ;
         goto l_153 ;
      l_144: 
         if ( HV_27 != 0 ) goto l_32 ;
         TCD3FES (pMyPar, "e_manual_LEBK_MON_n", 72, 446, 6, 72,
            &HV_28);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_27 = 1;
      l_32: 
         HV_3 [ HV_0 ]  = HV_28;
         continue ;
      l_153: 
         if ( HV_31 != 0 ) goto l_35 ;
         rc = TCD3FE1 (pMyPar, 2, "F_n", 364, 364, &HV_32);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_31 = 1;
      l_35: 
         if ( HV_33 != 0 ) goto l_38 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_34);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_33 = 1;
      l_38: 
         HV_35 = HV_32 - HV_34;
         if ( HV_29 != 0 ) goto l_41 ;
         rc = TCD3FE1 (pMyPar, 2, "F_Alpha_Distribution", 663, 663,
            &HV_30);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_29 = 1;
      l_41: 
         HV_36 = TCDMIN ( HV_30, HV_35 ) ;
         HV_37 = HV_36 * 12;
         HV_38 =   TCDRND ( HV_37, 0 ) ;
         HV_3 [ HV_0 ]  = HV_38;
         continue ;
      l_186: 
         if ( HV_0 == 2 ) goto l_198 ;
         goto l_237 ;
      l_198: 
         if ( HV_39 != 0 ) goto l_44 ;
         TCD3FES (pMyPar, "e_manual_LEBK_BWS_n", 71, 445, 6, 71,
            &HV_40);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_39 = 1;
      l_44: 
         if ( HV_40 != 0 ) goto l_210 ;
         goto l_219 ;
      l_210: 
         if ( HV_39 != 0 ) goto l_47 ;
         TCD3FES (pMyPar, "e_manual_LEBK_BWS_n", 71, 445, 6, 71,
            &HV_40);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_39 = 1;
      l_47: 
         HV_3 [ HV_0 ]  = HV_40;
         continue ;
      l_219: 
         HV_41 = HV_0 - 2;
         if ( HV_41 < 0 || HV_41 > pMyPar->pTCDTCD->SSAData.AnzZeilen -
            1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         HV_3 [ HV_0 ]  = HV_3 [ HV_41 ] ;
         continue ;
      l_237: 
         if ( HV_0 == 3 ) goto l_249 ;
         goto l_324 ;
      l_249: 
         HV_42 = HV_0 - 3;
         if ( HV_42 < 0 || HV_42 > pMyPar->pTCDTCD->SSAData.AnzZeilen -
            1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         if ( HV_3 [ HV_42 ]  == 0 ) goto l_270 ;
         goto l_279 ;
      l_270: 
         HV_43 = 0;
         HV_3 [ HV_0 ]  = HV_43;
         continue ;
      l_279: 
         if ( HV_59 != 0 ) goto l_310 ;
         if ( HV_17 != 0 ) goto l_50 ;
         rc = TCD3FE1 (pMyPar, 2, "F_IsProlongation", 662, 662,
            &HV_18);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_17 = 1;
      l_50: 
         HV_19 = 1 - HV_18;
         HV_59 = 1;
      l_310: 
         if ( HV_60 != 0 ) goto l_304 ;
         if ( HV_15 != 0 ) goto l_53 ;
         rc = TCD3FE1 (pMyPar, 2, "F_GrossPrem_wo_SD_o", 724, 724,
            &HV_16);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_15 = 1;
      l_53: 
         HV_20 = HV_16 * HV_19;
         HV_60 = 1;
      l_304: 
         if ( HV_61 != 0 ) goto l_298 ;
         if ( HV_13 != 0 ) goto l_56 ;
         rc = TCD3FE1 (pMyPar, 2, "F_GrossPrem_wo_SD_n", 721, 721,
            &HV_14);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_13 = 1;
      l_56: 
         HV_21 = HV_14 - HV_20;
         HV_61 = 1;
      l_298: 
         if ( HV_23 != 0 ) goto l_59 ;
         rc = TCD3FE1 (pMyPar, 2, "F_CommReductionFact", 636, 636,
            &HV_24);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_23 = 1;
      l_59: 
         HV_44 = HV_21 * HV_24;
         HV_45 =   TCDRND ( HV_44, 2 ) ;
         HV_46 = TCDMAX ( 0, HV_45 ) ;
         HV_3 [ HV_0 ]  = HV_46;
         continue ;
      l_324: 
         if ( HV_0 == 4 ) goto l_336 ;
         goto l_369 ;
      l_336: 
         if ( HV_59 != 0 ) goto l_358 ;
         if ( HV_17 != 0 ) goto l_62 ;
         rc = TCD3FE1 (pMyPar, 2, "F_IsProlongation", 662, 662,
            &HV_18);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_17 = 1;
      l_62: 
         HV_19 = 1 - HV_18;
         HV_59 = 1;
      l_358: 
         if ( HV_60 != 0 ) goto l_352 ;
         if ( HV_15 != 0 ) goto l_65 ;
         rc = TCD3FE1 (pMyPar, 2, "F_GrossPrem_wo_SD_o", 724, 724,
            &HV_16);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_15 = 1;
      l_65: 
         HV_20 = HV_16 * HV_19;
         HV_60 = 1;
      l_352: 
         if ( HV_61 != 0 ) goto l_346 ;
         if ( HV_13 != 0 ) goto l_68 ;
         rc = TCD3FE1 (pMyPar, 2, "F_GrossPrem_wo_SD_n", 721, 721,
            &HV_14);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_13 = 1;
      l_68: 
         HV_21 = HV_14 - HV_20;
         HV_61 = 1;
      l_346: 
         if ( HV_47 != 0 ) goto l_71 ;
         rc = TCD3FE1 (pMyPar, 2, "F_Comm_Percentage", 657, 657,
            &HV_48);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_47 = 1;
      l_71: 
         HV_49 = HV_21 * HV_48;
         HV_3 [ HV_0 ]  = HV_49;
         continue ;
      l_369: 
         if ( HV_0 == 5 ) goto l_381 ;
         goto l_396 ;
      l_381: 
         if ( HV_50 != 0 ) goto l_74 ;
         TCD3FES (pMyPar, "e_AddContrib_n", 31, 359, 6, 31, &HV_51);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_50 = 1;
      l_74: 
         if ( HV_23 != 0 ) goto l_77 ;
         rc = TCD3FE1 (pMyPar, 2, "F_CommReductionFact", 636, 636,
            &HV_24);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_23 = 1;
      l_77: 
         HV_52 = HV_51 * HV_24;
         HV_3 [ HV_0 ]  = HV_52;
         continue ;
      l_396: 
         if ( HV_0 == 6 ) goto l_408 ;
         goto l_423 ;
      l_408: 
         if ( HV_50 != 0 ) goto l_80 ;
         TCD3FES (pMyPar, "e_AddContrib_n", 31, 359, 6, 31, &HV_51);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_50 = 1;
      l_80: 
         if ( HV_53 != 0 ) goto l_83 ;
         rc = TCD3FE1 (pMyPar, 2, "F_CommAddContrib", 660, 660,
            &HV_54);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_53 = 1;
      l_83: 
         HV_55 = HV_51 * HV_54;
         HV_3 [ HV_0 ]  = HV_55;
         continue ;
      l_423: 
         if ( HV_0 == 7 ) goto l_435 ;
         goto l_477 ;
      l_435: 
         if ( HV_5 != 0 ) goto l_86 ;
         rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_6);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_5 = 1;
      l_86: 
         HV_9 = (TCD_INT) ( HV_6) ;
         if ( HV_7 != 0 ) goto l_89 ;
         rc = TCD3FE1 (pMyPar, 2, "_RecurringComm", 655, 655, &HV_8);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_7 = 1;
      l_89: 
         HV_10 = (TCD_INT) ( HV_8) ;
         if ( HV_11 != 0 ) goto l_92 ;
         TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_12);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_11 = 1;
      l_92: 
         if ( HV_10 < 0 || HV_10 > pMyPar->pTCDTCD->SSAData.AnzSpalten
            - 1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         if ( HV_9 < 0 || HV_9 > pMyPar->pTCDTCD->SSAData.AnzZeilen -
            1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         if ( HV_12 [ HV_9 * 110 + HV_10 ]  == 1 ) goto l_453 ;
         goto l_468 ;
      l_453: 
         if ( HV_13 != 0 ) goto l_95 ;
         rc = TCD3FE1 (pMyPar, 2, "F_GrossPrem_wo_SD_n", 721, 721,
            &HV_14);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_13 = 1;
      l_95: 
         if ( HV_23 != 0 ) goto l_98 ;
         rc = TCD3FE1 (pMyPar, 2, "F_CommReductionFact", 636, 636,
            &HV_24);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_23 = 1;
      l_98: 
         HV_56 = HV_14 * HV_24;
         HV_3 [ HV_0 ]  = HV_56;
         continue ;
      l_468: 
         HV_57 = 0;
         HV_3 [ HV_0 ]  = HV_57;
         continue ;
      l_477: 
         HV_58 = 0;
         HV_3 [ HV_0 ]  = HV_58;
         continue ;
      }


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetTb (pMyPar, &HV_3);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT637","End F_Commission",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Commission", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Commission", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Commission");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT662
   Beschreibung: Die Funktion berechnet die Formel 
                 F_IsProlongation
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT662 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_16 = 1;
      TCD_INT     HV_17 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT662","Begin F_IsProlongation",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,662,"12.12.2019 17:29:30",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_15);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT662",
              "Ende F_IsProlongation",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_7 = 0;
      HV_12 = 0;
      HV_18 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "e_method", 53, 409, 6, 53, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 > 0 ) goto l_24 ;
      goto l_81 ;
   l_24: 
      if ( HV_2 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "e_n_n", 0, 4, 6, 0, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_8: 
   TCDSetPS (pMyPar, 1, 94, &HV_5, &HV_4, HV_3);
      rc = TCD3FE1 (pMyPar, 4, "F_n", 364, 364, &HV_6);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 94, &HV_5, &HV_4, HV_3);
      if ( HV_7 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "e_n_o", 7, 104, 6, 7, &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_11: 
      if ( HV_18 != 0 ) goto l_40 ;
   TCDSetPS (pMyPar, 1, 94, &HV_10, &HV_9, HV_8);
      rc = TCD3FE1 (pMyPar, 4, "F_n", 364, 364, &HV_11);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 94, &HV_10, &HV_9, HV_8);
      HV_18 = 1;
   l_40: 
      if ( HV_6 > HV_11 ) goto l_51 ;
      goto l_81 ;
   l_51: 
      if ( HV_7 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "e_n_o", 7, 104, 6, 7, &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_14: 
      if ( HV_18 != 0 ) goto l_61 ;
   TCDSetPS (pMyPar, 1, 94, &HV_10, &HV_9, HV_8);
      rc = TCD3FE1 (pMyPar, 4, "F_n", 364, 364, &HV_11);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 94, &HV_10, &HV_9, HV_8);
      HV_18 = 1;
   l_61: 
      HV_14 = HV_11 - 1;
      if ( HV_12 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_17: 
      if ( HV_13 >= HV_14 ) goto l_75 ;
      goto l_81 ;
   l_75: 
      HV_16 = 1;
      HV_15 = HV_16;
      goto l_3 ;
   l_81: 
      HV_17 = 0;
      HV_15 = HV_17;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_15);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT662","End F_IsProlongation",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_IsProlongation", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_IsProlongation", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_IsProlongation");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT670
   Beschreibung: Die Funktion berechnet die Formel 
                 F_CreditableReserve
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT670 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_DOUBLE  HV_27 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_DOUBLE  HV_29 = 0;
      TCD_DOUBLE  HV_30 = 0;
      TCD_DOUBLE  HV_31 = 0;
      TCD_DOUBLE  HV_32 = 0;
      TCD_DOUBLE  HV_33 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_14 = 0;
      TCD_INT     HV_16 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_20 = 0;
      TCD_INT     HV_22 = 0;
      TCD_INT     HV_25 = 0;
      TCD_INT     HV_11 = 0;


   /* Generierung der BeschaffungsFlags: */
      int i_i_Reserve_IDBeschafft_18 = 0;
   int i_i_Reserve_ValBeschafft_19 = 0;


   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT670","Begin F_CreditableReserve",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,670,"12.12.2019 17:29:35",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT670",
              "Ende F_CreditableReserve",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_3 = 0;
      HV_6 = 0;
      HV_9 = 0;
      HV_14 = 0;
      HV_20 = 0;
      HV_22 = 0;
      HV_25 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "e_manual_reserve_n", 55, 411, 6, 55, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 > 0 ) goto l_18 ;
      goto l_36 ;
   l_18: 
      if ( HV_0 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "e_manual_reserve_n", 55, 411, 6, 55, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_8: 
      if ( HV_3 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_AddContrib", 33, 355, 1, 121, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_11: 
      HV_5 = HV_1 + HV_4;
      if ( HV_6 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_PartSurrender", 34, 356, 1, 122, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_14: 
      HV_8 = HV_5 - HV_7;
      HV_2 = HV_8;
      goto l_3 ;
   l_36: 
      if ( HV_9 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "e_method", 53, 409, 6, 53, &HV_10);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_9 = 1;
   l_17: 
      if ( HV_10 == 0 ) goto l_48 ;
      goto l_54 ;
   l_48: 
      if ( HV_3 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_AddContrib", 33, 355, 1, 121, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_20: 
      HV_2 = HV_4;
      goto l_3 ;
   l_54: 
      if ( HV_14 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "e_RateClass_o", 34, 362, 6, 34, &HV_15);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_14 = 1;
   l_23: 
   TCDSetPS (pMyPar, 1, 133, &HV_13, &HV_12, HV_11);
   TCDSetPS (pMyPar, 1, 118, &HV_17, &HV_16, HV_15);
       if ( !i_i_Reserve_IDBeschafft_18 &&
       !i_i_Reserve_ValBeschafft_19 ) {
         if (pMyPar->pTCDTCD->SSAData.pParSkal[104].Level==0) {
            TCDFtID (pMyPar, "i_Reserve", 16, 282, 1, &HV_18);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_Reserve_IDBeschafft_18 = 1;
         }
         if ( !i_i_Reserve_IDBeschafft_18 ) {
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = TCD_RC_OK;
            TCD3FES (pMyPar, "i_Reserve", 16, 282, 1, 104, &HV_19);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_Reserve_ValBeschafft_19 = 1;
         }
          if ( !i_i_Reserve_IDBeschafft_18 &&
          !i_i_Reserve_ValBeschafft_19 ) goto l_ende;
      }
      if (i_i_Reserve_IDBeschafft_18) {
         rc = TCD3FE1 (pMyPar, 3, "i_Reserve", 282, HV_18, &HV_19);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
      }
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 118, &HV_17, &HV_16, HV_15);
   TCDSetPS (pMyPar, 0, 133, &HV_13, &HV_12, HV_15);
      if ( HV_20 != 0 ) goto l_26 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Alpha1_Permille", 671, 671, &HV_21);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_20 = 1;
   l_26: 
      if ( HV_22 != 0 ) goto l_29 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Alpha2_Permille", 672, 672, &HV_23);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_22 = 1;
   l_29: 
      HV_24 = HV_21 + HV_23;
      if ( HV_25 != 0 ) goto l_32 ;
      rc = TCD3FE1 (pMyPar, 2, "F_IsProlongation", 662, 662, &HV_26);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_25 = 1;
   l_32: 
      HV_27 =   TCDRND ( HV_26, 0 ) ;
      HV_28 = HV_24 * HV_27;
      HV_29 = 1 - HV_28;
      HV_30 = HV_19 * HV_29;
      if ( HV_3 != 0 ) goto l_35 ;
      TCD3FES (pMyPar, "i_AddContrib", 33, 355, 1, 121, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_35: 
      HV_31 = HV_30 + HV_4;
      if ( HV_6 != 0 ) goto l_38 ;
      TCD3FES (pMyPar, "i_PartSurrender", 34, 356, 1, 122, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_38: 
      HV_32 = HV_31 - HV_7;
      HV_33 =   TCDRND ( HV_32, 2 ) ;
      HV_2 = HV_33;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT670","End F_CreditableReserve",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_CreditableReserve", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_CreditableReserve", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_CreditableReserve");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT675
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Benefit_Death
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT675 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_14 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT675","Begin F_Benefit_Death",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,675,"12.12.2019 17:29:34",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_4);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT675",
              "Ende F_Benefit_Death",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_5 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_2 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_8: 
      if ( HV_1 <= HV_3 ) goto l_18 ;
      goto l_51 ;
   l_18: 
      if ( HV_2 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_11: 
      if ( HV_0 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_14: 
      HV_9 = TCDINT ( HV_1 ) ;
   TCDSetPS (pMyPar, 1, 145, &HV_8, &HV_7, HV_3);
   TCDSetPS (pMyPar, 1, 108, &HV_11, &HV_10, HV_9);
      rc = TCD3FE1 (pMyPar, 4, "F_a1j", 272, 272, &HV_12);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 108, &HV_11, &HV_10, HV_9);
   TCDSetPS (pMyPar, 0, 145, &HV_8, &HV_7, HV_9);
      if ( HV_5 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_17: 
      HV_13 = HV_6 * HV_12;
      HV_4 = HV_13;
      goto l_3 ;
   l_51: 
      HV_14 = 0;
      HV_4 = HV_14;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_4);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT675","End F_Benefit_Death",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Benefit_Death", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Benefit_Death", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Benefit_Death");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT676
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Benefit_Endowment
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT676 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_11 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT676","Begin F_Benefit_Endowment",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,676,"12.12.2019 17:29:34",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_4);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT676",
              "Ende F_Benefit_Endowment",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_5 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_2 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_8: 
      if ( HV_1 <= HV_3 ) goto l_18 ;
      goto l_39 ;
   l_18: 
      if ( HV_2 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_11: 
   TCDSetPS (pMyPar, 1, 145, &HV_8, &HV_7, HV_3);
      rc = TCD3FE1 (pMyPar, 4, "F_ej", 257, 257, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 145, &HV_8, &HV_7, HV_3);
      if ( HV_5 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_14: 
      HV_10 = HV_6 * HV_9;
      HV_4 = HV_10;
      goto l_3 ;
   l_39: 
      HV_11 = 0;
      HV_4 = HV_11;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_4);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT676","End F_Benefit_Endowment",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Benefit_Endowment", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Benefit_Endowment", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Benefit_Endowment");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT683
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Reduction
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT683 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_DOUBLE  HV_29 = 0;
      TCD_DOUBLE  HV_30 = 0;
      TCD_DOUBLE  HV_31 = 0;
      TCD_DOUBLE  HV_33 = 0;
      TCD_DOUBLE  HV_34 = 0;
      TCD_DOUBLE  HV_35 = 0;
      TCD_DOUBLE  HV_36 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_15 = 0;
      TCD_INT     HV_17 = 0;
      TCD_INT     HV_19 = 0;
      TCD_INT     HV_22 = 0;
      TCD_INT     HV_25 = 0;
      TCD_INT     HV_27 = 0;
      TCD_INT     HV_32 = 0;
      TCD_INT     HV_38 = 0;
      TCD_INT     HV_39 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_37 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT683","Begin F_Reduction",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,683,"12.12.2019 17:29:31",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_4);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT683",
              "Ende F_Reduction",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_6 = 0;
      HV_8 = 0;
      HV_10 = 0;
      HV_13 = 0;
      HV_15 = 0;
      HV_17 = 0;
      HV_19 = 0;
      HV_22 = 0;
      HV_25 = 0;
      HV_27 = 0;
      HV_32 = 0;
      HV_38 = 0;
      HV_39 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_State", 67, 421, 1, 155, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_2 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_premFree", 648, 648, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_8: 
      if ( HV_1 == HV_3 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_5 = 0;
      HV_4 = HV_5;
      goto l_3 ;
   l_24: 
      if ( HV_6 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_11: 
      if ( HV_8 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "F_n", 364, 364, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_8 = 1;
   l_14: 
      if ( HV_7 == HV_9 ) goto l_36 ;
      goto l_48 ;
   l_36: 
      if ( HV_10 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_Surrender_xnt", 66, 420, 1, 154, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_17: 
      HV_12 =   TCDRND ( HV_11, 2 ) ;
      HV_4 = HV_12;
      goto l_3 ;
   l_48: 
      if ( HV_6 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_20: 
      if ( HV_13 != 0 ) goto l_23 ;
      rc = TCD3FE1 (pMyPar, 2, "F_m", 366, 366, &HV_14);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_13 = 1;
   l_23: 
      if ( HV_7 >= HV_14 ) goto l_60 ;
      goto l_66 ;
   l_60: 
      if ( HV_15 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_16);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_15 = 1;
   l_26: 
      HV_4 = HV_16;
      goto l_3 ;
   l_66: 
      if ( HV_38 != 0 ) goto l_76 ;
      if ( HV_17 != 0 ) goto l_29 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Exn", 258, 258, &HV_18);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_17 = 1;
   l_29: 
      if ( HV_19 != 0 ) goto l_32 ;
      rc = TCD3FE1 (pMyPar, 2, "F_A3xn", 273, 273, &HV_20);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_19 = 1;
   l_32: 
      HV_21 = HV_18 + HV_20;
      HV_38 = 1;
   l_76: 
      if ( HV_39 != 0 ) goto l_73 ;
      if ( HV_22 != 0 ) goto l_35 ;
      TCD3FES (pMyPar, "i_Gamma3", 54, 402, 1, 142, &HV_23);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_22 = 1;
   l_35: 
      HV_24 = HV_21 + HV_23;
      HV_39 = 1;
   l_73: 
      if ( HV_24 > 0 ) goto l_90 ;
      goto l_144 ;
   l_90: 
      if ( HV_25 != 0 ) goto l_38 ;
      rc = TCD3FE1 (pMyPar, 2, "F_A3xn_sub", 276, 276, &HV_26);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_25 = 1;
   l_38: 
      if ( HV_27 != 0 ) goto l_41 ;
      TCD3FES (pMyPar, "i_SumOfPremium", 64, 418, 1, 152, &HV_28);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_27 = 1;
   l_41: 
      HV_29 = HV_26 * HV_28;
      if ( HV_10 != 0 ) goto l_44 ;
      TCD3FES (pMyPar, "i_Surrender_xnt", 66, 420, 1, 154, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_44: 
      HV_30 = HV_11 - HV_29;
      if ( HV_38 != 0 ) goto l_121 ;
      if ( HV_17 != 0 ) goto l_47 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Exn", 258, 258, &HV_18);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_17 = 1;
   l_47: 
      if ( HV_19 != 0 ) goto l_50 ;
      rc = TCD3FE1 (pMyPar, 2, "F_A3xn", 273, 273, &HV_20);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_19 = 1;
   l_50: 
      HV_21 = HV_18 + HV_20;
      HV_38 = 1;
   l_121: 
      if ( HV_39 != 0 ) goto l_118 ;
      if ( HV_22 != 0 ) goto l_53 ;
      TCD3FES (pMyPar, "i_Gamma3", 54, 402, 1, 142, &HV_23);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_22 = 1;
   l_53: 
      HV_24 = HV_21 + HV_23;
      HV_39 = 1;
   l_118: 
   if ( HV_24 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_31 = HV_30 / HV_24;
      if ( HV_32 != 0 ) goto l_56 ;
      rc = TCD3FE1 (pMyPar, 2, "F_TotalMatAmount", 700, 700, &HV_33);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_32 = 1;
   l_56: 
      HV_34 = TCDMAX ( HV_33, 1 ) ;
   if ( HV_34 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_35 = HV_31 / HV_34;
      HV_36 =   TCDRND ( HV_35, 2 ) ;
      HV_4 = HV_36;
      goto l_3 ;
   l_144: 
      HV_37 = 0;
      HV_4 = HV_37;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_4);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT683","End F_Reduction",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Reduction", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Reduction", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Reduction");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT684
   Beschreibung: Die Funktion berechnet die Formel 
                 F_SurrenderFactor
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT684 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_27 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_DOUBLE  HV_29 = 0;
      TCD_DOUBLE  HV_30 = 0;
      TCD_DOUBLE  HV_31 = 0;
      TCD_DOUBLE  HV_32 = 0;
      TCD_DOUBLE  HV_33 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_16 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_20 = 0;
      TCD_INT     HV_22 = 0;
      TCD_INT     HV_24 = 0;
      TCD_INT     HV_26 = 0;
      TCD_INT     HV_35 = 0;
      TCD_INT     HV_36 = 0;
      P_TCDTAB2   HV_7;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_15 = 1;
      TCD_INT     HV_34 = 1;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT684","Begin F_SurrenderFactor",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,684,"12.12.2019 17:29:31",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_11);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT684",
              "Ende F_SurrenderFactor",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_6 = 0;
      HV_8 = 0;
      HV_13 = 0;
      HV_16 = 0;
      HV_18 = 0;
      HV_20 = 0;
      HV_22 = 0;
      HV_24 = 0;
      HV_26 = 0;
      HV_35 = 0;
      HV_36 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_5: 
      HV_4 = (TCD_INT) ( HV_1) ;
      if ( HV_2 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_CancFac_from", 652, 652, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_8: 
      HV_5 = (TCD_INT) ( HV_3) ;
      if ( HV_6 != 0 ) goto l_11 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_11: 
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_4 < 0 || HV_4 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_7 [ HV_4 * 110 + HV_5 ]  == 0 ) goto l_27 ;
      goto l_48 ;
   l_27: 
      if ( HV_0 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_14: 
      HV_4 = (TCD_INT) ( HV_1) ;
      if ( HV_8 != 0 ) goto l_17 ;
      rc = TCD3FE1 (pMyPar, 2, "_CancFac_to", 651, 651, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_8 = 1;
   l_17: 
      HV_10 = (TCD_INT) ( HV_9) ;
      if ( HV_6 != 0 ) goto l_20 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_20: 
      if ( HV_10 < 0 || HV_10 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
         1) { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_4 < 0 || HV_4 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_7 [ HV_4 * 110 + HV_10 ]  == 0 ) goto l_42 ;
      goto l_48 ;
   l_42: 
      HV_12 = 0;
      HV_11 = HV_12;
      goto l_3 ;
   l_48: 
      if ( HV_13 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_RateClass", 30, 347, 1, 118, &HV_14);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_13 = 1;
   l_23: 
      if ( HV_14 == 2 ) goto l_60 ;
      goto l_66 ;
   l_60: 
      HV_15 = 1;
      HV_11 = HV_15;
      goto l_3 ;
   l_66: 
      if ( HV_16 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_State", 67, 421, 1, 155, &HV_17);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_16 = 1;
   l_26: 
      if ( HV_18 != 0 ) goto l_29 ;
      rc = TCD3FE1 (pMyPar, 2, "_regularPremium", 649, 649, &HV_19);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_18 = 1;
   l_29: 
      if ( HV_17 == HV_19 ) goto l_102 ;
      goto l_84 ;
   l_84: 
      if ( HV_16 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "i_State", 67, 421, 1, 155, &HV_17);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_16 = 1;
   l_32: 
      if ( HV_20 != 0 ) goto l_35 ;
      rc = TCD3FE1 (pMyPar, 2, "_premFree", 648, 648, &HV_21);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_20 = 1;
   l_35: 
      if ( HV_17 == HV_21 ) goto l_93 ;
      goto l_198 ;
   l_93: 
      if ( HV_22 != 0 ) goto l_38 ;
      TCD3FES (pMyPar, "i_StateDetail", 68, 422, 1, 156, &HV_23);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_22 = 1;
   l_38: 
      if ( HV_23 == 2 ) goto l_102 ;
      goto l_198 ;
   l_102: 
      if ( HV_24 != 0 ) goto l_41 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_25);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_24 = 1;
   l_41: 
      if ( HV_25 > 5 ) goto l_117 ;
      goto l_186 ;
   l_117: 
      if ( HV_26 != 0 ) goto l_44 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_27);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_26 = 1;
   l_44: 
      if ( HV_27 > 5 ) goto l_126 ;
      goto l_186 ;
   l_126: 
      if ( HV_0 != 0 ) goto l_47 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_47: 
      HV_4 = (TCD_INT) ( HV_1) ;
      if ( HV_2 != 0 ) goto l_50 ;
      rc = TCD3FE1 (pMyPar, 2, "_CancFac_from", 652, 652, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_50: 
      HV_5 = (TCD_INT) ( HV_3) ;
      if ( HV_0 != 0 ) goto l_53 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_53: 
      HV_4 = (TCD_INT) ( HV_1) ;
      if ( HV_8 != 0 ) goto l_56 ;
      rc = TCD3FE1 (pMyPar, 2, "_CancFac_to", 651, 651, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_8 = 1;
   l_56: 
      HV_10 = (TCD_INT) ( HV_9) ;
      if ( HV_0 != 0 ) goto l_59 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_59: 
      HV_4 = (TCD_INT) ( HV_1) ;
      if ( HV_2 != 0 ) goto l_62 ;
      rc = TCD3FE1 (pMyPar, 2, "_CancFac_from", 652, 652, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_62: 
      HV_5 = (TCD_INT) ( HV_3) ;
      if ( HV_6 != 0 ) goto l_65 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_65: 
      if ( HV_6 != 0 ) goto l_68 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_68: 
      if ( HV_10 < 0 || HV_10 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
         1) { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_4 < 0 || HV_4 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_4 < 0 || HV_4 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_28 = HV_7 [ HV_4 * 110 + HV_10 ]  - HV_7 [ HV_4 * 110 + HV_5 ]
         ;
      if ( HV_24 != 0 ) goto l_71 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_25);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_24 = 1;
   l_71: 
      HV_29 = HV_25 - 5;
      HV_30 = HV_28 * HV_29;
      if ( HV_26 != 0 ) goto l_74 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_27);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_26 = 1;
   l_74: 
      HV_31 = HV_27 - 5;
   if ( HV_31 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_32 = HV_30 / HV_31;
      if ( HV_6 != 0 ) goto l_77 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_77: 
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_4 < 0 || HV_4 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_33 = HV_7 [ HV_4 * 110 + HV_5 ]  + HV_32;
      HV_11 = HV_33;
      goto l_3 ;
   l_186: 
      if ( HV_0 != 0 ) goto l_80 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_80: 
      HV_4 = (TCD_INT) ( HV_1) ;
      if ( HV_2 != 0 ) goto l_83 ;
      rc = TCD3FE1 (pMyPar, 2, "_CancFac_from", 652, 652, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_83: 
      HV_5 = (TCD_INT) ( HV_3) ;
      if ( HV_6 != 0 ) goto l_86 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_86: 
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_4 < 0 || HV_4 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_11 = HV_7 [ HV_4 * 110 + HV_5 ] ;
      goto l_3 ;
   l_198: 
      HV_34 = 1;
      HV_11 = HV_34;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_11);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT684","End F_SurrenderFactor",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_SurrenderFactor", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_SurrenderFactor", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_SurrenderFactor");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT685
   Beschreibung: Die Funktion berechnet die Formel 
                 F_SurrenderValue
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT685 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_3 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT685","Begin F_SurrenderValue",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,685,"12.12.2019 17:29:32",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT685",
              "Ende F_SurrenderValue",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      HV_6 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 0 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_4 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_Vxnt", 14, 278, 1, 102, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_8: 
      if ( HV_6 != 0 ) goto l_11 ;
      rc = TCD3FE1 (pMyPar, 2, "F_SurrenderFactor", 684, 684, &HV_7);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_6 = 1;
   l_11: 
      HV_8 = HV_5 * HV_7;
      HV_9 =   TCDRND ( HV_8, 2 ) ;
      HV_10 = TCDMAX ( 0, HV_9 ) ;
      HV_2 = HV_10;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT685","End F_SurrenderValue",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_SurrenderValue", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_SurrenderValue", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_SurrenderValue");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT693
   Beschreibung: Die Funktion berechnet die Formel 
                 F_guaranteePeriod
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT693 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT693","Begin F_guaranteePeriod",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,693,"12.12.2019 17:29:30",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT693",
              "Ende F_guaranteePeriod",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_guaranteePeriod", 71, 428, 1, 159, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
   if ( 12 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_3 = HV_2 / 12;
      HV_4 = TCDINT ( HV_3 ) ;
      HV_0 = HV_4;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT693","End F_guaranteePeriod",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_guaranteePeriod", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_guaranteePeriod", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_guaranteePeriod");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT695
   Beschreibung: Die Funktion berechnet die Formel 
                 F_AnnuityPeriod
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT695 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_11 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT695","Begin F_AnnuityPeriod",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,695,"12.12.2019 17:29:30",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_4);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT695",
              "Ende F_AnnuityPeriod",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_5 = 0;
      HV_11 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_benefitPeriod", 718, 718, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_5: 
      if ( HV_2 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_lifelong", 646, 646, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_8: 
      if ( HV_1 == HV_3 ) goto l_18 ;
      goto l_30 ;
   l_18: 
      if ( HV_11 != 0 ) goto l_22 ;
      if ( HV_5 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_pa", 9, 222, 1, 97, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_11: 
      HV_7 = 120 - HV_6;
      HV_11 = 1;
   l_22: 
      HV_4 = HV_7;
      goto l_3 ;
   l_30: 
      if ( HV_0 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "F_benefitPeriod", 718, 718, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_14: 
   if ( 12 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_8 = HV_1 / 12;
      HV_9 = TCDINT ( HV_8 ) ;
      if ( HV_11 != 0 ) goto l_49 ;
      if ( HV_5 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_pa", 9, 222, 1, 97, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_17: 
      HV_7 = 120 - HV_6;
      HV_11 = 1;
   l_49: 
      HV_10 = TCDMIN ( HV_9, HV_7 ) ;
      HV_4 = HV_10;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_4);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT695","End F_AnnuityPeriod",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_AnnuityPeriod", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_AnnuityPeriod", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_AnnuityPeriod");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT697
   Beschreibung: Die Funktion berechnet die Formel 
                 F_DeathFactor
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT697 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_8 = 0;
      P_TCDTAB2   HV_9;
      TCD_INT     HV_11 = 1;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT697","Begin F_DeathFactor",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,697,"12.12.2019 17:29:33",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_10);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT697",
              "Ende F_DeathFactor",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_4 = 0;
      HV_8 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_DeathBenefitFactor", 60, 413, 1, 148,
         &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 0 ) goto l_21 ;
      goto l_42 ;
   l_21: 
      if ( HV_2 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_8: 
      HV_6 = (TCD_INT) ( HV_3) ;
      if ( HV_4 != 0 ) goto l_11 ;
      rc = TCD3FE1 (pMyPar, 2, "_Has_Factor_Demise", 596, 596, &HV_5);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_4 = 1;
   l_11: 
      HV_7 = (TCD_INT) ( HV_5) ;
      if ( HV_8 != 0 ) goto l_14 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_9);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_8 = 1;
   l_14: 
      if ( HV_7 < 0 || HV_7 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_6 < 0 || HV_6 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_9 [ HV_6 * 110 + HV_7 ]  == 1 ) goto l_36 ;
      goto l_42 ;
   l_36: 
      HV_11 = 1;
      HV_10 = HV_11;
      goto l_3 ;
   l_42: 
      if ( HV_0 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_DeathBenefitFactor", 60, 413, 1, 148,
         &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_17: 
      HV_10 = HV_1;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_10);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT697","End F_DeathFactor",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_DeathFactor", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_DeathFactor", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_DeathFactor");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT700
   Beschreibung: Die Funktion berechnet die Formel 
                 F_TotalMatAmount
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT700 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_11 = 0;
      TCD_INT     HV_10 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT700","Begin F_TotalMatAmount",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,700,"12.12.2019 17:29:33",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT700",
              "Ende F_TotalMatAmount",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_5 = 0;
      if ( HV_3 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_5: 
      if ( HV_5 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_n", 364, 364, &HV_6);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_5 = 1;
   l_8: 
      HV_7 = HV_4 + HV_6;
   TCDSetPS (pMyPar, 1, 97, &HV_9, &HV_8, HV_7);
   TCDSetPS (pMyPar, 1, 88, &HV_12, &HV_11, HV_10);
      rc = TCD3FE1 (pMyPar, 4, "F_ae_delta", 313, 313, &HV_13);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 88, &HV_12, &HV_11, HV_10);
   TCDSetPS (pMyPar, 0, 97, &HV_9, &HV_8, HV_10);
      if ( HV_1 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_11: 
      HV_14 = HV_2 * HV_13;
      HV_15 =   TCDRND ( HV_14, 2 ) ;
      HV_0 = HV_15;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT700","End F_TotalMatAmount",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_TotalMatAmount", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_TotalMatAmount", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_TotalMatAmount");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT716
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Vxnt_OCDis
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT716 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_27 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_DOUBLE  HV_30 = 0;
      TCD_DOUBLE  HV_32 = 0;
      TCD_DOUBLE  HV_33 = 0;
      TCD_DOUBLE  HV_35 = 0;
      TCD_DOUBLE  HV_38 = 0;
      TCD_DOUBLE  HV_39 = 0;
      TCD_DOUBLE  HV_41 = 0;
      TCD_DOUBLE  HV_42 = 0;
      TCD_DOUBLE  HV_43 = 0;
      TCD_DOUBLE  HV_45 = 0;
      TCD_DOUBLE  HV_46 = 0;
      TCD_DOUBLE  HV_47 = 0;
      TCD_DOUBLE  HV_48 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_17 = 0;
      TCD_INT     HV_22 = 0;
      TCD_INT     HV_24 = 0;
      TCD_INT     HV_26 = 0;
      TCD_INT     HV_29 = 0;
      TCD_INT     HV_31 = 0;
      TCD_INT     HV_34 = 0;
      TCD_INT     HV_37 = 0;
      TCD_INT     HV_40 = 0;
      TCD_INT     HV_44 = 0;
      TCD_INT     HV_36 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT716","Begin F_Vxnt_OCDis",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,716,"12.12.2019 17:29:35",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_4);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT716",
              "Ende F_Vxnt_OCDis",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_5 = 0;
      HV_7 = 0;
      HV_9 = 0;
      HV_13 = 0;
      HV_17 = 0;
      HV_22 = 0;
      HV_24 = 0;
      HV_26 = 0;
      HV_31 = 0;
      HV_40 = 0;
      HV_44 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_State", 67, 421, 1, 155, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_2 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_regularPremium", 649, 649, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_8: 
      if ( HV_1 == HV_3 ) goto l_18 ;
      goto l_66 ;
   l_18: 
      if ( HV_9 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_OccSurcharge", 36, 365, 1, 124, &HV_10);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_9 = 1;
   l_11: 
      HV_11 = 1 + HV_10;
      if ( HV_7 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_PBxn", 13, 275, 1, 101, &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_14: 
   if ( HV_11 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_12 = HV_8 / HV_11;
      if ( HV_13 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_SportsSurcharge", 37, 366, 1, 125, &HV_14);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_13 = 1;
   l_17: 
      HV_15 = 1 + HV_14;
   if ( HV_15 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_16 = HV_12 / HV_15;
      if ( HV_17 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_Pxnt", 17, 283, 1, 105, &HV_18);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_17 = 1;
   l_20: 
      HV_19 = HV_16 * HV_18;
      if ( HV_5 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_Bxnt", 15, 280, 1, 103, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_23: 
      HV_20 = HV_6 - HV_19;
      HV_21 =   TCDRND ( HV_20, 2 ) ;
      HV_4 = HV_21;
      goto l_3 ;
   l_66: 
      if ( HV_22 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_StateDetail", 68, 422, 1, 156, &HV_23);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_22 = 1;
   l_26: 
      if ( HV_23 == 0 ) goto l_78 ;
      goto l_147 ;
   l_78: 
      if ( HV_24 != 0 ) goto l_29 ;
      TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_25);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_24 = 1;
   l_29: 
      if ( HV_26 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_27);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_26 = 1;
   l_32: 
      HV_28 = HV_25 + HV_27;
      if ( HV_31 != 0 ) goto l_35 ;
      TCD3FES (pMyPar, "i_benefitPeriod", 72, 429, 1, 160, &HV_32);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_31 = 1;
   l_35: 
      if ( HV_26 != 0 ) goto l_38 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_27);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_26 = 1;
   l_38: 
      HV_33 = HV_32 - HV_27;
   TCDSetPS (pMyPar, 1, 90, &HV_30, &HV_29, HV_28);
   TCDSetPS (pMyPar, 1, 93, &HV_35, &HV_34, HV_33);
   TCDSetPS (pMyPar, 1, 88, &HV_38, &HV_37, HV_36);
      rc = TCD3FE1 (pMyPar, 4, "F_aei_OCDis", 708, 708, &HV_39);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 88, &HV_38, &HV_37, HV_36);
   TCDSetPS (pMyPar, 0, 93, &HV_35, &HV_34, HV_36);
   TCDSetPS (pMyPar, 0, 90, &HV_30, &HV_29, HV_36);
      if ( HV_40 != 0 ) goto l_41 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Delta", 504, 504, &HV_41);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_40 = 1;
   l_41: 
      HV_42 = 1 + HV_41;
      HV_43 = HV_39 * HV_42;
      if ( HV_44 != 0 ) goto l_44 ;
      TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_45);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_44 = 1;
   l_44: 
      HV_46 = HV_43 * HV_45;
      HV_47 =   TCDRND ( HV_46, 2 ) ;
      HV_4 = HV_47;
      goto l_3 ;
   l_147: 
      if ( HV_5 != 0 ) goto l_47 ;
      TCD3FES (pMyPar, "i_Bxnt", 15, 280, 1, 103, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_47: 
      HV_48 =   TCDRND ( HV_6, 2 ) ;
      HV_4 = HV_48;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_4);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT716","End F_Vxnt_OCDis",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Vxnt_OCDis", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Vxnt_OCDis", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Vxnt_OCDis");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT717
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Bxnt_OCDis
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT717 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_11 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_17 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT717","Begin F_Bxnt_OCDis",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,717,"12.12.2019 17:29:35",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT717",
              "Ende F_Bxnt_OCDis",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_6 = 0;
      HV_8 = 0;
      HV_11 = 0;
      HV_13 = 0;
      HV_17 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_CashValue_OccDis", 715, 715, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
      if ( HV_3 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_8: 
      HV_5 = HV_2 * HV_4;
      if ( HV_6 != 0 ) goto l_11 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AlphaOccDis_CV", 702, 702, &HV_7);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_6 = 1;
   l_11: 
      if ( HV_8 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "F_BetaOccDis_CV", 703, 703, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_8 = 1;
   l_14: 
      HV_10 = HV_7 + HV_9;
      if ( HV_13 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_OccSurcharge", 36, 365, 1, 124, &HV_14);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_13 = 1;
   l_17: 
      HV_15 = 1 + HV_14;
      if ( HV_11 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_PBxn", 13, 275, 1, 101, &HV_12);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_11 = 1;
   l_20: 
   if ( HV_15 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_16 = HV_12 / HV_15;
      if ( HV_17 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_SportsSurcharge", 37, 366, 1, 125, &HV_18);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_17 = 1;
   l_23: 
      HV_19 = 1 + HV_18;
   if ( HV_19 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_20 = HV_16 / HV_19;
      HV_21 = HV_10 * HV_20;
      HV_22 = HV_5 + HV_21;
      HV_23 =   TCDRND ( HV_22, 2 ) ;
      HV_0 = HV_23;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT717","End F_Bxnt_OCDis",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Bxnt_OCDis", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Bxnt_OCDis", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Bxnt_OCDis");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT718
   Beschreibung: Die Funktion berechnet die Formel 
                 F_benefitPeriod
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT718 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT718","Begin F_benefitPeriod",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,718,"12.12.2019 17:29:30",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT718",
              "Ende F_benefitPeriod",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_benefitPeriod", 72, 429, 1, 160, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
   if ( 12 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_3 = HV_2 / 12;
      HV_4 = TCDINT ( HV_3 ) ;
      HV_0 = HV_4;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT718","End F_benefitPeriod",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_benefitPeriod", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_benefitPeriod", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_benefitPeriod");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT735
   Beschreibung: Die Funktion berechnet die Formel 
                 F_SumsOfPrem_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT735 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_27 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_DOUBLE  HV_29 = 0;
      TCD_DOUBLE  HV_31 = 0;
      TCD_DOUBLE  HV_32 = 0;
      TCD_DOUBLE  HV_33 = 0;
      TCD_DOUBLE  HV_35 = 0;
      TCD_DOUBLE  HV_37 = 0;
      TCD_DOUBLE  HV_38 = 0;
      TCD_DOUBLE  HV_40 = 0;
      TCD_DOUBLE  HV_41 = 0;
      TCD_DOUBLE  HV_42 = 0;
      TCD_DOUBLE  HV_44 = 0;
      TCD_DOUBLE  HV_45 = 0;
      TCD_DOUBLE  HV_46 = 0;
      TCD_DOUBLE  HV_48 = 0;
      TCD_DOUBLE  HV_49 = 0;
      TCD_DOUBLE  HV_51 = 0;
      TCD_DOUBLE  HV_52 = 0;
      TCD_DOUBLE  HV_53 = 0;
      TCD_DOUBLE  HV_55 = 0;
      TCD_DOUBLE  HV_56 = 0;
      TCD_DOUBLE  HV_57 = 0;
      TCD_DOUBLE  HV_59 = 0;
      TCD_DOUBLE  HV_60 = 0;
      TCD_DOUBLE  HV_62 = 0;
      TCD_DOUBLE  HV_63 = 0;
      TCD_DOUBLE  HV_64 = 0;
      TCD_DOUBLE  HV_65 = 0;
      TCD_DOUBLE  HV_66 = 0;
      TCD_DOUBLE  HV_68 = 0;
      TCD_DOUBLE  HV_69 = 0;
      TCD_DOUBLE  HV_71 = 0;
      TCD_DOUBLE  HV_72 = 0;
      TCD_DOUBLE  HV_73 = 0;
      TCD_DOUBLE  HV_75 = 0;
      TCD_DOUBLE  HV_76 = 0;
      TCD_DOUBLE  HV_77 = 0;
      TCD_DOUBLE  HV_79 = 0;
      TCD_DOUBLE  HV_80 = 0;
      TCD_DOUBLE  HV_82 = 0;
      TCD_DOUBLE  HV_83 = 0;
      TCD_DOUBLE  HV_84 = 0;
      TCD_DOUBLE  HV_86 = 0;
      TCD_DOUBLE  HV_87 = 0;
      TCD_DOUBLE  HV_88 = 0;
      TCD_DOUBLE  HV_90 = 0;
      TCD_DOUBLE  HV_91 = 0;
      TCD_DOUBLE  HV_93 = 0;
      TCD_DOUBLE  HV_94 = 0;
      TCD_DOUBLE  HV_95 = 0;
      TCD_DOUBLE  HV_96 = 0;
      TCD_DOUBLE  HV_97 = 0;
      TCD_DOUBLE  HV_98 = 0;
      TCD_DOUBLE  HV_99 = 0;
      TCD_DOUBLE  HV_100 = 0;
      TCD_DOUBLE  HV_101 = 0;
      TCD_DOUBLE  HV_103 = 0;
      TCD_DOUBLE  HV_104 = 0;
      TCD_DOUBLE  HV_105 = 0;
      TCD_DOUBLE  HV_107 = 0;
      TCD_DOUBLE  HV_108 = 0;
      TCD_DOUBLE  HV_109 = 0;
      TCD_DOUBLE  HV_111 = 0;
      TCD_DOUBLE  HV_112 = 0;
      TCD_DOUBLE  HV_114 = 0;
      TCD_DOUBLE  HV_115 = 0;
      TCD_DOUBLE  HV_116 = 0;
      TCD_DOUBLE  HV_118 = 0;
      TCD_DOUBLE  HV_119 = 0;
      TCD_DOUBLE  HV_120 = 0;
      TCD_DOUBLE  HV_122 = 0;
      TCD_DOUBLE  HV_123 = 0;
      TCD_DOUBLE  HV_125 = 0;
      TCD_DOUBLE  HV_126 = 0;
      TCD_DOUBLE  HV_127 = 0;
      TCD_DOUBLE  HV_128 = 0;
      TCD_DOUBLE  HV_129 = 0;
      TCD_DOUBLE  HV_130 = 0;
      TCD_DOUBLE  HV_131 = 0;
      TCD_DOUBLE  HV_132 = 0;
      TCD_DOUBLE  HV_133 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_14 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_21 = 0;
      TCD_INT     HV_24 = 0;
      TCD_INT     HV_26 = 0;
      TCD_INT     HV_30 = 0;
      TCD_INT     HV_34 = 0;
      TCD_INT     HV_36 = 0;
      TCD_INT     HV_39 = 0;
      TCD_INT     HV_43 = 0;
      TCD_INT     HV_47 = 0;
      TCD_INT     HV_50 = 0;
      TCD_INT     HV_54 = 0;
      TCD_INT     HV_58 = 0;
      TCD_INT     HV_61 = 0;
      TCD_INT     HV_67 = 0;
      TCD_INT     HV_70 = 0;
      TCD_INT     HV_74 = 0;
      TCD_INT     HV_78 = 0;
      TCD_INT     HV_81 = 0;
      TCD_INT     HV_85 = 0;
      TCD_INT     HV_89 = 0;
      TCD_INT     HV_92 = 0;
      TCD_INT     HV_102 = 0;
      TCD_INT     HV_106 = 0;
      TCD_INT     HV_110 = 0;
      TCD_INT     HV_113 = 0;
      TCD_INT     HV_117 = 0;
      TCD_INT     HV_121 = 0;
      TCD_INT     HV_124 = 0;
      TCD_INT     HV_134 = 0;
      TCD_INT     HV_135 = 0;
      TCD_INT     HV_136 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT735","Begin F_SumsOfPrem_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,735,"12.12.2019 17:29:33",
                       5);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_33);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT735",
              "Ende F_SumsOfPrem_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      HV_12 = 0;
      HV_24 = 0;
      HV_34 = 0;
      HV_67 = 0;
      HV_134 = 0;
      HV_135 = 0;
      HV_136 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "e_TBeg_o", 9, 122, 6, 9, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_4 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_8: 
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
   TCDSetPS (pMyPar, 1, 119, &HV_7, &HV_6, HV_5);
      rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY_plus_i_t", 579, 579,
         &HV_8);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 119, &HV_7, &HV_6, HV_5);
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_5);
   TCDSetPS (pMyPar, 1, 116, &HV_10, &HV_9, HV_8);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_11);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_10, &HV_9, HV_8);
      if ( HV_0 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "e_TBeg_o", 9, 122, 6, 9, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_11: 
      if ( HV_12 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "e_m_o", 6, 103, 6, 6, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_14: 
      if ( HV_134 != 0 ) goto l_76 ;
   TCDSetPS (pMyPar, 1, 91, &HV_15, &HV_14, HV_13);
      rc = TCD3FE1 (pMyPar, 4, "F_m", 366, 366, &HV_16);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 91, &HV_15, &HV_14, HV_13);
      HV_134 = 1;
   l_76: 
      if ( HV_135 != 0 ) goto l_73 ;
      HV_17 =   TCDRND ( HV_16, 0 ) ;
      HV_135 = 1;
   l_73: 
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
   TCDSetPS (pMyPar, 1, 119, &HV_19, &HV_18, HV_17);
      rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY_plus_i_t", 579, 579,
         &HV_20);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 119, &HV_19, &HV_18, HV_17);
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_17);
   TCDSetPS (pMyPar, 1, 116, &HV_22, &HV_21, HV_20);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_23);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_22, &HV_21, HV_20);
      if ( HV_11 > HV_23 ) goto l_90 ;
      goto l_156 ;
   l_90: 
      if ( HV_24 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "e_YieldDate_o", 82, 459, 6, 82, &HV_25);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_24 = 1;
   l_17: 
      if ( HV_136 != 0 ) goto l_94 ;
   TCDSetPS (pMyPar, 1, 116, &HV_27, &HV_26, HV_25);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_28);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_27, &HV_26, HV_25);
      HV_136 = 1;
   l_94: 
      if ( HV_0 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "e_TBeg_o", 9, 122, 6, 9, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_20: 
      if ( HV_12 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "e_m_o", 6, 103, 6, 6, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_23: 
      if ( HV_134 != 0 ) goto l_136 ;
   TCDSetPS (pMyPar, 1, 91, &HV_15, &HV_14, HV_13);
      rc = TCD3FE1 (pMyPar, 4, "F_m", 366, 366, &HV_16);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 91, &HV_15, &HV_14, HV_13);
      HV_134 = 1;
   l_136: 
      if ( HV_135 != 0 ) goto l_133 ;
      HV_17 =   TCDRND ( HV_16, 0 ) ;
      HV_135 = 1;
   l_133: 
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
   TCDSetPS (pMyPar, 1, 119, &HV_19, &HV_18, HV_17);
      rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY_plus_i_t", 579, 579,
         &HV_29);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 119, &HV_19, &HV_18, HV_17);
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_17);
   TCDSetPS (pMyPar, 1, 116, &HV_31, &HV_30, HV_29);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_32);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_31, &HV_30, HV_29);
      if ( HV_28 > HV_32 ) goto l_150 ;
      goto l_156 ;
   l_150: 
      if ( HV_34 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "e_SumOfPremiums_o", 68, 442, 6, 68, &HV_35);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_34 = 1;
   l_26: 
      HV_33 = HV_35;
      goto l_3 ;
   l_156: 
      if ( HV_0 != 0 ) goto l_29 ;
      TCD3FES (pMyPar, "e_TBeg_o", 9, 122, 6, 9, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_29: 
      if ( HV_0 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "e_TBeg_o", 9, 122, 6, 9, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_32: 
      if ( HV_4 != 0 ) goto l_35 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_35: 
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
   TCDSetPS (pMyPar, 1, 119, &HV_7, &HV_6, HV_5);
      rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY_plus_i_t", 579, 579,
         &HV_38);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 119, &HV_7, &HV_6, HV_5);
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_5);
   TCDSetPS (pMyPar, 1, 116, &HV_40, &HV_39, HV_38);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_41);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_40, &HV_39, HV_38);
      if ( HV_0 != 0 ) goto l_38 ;
      TCD3FES (pMyPar, "e_TBeg_o", 9, 122, 6, 9, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_38: 
      if ( HV_12 != 0 ) goto l_41 ;
      TCD3FES (pMyPar, "e_m_o", 6, 103, 6, 6, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_41: 
      if ( HV_134 != 0 ) goto l_259 ;
   TCDSetPS (pMyPar, 1, 91, &HV_15, &HV_14, HV_13);
      rc = TCD3FE1 (pMyPar, 4, "F_m", 366, 366, &HV_16);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 91, &HV_15, &HV_14, HV_13);
      HV_134 = 1;
   l_259: 
      if ( HV_135 != 0 ) goto l_256 ;
      HV_17 =   TCDRND ( HV_16, 0 ) ;
      HV_135 = 1;
   l_256: 
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
   TCDSetPS (pMyPar, 1, 119, &HV_19, &HV_18, HV_17);
      rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY_plus_i_t", 579, 579,
         &HV_42);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 119, &HV_19, &HV_18, HV_17);
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_17);
   TCDSetPS (pMyPar, 1, 116, &HV_44, &HV_43, HV_42);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_45);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_44, &HV_43, HV_42);
      HV_46 = TCDMIN ( HV_41, HV_45 ) ;
   TCDSetPS (pMyPar, 1, 120, &HV_48, &HV_47, HV_46);
      rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY", 580, 580, &HV_49);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 120, &HV_48, &HV_47, HV_46);
   TCDSetPS (pMyPar, 1, 117, &HV_37, &HV_36, HV_1);
   TCDSetPS (pMyPar, 1, 115, &HV_51, &HV_50, HV_49);
      rc = TCD3FE1 (pMyPar, 4, "F_Years", 576, 576, &HV_52);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 115, &HV_51, &HV_50, HV_49);
   TCDSetPS (pMyPar, 0, 117, &HV_37, &HV_36, HV_49);
      if ( HV_0 != 0 ) goto l_44 ;
      TCD3FES (pMyPar, "e_TBeg_o", 9, 122, 6, 9, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_44: 
      if ( HV_24 != 0 ) goto l_47 ;
      TCD3FES (pMyPar, "e_YieldDate_o", 82, 459, 6, 82, &HV_25);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_24 = 1;
   l_47: 
      if ( HV_136 != 0 ) goto l_307 ;
   TCDSetPS (pMyPar, 1, 116, &HV_27, &HV_26, HV_25);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_28);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_27, &HV_26, HV_25);
      HV_136 = 1;
   l_307: 
      if ( HV_0 != 0 ) goto l_50 ;
      TCD3FES (pMyPar, "e_TBeg_o", 9, 122, 6, 9, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_50: 
      if ( HV_12 != 0 ) goto l_53 ;
      TCD3FES (pMyPar, "e_m_o", 6, 103, 6, 6, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_53: 
      if ( HV_134 != 0 ) goto l_349 ;
   TCDSetPS (pMyPar, 1, 91, &HV_15, &HV_14, HV_13);
      rc = TCD3FE1 (pMyPar, 4, "F_m", 366, 366, &HV_16);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 91, &HV_15, &HV_14, HV_13);
      HV_134 = 1;
   l_349: 
      if ( HV_135 != 0 ) goto l_346 ;
      HV_17 =   TCDRND ( HV_16, 0 ) ;
      HV_135 = 1;
   l_346: 
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
   TCDSetPS (pMyPar, 1, 119, &HV_19, &HV_18, HV_17);
      rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY_plus_i_t", 579, 579,
         &HV_53);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 119, &HV_19, &HV_18, HV_17);
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_17);
   TCDSetPS (pMyPar, 1, 116, &HV_55, &HV_54, HV_53);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_56);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_55, &HV_54, HV_53);
      HV_57 = TCDMIN ( HV_28, HV_56 ) ;
   TCDSetPS (pMyPar, 1, 120, &HV_59, &HV_58, HV_57);
      rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY", 580, 580, &HV_60);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 120, &HV_59, &HV_58, HV_57);
   TCDSetPS (pMyPar, 1, 117, &HV_37, &HV_36, HV_1);
   TCDSetPS (pMyPar, 1, 115, &HV_62, &HV_61, HV_60);
      rc = TCD3FE1 (pMyPar, 4, "F_Years", 576, 576, &HV_63);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 115, &HV_62, &HV_61, HV_60);
   TCDSetPS (pMyPar, 0, 117, &HV_37, &HV_36, HV_60);
      HV_64 = TCDINT ( HV_63 ) ;
      HV_65 = HV_52 - HV_64;
      HV_66 = HV_65 - 0.00274;
      if ( HV_66 >= 0 ) goto l_369 ;
      goto l_591 ;
   l_369: 
      if ( HV_0 != 0 ) goto l_56 ;
      TCD3FES (pMyPar, "e_TBeg_o", 9, 122, 6, 9, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_56: 
      if ( HV_0 != 0 ) goto l_59 ;
      TCD3FES (pMyPar, "e_TBeg_o", 9, 122, 6, 9, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_59: 
      if ( HV_4 != 0 ) goto l_62 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_62: 
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
   TCDSetPS (pMyPar, 1, 119, &HV_7, &HV_6, HV_5);
      rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY_plus_i_t", 579, 579,
         &HV_69);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 119, &HV_7, &HV_6, HV_5);
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_5);
   TCDSetPS (pMyPar, 1, 116, &HV_71, &HV_70, HV_69);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_72);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_71, &HV_70, HV_69);
      if ( HV_0 != 0 ) goto l_65 ;
      TCD3FES (pMyPar, "e_TBeg_o", 9, 122, 6, 9, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_65: 
      if ( HV_12 != 0 ) goto l_68 ;
      TCD3FES (pMyPar, "e_m_o", 6, 103, 6, 6, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_68: 
      if ( HV_134 != 0 ) goto l_484 ;
   TCDSetPS (pMyPar, 1, 91, &HV_15, &HV_14, HV_13);
      rc = TCD3FE1 (pMyPar, 4, "F_m", 366, 366, &HV_16);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 91, &HV_15, &HV_14, HV_13);
      HV_134 = 1;
   l_484: 
      if ( HV_135 != 0 ) goto l_481 ;
      HV_17 =   TCDRND ( HV_16, 0 ) ;
      HV_135 = 1;
   l_481: 
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
   TCDSetPS (pMyPar, 1, 119, &HV_19, &HV_18, HV_17);
      rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY_plus_i_t", 579, 579,
         &HV_73);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 119, &HV_19, &HV_18, HV_17);
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_17);
   TCDSetPS (pMyPar, 1, 116, &HV_75, &HV_74, HV_73);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_76);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_75, &HV_74, HV_73);
      HV_77 = TCDMIN ( HV_72, HV_76 ) ;
   TCDSetPS (pMyPar, 1, 120, &HV_79, &HV_78, HV_77);
      rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY", 580, 580, &HV_80);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 120, &HV_79, &HV_78, HV_77);
   TCDSetPS (pMyPar, 1, 117, &HV_37, &HV_36, HV_1);
   TCDSetPS (pMyPar, 1, 115, &HV_82, &HV_81, HV_80);
      rc = TCD3FE1 (pMyPar, 4, "F_Years", 576, 576, &HV_83);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 115, &HV_82, &HV_81, HV_80);
   TCDSetPS (pMyPar, 0, 117, &HV_37, &HV_36, HV_80);
      if ( HV_0 != 0 ) goto l_71 ;
      TCD3FES (pMyPar, "e_TBeg_o", 9, 122, 6, 9, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_71: 
      if ( HV_24 != 0 ) goto l_74 ;
      TCD3FES (pMyPar, "e_YieldDate_o", 82, 459, 6, 82, &HV_25);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_24 = 1;
   l_74: 
      if ( HV_136 != 0 ) goto l_532 ;
   TCDSetPS (pMyPar, 1, 116, &HV_27, &HV_26, HV_25);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_28);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_27, &HV_26, HV_25);
      HV_136 = 1;
   l_532: 
      if ( HV_0 != 0 ) goto l_77 ;
      TCD3FES (pMyPar, "e_TBeg_o", 9, 122, 6, 9, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_77: 
      if ( HV_12 != 0 ) goto l_80 ;
      TCD3FES (pMyPar, "e_m_o", 6, 103, 6, 6, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_80: 
      if ( HV_134 != 0 ) goto l_574 ;
   TCDSetPS (pMyPar, 1, 91, &HV_15, &HV_14, HV_13);
      rc = TCD3FE1 (pMyPar, 4, "F_m", 366, 366, &HV_16);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 91, &HV_15, &HV_14, HV_13);
      HV_134 = 1;
   l_574: 
      if ( HV_135 != 0 ) goto l_571 ;
      HV_17 =   TCDRND ( HV_16, 0 ) ;
      HV_135 = 1;
   l_571: 
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
   TCDSetPS (pMyPar, 1, 119, &HV_19, &HV_18, HV_17);
      rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY_plus_i_t", 579, 579,
         &HV_84);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 119, &HV_19, &HV_18, HV_17);
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_17);
   TCDSetPS (pMyPar, 1, 116, &HV_86, &HV_85, HV_84);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_87);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_86, &HV_85, HV_84);
      HV_88 = TCDMIN ( HV_28, HV_87 ) ;
   TCDSetPS (pMyPar, 1, 120, &HV_90, &HV_89, HV_88);
      rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY", 580, 580, &HV_91);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 120, &HV_90, &HV_89, HV_88);
   TCDSetPS (pMyPar, 1, 117, &HV_37, &HV_36, HV_1);
   TCDSetPS (pMyPar, 1, 115, &HV_93, &HV_92, HV_91);
      rc = TCD3FE1 (pMyPar, 4, "F_Years", 576, 576, &HV_94);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 115, &HV_93, &HV_92, HV_91);
   TCDSetPS (pMyPar, 0, 117, &HV_37, &HV_36, HV_91);
      HV_95 = TCDINT ( HV_94 ) ;
      HV_96 = HV_83 - HV_95;
      HV_97 = HV_96 - 0.00274;
      HV_98 = TCDINT ( HV_97 ) ;
      if ( HV_67 != 0 ) goto l_83 ;
      rc = TCD3FE1 (pMyPar, 2, "F_GrossPrem_wo_SD_o", 724, 724,
         &HV_68);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_67 = 1;
   l_83: 
      HV_99 = HV_68 * HV_98;
      if ( HV_34 != 0 ) goto l_86 ;
      TCD3FES (pMyPar, "e_SumOfPremiums_o", 68, 442, 6, 68, &HV_35);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_34 = 1;
   l_86: 
      HV_100 = HV_35 + HV_99;
      HV_33 = HV_100;
      goto l_3 ;
   l_591: 
      if ( HV_0 != 0 ) goto l_89 ;
      TCD3FES (pMyPar, "e_TBeg_o", 9, 122, 6, 9, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_89: 
      if ( HV_0 != 0 ) goto l_92 ;
      TCD3FES (pMyPar, "e_TBeg_o", 9, 122, 6, 9, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_92: 
      if ( HV_4 != 0 ) goto l_95 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_95: 
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
   TCDSetPS (pMyPar, 1, 119, &HV_7, &HV_6, HV_5);
      rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY_plus_i_t", 579, 579,
         &HV_101);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 119, &HV_7, &HV_6, HV_5);
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_5);
   TCDSetPS (pMyPar, 1, 116, &HV_103, &HV_102, HV_101);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_104);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_103, &HV_102, HV_101);
      if ( HV_0 != 0 ) goto l_98 ;
      TCD3FES (pMyPar, "e_TBeg_o", 9, 122, 6, 9, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_98: 
      if ( HV_12 != 0 ) goto l_101 ;
      TCD3FES (pMyPar, "e_m_o", 6, 103, 6, 6, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_101: 
      if ( HV_134 != 0 ) goto l_709 ;
   TCDSetPS (pMyPar, 1, 91, &HV_15, &HV_14, HV_13);
      rc = TCD3FE1 (pMyPar, 4, "F_m", 366, 366, &HV_16);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 91, &HV_15, &HV_14, HV_13);
      HV_134 = 1;
   l_709: 
      if ( HV_135 != 0 ) goto l_706 ;
      HV_17 =   TCDRND ( HV_16, 0 ) ;
      HV_135 = 1;
   l_706: 
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
   TCDSetPS (pMyPar, 1, 119, &HV_19, &HV_18, HV_17);
      rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY_plus_i_t", 579, 579,
         &HV_105);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 119, &HV_19, &HV_18, HV_17);
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_17);
   TCDSetPS (pMyPar, 1, 116, &HV_107, &HV_106, HV_105);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_108);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_107, &HV_106, HV_105);
      HV_109 = TCDMIN ( HV_104, HV_108 ) ;
   TCDSetPS (pMyPar, 1, 120, &HV_111, &HV_110, HV_109);
      rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY", 580, 580, &HV_112);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 120, &HV_111, &HV_110, HV_109);
   TCDSetPS (pMyPar, 1, 117, &HV_37, &HV_36, HV_1);
   TCDSetPS (pMyPar, 1, 115, &HV_114, &HV_113, HV_112);
      rc = TCD3FE1 (pMyPar, 4, "F_Years", 576, 576, &HV_115);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 115, &HV_114, &HV_113, HV_112);
   TCDSetPS (pMyPar, 0, 117, &HV_37, &HV_36, HV_112);
      if ( HV_0 != 0 ) goto l_104 ;
      TCD3FES (pMyPar, "e_TBeg_o", 9, 122, 6, 9, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_104: 
      if ( HV_24 != 0 ) goto l_107 ;
      TCD3FES (pMyPar, "e_YieldDate_o", 82, 459, 6, 82, &HV_25);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_24 = 1;
   l_107: 
      if ( HV_136 != 0 ) goto l_757 ;
   TCDSetPS (pMyPar, 1, 116, &HV_27, &HV_26, HV_25);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_28);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_27, &HV_26, HV_25);
      HV_136 = 1;
   l_757: 
      if ( HV_0 != 0 ) goto l_110 ;
      TCD3FES (pMyPar, "e_TBeg_o", 9, 122, 6, 9, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_110: 
      if ( HV_12 != 0 ) goto l_113 ;
      TCD3FES (pMyPar, "e_m_o", 6, 103, 6, 6, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_113: 
      if ( HV_134 != 0 ) goto l_799 ;
   TCDSetPS (pMyPar, 1, 91, &HV_15, &HV_14, HV_13);
      rc = TCD3FE1 (pMyPar, 4, "F_m", 366, 366, &HV_16);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 91, &HV_15, &HV_14, HV_13);
      HV_134 = 1;
   l_799: 
      if ( HV_135 != 0 ) goto l_796 ;
      HV_17 =   TCDRND ( HV_16, 0 ) ;
      HV_135 = 1;
   l_796: 
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
   TCDSetPS (pMyPar, 1, 119, &HV_19, &HV_18, HV_17);
      rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY_plus_i_t", 579, 579,
         &HV_116);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 119, &HV_19, &HV_18, HV_17);
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_17);
   TCDSetPS (pMyPar, 1, 116, &HV_118, &HV_117, HV_116);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_119);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_118, &HV_117, HV_116);
      HV_120 = TCDMIN ( HV_28, HV_119 ) ;
   TCDSetPS (pMyPar, 1, 120, &HV_122, &HV_121, HV_120);
      rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY", 580, 580, &HV_123);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 120, &HV_122, &HV_121, HV_120);
   TCDSetPS (pMyPar, 1, 117, &HV_37, &HV_36, HV_1);
   TCDSetPS (pMyPar, 1, 115, &HV_125, &HV_124, HV_123);
      rc = TCD3FE1 (pMyPar, 4, "F_Years", 576, 576, &HV_126);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 115, &HV_125, &HV_124, HV_123);
   TCDSetPS (pMyPar, 0, 117, &HV_37, &HV_36, HV_123);
      HV_127 = TCDINT ( HV_126 ) ;
      HV_128 = HV_115 - HV_127;
      HV_129 = HV_128 - 0.00274;
      HV_130 = HV_129 - 1;
      HV_131 = TCDINT ( HV_130 ) ;
      if ( HV_67 != 0 ) goto l_116 ;
      rc = TCD3FE1 (pMyPar, 2, "F_GrossPrem_wo_SD_o", 724, 724,
         &HV_68);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_67 = 1;
   l_116: 
      HV_132 = HV_68 * HV_131;
      if ( HV_34 != 0 ) goto l_119 ;
      TCD3FES (pMyPar, "e_SumOfPremiums_o", 68, 442, 6, 68, &HV_35);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_34 = 1;
   l_119: 
      HV_133 = HV_35 + HV_132;
      HV_33 = HV_133;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_33);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT735","End F_SumsOfPrem_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_SumsOfPrem_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_SumsOfPrem_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_SumsOfPrem_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT736
   Beschreibung: Die Funktion berechnet die Formel 
                 F_SumOfPremPortfolio
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT736 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_27 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_DOUBLE  HV_29 = 0;
      TCD_DOUBLE  HV_30 = 0;
      TCD_DOUBLE  HV_32 = 0;
      TCD_DOUBLE  HV_33 = 0;
      TCD_DOUBLE  HV_34 = 0;
      TCD_DOUBLE  HV_36 = 0;
      TCD_DOUBLE  HV_37 = 0;
      TCD_DOUBLE  HV_39 = 0;
      TCD_DOUBLE  HV_40 = 0;
      TCD_DOUBLE  HV_41 = 0;
      TCD_DOUBLE  HV_42 = 0;
      TCD_DOUBLE  HV_43 = 0;
      TCD_DOUBLE  HV_44 = 0;
      TCD_DOUBLE  HV_45 = 0;
      TCD_DOUBLE  HV_46 = 0;
      TCD_DOUBLE  HV_47 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_14 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_21 = 0;
      TCD_INT     HV_24 = 0;
      TCD_INT     HV_26 = 0;
      TCD_INT     HV_31 = 0;
      TCD_INT     HV_35 = 0;
      TCD_INT     HV_38 = 0;
      TCD_INT     HV_48 = 0;
      TCD_INT     HV_49 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT736","Begin F_SumOfPremPortfolio",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,736,"12.12.2019 17:29:32",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT736",
              "Ende F_SumOfPremPortfolio",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_3 = 0;
      HV_8 = 0;
      HV_12 = 0;
      HV_24 = 0;
      HV_26 = 0;
      HV_31 = 0;
      HV_35 = 0;
      HV_38 = 0;
      HV_48 = 0;
      HV_49 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "e_manualSumsOfPrem", 70, 444, 6, 70, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 != 0 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      if ( HV_0 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "e_manualSumsOfPrem", 70, 444, 6, 70, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_8: 
      HV_2 = HV_1;
      goto l_3 ;
   l_24: 
      if ( HV_3 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "e_CalcDate", 29, 351, 6, 29, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_11: 
   TCDSetPS (pMyPar, 1, 116, &HV_6, &HV_5, HV_4);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_7);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_6, &HV_5, HV_4);
      if ( HV_8 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "e_TBeg_n", 2, 19, 6, 2, &HV_9);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_8 = 1;
   l_14: 
      if ( HV_12 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "e_m_n", 1, 8, 6, 1, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_17: 
   TCDSetPS (pMyPar, 1, 91, &HV_15, &HV_14, HV_13);
      rc = TCD3FE1 (pMyPar, 4, "F_m", 366, 366, &HV_16);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 91, &HV_15, &HV_14, HV_13);
      HV_17 =   TCDRND ( HV_16, 0 ) ;
   TCDSetPS (pMyPar, 1, 116, &HV_11, &HV_10, HV_9);
   TCDSetPS (pMyPar, 1, 119, &HV_19, &HV_18, HV_17);
      rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY_plus_i_t", 579, 579,
         &HV_20);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 119, &HV_19, &HV_18, HV_17);
   TCDSetPS (pMyPar, 0, 116, &HV_11, &HV_10, HV_17);
   TCDSetPS (pMyPar, 1, 116, &HV_22, &HV_21, HV_20);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_23);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_22, &HV_21, HV_20);
      if ( HV_7 >= HV_23 ) goto l_87 ;
      goto l_99 ;
   l_87: 
      if ( HV_24 != 0 ) goto l_20 ;
      rc = TCD3FE1 (pMyPar, 2, "F_SumsOfPrem_o", 735, 735, &HV_25);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_24 = 1;
   l_20: 
      if ( HV_26 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "e_AddContrib_n", 31, 359, 6, 31, &HV_27);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_26 = 1;
   l_23: 
      HV_28 = HV_25 + HV_27;
      HV_2 = HV_28;
      goto l_3 ;
   l_99: 
      if ( HV_3 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "e_CalcDate", 29, 351, 6, 29, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_26: 
   TCDSetPS (pMyPar, 1, 116, &HV_6, &HV_5, HV_4);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_29);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_6, &HV_5, HV_4);
      if ( HV_8 != 0 ) goto l_29 ;
      TCD3FES (pMyPar, "e_TBeg_n", 2, 19, 6, 2, &HV_9);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_8 = 1;
   l_29: 
   TCDSetPS (pMyPar, 1, 116, &HV_11, &HV_10, HV_9);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_30);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_11, &HV_10, HV_9);
      if ( HV_29 == HV_30 ) goto l_129 ;
      goto l_147 ;
   l_129: 
      if ( HV_24 != 0 ) goto l_32 ;
      rc = TCD3FE1 (pMyPar, 2, "F_SumsOfPrem_o", 735, 735, &HV_25);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_24 = 1;
   l_32: 
      if ( HV_31 != 0 ) goto l_35 ;
      rc = TCD3FE1 (pMyPar, 2, "F_GrossPrem_wo_SD_n", 721, 721,
         &HV_32);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_31 = 1;
   l_35: 
      HV_33 = HV_25 + HV_32;
      if ( HV_26 != 0 ) goto l_38 ;
      TCD3FES (pMyPar, "e_AddContrib_n", 31, 359, 6, 31, &HV_27);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_26 = 1;
   l_38: 
      HV_34 = HV_33 + HV_27;
      HV_2 = HV_34;
      goto l_3 ;
   l_147: 
      if ( HV_24 != 0 ) goto l_41 ;
      rc = TCD3FE1 (pMyPar, 2, "F_SumsOfPrem_o", 735, 735, &HV_25);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_24 = 1;
   l_41: 
      if ( HV_35 != 0 ) goto l_44 ;
      rc = TCD3FE1 (pMyPar, 2, "F_GrossPrem_wo_SD_o", 724, 724,
         &HV_36);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_35 = 1;
   l_44: 
      HV_37 = HV_25 - HV_36;
      if ( HV_48 != 0 ) goto l_187 ;
      if ( HV_38 != 0 ) goto l_47 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_39);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_38 = 1;
   l_47: 
      HV_40 = TCDINT ( HV_39 ) ;
      HV_48 = 1;
   l_187: 
      if ( HV_49 != 0 ) goto l_181 ;
      if ( HV_38 != 0 ) goto l_50 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_39);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_38 = 1;
   l_50: 
      HV_41 = HV_39 - HV_40;
      HV_49 = 1;
   l_181: 
      HV_42 = 1 - HV_41;
      if ( HV_31 != 0 ) goto l_53 ;
      rc = TCD3FE1 (pMyPar, 2, "F_GrossPrem_wo_SD_n", 721, 721,
         &HV_32);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_31 = 1;
   l_53: 
      HV_43 = HV_32 * HV_42;
      HV_44 = HV_37 + HV_43;
      if ( HV_48 != 0 ) goto l_205 ;
      if ( HV_38 != 0 ) goto l_56 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_39);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_38 = 1;
   l_56: 
      HV_40 = TCDINT ( HV_39 ) ;
      HV_48 = 1;
   l_205: 
      if ( HV_49 != 0 ) goto l_199 ;
      if ( HV_38 != 0 ) goto l_59 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_39);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_38 = 1;
   l_59: 
      HV_41 = HV_39 - HV_40;
      HV_49 = 1;
   l_199: 
      if ( HV_35 != 0 ) goto l_62 ;
      rc = TCD3FE1 (pMyPar, 2, "F_GrossPrem_wo_SD_o", 724, 724,
         &HV_36);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_35 = 1;
   l_62: 
      HV_45 = HV_36 * HV_41;
      HV_46 = HV_44 + HV_45;
      if ( HV_26 != 0 ) goto l_65 ;
      TCD3FES (pMyPar, "e_AddContrib_n", 31, 359, 6, 31, &HV_27);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_26 = 1;
   l_65: 
      HV_47 = HV_46 + HV_27;
      HV_2 = HV_47;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT736","End F_SumOfPremPortfolio",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_SumOfPremPortfolio", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_SumOfPremPortfolio", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_SumOfPremPortfolio");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT769
   Beschreibung: Die Funktion berechnet die Formel 
                 F_IsLiquidAnnuity
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT769 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT769","Begin F_IsLiquidAnnuity",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,769,"12.12.2019 17:29:32",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT769",
              "Ende F_IsLiquidAnnuity",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT769","End F_IsLiquidAnnuity",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_IsLiquidAnnuity", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_IsLiquidAnnuity", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_IsLiquidAnnuity");
   }                                         
   return ;

   }
}

