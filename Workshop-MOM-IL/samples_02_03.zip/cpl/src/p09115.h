/*---------------------------------------------------------------------------

(C) Copyright 1993-2002, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------
    Datei       : P09115.H

    Beschreibung: ADT dynamische Vektoren
    von         : RWE
    Datum       : 26.07.95
    Historie    : MUB 11.04.96 ausgebaut
                  RWE 21.06.96 f�r Verwendung im Subsyst. angepa�t
                  EDU 07.11.96 tcdport.h includieren, sonst kennt er 
                  kein TCD_INT

    Status      : Modul
    Reviews     :

-----------------------------------------------------------------------
Die Schnittstelle f�r den Aufrufer bilden die Datentypen:

      S_VECT   normaler Vektor
      S_SVECT  sortierter Vektor

und die in diesem Include-File aufgef�hrten zugeh�rigen Methoden.

*--------------------------------------------------------------------*/
#if !defined(P09115_H)
#define P09115_H

/*-------------------------------------------------------------------*/
/* Includes                                                          */
/*-------------------------------------------------------------------*/
#include "c88.h"
#ifndef SUBSYSTEM

#include "tcdadt.h"

#else

#undef  ADT_EXPORT
#define ADT_EXPORT
#undef  PRECOND
#define PRECOND
#undef  TCD_INTL_ERR
#define TCD_INTL_ERR

#endif

#define  VectLen(pVect)        ( (pVect) ? (pVect)->iLenOccupied : 0 )

#define  GetVectElt(pVect, iIndex) \
        ( (iIndex >= (pVect)->iLen) ?  \
        GetVectEltInt ((pVect), iIndex)  : \
        (char *)(pVect)->pArray+(TCD_LONG)iIndex*(pVect)->iSizeOfData)

/* -------------------------------------------------------
Grundstruktur VECTOR
------------------------------------------------------- */
typedef    struct tagVECTOR
{
TCD_INT    iSizeOfData;   /* Gr��e eines Vektorelements */
TCD_INT    iLenOccupied;  /* Anzahl aktueller Elemente */
TCD_INT    iLen;          /* aktuelle Gesamtl�nge des Vektors */
TCD_INT    iDelta;        /* Schrittweite f�r Vergr��erung */

TCD_INT    ( *pCopyData)   (void * ,void *);/* Funktion zum Kopieren */
                                         /* eines Datenelements */
void       ( *pConstrData)(void *)        ; /* Konstruktor f�r ein */
                                         /* Datenelement */
void       ( *pDestrData) (void *)        ; /* Destruktor f�r ein */
                                         /* Datenelement */

void *     pArray;                       /* Zeigen auf die Nutzdaten*/

TCD_INT    ( *pCompareData)(const void *, const void *);
                                        /* Ist genau dann !=NULL, */
                                        /* falls das pArray der- */
                                        /* zeit sortiert ist. */
                                        /* pCompareData zeigt dann */
                                        /* auf die zuletzt benutzte */
                                        /* Vergleichsfunktion. */
}    S_VECT;

/* normaler Vektor---------------------------------------------------*/
/*-S_VECT-----------------------------------------------------------*/

typedef S_VECT * LP_VECT;


/* Konstruktoren (statisch & dynamisch): */

/* ------------------------------------------------------------------
  SConstrVect gibt 0 zurueck, wenn mehr als 64K Speicher belegt wuerden
   sonst 1
------------------------------------------------------------------  */
ADT_EXPORT TCD_INT     SConstrVect      (LP_VECT pVect,
                            TCD_INT iSizeOfData,
                            TCD_INT iStartLen,
                            TCD_INT iDelta,
                            TCD_INT ( * pCopyData)  (void *,void *),
                            void    ( * pConstrData)(void *)       ,
                            void    ( * pDestrData) (void *)      );

ADT_EXPORT LP_VECT     DConstrVect          (TCD_INT iSizeOfData,
                            TCD_INT iStartLen,
                            TCD_INT iDelta,
                            TCD_INT ( * pCopyData)  (void *,void *),
                            void    ( * pConstrData)(void *)       ,
                            void    ( * pDestrData) (void *)       );


/* 
F�r die Funktionspointer pCopyData pSConstrData pSDestrData 
k�nnen NULL-Pointer �bergeben werden. 
pCopyData wird in diesem Fall durch die Funktionen 'memcpy' realisiert.

pCopyData ist immer dann anzugeben, wenn die Daten, die kopiert werden
sollen, so aufgebaut sind, dass eine spezielle Kopierfunktion n�tig 
ist.

Ist der Zeiger auf den Datenkonstruktor==NULL, wird der Speicherbereich
f�r das jeweilige Datenelement reserviert und mit 0 initialisiert. 

Ist der Zeiger auf den Datendestruktor = NULL, wird der Speicherbereich
freigegeben, es findet aber keine weitere Bereinigung statt
*/

/* Destruktoren */
ADT_EXPORT S_VECT		SInitVect( int ElementSize );

ADT_EXPORT void        SDestrVect           (LP_VECT pVect );
ADT_EXPORT void        DDestrVect           (void ** ppVect );

/* Ausleeren des Vektors: */
ADT_EXPORT void        FlushVect            (LP_VECT pVect );

/* Wieviele Elemente sind im Vektor enthalten? */
/* TCD_INT     VectLen              (LP_VECT pVect);*/

/* Zugriff auf und Besetzen von Vektorkomponenten: */
ADT_EXPORT TCD_INT     AddVectElt  (LP_VECT pVect, void *pData);
ADT_EXPORT TCD_INT     SetVectElt  (LP_VECT pVect, TCD_INT iIndex, 
                                    void *pData);
ADT_EXPORT void *      GetVectEltInt  (LP_VECT pVect, TCD_INT iIndex);

/* 
Suche erstes Auftreten eines Elements �ber Bedingung: 
Zus�tzliche Argumente f�r die EltTestOk-Funktion werden wieder �ber
pArgs weitergereicht (s.a. Listenverwaltung). 
*/

ADT_EXPORT void *      FindFirstVectEl      (LP_VECT pVect,
                TCD_INT (* EltTestOk)(void * pEltToTest,void * pArgs),
                TCD_INT * pResultIndex,
                void *  pArgs);

/* Element(i) aus dem Vektor entfernen (pSDestrData wird aufgerufen,
die anderen Vektorelemente werden "nachger�ckt") 
 Ergebnis==success, dh. ob Elt gel�scht wurde. */

ADT_EXPORT TCD_INT     DelEltFromVectByIndex(LP_VECT pVect,
                                            TCD_INT iIndex);

/* Der Vektor wird um iDelta vergroessert*/
ADT_EXPORT TCD_INT     ResizeVect (LP_VECT pVect, TCD_INT iNumOfElts);

/* Diese Funktionen sind noch nicht implementiert
 Mehrere Elemente aus dem Vektor l�schen (mit O(Len)) 
        TCD_INT DelEltsFromVect(LP_VECT pVect, 
                TCD_INT (*EltIsToDel)(void *pEltToTest, void *pArgs),
                void   *pArgs ); 
 Ergebnis: Anzahl der gel�schten Elemente. */

/* Sortiere Vektor: */
ADT_EXPORT void    SortVect       (LP_VECT pVect,
          TCD_INT (* pCompareData)(const void * , const void *));

/* pCompareData(p1,p2) muss, analog zu strcmp, 
    folgende Werte zur�ckgeben: */
/* -1, falls "*p1 < *p2", */
/* 0,  falls "*p1 = *p2", */
/*  1, falls "*p1 > *p2". */

/* Suche mit Bisektion, falls Vektor sortiert wurde: */

ADT_EXPORT void     *  FindVectEltByBisec (LP_VECT pVect,
                                          void *  pEltToTest,
                                          TCD_INT * pResultIndex);

/* --------------------------------------------------------------
   Kopiert einen Vektor in einen anderen.
   pDst darf nicht NULL sein!
------------------------------------------------------------------*/
ADT_EXPORT TCD_INT     CopyVectToVect     (LP_VECT pDst,
                                          LP_VECT pSrc);

/* sortierter Vektor-------------------------------------------------*/
/* Im Gegensatz zu obigem Vektor, der sortiert werden kann, ist der 
SVECT  nach jedem Einf�gen sofort sortiert. */

typedef S_VECT      S_SVECT;
typedef S_SVECT   * LP_SVECT;

/* Konstruktoren (statisch & dynamisch): */
ADT_EXPORT TCD_INT     SConstrSVect          (LP_SVECT pSVect,
                 TCD_INT  iSizeOfData,
                 TCD_INT  iStartLen,
                 TCD_INT  iDelta,
                 TCD_INT  ( * pCopyData)   (void *,void *),
                 void     ( * pSConstrData)(void *)       ,
                 void     ( * pSDestrData) (void *)       ,
                 TCD_INT  ( * pCompareData)(const void *,const void *)
                );

/* (pCompareData darf nicht NULL sein) */
ADT_EXPORT LP_SVECT    DConstrSVect          (TCD_INT  iSizeOfData,
                 TCD_INT  iStartLen,
                 TCD_INT  iDelta,
                 TCD_INT  ( * pCopyData)   (void *,void *),
                 void     ( * pSConstrData)(void *)       ,
                 void     ( * pSDestrData) (void *)       ,
                 TCD_INT  ( * pCompareData)(const void *,const void *)
                );

/* Destruktoren */
ADT_EXPORT void        SDestrSVect           (LP_SVECT pSVect );
ADT_EXPORT void        DDestrSVect           (void ** ppSVect );

/* Ausleeren des Vektors: */
ADT_EXPORT void        FlushSVect            (LP_SVECT pSVect );

/* Wieviele Elemente sind im Vektor enthalten? */
ADT_EXPORT TCD_INT     SVectLen              (LP_SVECT pSVect);

/* Sortiererei kurzfristig aus/einschalten: */
/*      void      DisableSortingOfSVect( LP_SVECT pSVect ); */
/*      void      EnableSortingOfSVect ( LP_SVECT pSVect ); */

/* f�gt das Element (mithilfe von pCompareData) an der richtigen 
    Stelle ein, verschiebt ggf. die �brigen Daten. */
    
ADT_EXPORT TCD_INT     InsertSVectElt(LP_SVECT pSVect, void *pData);

/* Zugriff auf Vektorkomponente: */
ADT_EXPORT void *      GetSVectElt(LP_SVECT pSVect, TCD_INT iIndex);

/* Find-Funktion: */
ADT_EXPORT void *      FindSVectElt          (LP_SVECT pSVect,
                                             void *   pEltToTest,
                                             TCD_INT * pResultIndex);

/* Ein Element aus dem Vektor entfernen (pSDestrData wird aufgerufen,*/
/* die anderen Vektorelemente werden "nachger�ckt") */
/* Ergebnis==success, dh. ob Elt gel�scht wurde. */
ADT_EXPORT TCD_INT     DelEltFromSVect       (LP_SVECT pSVect,
                                              void   *pData);
ADT_EXPORT TCD_INT     DelEltFromSVectByIndex(LP_SVECT pSVect,
                                             TCD_INT  iIndex);

/* Mehrere Elemente aus dem Vektor l�schen (mit O(Len)) */
/* ------------------------------------------------------------------
ADT_EXPORT TCD_INT  DelEltsFromSVect(LP_SVECT pSVect,
                                TCD_INT (*EltIsToDel)(void *pEltToTest,
                                 void *pArgs),
                                void *   pArgs );
------------------------------------------------------------------  */

/* Neue Sortierung: */
/* Der Vektor wird umsortiert und erh�lt das neue Sortierkriterium */
/* zugewiesen. */
ADT_EXPORT void        ResortSVect (LP_SVECT pSVect,
               TCD_INT  (* pCompareData)(const void *,const void *));

#endif



