/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_PKF_H)
#define TCD_PKF_H
/*---------------------------------------------------------------------
    Modul:        C:\dev\TCD_DB\template\db\R3FE\C\C3E9\lifet345.h

    Beschreibung: Funktionsprototypen der externen Funktionen der
                  Formelsammlungsdatei
    By:           BEGGI
    Generiert am: 16.12.2019 15:07:19
---------------------------------------------------------------------*/
   
      void LifeT178 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT179 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT180 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT181 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT182 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT183 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT184 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT185 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT186 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT187 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT188 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT189 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT190 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT191 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT192 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT193 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT194 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT195 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT196 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT197 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT198 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT199 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT200 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT201 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT202 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT203 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT204 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT205 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT206 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT207 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT208 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT209 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT210 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT211 (P_TCD_C_F1 pMyPar) ;
   

#endif
