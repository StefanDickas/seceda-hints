/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_PKF_H)
#define TCD_PKF_H
/*---------------------------------------------------------------------
    Modul:        C:\dev\TCD_DB\template\db\R3FE\C\C3E9\lifet425.h

    Beschreibung: Funktionsprototypen der externen Funktionen der
                  Formelsammlungsdatei
    By:           BEGGI
    Generiert am: 16.12.2019 15:07:19
---------------------------------------------------------------------*/
   
      void LifeT212 (P_TCD_C_F1 pMyPar) ;
   

#endif
