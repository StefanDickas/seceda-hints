/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_PKF_H)
#define TCD_PKF_H
/*---------------------------------------------------------------------
    Modul:        C:\dev\TCD_DB\template\db\R3FE\C\C3E9\lifet190.h

    Beschreibung: Funktionsprototypen der externen Funktionen der
                  Formelsammlungsdatei
    By:           BEGGI
    Generiert am: 16.12.2019 15:07:19
---------------------------------------------------------------------*/
   
      void LifeT111 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT112 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT113 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT114 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT115 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT116 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT117 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT118 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT119 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT120 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT121 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT122 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT123 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT124 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT125 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT126 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT127 (P_TCD_C_F1 pMyPar) ;
   

#endif
