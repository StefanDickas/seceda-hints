/*---------------------------------------------------------------------------

(C) Copyright 1993-2002, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------------*/
/* 
Modul:   P09201.C
  
Beschreibung: Methoden zu den Paarlisten relevante Attribute
und Ergebnisse hierzu
History:
19.04.96 MUB: angelegt
21.06.96 RWE: _TCDALLOC eingebaut (f. Verwendung im Subsyst.)
23.06.96 RWE: pErgebnisPool kann auch leere Vektorelemente beinhalten
Neue Auskunftsfunktionen:
    ErgPoolAnzErgs, ErgPoolAnzProcs
24.06.96 RWE: ReleaseGlobalErgebnis loescht fuer ProcID==0 den ganzen
ErgebnisPool
26.06.96 RWE: In DestrErgPoolElt ca. 3 Fehler ausgebaut
01.07.96 MUB: bei relevanten Attributen werden jetzt nur noch die 
Tab-ID's gemerkt
Unterscheidung zwischen TCD-Tabellen und externen Tabellen noch nicht
komplett
02.07.96 MUB: Umstellung wg. Herausnahme von LOCDATA :
Beschaffung von geerbten Werten umsgestellt.
Zugriff auf Knoten und relevante Attribute jetzt direkt auf die 
entsprechendenTeilstrukuten der globalen Datenstruktur pTCDTCD
9.7.96   MUB: PaarListEltToProtect() prueft jetzt auf NULL-Zeiger.
22.7.96  MUB: Wiederverwendungslistenlaenge darf jetzt auch 0 sein!
21.8.96  MUB: CopyErgPoolElt nochmals ueberarbeitet.
21.8.96  MUB  FetchFromGlobalErgebnisPool() hat jetzt einen Parameter 
weniger und gibt das Ergebnis direktzurueck (als void *)!
28.8.96  MUB  ComparePaarlistenElt ueberarbeitet:
haben 2 betrachtete relevante Attribute in 'bNotOverwritten' jeweils 
-1, wird der Wert nicht mehr betrachtet.
*/

#include <stdio.h>
#ifndef SUBSYSTEM
#include <malloc.h>
#endif
#include <memory.h>
#include <string.h>
#include <stdarg.h>

#include "c88.h"           /* "tcdport.h"   Portability File */
#include "c90.h"           /* "tcdc.h"      Tcd-Konstanten   */
#include "c89.h"           /* "tcddat.h"                     */

#include "p09201.h"

#ifndef SUBSYSTEM

#undef _TCDALLOC
#undef _TCDFREE
#define _TCDALLOC(len,size)    malloc( (size_t)((len) * (size))) ;
#define _TCDFREE(ptr)          {free(ptr), ptr = NULL;}

#endif

/* --Prototypen der internen Funktionen-- */

P_PAARLISTE         DConstrAttrsResults    (TCD_INT,TCD_INT);
P_ERGEBNIS_POOL_ELT InitErgPoolElt         () ;

LP_VECT             DConstrAttrs           (TCD_INT);
LP_VECT             DConstrErgPool         (TCD_INT);

void                ConstrPaarListenElt    (void *);
void                DestrErgPoolElt        (void *);
void                DestrPaarListenElt     (void *);
void                ConstrAttrElt          (void *);
void                DestrAttrElt           (void *);

TCD_INT             CopyErgPoolElt         (void *,void *);
TCD_INT             GetIndexToGlobalErgPool(LP_VECT);
TCD_INT             CopyPaarListenElt      (void *, void *);
TCD_INT             GetRelAttrs            (P_TCD_C_G,P_TCDPRCNODE,
                                            P_PAARLISTE);
TCD_INT             InsertRelAttr          (P_PAARLISTE,P_TCDRELATTR,
                                            TCD_INT);
TCD_INT             SetRelAttr             (LP_VECT,P_TCDRELATTR,
                                            TCD_INT );
TCD_INT             ComparePaarListenElt   (void *,void *);
TCD_INT             CopyAttrElt            (void *,void *);
TCD_INT             GetIndexToPaarListElt  (P_TCD_C_G, P_PAARLISTE);
/* 
   P_PAARLISTE DConstrAttrsResults
   Die Funktion legt Speicher fuer P_PAARLISTE an.

   Direkter Vektor P_PAARLISTE.pAttrs     wird angelegt
   Liste           P_PAARLISTE.pPaarListe wird angelegt
  */
P_PAARLISTE DConstrAttrsResults ( TCD_INT   iWiederVerwendungsTyp  ,
                                  TCD_INT   iWiederVerwListenLaenge)

{
   P_PAARLISTE pPaarListe;

   /* 
      Falls mal durch einen Fehler in der statischen Analyse oder 
      sonstwo die WiederVerwListenLaenge < 1 ist, wird trotzdem 
      konstruiert ...
      MUB  22.7.96: WiederVerwListenLaenge darf jetzt auch 0 sein.
     */
   if ( iWiederVerwListenLaenge == 0 )
        return NULL;

   pPaarListe = (P_PAARLISTE) _TCDALLOC(1,sizeof(S_PAARLISTE));

   if ( pPaarListe )
   {
      pPaarListe->iWiederVerwendungsTyp   = iWiederVerwendungsTyp;
      pPaarListe->iWiederVerwListenLaenge = iWiederVerwListenLaenge;

      pPaarListe->pAttrs                  = NULL;
      pPaarListe->iAct                    = 0;

      /* --Die Liste der Attribute/Ergebnisse-- */
      pPaarListe->pPaarListenElts =
             DConstrVect((TCD_INT)sizeof(S_PAARLISTEN_EL),
                         (TCD_INT)iWiederVerwListenLaenge,
                         (TCD_INT)1,
                         CopyPaarListenElt,ConstrPaarListenElt,
                         DestrPaarListenElt);

      if ( !pPaarListe->pPaarListenElts )
         return NULL;

      return pPaarListe ;
   }
   return NULL;
}

/* 
   LP_VECT DConstrAttrs
   Konstruktur fuer die Liste der Relevanten Attribute
  */
LP_VECT DConstrAttrs ( TCD_INT iAnz )
{
    return (LP_VECT)
       DConstrVect((TCD_INT)sizeof(S_TCDRELATTR),iAnz,1,CopyAttrElt,
                    ConstrAttrElt,DestrAttrElt);
}

/* 
   TCD_INT SetRelAttr
   Einfuegen von VektorElementen des Typs S_TCDRELATTR in den 
   Vektor pAttrs
  */
TCD_INT SetRelAttr                  ( LP_VECT         pAttrs       ,
                                      P_TCDRELATTR    pAttr         ,
                                      TCD_INT         iIndex        )
{
   return ( SetVectElt (pAttrs,iIndex,(void *) pAttr) );
}

/* 
   GetRelAttrs:
   Liest die relevanten Attribute aus dem beruehmten Array ein
  */
TCD_INT       GetRelAttrs(P_TCD_C_G    pTCDTCD,
                          P_TCDPRCNODE pNode , 
                          P_PAARLISTE  pPaarListe )
{
   P_TCDRELATTR_IMP    pRelAttrImp   = 
                       &pTCDTCD->pRelAttrs[pNode->iFirstRelAttrIx];
   S_TCDRELATTR        RelAttr    ;
   TCD_INT             i;

   for ( i=0; i < pNode->iAnzRelAttrs; i++ )
   {
      memset((void *)&RelAttr,0,sizeof(S_TCDRELATTR));

      RelAttr.iBerechnungsNummer = pTCDTCD->iBerechnungsNummer;
      RelAttr.AttrID             = pRelAttrImp->AttrID;
      RelAttr.AttrType           = pRelAttrImp->AttrType;

      if ( pRelAttrImp->iIndex >= 0 )
      {
         if(!(GetValueFromNode(pTCDTCD,&RelAttr,pRelAttrImp->iIndex)))
            return 0;
      }

      if (!(InsertRelAttr(pPaarListe,(P_TCDRELATTR)&RelAttr,i)))

           return 0;
      else pRelAttrImp++;
   }
   return 1;
}

/* 
   TCD_INT GetValueFromNode:
   Holt den geerbten Wert vom Knoten
  */
TCD_INT GetValueFromNode( P_TCD_C_G pTCDTCD, 
                          P_TCDRELATTR pRelAttr,
                          TCD_INT iIndex)
{
   P_TCDPRCNODE pNode = &pTCDTCD->pPrcTreeNode[iIndex].Node;

   if ( pNode )
   {
      pRelAttr->bGeerbterWertVorhanden = 1;
      pRelAttr->AttrType               = pNode->AttrType;

      switch ( pNode->AttrType )
      {
        case TCD_ATTRFMT_SKAL :
        pRelAttr->Belegung.Skalar = pNode->AssignVal.Val.Skalar;
        break;

        case TCD_ATTRFMT_TAB1 :
        case TCD_ATTRFMT_TAB2 :

        pRelAttr->Belegung.TabID=pNode->AssignVal.Val.TabData.TabID;
        break;

        case TCD_ATTRFMT_VGLO :
        strcpy(pRelAttr->Belegung.VglOp,pNode->AssignVal.Val.Datum);
        break;

        case TCD_ATTRFMT_DATE :
        strcpy(pRelAttr->Belegung.VglOp,pNode->AssignVal.Val.VglOp);
        break;

        default               :
        pRelAttr->bGeerbterWertVorhanden = 0;
        break;
      }
      return 1;
   }
   return 0;
}

/* 
   InsertRelAttr :
   Schreibt ein relevantes Attribut in den Vektor
  */
TCD_INT       InsertRelAttr      (P_PAARLISTE  pPaarListe , 
                                  P_TCDRELATTR pRelAttr , 
                                  TCD_INT iIndex )
{
   return SetRelAttr (pPaarListe->pAttrs , pRelAttr , iIndex );
}


/* 
   void * GetRelAttr
   Abholen von VektorElementen des Typs S_TCDRELATTR aus 
   dem Vektor pAttrs
  */
void * GetRelAttr                   (LP_VECT pAttrs,
                                     TCD_INT iIndex                )
{
   return ( GetVectElt (pAttrs,iIndex) );
}

/* 
   void ConstrAttrElt :
   Erzeugt ein leeres AttribElement
  */
void ConstrAttrElt          ( void * p )
{
   P_TCDRELATTR pAttrElt = ( P_TCDRELATTR) p;
   memset((void *)pAttrElt,0,sizeof(S_TCDRELATTR));
}

/* 
   TCD_INT CopyAttrElt :
   Kopiert ein neues relevantes Attribut in den Vektor pAttrs
  */
TCD_INT      CopyAttrElt ( void * p1, void * p2 )
{
   P_TCDRELATTR pDst     = (P_TCDRELATTR)p1;
   P_TCDRELATTR pSrc     = (P_TCDRELATTR)p2;

   /* 
      Auf jeden Fall Destruktor fuer Zielstruktur aufrufen. War dieses
      Element schon mal belegt, wurde u.U. Speicher allociert, der
      freigegeben werden muss.
     */
   DestrAttrElt(p1);
   pDst->iBerechnungsNummer     = pSrc->iBerechnungsNummer;
   pDst->AttrID                 = pSrc->AttrID;
   pDst->AttrType               = pSrc->AttrType;
   pDst->bGeerbterWertVorhanden = pSrc->bGeerbterWertVorhanden;
   pDst->bNotOverwritten        = pSrc->bNotOverwritten;

   switch ( pSrc->AttrType )
   {
      case TCD_ATTRFMT_TAB1 :
      case TCD_ATTRFMT_TAB2 :

         pDst->Belegung.TabID = pSrc->Belegung.TabID;
         break;

      case TCD_ATTRFMT_SKAL:
         pDst->Belegung.Skalar = pSrc->Belegung.Skalar;
         break;

      case TCD_ATTRFMT_DATE :
         strcpy(pDst->Belegung.Datum,pSrc->Belegung.Datum);
         break;

      case TCD_ATTRFMT_VGLO :
         strcpy(pDst->Belegung.VglOp,pSrc->Belegung.VglOp);
         break;

   }
   return 1;
}

/* 
   void DestrAttrElt:
   Zerstoert ein Element des Vektor pAttrs (relevantes Attribut)
  */
void     DestrAttrElt    ( void * p )
{
   P_TCDRELATTR pRelAttr = (P_TCDRELATTR) p;

   switch ( pRelAttr->AttrType )
   {
      case TCD_ATTRFMT_SKAL :
         break;

      case TCD_ATTRFMT_TAB1 :
      case TCD_ATTRFMT_TAB2 :
         break;
   }
   pRelAttr->bGeerbterWertVorhanden = 0;
   pRelAttr->AttrType               = 0;
   pRelAttr->bNotOverwritten        = 0;
   memset((void *)&pRelAttr->Belegung,0,sizeof(U_TCDWVALUE));
}

/* 
   TCD_INT InsertPaarListElt
   Erzeugen eines neuen Elements der PaarListe
  */
TCD_INT InsertPaarListElt           (P_TCD_C_G        pTCDTCD ,
                                     P_PAARLISTE      pPaarListe,
                                     P_PAARLISTEN_EL  pPaarListenElt)
{
   TCD_INT iRc;
   TCD_INT iAct;

/* 
Achtung: Wenn die relevanten Attribute von PaarListen(iAct) NUe sind,
dann nicht ueberschreiben, sondern ggf. naechstes Element suchen, bei
dem o.g.Bedingung nicht zutrifft, oder gar nicht speichern (wenn Listen
laenge == 1)
pPaarListe->iAct zeigt hier schon auf den naechsten Eintrag,
den er nehmen wuerde...
Wenn kein Platz gefunden wurde, -1 zurueckliefern,
wenn Listenelement nicht gesetzt werden konnte, (Speichermangel?) 
-9 zur|ckgeben!
*/

   /* Wenn das unterzubringende Ergebnis ohne �berschreibung entstanden
      ist, ist es in jedem Fall in die Ergebnisliste einzutragen,
      sonst ist ein freier Platz zu suchen.
      Im anderen Fall wird auf den n�chsten freien Platz
      (pPaarListe->iAct zeigt darauf!) geschrieben  */

   if ( !(PaarListEltToProtect(pPaarListenElt->pAttrs)) ) 
   {                                         
       /* es ist ein nicht sch�tzenswertes Ergebnis, f�r das
          in der Paarliste ein freier Platz gesucht werden mu�,
          d.h, es werden dort keine Ergebnisse ohne �berschreibung
          �bernudelt */
       
       if ( (iAct = GetIndexToPaarListElt(pTCDTCD,pPaarListe)) == -1 )
          
            return -1; /* alles besetzt! */
       else pPaarListe->iAct = iAct; 
                /* noch ein Pl�tzchen gefunden...*/
   }
   
   iRc = SetVectElt (pPaarListe->pPaarListenElts,pPaarListe->iAct,
                     (void *)pPaarListenElt);

   if ( iRc )
   {    
      iAct = pPaarListe->iAct;
      pPaarListe->iAct++;
      if ( pPaarListe->iAct >= pPaarListe->iWiederVerwListenLaenge )
         pPaarListe->iAct = 0;

      return iAct; /* Index, an dem zuletzt eingefuegt wurde */
   }
   /* -9 zur|ckgeben, weil SetVectElt schief ging. 
      Vermutlich kein Speicher mehr ! */
   return -9;
}

/* 
   P_PAARLISTEN_EL FindPaarListElt :
   Gibt ein PaarListenElement zurueck
   Wenn iSuchArt == 1  wird in den PaarListen gesucht sonst
   wird das 0te Element genommen
   ruft entweder GetPaarListElt oder GetPaarListEltByIndex auf
  */
P_PAARLISTEN_EL FindPaarListElt (P_PAARLISTE pPaarListe,
                                 TCD_INT iIndex )
{ 
   if ( iIndex == -1 )
   {
      /* suchen */
      return (P_PAARLISTEN_EL)
      FindFirstVectEl ((LP_VECT)pPaarListe->pPaarListenElts,
                        ComparePaarListenElt,
                        &iIndex,
                        (void *)pPaarListe->pAttrs);
   }
   
   /* nicht suchen , gib Element(iIndex) zurueck... */
   else return (P_PAARLISTEN_EL)
                GetVectElt (pPaarListe->pPaarListenElts,iIndex);
}

/* 
TCD_INT ComparePaarListenElt :
Vergleicht zwei Vektoren
p1    = Element PaarListe mit Vector von relevanten Attributen
pArgs = Vector von relevanten Attributen mit aktueller Belegung
Die Funktion soll die PaarListe durchsuchen und dabei jeden Vektor
von relevanten Attributen gegen den uebergebenen Vektor relevanter
Attribute vergleichen
*/
TCD_INT ComparePaarListenElt ( void * p1 , void * pArgs )
{
   P_PAARLISTEN_EL  pPaarListenElt   = (P_PAARLISTEN_EL) p1;

   LP_VECT          pPaarListenAttrs = (LP_VECT)pPaarListenElt->pAttrs;
   LP_VECT          pAttrs           = (LP_VECT)pArgs;

   P_TCDRELATTR     pAttrElDerPaarListe;
   P_TCDRELATTR     pAttrElAktuellBelegt;

   TCD_INT          iFound = VectLen(pAttrs);
   TCD_INT          i, iVectLen;
   TCD_INT          iTyp3NotOverwrittenPL;
   TCD_INT          iTyp3NotOverwrittenA;

   iVectLen = VectLen(pAttrs);
   for ( i=0; i < iVectLen; i++ )
   {
      pAttrElDerPaarListe = GetVectElt(pPaarListenAttrs,i);
      pAttrElAktuellBelegt= GetVectElt(pAttrs          ,i);

/* 
Wenn pAttrElDerPaarListe->bNotOverwritten == TYP3_NOT_OVERWRITTEN (-1)
dann handelt es sich um ein relevantes Attribut zu einem Typ3-Knoten, 
das nicht ueberschrieben war, also eigentlich um kein relevantes 
Attribut. Die richtige Belegung kann erst mit der Berechnung ermittelt
werden, deshalb findet man im relevanten Attribut immer den 
(Default-)Wert 0 vor.
*/

      iTyp3NotOverwrittenPL = 
         pAttrElDerPaarListe->bNotOverwritten==TYP3_NOT_OVERWRITTEN
         ? 1 : 0;
      iTyp3NotOverwrittenA = 
         pAttrElAktuellBelegt->bNotOverwritten==TYP3_NOT_OVERWRITTEN
         ? 1 : 0;                               
         
      switch ( iTyp3NotOverwrittenPL + iTyp3NotOverwrittenA ) {
          case 2: 
              /* ist jeweils ohne Ueberschreibung berechnet worden, 
                 sollte auch das gleiche "Ergebnis" geliefert haben */
              iFound--;
              break;
          case 1:
              /* genau einer ist ohne Ueberschreibung gerechnet 
                 worden, der Wert 0 darf nicht verglichen werden */
              break;
          case 0:        
             switch ( pAttrElDerPaarListe->AttrType )
             {
                 case TCD_ATTRFMT_TAB1 :
                 case TCD_ATTRFMT_TAB2 :
    
        /* 
          Ist die ID == 0 (nicht wiederverwendbare AnwenderTabelle)
          darf iFound nur vermindert werden, wenn die aktuelle 
          Berechnungs-Nummer uebereinstimmt ...
          Ueberschriebene TabellenWerte sind noch nicht beruecksichtigt
          */
                    if ( pAttrElDerPaarListe->Belegung.TabID == 
                         pAttrElAktuellBelegt->Belegung.TabID )
                    {
                       if ( pAttrElDerPaarListe->Belegung.TabID == 0 &&
                            pPaarListenElt->iBerechnungsNummer  != 
                              pAttrElAktuellBelegt->iBerechnungsNummer)
                            ;
                       else iFound--;
                    }
                    break;
    
                 default :
    
                    if ( pAttrElDerPaarListe->Belegung.Skalar == 
                          pAttrElAktuellBelegt->Belegung.Skalar )
                       iFound--;
    
                    break;
             }
      }
   }
   /* 
      Waren alle gleich, muss iFound 0 sein!
     */
   if ( !iFound )

        return 1;
   else return 0;
}

/* 
   void ConstrPaarListenElt :
   Erzeugt ein leeres PaarListenElement
  */
void ConstrPaarListenElt    ( void * p )
{
   memset(p,0,sizeof(S_PAARLISTEN_EL));
}

/* 
   TCD_INT CopyPaarListenElt :
   Kopiert ein PaarListenElement
  */
TCD_INT CopyPaarListenElt   (void * p1,  void * p2 )
{
   P_PAARLISTEN_EL pDst           = (P_PAARLISTEN_EL) p1;
   P_PAARLISTEN_EL pSrc           = (P_PAARLISTEN_EL) p2;

   TCD_LONG         lAllocLen      = 0;
   TCD_LONG         lCopyLen       = 0;
   TCD_LONG         i;

   
   DestrPaarListenElt ( p1 );
   if ( pSrc->pAttrs )
   {
      pDst->pAttrs = DConstrAttrs (VectLen(pSrc->pAttrs));
      if ( !(CopyVectToVect(pDst->pAttrs,pSrc->pAttrs)) )
         return 0;
   }

   pDst->iType              = pSrc->iType;
   pDst->iBerechnungsNummer = pSrc->iBerechnungsNummer;
   
   pDst->lTabZeilen         = pSrc->lTabZeilen;
   pDst->lTabSpalten        = pSrc->lTabSpalten;
   
   if ( pSrc->iType == TCD_ATTRFMT_TAB1 )
   {
      lAllocLen = pSrc->lTabZeilen * (TCD_LONG) sizeof(double);
      lCopyLen  = pSrc->lTabZeilen;
   }

   if ( pSrc->iType == TCD_ATTRFMT_TAB2 )
   {
      lAllocLen = (pSrc->lTabZeilen * pSrc->lTabSpalten) * 
                  (TCD_LONG) sizeof(double);
      lCopyLen  = (pSrc->lTabZeilen * pSrc->lTabSpalten);
   }
   
   switch ( pSrc->iType )
   {
      case TCD_ATTRFMT_TAB1 :
      case TCD_ATTRFMT_TAB2 :

         pDst->Ergebnis.pTab = (P_TCDTAB)
                                _TCDTABALLOC(lAllocLen,(TCD_INT)1);
         if ( pDst->Ergebnis.pTab == NULL )
            return 0;

         for ( i=0; i < lCopyLen; i++ )
            *(pDst->Ergebnis.pTab+i) = *(pSrc->Ergebnis.pTab+i);

         break;

      case TCD_ATTRFMT_SKAL:
         pDst->Ergebnis.Skalar = pSrc->Ergebnis.Skalar;
         break;

      case TCD_ATTRFMT_DATE :
         strcpy(pDst->Ergebnis.Datum,pSrc->Ergebnis.Datum);
         break;

      case TCD_ATTRFMT_VGLO :
         strcpy(pDst->Ergebnis.VglOp,pSrc->Ergebnis.VglOp);
         break;

   }
   return 1;
}

/* 
   void DestrPaarListenElt :
   Zerstoert ein leeres PaarListenElement
  */
void DestrPaarListenElt     ( void * p )
{
   P_PAARLISTEN_EL pPaarListenElt = ( P_PAARLISTEN_EL) p;

   if ( pPaarListenElt->pAttrs )
      DDestrVect((void **)&pPaarListenElt->pAttrs);

   switch ( pPaarListenElt->iType )
   {
      case TCD_ATTRFMT_SKAL :
         break;

      case TCD_ATTRFMT_TAB1 :
      case TCD_ATTRFMT_TAB2 :

         if ( pPaarListenElt->Ergebnis.pTab )
            _TCDTABFREE(pPaarListenElt->Ergebnis.pTab);

         break;
   }
   pPaarListenElt->iType              = 0;
   pPaarListenElt->iBerechnungsNummer = 0;

   memset((void *)&pPaarListenElt->Ergebnis,0,sizeof(U_TCDVALUE));
}

/* 
   TCD_INT GetIndexToPaarListElt:
   Sucht in der PaarListe den naechsten freien Eintrag.
   Ein freier Eintrag kann iIndex+1 oder 0 sein, wenn keiner dieser
   Eintraege ein Ergebnis enthaelt, das ohne eine Ueberschreibung
   entstanden ist.
   in pPaarListe->iAct steht, welchen er gerne nehmen w|rde ...
  */
TCD_INT GetIndexToPaarListElt(P_TCD_C_G pTCDTCD,P_PAARLISTE pPaarListe)
{
   TCD_INT          i, iVectLen;

   P_PAARLISTEN_EL pPaarListenElt;
   LP_VECT         pVect = pPaarListe->pPaarListenElts;

   /* 
      Vektor ist noch leer, oder es wird kein bereits belegtes Element
      angesprochen
     */
   iVectLen = VectLen(pVect);
   if ( iVectLen      == 0             ||
        pPaarListe->iAct == iVectLen )

      return pPaarListe->iAct;

   /* --Schleife ueber die bisherigen Eintraege- */
   for( i=pPaarListe->iAct; i < iVectLen; i++ )
   {
     pPaarListenElt = (P_PAARLISTEN_EL)GetVectElt (pVect,i);

     if ( !pPaarListenElt->pAttrs )
        return pPaarListe->iAct ;

     if ( !(PaarListEltToProtect(pPaarListenElt->pAttrs)) )
     {
        /* --Darf fuer jeden Knotentyp immer ueberschrieben werden */
        return i;
     }
     else
     {
        /* 
           Bei Knotentyp 2 muss das Ergebnis die aktuelle 
           Berechnungsnummer haben um schuetzenswert zu sein
          */
        if ( pPaarListe->iWiederVerwendungsTyp == 2 )

           if ( pPaarListenElt->iBerechnungsNummer == 
                pTCDTCD->iBerechnungsNummer )

                continue;
           else return i;
/* 
zwar ein Ergebnis ohne Ueberschreibung, aber aus einer alten Berechnung
Daher zu ueberschreiben ...
*/
        else continue;
     }
   }
/* wrap around */
/* wenn pPaarListe nicht 0 war, also mitten im Vektor 
   angefangen wurde- */
   if ( pPaarListe->iAct > 0 )
   {
      pPaarListe->iAct = 0;
      GetIndexToPaarListElt(pTCDTCD,pPaarListe);
   }
   return -1;
}

/* 
   TCD_INT PaarListEltToProtect:
   Prueft, ob alle relevanten Attribute eines Ergebnisses nicht
   ueberschrieben sind
  */
TCD_INT PaarListEltToProtect( LP_VECT pVect )
{
   P_TCDRELATTR pAttrEl;
   TCD_INT      i, iVectLen ;
   TCD_INT      iNotOverwritten=0;

   if ( !pVect ) return 1;  
   iVectLen = VectLen(pVect);
   for ( i=0; i < iVectLen; i++ )
   {
      pAttrEl = (P_TCDRELATTR)GetRelAttr(pVect,i);
      if (pAttrEl->bNotOverwritten == TYP3_NOT_OVERWRITTEN) return 0;
      iNotOverwritten += pAttrEl->bNotOverwritten;
   }
   if ( iNotOverwritten != iVectLen ) 
   /* Ergebnis nicht vollstaendig ohne Ueberschreibung entstanden */

        return 0; /* nicht vollstaendig ohne Ueberschreibung  */
   else return 1 ;/* vollstaendig ohne Ueberschreibung */
}

/* 
   TCD_INT CopyErgPoolElt :
   CopyFunktion fuer ein Element des globalen ErgebnisPools
  */
TCD_INT  CopyErgPoolElt    (void * p1 , void * p2)
{
   P_ERGEBNIS_POOL_ELT pDst          = (P_ERGEBNIS_POOL_ELT)p1;
   P_ERGEBNIS_POOL_ELT pSrc          = (P_ERGEBNIS_POOL_ELT)p2;

   int                 i, iVectLen;

   pDst->ID            = pSrc->ID;
   pDst->pPaarListe =
      DConstrAttrsResults(pSrc->pPaarListe->iWiederVerwendungsTyp, 
                          pSrc->pPaarListe->iWiederVerwListenLaenge);

   if ( pDst->pPaarListe == NULL )
      return 0;
      
   if ( pSrc->pPaarListe->pAttrs )
   {
      pDst->pPaarListe->pAttrs = DConstrAttrs 
                                 (VectLen(pSrc->pPaarListe->pAttrs));
      if ( !(CopyVectToVect(pDst->pPaarListe->pAttrs,
                            pSrc->pPaarListe->pAttrs)) )
         return 0;
   }
                                  
   iVectLen = VectLen(pSrc->pPaarListe->pPaarListenElts);
   for ( i=0; i < iVectLen; i++ )
   {
      P_PAARLISTEN_EL p = (P_PAARLISTEN_EL)
                      GetVectElt(pSrc->pPaarListe->pPaarListenElts,i);

      /* SetVectElt() ruft 'CopyPaarListenElt()' auf, dass sich um die 
         relevanten Attribute eines PaarlistenElts kuemmert  */
      if ( !SetVectElt(pDst->pPaarListe->pPaarListenElts,i,(void *)p))
         return 0;
   }
   return 1;
}

/* 
   void DestrErgPoolElt :
   Destruktor fuer ein Element aus dem globalen ErgebnisPool
  */
void     DestrErgPoolElt(void * p)
{
   P_ERGEBNIS_POOL_ELT pElt          = (P_ERGEBNIS_POOL_ELT)p;
   P_PAARLISTE     pPaarListe = pElt->pPaarListe;

   if (pElt->ID == 0) return;

   pElt->ID = 0;                    /* RWE, 23.06.96 */
   if (!pPaarListe) return;      /* " */

   if ( pPaarListe->pAttrs )
   {
      DDestrVect((void **)&pPaarListe->pAttrs);
      pPaarListe->pAttrs = NULL;
   }
   if ( pPaarListe->pPaarListenElts )
   {
     DDestrVect((void **)&pPaarListe->pPaarListenElts);
     pPaarListe->pPaarListenElts = NULL;
   }
   _TCDFREE (pPaarListe);
   pElt->pPaarListe=NULL;

}
/* 
   InitErgPoolElt :
   Fuegt eine PaarListe in den globalen ErgebnisPool ein.
  */
LP_VECT DConstrErgPool(TCD_INT iNumOfElts) 
{
   return (LP_VECT)DConstrVect((TCD_INT)sizeof(S_ERGEBNIS_POOL_ELT),
                               iNumOfElts,10,
                               CopyErgPoolElt,NULL,DestrErgPoolElt);
}

/* 
   GetErgPoolElt :
   Gibt ein Element aus dem globalen ErgebnisPool zurueck
   Gesucht wird ueber die ID
  */
void *        GetErgPoolElt      (P_TCD_C_G pTCDTCD , TCD_LONG ID )
{
   P_ERGEBNIS_POOL_ELT pPoolEnt=NULL;
   TCD_INT             i, iVectLen ;

   if ( pTCDTCD->pErgebnisPool )
   {                               
      iVectLen = VectLen(pTCDTCD->pErgebnisPool);
      for ( i=0; i < iVectLen ; i++ )
      {
         if ( (pPoolEnt = (P_ERGEBNIS_POOL_ELT)GetVectElt
                           (pTCDTCD->pErgebnisPool,i)) == NULL )
            return NULL;

         if ( pPoolEnt->ID == ID )
         {
            return (void *)pPoolEnt;
         }
      }
      return NULL;
   }
   else return NULL;  
}
/* 
   ReleaseGlobalErgebnisPool:
   Zerstoert den globalen ErgebnisPool
  */
void          ReleaseGlobalErgebnisPool(P_TCD_C_G pTCDTCD)
{
   if ( pTCDTCD->pErgebnisPool)
      DDestrVect((void **)&pTCDTCD->pErgebnisPool);
   
   pTCDTCD->pErgebnisPool=NULL;
}

/* 
   ReleaseGlobalErgebnis:
   Entfernt AttrsResults zu einer vorgeg. Prc aus dem ErgebnisPool
  */
TCD_INT /*bSuccess*/ ReleaseGlobalErgebnis( P_TCD_C_G pTCDTCD, 
                                            TCD_LONG PrcID )
{
   P_ERGEBNIS_POOL_ELT pPoolElement;
   if (PrcID == 0)
   {
      ReleaseGlobalErgebnisPool(pTCDTCD);
      return 1;
   }
   pPoolElement = (P_ERGEBNIS_POOL_ELT)GetErgPoolElt(pTCDTCD,PrcID);

   if (!pPoolElement)                return 0;
   if (!pPoolElement->pPaarListe) return 0;

   DestrErgPoolElt((void *) pPoolElement);
   return 1;
}

/* 
   ReleaseLocalErgebnisPool:
   Zerstoert den lokalen ErgebnisPool
  */
void          ReleaseLocalErgebnisPool(P_PAARLISTE pPaarListe )
{
   if ( pPaarListe->pAttrs )
      DDestrVect((void **)&pPaarListe->pAttrs);

   DDestrVect((void **)&pPaarListe->pPaarListenElts);

   _TCDFREE(pPaarListe);
   pPaarListe = NULL;
}
/* 
   TCD_INT GetIndexToGlobalErgPool:
   sucht nach einem moeglichen freien Platz im globalen ErgebnisPool
  */
TCD_INT GetIndexToGlobalErgPool(LP_VECT pVect)
{

   P_ERGEBNIS_POOL_ELT pPoolEnt=NULL;
   TCD_INT            i, iVectLen;
                                 
   iVectLen = VectLen(pVect);
   for ( i=0; i < iVectLen; i++ )
   {
       pPoolEnt = (P_ERGEBNIS_POOL_ELT)GetVectElt(pVect,i);
       if ( pPoolEnt->ID == 0 )
          return i;
   }
   return iVectLen; /* ans Ende damit! */
}

/* 
   void * FetchFromGlobalErgebnisPool :
   Liefert Ergebnisse an die Testfallfunktion Fetch() zurueck:
  */
void * FetchFromGlobalErgebnisPool ( P_TCD_C_G pTCDTCD, TCD_LONG ID,
                                     TCD_INT iType )
{
   P_ERGEBNIS_POOL_ELT pPoolEnt      = GetErgPoolElt(pTCDTCD,ID);

   P_PAARLISTE     pPaarListe = NULL;
   P_PAARLISTEN_EL    pPaarListElt  = NULL;
   TCD_INT             i, iVectLen;

   if ( !pPoolEnt ) /* kein ErgebnisPool !? */

        return NULL;
   else pPaarListe = pPoolEnt->pPaarListe;
                                  
   iVectLen = VectLen(pPaarListe->pPaarListenElts);
   for ( i=0; i < iVectLen; i++ )
   {
      pPaarListElt = FindPaarListElt(pPaarListe,i);
      if ( pPaarListElt->iBerechnungsNummer == 
           pTCDTCD->iBerechnungsNummer )
      {
         /* gibt 1 zurueck, wenn alle Elemente der relevanten 
            Attribute nicht ueberschrieben sind */
         if ( (PaarListEltToProtect(pPaarListElt->pAttrs)) )
         {
            switch ( iType )
            {
               case TCD_ATTRFMT_SKAL:
               {
                  return (void *)&pPaarListElt->Ergebnis.Skalar ;
               }

               case TCD_ATTRFMT_TAB1 :
               case TCD_ATTRFMT_TAB2 :
               {
                  return (void *)pPaarListElt->Ergebnis.pTab;
               }
            }
         }
      }
   }
   return NULL;
}


/* 
   NewAttrsResults :
   Legt eine PaarListe entweder im globalen ErgebnisPool oder
   beim Knoten an und holt, soweit vorhanden, die relevanten Attribute
   aus der Schnittstelle
  */
P_PAARLISTE NewAttrsResults  (P_TCD_C_G pTCDTCD , P_TCDPRCNODE pNode,
                              TCD_LONG ID )
{
   P_PAARLISTE     pPaarListe = NULL;
   TCD_INT         iIndex     = 0 ;
   
   S_ERGEBNIS_POOL_ELT ErgPoolElt;

   switch ( pNode->iWiederVerwendungsTyp )
   {
      case 1:
      case 2:

         /* Falls der globale ErgebnisPool noch nicht existiert, 
            konstruieren */
         if ( !pTCDTCD->pErgebnisPool )
         {
			 /*MGS 07.03.2000 Schrittweite erh�hen, WV-Optimierung */
			if((pTCDTCD->pErgebnisPool = DConstrErgPool(3)) == NULL )
               return NULL;
         }
         memset((void *)&ErgPoolElt,0,sizeof(S_ERGEBNIS_POOL_ELT));
         /* 
            Der globale Ergebnisvektor kann Luecken haben, daher 
            nach einem freien Platz suchen und ErgPoolElement belegen
           */
         iIndex = GetIndexToGlobalErgPool(pTCDTCD->pErgebnisPool);

         /* PROC-ID ... */
         ErgPoolElt.ID = ID;

         /* Konstruieren der PaarListe */
         if ( (ErgPoolElt.pPaarListe =
            DConstrAttrsResults (pNode->iWiederVerwendungsTyp,
                            pNode->iWiederVerwListenLaenge)) == NULL )
            return NULL;

         /* --Der Vektor der relevanten Attribute- */
         if ( pNode->iAnzRelAttrs )
         {
              ErgPoolElt.pPaarListe->pAttrs = DConstrAttrs 
                                              ( pNode->iAnzRelAttrs );

              /* relevante Attribute aus der Schnittstelle besorgen */
              if (!(GetRelAttrs(pTCDTCD,pNode,ErgPoolElt.pPaarListe)))
                 return NULL;
         }

         /* in den globalen Vektor eintragen */
         if ( !(SetVectElt(pTCDTCD->pErgebnisPool,iIndex,
                           (void *)&ErgPoolElt)) )
            return NULL;

         /* weg damit!  */
         DestrErgPoolElt((void *)&ErgPoolElt);

         /* nochmal lesen, weil in CopyErgPoolElt kopiert wurde und 
            sich die Adressen geaendert haben! */
         {
            P_ERGEBNIS_POOL_ELT p = (P_ERGEBNIS_POOL_ELT)
                            GetVectElt(pTCDTCD->pErgebnisPool,iIndex);
            return (P_PAARLISTE)p->pPaarListe;
         }

      case 3 :

         if ( (pPaarListe =
            DConstrAttrsResults (pNode->iWiederVerwendungsTyp,
                           pNode->iWiederVerwListenLaenge)) == NULL )
            return NULL;

         if ( pNode->iAnzRelAttrs )
         {
            pPaarListe->pAttrs = DConstrAttrs ( pNode->iAnzRelAttrs );
            if ( !(GetRelAttrs(pTCDTCD,pNode,pPaarListe)) )
               return NULL;
         }
         return pPaarListe;

      default :
         return NULL;
   }
}
