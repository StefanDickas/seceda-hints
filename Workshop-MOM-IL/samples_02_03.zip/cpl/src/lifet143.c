/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
 /*--------------------------------------------------------------------
    Modul:        TCD_PKF.c

    Beschreibung: Funktionen C-Generator, die vom Makrogenerator
                  aufgerufen werden
    By:           BEGGI
    Datum:        16.12.2019 15:07:19
    Historie :    BEG  22.11.95      FM: 384
  MUB  21.5.96 Optimierung begonnen, Beschaffungsflags etc.
  MUB          Pr�fung, ob Ergebnis schon berechnet wurde.
  MUB 17.7.96  Abweisungen zwischen #ifdef TRACEFKT #endif korrigiert
  MUB 26.7.96  Erfolgreiche Wiederverwendung eines Ergebnisses
               ins Tracefile schreiben
---------------------------------------------------------------------*/

/* Includes */
/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDPORTAB_H)
#define TCDPORTAB_H

/*-----------------
Name        : TCDPORTAB.H

Beschreibung: externes Include File, das generierumgeungsspezifische
Informationen enthaelt (Makrovorlage).
By          : BEGGI
Datum       : 20.04.94
Historie:     BEG   17.01.95  neues Makro _TCDMEMINI anstatt memset
BEG   02.03.95  bedingte Macros TCDHUGE
BEG   22.06.95  _TCDMEMINI nur im HUGE-Modell redefiniert.
BEG   20.02.96  malloc.h wird nicht mehr inkludiert (FM 451)
RWE   21.06.96  malloc.h wird wieder includiert (aber nur
              fuers HUGE-Modell, d.h. fuer DOS/WIN-Compiler)
RWE   26.06.96  WATCHMEM-Makros eingebaut (fuer TCDALLOC etc)
MUB   17.7.96   Include mit !defined versehen
KFC   02.09.96  #define TCDHUGE vorgezogen

-------------------*/

/* #define TCDHUGE */              /* bei gro�en Tabellen einschalten*/
/* Systemincludes */                  
#include <stdlib.h>                /* atoi, ...       */
#include <stdio.h>                 /* fprintf, ...    */
#include <string.h>                /* strcpy, ...     */
#include <time.h>                  /* time_t, ...     */
#include <math.h>                  /* exp, min, max, ... */

#ifdef TCDHUGE
#include <malloc.h>
#endif

/* Defines */
#define  TCDC_EXT_NAME_LNG    8  /* maximale L�nge von externen 
                                    Bezeichnern*/
/*-----------------
  Definitionen aus standard C-Includes z.B. stdio.h
-------------------*/
#ifndef NULL
#define    NULL    (void *)0
#endif

/*-----------------
  Definitionen von Basistypen
-------------------*/
typedef    short   TCD_BOOL ;
typedef    long    TCD_LONG ;
typedef    int     TCD_INT  ;
typedef    double  TCD_DOUBLE ;


/*-----------------
  modellabhaengige Definitionen von Basistypen
-------------------*/
typedef    TCD_DOUBLE  TCDTAB ;
#ifdef TCDHUGE
typedef    TCDTAB       huge * P_TCDTAB ;
typedef    TCD_DOUBLE   huge * P_TCD_DOUBLE ;
typedef    P_TCD_DOUBLE * P_P_TCD_DOUBLE ;
typedef    char huge    * TCD_LPCHAR ;
#else
typedef    TCDTAB       * P_TCDTAB ;
typedef    TCD_DOUBLE   * P_TCD_DOUBLE ;
typedef    P_TCD_DOUBLE * P_P_TCD_DOUBLE ;
typedef    char         * TCD_LPCHAR ;
#endif

/*-----------------
  weitere (Typ-)Defines 
-------------------*/  
typedef int ERRNO_TYPE;
#define TCD_FILENAME_LNG 128

/*-----------------
  Definitionen von Makros f�r Speicherallokation
-------------------*/  

/* WATCHMEM muss im TCDHUGE-Modus abgeschaltet sein */
#ifdef TCDHUGE
#undef WATCHMEM
#endif

#undef _TCDALLOC
#undef _TCDFREE
#undef _TCDREALLOC

#ifndef WATCHMEM

#define _TCDALLOC(len,size)    malloc( (size_t)(len) * (size)) ;
#define _TCDFREE(ptr)          {free(ptr), ptr = NULL;}
#define _TCDREALLOC(ptr,size)  realloc( ptr, (size_t)(size) ) ;

#else
 
void *MallocAndProt(char *sFile_,int iLine_, size_t size);
#define _TCDALLOC(len,size)\
 MallocAndProt(__FILE__,__LINE__,(len) * (size))

void FreeAndProt(char *sFile_, int iLine_, void *p_);

#define _TCDFREE(ptr)\
       {FreeAndProt(__FILE__, __LINE__, ptr) , ptr = NULL;}

void *ReallocAndProt(char *sFile_,int iLine_, void *p_, size_t size);
#define _TCDREALLOC(ptr,size)\
 ReallocAndProt(__FILE__, __LINE__, ptr,size)

void ResumeWatchmem();

#endif

/*-----------------
  modellabh�ngige Definitionen von Makros f�r Speicherallokation
-------------------*/
#undef _TCDTABALLOC
#undef _TCDTABFREE
#undef _TCDMEMINI

#ifdef TCDHUGE

#define _TCDTABALLOC(len,size)\
  _halloc( (long)(len) , (size_t)(size)) ;
#define _TCDTABFREE(ptr)\
      { _hfree ( (void huge *)ptr); ptr = NULL;}

#else

#ifndef WATCHMEM
#define _TCDTABALLOC(len,size)\
 malloc((size_t)((long)len) * ((size_t)size)) ;
#define _TCDTABFREE(ptr)       {free(ptr), ptr = NULL;}
#else
#define _TCDTABALLOC(len,size)\
 MallocAndProt(__FILE__,__LINE__,(len) * (size))
#define _TCDTABFREE(ptr)\
       FreeAndProt(__FILE__, __LINE__, ptr)
#endif

#endif


#ifdef TCDHUGE
#define _TCDMEMINI(ptr,size,nr)\
{\
   long       j;\
   TCD_LPCHAR lp;\
   for (j= 0 , lp = (TCD_LPCHAR)ptr;\
        j < ((long)(size) * (long)(nr)); j++, lp++) \
      *lp = 0;\
}  

#else
#define _TCDMEMINI(ptr,size,nr)\
 { memset (ptr, 0, (size_t) ((size) * (nr))) ; }
#endif
/*---------------------------------
  NON-Ansi-Namen mit oder ohne "_"
----------------------------------*/

/* #define NON_ANSI_WITHOUT__ */

#ifdef NON_ANSI_WITHOUT__
#define _fcvt fcvt
#endif

/*---------------------------
  ggf. Verkuerzung der Namen
-----------------------------*/
#ifdef TCD_NAMLEN8

#define TCDIMPReleaseProcData       TCD_0001
#define TCDIMPReleaseNodeData       TCD_0002
#define TCDIMPReleaseTabImpData     TCD_0003   

#define FetchFromGlobalErgebnisPool TCD_0004

#define DelEltFromSVect             TCD_0005
#define DelEltFromSVectByIndex      TCD_0006

#define DelEltFromVect              TCD_0007
#define DelEltFromVectByIndex       TCD_0008
                                
                                
#define ReleaseGlobalErgebnisPool   TCD_0009
#define ReleaseGlobalErgebnis       TCD_0010
#define ReleaseLocalErgebnisPool    TCD_0011

#define GetPrcDataSkal              TCD_0012
#define GetPrcDataTab               TCD_0013
#define GetPrcDataDat               TCD_0014
#define GetPrcDataFrm               TCD_0015

#define GetPrcAttrSkal              TCD_0016
#define GetPrcAttrTab               TCD_0017

#define GetSSAttrSkal               TCD_0018
#define GetSSAttrTab                TCD_0019

#define ErgPoolGetFirstInfo         TCD_0020
#define ErgPoolGetNextInfo          TCD_0021

#define DConstrAttrs                TCD_0022
#define DConstrAttrsResults         TCD_0023

#define GetRelAttrs                 TCD_0024

#define GetIndexToGlobalErgPool     TCD_0025
#define GetIndexToPaarListElt       TCD_0026

#define GetIndexToSS                TCD_0027
#define GetIndexToUes               TCD_0028
#define GetFromSS                   TCD_0029
#define GetFromUes                  TCD_0030

#define TCDIMPImportTreeData        TCD_0031
#define TCDIMPNFIntl                TCD_0032
#define TCDIMPGetNodeFromID         TCD_0033
#define TCDIMPGetNodeFromPath       TCD_0034
#define compBsearch                 TCD_0035
#define TCDIMPReleaseTreeData       TCD_0036 
#define TCDIMPReleaseTabData        TCD_0037  
#define DConstrTCD_C_G              TCD_0038
#define DDestrTCD_C_G               TCD_0039 
#define SConstrTCD_C_G              TCD_0040
#define DConstrTCDRbsSS             TCD_0041
#define SConstrTCDRbsSS             TCD_0042
#define SConstrTCDISSADATA          TCD_0043
#define SDestrTCD_C_G               TCD_0044
#define DDestrTCDRbsSS              TCD_0045
#define SDestrTCDRbsSS              TCD_0046
#define SDestrTCDISSADATA           TCD_0047
#define GetRbsSSFkt                 TCD_0048
#define TCDIMPGetTabIDAndTypFromPath TCD_0049
#define TCDIMPGetPathAndTypFromID    TCD_0050
#define TCDIMPReleaseTabTreeData     TCD_0051
#define TCDIMPImportTabTreeData      TCD_0052
#endif

#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDC_H)
#define TCDC_H

#ifdef TCDV2_5
#define TCDVERS 25
#endif
#ifdef TCDV3_0
#define TCDVERS 30
#endif
#ifndef TCDVERS
#error TCD Version muss in Makefiles angegeben werden.
#endif

/*---------
Name        : TCDC.H

Beschreibung: Zentrales Include File fuer die Anwendung
TCD weit gueltig
*----------*/

#include "p09115.h" /* direkte Vektoren */

#define  TCD_TRUE                1
#define  TCD_FALSE               0

/*---------
  Definitionen Opcodes
*----------*/
#define  TCD_OPC_INIT_RBS                    1
#define  TCD_OPC_CALC_FRM                    2
#define  TCD_OPC_CALC_PRC                    3
#define  TCD_OPC_GETNUM_FRM                  4
#define  TCD_OPC_GET_ATTR_VAL                5
#define  TCD_OPC_RESET_RBS                   6
#define  TCD_OPC_SET_PRC                     7
#define  TCD_OPC_RESET_PRC                   8
#define  TCD_OPC_SET_POOLTAB                 9
#define  TCD_OPC_RESET_POOLTAB              10
#define  TCD_OPC_SET_ATTR_VAL               11
#define  TCD_OPC_GET_PRC_INFO               12
#define  TCD_OPC_SET_POOLTAB_I              13
#define  TCD_OPC_RESET_POOLTAB_I            14
#define  TCD_OPC_SET_ATTR_IN_PRC            15
#define  TCD_OPC_SET_TRACE_ON               16
#define  TCD_OPC_SET_TRACE_OFF              17
#define  TCD_OPC_REMOVE_RESULTS             18
#define  TCD_OPC_GET_FIRST_RESULTS_INFO     19
#define  TCD_OPC_GET_NEXT_RESULTS_INFO      20

/*---------
  Definitionen Returncodes
*----------*/
#define  TCD_RC_NOT_OK              0
#define  TCD_RC_OK                  1
#define  TCD_RC_ILLOPC              2
#define  TCD_RC_VERSION_CONFLICT    3
#define  TCD_RC_UNKNOWN_FORM        4
#define  TCD_RC_ILLEGAL_FORM        5
#define  TCD_RC_ILLEGAL_PARAM       6
#define  TCD_RC_UNKNOWN_ATTR        7
#define  TCD_RC_NOT_FOUND           8
#define  TCD_RC_INPUT_MISSING       9
#define  TCD_RC_ILLEGAL_DIVISION   10
#define  TCD_RC_ILLEGAL_TAB_RANGE  11
#define  TCD_RC_STACK_OVERFLOW     12
#define  TCD_RC_CONDITION_FAIL     15
#define  TCD_RC_PAR_ERROR          20
#define  TCD_RC_TAB_IN_POOL        21
#define  TCD_RC_TAB_NOT_IN_POOL    22
#define  TCD_RC_PRC_IN_POOL        23
#define  TCD_RC_PRC_NOT_IN_POOL    24
#define  TCD_RC_UNKNOWN_PROC       25
#define  TCD_RC_PAARLISTEN_ERROR   26
#define  TCD_RC_NO_VALUE_AVAIL     30
#define  TCD_RC_USER_SET_ERROR    900
#define  TCD_RC_INTERNAL_ERR      999
#define  TCD_RC_NO_RETURN         888

/*---------
  allgemeine globale Konstanten
*----------*/
#define TCD_INIT_VARSETLEVEL    9999

/*---------
  Konfigurationsangaben
*----------*/
#define TCD_POOLADMIN_SIZE        20
#define TCD_C_MIN_USER_TYPE_ID    0
#define TCD_C_TABLISTLEN          10
#define TCD_C_MAXPRCCALLNR        2147483647

/*---------
  Definitionen Laengenangaben
*----------*/
#define TCD_DATUM_LNG              9
#define TCD_FRM_DATUM_LNG         20
#define TCD_VGLOP_LNG              3
#define TCD_NAME_LNG              26

/*---------
  Definitionen Aufrufart: (Aufzaehlungstyp)
-----------*/
#define TCD_CALLTYP_ATTR        1
#define TCD_CALLTYP_STA         2
#define TCD_CALLTYP_DYN         3
#define TCD_CALLTYP_STA_UE      4

/*---------
  Definitionen Prefix
-----------*/
#define TCD_PREFIX_TAB            '&'
#define TCD_PREFIX_PRC            '$'
#define TCD_PREFIX_FRM            'F'
#define TCD_PREFIX_ATTR           'A'

/*---------
  Definitionen Formeltypen (Aufzaehlungstyp, Wertevergabe analog Cobol)
-----------*/
#define TCD_FRMTYP_SKAL        1
#define TCD_FRMTYP_TAB1        2
#define TCD_FRMTYP_TAB2        3

/*---------
  Definitionen Belegungswerte PoolEntry
-----------*/
#define  TCD_POOLENT_INIT          0
#define  TCD_POOLENT_USED          1
#define  TCD_POOLENT_I_USED        2
#define  TCD_POOLENT_E_USED        3

/*---------
  Definitionen Assigntype
*----------*/
#define  TCD_DC_USE_NOT            0
#define  TCD_DC_USE_FRM            1
#define  TCD_DC_USE_PRC            2
#define  TCD_DC_USE_TAB            3
#define  TCD_DC_USE_VAL            4

/*----------
  Definitionen Formattypen
-----------*/
#define  TCD_ATTRFMT_SKAL          1
#define  TCD_ATTRFMT_TAB1          2
#define  TCD_ATTRFMT_TAB2          3
#define  TCD_ATTRFMT_VGLO          4
#define  TCD_ATTRFMT_DATE          5

/*----------
  Struktur Bestandsattributtabelle
 ----------*/
  typedef struct tagS_TCDATAB {
        char          Name [TCD_NAME_LNG] ;
        TCD_LONG      ID         ;
        TCD_INT       Index      ;
        TCD_INT       AttrTyp    ;
  } S_TCDATAB     ;

 typedef S_TCDATAB     * P_TCDATAB     ;

/*----------
  Struktur Tabelle aller Attribute
 ----------*/
  typedef struct tagS_ATTRTAB
  {
    TCD_LONG  ID    ;
    TCD_INT   Index ;
  } S_ATTRTAB ;

  typedef S_ATTRTAB    * P_ATTRTAB     ;

/*----------
  Typdefinition systemunabhanegiger Typen
 ----------*/
   typedef  char  TCD_VGLOP [TCD_VGLOP_LNG] ;
   typedef  char  TCD_DATUM [TCD_DATUM_LNG] ;

   typedef TCD_DOUBLE TCDTAB1 ;
   typedef P_TCDTAB   P_TCDTAB1 ;

   typedef TCD_DOUBLE TCDTAB2 ;
   typedef P_TCDTAB   P_TCDTAB2 ;

   typedef P_P_TCD_DOUBLE P_P_TCDTAB ;

/*---------
  Union Attributbelegung
 ----------*/
  typedef  union tagU_TCDVALUE {
           TCD_DOUBLE        Skalar;
           P_TCDTAB1         pTab1 ;
           P_TCDTAB2         pTab2 ;
   } U_TCDVALUE ;

  typedef  union tagU_TCDGVALUE {
           TCD_DOUBLE        Skalar;
           P_TCDTAB          pTab  ;
           TCD_VGLOP         VglOp ;
           TCD_DATUM         Datum ;
   } U_TCDGVALUE ;

/* --
 MUB 2.7.96: neu eingefuehrt, weil wir die TabellenID brauchen
--  */
  typedef  union tagU_TCDWVALUE
  {
           TCD_DOUBLE        Skalar;

           TCD_LONG          TabID ;  /*  die relevanten Attribute */
           P_TCDTAB1         pTab  ;  /*  das Ergebnis */

           TCD_VGLOP         VglOp ;
           TCD_DATUM         Datum ;
   } U_TCDWVALUE ;

  typedef struct tagS_TCDPRCVAL {
          TCD_LONG   PrcID ;
          TCD_LONG   FormelNr ;
          TCD_INT    FormelIx ;
          char       FormelName [TCD_NAME_LNG] ;
          TCD_INT    PoolIx ;
#if TCDVERS > 25
/* Version der Formel zur Pruefung 
		  Formel-Generat gegen Transport-Format */
          TCD_INT    FormelVers;
#endif

 } S_TCDPRCVAL ;

  typedef union  tagU_TCDNDVALUE {
          struct   tagTabData {
             TCD_LONG  TabID ;
             TCD_INT   PoolIx ;
          } TabData  ;
          TCD_DOUBLE Skalar ;
          char       Datum [TCD_DATUM_LNG] ;
          char       VglOp [TCD_VGLOP_LNG];
 } U_TCDNDVALUE ;


  typedef struct tagS_TCDFORMEL {
           TCD_LONG  FormelNr ;
           TCD_INT  FormelIx ;
           char     FormelName [TCD_NAME_LNG] ;
           TCD_INT  IsStaRef ;                                 
#if TCDVERS > 25
/* Version der Formel zur Pruefung 
		   Formel-Generat gegen Transport-Format */
		   TCD_INT  FormelVers;
#endif
 } S_TCDFORMEL ;

  typedef union  tagU_TCDASSIGNVAL {

       S_TCDPRCVAL  Prc    ;
       U_TCDNDVALUE Val    ;
       S_TCDFORMEL  Formel  ;

 } U_TCDASSIGNVAL ;

#define TYP3_NOT_OVERWRITTEN 2

typedef struct tagS_TCDREL_ATTR
{                                 
   TCD_LONG    iBerechnungsNummer;
   /* ID des Attributs                            */
   TCD_LONG    AttrID                  ;  
   /* Typ der Belegung SKALAR, TAB, DATUM , VGLOP */
   TCD_INT     AttrType              :4;  
   /* Flag, ob ein geerbter Wert vorhanden ist    */
   TCD_INT     bGeerbterWertVorhanden:2;  
   /* Flag, ob ein geerbter Wert vorhanden ist    */
   TCD_INT     bNotOverwritten         ;
   /* GGf. Wert hierzu                            */
   U_TCDWVALUE Belegung                ;  

}  S_TCDRELATTR;

typedef S_TCDRELATTR * P_TCDRELATTR ;

/* --
   S_TCDRELATTR_IMP    Relevantes Attribut fuer den Import
--  */
typedef struct tagS_TCDREL_ATTR_IMP
{
   TCD_LONG AttrID;
   TCD_INT  AttrType               : 4;
   TCD_INT  iIndex;

}  S_TCDRELATTR_IMP;

typedef S_TCDRELATTR_IMP * P_TCDRELATTR_IMP ;

/* --
   S_PAARLISTEN_EL    Struktur fuer ein PaarlistenElement
--  */
typedef struct tagS_PAARLISTEN_EL
{
   /* Vektor der relevanten Attribute mit der aktuellen Belegung     */
   LP_VECT          pAttrs;        
   /* lfde. Nummer der aktuellen Berechnung                          */
   TCD_LONG         iBerechnungsNummer; 
   
   TCD_LONG         lTabZeilen;         
   TCD_LONG         lTabSpalten;
   
   /* Typ des Ergebnisses (kann 'NOT_OVERWRITTEN' sein)              */
   TCD_INT          iType;              
   /* Ergebnis hierzu                                                */
   U_TCDWVALUE      Ergebnis;           

}  S_PAARLISTEN_EL;

typedef S_PAARLISTEN_EL * P_PAARLISTEN_EL ;

/* --
   S_PAARLISTE     Struktur zu einem Belegknoten einer BV
   Sie enthaelt 1 sortierten Vektor, 1 Liste und eine maximale Laenge
   fuer die Anzahl Elemente der Paarliste (Belegung,Ergebnis)
--  */
typedef struct tagS_PAARLISTE
{
   TCD_INT iWiederVerwendungsTyp;   /* KnotenTyp 1/2/3     */
   TCD_INT iWiederVerwListenLaenge; /* ListenLaenge maximal */
   TCD_INT iAct ;                   /* letztes Element     */

   /* direkter Vektor von S_ATTR_EL's   */
   LP_VECT pAttrs;                  
   /* direkter Vektor von S_PAARLISTEN_EL's */
   LP_VECT pPaarListenElts;         

}  S_PAARLISTE;

typedef S_PAARLISTE * P_PAARLISTE ; 

/* --
   S_ERGEBNIS_POOL_ELT Element eines PoolErgebnisses
--  */
typedef struct tagS_ERGEBNIS_POOL_ELT
{
   TCD_LONG    ID;
   P_PAARLISTE pPaarListe;

}  S_ERGEBNIS_POOL_ELT;

typedef S_ERGEBNIS_POOL_ELT * P_ERGEBNIS_POOL_ELT ;

/*-----------
  Struktur     Belegungsknoten
------------*/
  typedef struct tagS_TCDPRCNODE
  {
      TCD_LONG         AttrID                  ;
      TCD_INT          NodeID                  ;
      TCD_INT          AttrType                ;
      TCD_INT          AssignType              ;
      U_TCDASSIGNVAL   AssignVal               ;
      TCD_INT          SuccNodeIx              ;
      TCD_INT          AnzSuccNodes            ;
      TCD_INT          Usage                   ;

      P_PAARLISTE      pPaarListe              ;
      P_PAARLISTEN_EL  pResultForGetAttr       ;

      TCD_INT          iWiederVerwendungsTyp   ;
      TCD_INT          iWiederVerwListenLaenge ;
      TCD_INT          iAnzRelAttrs            ;
      TCD_INT          iFirstRelAttrIx         ;

  }   S_TCDPRCNODE ;

 typedef S_TCDPRCNODE  * P_TCDPRCNODE ;

/*-----------
  Struktur Auspraegungs-Belegungs-Information
------------*/
  typedef struct tagS_TCDPRCINFO {
         char  Name [TCD_NAME_LNG] ;
         TCD_LONG  ID ;
         TCD_INT   Formattyp ;
         TCD_INT   Typ ;
         TCD_INT   Klasse ;
         TCD_INT   AnzBeleg ;
         TCD_INT   TabIx ;
         TCD_LONG  RefNodeId ;
 } S_TCDPRCINFO ;

 typedef S_TCDPRCINFO  * P_TCDPRCINFO ;

/*--------
  Struktur LocalData MUB 2.7.96: wird nicht mehr verwendet!
 --------*/
  typedef struct tagS_TCDPRCLOCD {
          TCD_LONG FormelNr     ;
          TCD_INT  Usage        ;
          TCD_INT  Typ          ;
          union   {
              TCD_INT    PoolIx ;
              TCD_DOUBLE Val    ;
          } Data ;
          TCD_LONG  CalcByCallNr ;
   } S_TCDPRCLOCD ;

   typedef S_TCDPRCLOCD * P_TCDPRCLOCD ;

/*---------
  Struktur Header Auspraegungsbaum
----------*/
  typedef struct tagS_TCDPRCHDR {
    TCD_LONG       PrcID        ;
    TCD_LONG       FormelNr     ;
    TCD_INT        AnzPrcTree   ;
    TCD_INT        AnzBelegInfo ;
    TCD_INT        AnzRelAttrs  ;
    TCD_BOOL       FlSetAttrSkal;
    TCD_BOOL       FlSetAttrTab ;
    TCD_BOOL       FlSetAttrVgl ;
    TCD_BOOL       FlSetAttrDat ;
    TCD_BOOL       FlPrcCompl   ;
    TCD_LONG       PrcResIx     ;
    TCD_LONG       PrcCallNr    ;

 } S_TCDPRCHDR     ;


/*---------
  Struktur Auspraegungselement
-----------*/
  typedef union  tagU_TCDPRCELEM
  {
     S_TCDPRCHDR      TreeHdr;
     S_TCDPRCNODE     Node ;
     S_TCDPRCINFO     Info ;     
  }  U_TCDPRCELEM ;

 typedef U_TCDPRCELEM  * P_TCDPRCELEM ;

#define TCDPRCSIZE(pPrc)    (pPrc ? sizeof(S_TCDRELATTR_IMP)*\
                            (TCD_LONG)pPrc->TreeHdr.AnzRelAttrs +\
                            sizeof(U_TCDPRCELEM)*\
                            ( (TCD_LONG)pPrc->TreeHdr.AnzPrcTree +\
                             (TCD_LONG)pPrc->TreeHdr.AnzBelegInfo) : 0)


/*-------
  Datenstruktur Mehrfach-Auspraegung (MultiProc)
 --------*/
  typedef struct tagS_TCDMPRCENTRY {
        TCD_INT              PrcBelegt ;
        TCD_LONG             ID ;
        P_TCDPRCELEM         pPrcData ;
 } S_TCDMPRCENTRY ;

  typedef S_TCDMPRCENTRY * P_TCDMPRCENTRY ;

  typedef struct tagS_TCDMPRCADMIN {
        TCD_INT          Anzahl  ;
        P_TCDMPRCENTRY   Data    ;
 } S_TCDMPRCADMIN ;

 typedef S_TCDMPRCADMIN * P_TCDMPRCADMIN ;

/*--------
  Datenstruktur PoolAdmin
--------*/
  typedef struct tagS_TCDPOOLENTRY {
        TCD_LONG     ID ;
        TCD_INT      Usage ;
        TCD_INT      Typ ;
        TCD_INT      Fmttyp ;
        P_TCD_DOUBLE pData ;
  } S_TCDPOOLENTRY ;

  typedef S_TCDPOOLENTRY * P_TCDPOOLENTRY ;

  typedef struct tagS_TCDPOOLADMIN {
        TCD_INT          Anzahl  ;
        TCD_INT          AnzTabs ;
        TCD_INT          AnzProcs ;
        TCD_INT          AnzTemp  ;
        S_TCDPOOLENTRY * Data    ;
 } S_TCDPOOLADMIN ;

  typedef S_TCDPOOLADMIN * P_TCDPOOLADMIN ;

/*------
  Datenstruktur Kontrollstruktur
--------*/
  typedef struct tagS_TCDRBSINFO {
       char TcdVersion [TCD_DATUM_LNG]   ;
       char TcdRelease [TCD_DATUM_LNG]   ;
       char RbsInterf  [TCD_DATUM_LNG]   ;
       TCD_LONG RbsId ;
   } S_TCDRBSINFO ;

   typedef struct tagS_TCDRCINFO {
       TCD_INT   Rc ;
       TCD_INT   Errc ;
       char FormelName [TCD_NAME_LNG] ;
       TCD_INT   FormelNr ;
       char AttrName   [TCD_NAME_LNG] ;
   } S_TCDRCINFO          ;

   typedef S_TCDRCINFO * P_TCDRCINFO ;


   typedef struct tagS_TCDCTLPAR {

/*-
  Opcode:   TCD_OPC_GET_ATTR_VAL, TCD_OPC_SET_ATTR_VAL
--*/
        struct tagS_TCDPARGA {
           TCD_LONG    ProcID;
           TCD_LONG    ID;
           TCD_LONG    TabID;
           TCD_INT     TabIx ;
           U_TCDGVALUE Val ;
           TCD_INT     Typ ;
           TCD_INT     ProcIx;
        }            GA ;

/*-
  Opcode:   TCD_OPC_SET_POOLTAB
--*/
        struct tagS_TCDPARST {
            TCD_LONG  ID;
            TCD_INT   Dim ;
            P_TCDTAB  pTab ;
            TCD_INT    TabIx ;
        }            ST ;

/*-
  Opcode:   TCD_OPC_RESET_POOLTAB
--*/
        struct tagS_TCDPARRT{
            TCD_LONG  ID;
            P_TCDTAB  pTab ;
        }            RT ;

/*-
  Opcode:   TCD_OPC_SET_PRC
--*/
        struct tagS_TCDPARSP {
            TCD_LONG      ProcID;
            P_TCDPRCELEM  pProc;
            TCD_INT       ProcIx;
        }            SP;

/*-
  Opcode:   TCD_OPC_RESET_PRC
--*/
        struct tagS_TCDPARRP {
            TCD_LONG  ProcID;
            P_TCDPRCELEM  pProc;
        }            RP;

/*-
  Opcode:   TCD_OPC_CALC_FRM , TCD_OPC_CALC_PRC
--*/
        struct tagS_TCDPARCFP {
            TCD_LONG       FormelNr ;
            TCD_LONG       ProcID;
            TCD_INT        Typ ;
            U_TCDVALUE     Value ;
            TCD_INT        ProcIx;
        }            CFP ;

/*-
  Opcode:   TCD_OPC_GETNUM_FRM
--*/
        struct tagS_TCDPARGF {
            char  Name [TCD_NAME_LNG] ;
            TCD_LONG  FormelNr ;
        }            GF ;

/*-
  Opcode:   TCD_OPC_GET_PRC_INFO
--*/
        struct tagS_TCDPRCBINFO {
            TCD_LONG        ProcID;
            TCD_INT         ProcIx;
            P_TCDPRCELEM    pProcInfo;
            TCD_INT         AnzProcInfo ;
        }            PI ;

/*-
  Opcode:   TCD_OPC_REMOVE_RESULTS,
            TCD_OPC_GET_FIRST_RESULTS_INFO,
            TCD_OPC_GET_NEXT_RESULTS_INFO
--*/
        struct tagS_TCDPAR_RESULTPOOL {
            TCD_LONG        ProcID;
            TCD_LONG        lNumOfResults;
            TCD_INT         bFinished;
        }            RESP ;

   } S_TCDCTLPAR ;

   typedef S_TCDCTLPAR * P_TCDCTLPAR ;

   typedef struct tagS_TCDRBSCTL {
          TCD_INT       Opc     ;
          S_TCDRBSINFO  RbsInfo ;
          S_TCDRCINFO   RCInfo  ;
          S_TCDCTLPAR   Par     ;
  } S_TCDRBSCTL ;

   typedef S_TCDRBSCTL * P_TCDRBSCTL ;

/*------
  Datenstruktur Rechenbausteinschnittstelle
 --------*/
   typedef struct tagS_TCDV_F_FLAGS {
         TCD_BOOL       V_In   ;
         TCD_BOOL       F_In   ;
         TCD_BOOL       V_Comp ;
         TCD_BOOL       V_Use  ;
         TCD_BOOL       F_Use  ;
         TCD_BOOL       V_Miss ;
         TCD_BOOL       F_Miss ;
   } S_TCDV_F_FLAGS ;

   typedef S_TCDV_F_FLAGS * P_TCDV_F_FLAGS ;

   typedef struct tagS_TCDV_FLAGS {
         TCD_BOOL       V_In   ;
         TCD_BOOL       V_Use  ;
         TCD_BOOL       V_Miss ;
   } S_TCDV_FLAGS ;

   typedef S_TCDV_FLAGS   * P_TCDV_FLAGS   ;

   typedef struct tagS_TCDSKAL_DATA
   {
        TCD_DOUBLE      Val    ;
        TCD_LONG        Formel ;
        S_TCDV_F_FLAGS  Flags  ;
   } S_TCDSKAL_DATA ;

   typedef S_TCDSKAL_DATA * P_TCDSKAL_DATA ;

   typedef struct tagS_TCDTAB1_DATA
   {
     TCD_LONG        TabID;
     P_TCDTAB1       pVal ;
     TCD_LONG        Formel ;
     S_TCDV_F_FLAGS  Flags ;

   } S_TCDTAB1_DATA ;
   typedef S_TCDTAB1_DATA  * P_TCDTAB1_DATA  ;

   typedef struct tagS_TCDTAB2_DATA
   {
     TCD_LONG        TabID;
     P_TCDTAB2       pVal ;
     TCD_LONG        Formel ;
     S_TCDV_F_FLAGS  Flags ;

   } S_TCDTAB2_DATA ;
   typedef S_TCDTAB2_DATA * P_TCDTAB2_DATA ;

   typedef struct tagS_TCDDAT_DATA {
        char             Val [TCD_DATUM_LNG] ;
        S_TCDV_FLAGS     Flags ;
   } S_TCDDAT_DATA ;

   typedef S_TCDDAT_DATA * P_TCDDAT_DATA ;

   typedef struct tagS_TCDVGL_DATA {
        char            Val [TCD_VGLOP_LNG] ;
        S_TCDV_FLAGS    Flags ;
   } S_TCDVGL_DATA ;

   typedef S_TCDVGL_DATA * P_TCDVGL_DATA ;

   typedef struct tagS_TCD_RBS_SSA
   {
        P_TCDSKAL_DATA    pSkal ;
        P_TCDTAB1_DATA    pTab1 ;
        P_TCDTAB2_DATA    pTab2 ;
        P_TCDDAT_DATA     pDat  ;
        P_TCDVGL_DATA     pVgl  ;
   } S_TCD_RBS_SSA ;

   typedef S_TCD_RBS_SSA  * P_TCD_RBS_SSA ;


   typedef struct tagS_TCDRBS_SS {
       S_TCDRBSCTL       RCTL ;
       S_TCD_RBS_SSA     SSAData   ;
       S_TCDPOOLADMIN    PoolAdmin ;
       S_TCDMPRCADMIN    MPrcAdmin ;
 } S_TCDRBS_SS ;

 typedef S_TCDRBS_SS  * P_TCDRBS_SS ;

  typedef struct tagS_TCDPARATTR_SK {
        TCD_INT      Level ;
        TCD_DOUBLE   Val ;
 } S_TCDPARATTR_SK   ;

 typedef S_TCDPARATTR_SK  * P_TCDPARATTR_SK ;

  typedef struct tagS_TCDPARATTR_VGL {
        TCD_INT      Level;
        char         Val  [TCD_VGLOP_LNG] ;
 } S_TCDPARATTR_VGL  ;

 typedef S_TCDPARATTR_VGL * P_TCDPARATTR_VGL ;

  typedef struct tagS_TCDPARATTR_DAT
  {
        TCD_INT      Level;
        char         Val  [TCD_DATUM_LNG] ;
 } S_TCDPARATTR_DAT  ;

 typedef S_TCDPARATTR_DAT * P_TCDPARATTR_DAT ;

/*-----------
  Struktur Schnittstellendaten (interne Sicht)
-----------*/
  typedef struct tagS_TCDISSADATA
  {
     TCD_INT      AnzSSASkal ;
     TCD_INT      AnzSSATab1 ;
     TCD_INT      AnzSSATab2 ;
     TCD_INT      AnzSSADat ;
     TCD_INT      AnzSSAVgl ;
     TCD_INT      AnzParSkal;
     TCD_INT      AnzParVgl ;
     TCD_INT      AnzParDat ;
     TCD_INT      AnzZeilen ;
     TCD_INT      AnzSpalten ;
     P_TCDSKAL_DATA    pSkal ;
     P_TCDTAB1_DATA    pTab1 ;
     P_TCDTAB2_DATA    pTab2 ;
     P_TCDDAT_DATA     pDat ;
     P_TCDVGL_DATA     pVgl ;
     P_TCDPARATTR_SK   pParSkal ;
     P_TCDPARATTR_VGL  pParVgl;
     P_TCDPARATTR_DAT  pParDat;

 }   S_TCDISSADATA ;
 typedef S_TCDISSADATA * P_TCDISSADATA ;



/*------
Datenstruktur globale Daten des Rechenbausteins;
diese Datenstruktur enthaelt Informationen und Teilstrukturen, die
in den programmierten Funktionen benoetigt werden.
Initialisierung dieser Daten erfolgt mehrstufig.
- beim Init: globaler Pointer pTCDTCD initialisiert (zeigt auf die Str)
pRbsSS zeigt auf die RBS-Schnittstelle
- bei auspraegungsspez. Opcodes werden die Teilstrukturen fuer die
Auspraegung initialisiert, ...
- bei einer neuen Berechnung werden die internen Aufrufschnittstellen
initialisiert
--------*/
  typedef struct tagS_TCD_C_G
  {
      P_TCDRBS_SS      pRbsSS      ;
      P_TCDPRCELEM     pPrcData    ;
      S_TCDPRCHDR *    pPrcHdr     ;
      P_TCDPRCELEM     pPrcTreeNode;
      P_TCDPRCELEM     pInfo       ;
      P_TCDRELATTR_IMP pRelAttrs   ;
      P_TCDMPRCADMIN   pMPrcAdmin  ;
      P_TCDRBSCTL      pRbsCtl     ;
      S_TCDISSADATA    SSAData     ;
      P_TCDPOOLADMIN   pPoolAdmin  ;
      TCD_INT          GlbVarSet   ;
      TCD_LONG         RBS_ID      ;
      TCD_BOOL         ValFound    ;
      TCD_BOOL         FrmFound    ;
      TCD_BOOL         V_Comp      ;
      TCD_BOOL         PrcChg      ;
      void *           pApplIf     ;
      P_TCDTAB         ResTab      ;
      TCD_DOUBLE       ResSkal     ;
      
      TCD_LONG         LastCalcPrcID;
      LP_VECT          pErgebnisPool;
      TCD_LONG         iBerechnungsNummer;
      TCD_INT          iErgPoolIteratorGl;                       
      P_PAARLISTE      pPaarListeNotToSave;
      
      TCD_BOOL         btrace_open;
      TCD_BOOL         btrace_enabled;
      
/* RWE, 10.06.1997: Neues Datenelement fuer Beobachtung
   der Wiederverwendung (ehemals WatchPol-Funktionalitaet) */
      TCD_BOOL         bProtWV;
      
  }   S_TCD_C_G ;
  typedef S_TCD_C_G   * P_TCD_C_G ;
#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDI_H)
#define TCDI_H
/*--------------
    Name        : TCDI.H

    Beschreibung: Include File intern nur f�r C- Generator
                  wird von den fest programmierten Moduln und
                  generierten Moduln benoetigt
    By          : BEGGI
    Datum       : 22.02.94
    Historie    : BEG   28.11.95   Definition Attributklassen
*--------------*/

/*-------------
  Returncodes FrmRet und ValRet (Definitionen analog Cobol) fuer
  Attributmanager
---------------*/
#define TCD_AIRC_CALLVIAFRM    4

/*-------------
  Definitionen Attributtypen (Aufzaehlungstyp)
---------------*/
#define TCD_ATTYP_TAR_SKAL      1
#define TCD_ATTYP_TAR_TAB1      2
#define TCD_ATTYP_TAR_TAB2      3
#define TCD_ATTYP_TAR_DATE      4
#define TCD_ATTYP_TAR_VGLO      5
#define TCD_ATTYP_BST_SKAL      6
#define TCD_ATTYP_BST_TAB1      7
#define TCD_ATTYP_BST_TAB2      8
#define TCD_ATTYP_BST_DATE      9
#define TCD_ATTYP_BST_VGLO     10

#define TCD_ATTRTYP_SKAL        0
#define TCD_ATTRTYP_TAB1        1
#define TCD_ATTRTYP_TAB2        2
#define TCD_ATTRTYP_DATE        3
#define TCD_ATTRTYP_VGLO        4

/*--------------
  Definitionen Attributklasse
---------------*/
#define TCD_ATTRCLASS_TAR       1
#define TCD_ATTRCLASS_BST       6

/*-------------
  Definitionen Errorcodes
---------------*/
#define TCD_UNKNOWN_OPCODE       1
#define TCD_NO_SPACE_IN_TLIST    2
#define TCD_ERR_GETMEM           3
#define TCD_GETEMPTYENTRY        4
#define TCD_NOPOOLADMIN          5
#define TCD_ILLTABFMT            6
#define TCD_UNK_ASSIGNTYP        7
#define TCD_NO_MPRCADMIN         8
#define TCD_EXPPOOLADMIN         9
#define TCD_NO_MEMORY           10
#define TCD_NO_PRCREF           11
#define TCD_ILLFRM_ID           12
#define TCD_ILLFRM_CMP          13
#define TCD_ERR_INIT_FORMEL     14
#define TCD_FRMGEN_OUT_OF_DATE	15
#define TCD_TRPFMT_OUT_OF_DATE	16

/*----------
  Datenstruktur Freigabeliste  Hilfsvariablentabellen
 ------------*/
  typedef struct tagS_TCDTABLIST    {
         TCD_INT        CallOvw ;
         TCD_LONG       CallerID ;
         TCD_LONG       CallFrmNr ;
         TCD_INT        CallType  ;
         P_TCD_DOUBLE   Adr ;
 } S_TCDTABLIST   ;

 typedef  S_TCDTABLIST  * P_TCDTABLIST  ;

/*----------
  Datenstruktur Formelparameter
 ------------*/
  typedef struct tagS_TCD_C_F1 
  {
     char         * FormelName     ;
     TCD_INT        FrmTyp         ;
     TCD_LONG       FrmNr          ;
     TCD_INT        FrmIx          ;
     char         * AttrName       ;
     TCD_INT        CallType       ;
     TCD_LONG       AttrID         ;
     TCD_INT        AttrTyp        ;
     TCD_INT        AttrIx         ;
     TCD_INT        ParIx          ;
     TCD_INT        Ret            ;
     TCD_INT        ExecCond       ;
     P_TCDPRCNODE   PrcFNode       ;
     P_TCDPRCNODE   pNode          ;
     TCD_INT        MinVarSet      ;
     TCD_INT        BegVarSet      ;
     char         * CmpTime        ;
     TCD_INT        Level          ;
     P_TCD_DOUBLE   pVarSkal       ;
     P_P_TCDTAB     pVarTab        ;
     char         * VarDatVgl      ;
     TCD_INT      * VarIndex       ;
     P_TCDTABLIST   FreeList       ;
     TCD_INT        AnzTabList     ;
     TCD_INT        AnzTabListEnt  ;
     P_TCDPRCNODE   NextFNode      ;
     TCD_INT        NextExecCond   ;
     TCD_INT        NextCallType   ;
     struct tagS_TCD_C_F1 * pPrevLevelInfo ;
     P_TCD_C_G      pTCDTCD ;
  } S_TCD_C_F1 ;

  typedef  S_TCD_C_F1 *   P_TCD_C_F1 ;

  typedef struct tagS_TCDFTAB {
        char          FrmName [TCD_NAME_LNG] ;
        void          (* pFormelFunc ) ( P_TCD_C_F1);
        TCD_LONG      FrmNr      ;
        TCD_INT       FrmTyp     ;
        char          Datum [TCD_FRM_DATUM_LNG] ;
  } S_TCDFTAB     ;

 typedef S_TCDFTAB     * P_TCDFTAB     ;

/* extern P_TCD_C_G pTCDTCD ; */

#endif


/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_POOL_H)
#define TCD_POOL_H
/*---------------------------------------------------------------------
  Datei      : TCD_POOL.h
  Generiert am 16.12.2019 15:07:18
  Historie      : 27.7.95    BEG neuer Prefix fuer Tabellenentry
---------------------------------------------------------------------*/
void    TCDPIT   (P_TCD_C_G);
void    TCDPRP   (P_TCD_C_G) ;
void    TCDPST   (P_TCD_C_G) ;
void    TCDPRT   (P_TCD_C_G) ;
void    TCDPSAT  (P_TCD_C_G) ;
void    TCDPRTA  (P_TCD_C_G) ;
TCD_INT TCDPGF   (P_TCD_C_G,P_TCD_DOUBLE Var, TCD_INT *PIndex) ;

#endif

/*---------------------------------------------------------------------------

(C) Copyright 1993-2002, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------------*/
#if !defined (TCD_ATTR_H)
#define TCD_ATTR_H
/*---------------------------------------------------------------------
  Datei:        TCD_ATTR.H
  Beschreibung: Attributmanager
---------------------------------------------------------------------*/
TCD_INT   TCDAATS (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAATT (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAABS (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAABT (P_TCD_C_F1 pF1) ;
void      TCDAATD (P_TCD_C_F1 pF1) ;
void      TCDAABD (P_TCD_C_F1 pF1) ;
void      TCDAATV (P_TCD_C_F1 pF1) ;
void      TCDAABV (P_TCD_C_F1 pF1) ;
void      TCDAFT  (P_TCD_C_F1 pF1) ;
void      TCDAFBS (P_TCD_C_F1 pF1) ;
void      TCDAFBT (P_TCD_C_F1 pF1) ;

#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_FRT_H)
#define TCD_FRT_H
/*---------------------------------------------------------------------
    Datei:        TCD_FRT.H

Beschreibung: Modul zur allgemeinen Endebehandlung einer Formelfunktion
By:           BEGGI
Datum:        30.03.94
Historie:     BEG    28.11.95  neue Funktion: TCDSetPD
---------------------------------------------------------------------*/
TCD_INT TCDInit (P_TCD_C_F1 pMyPar, TCD_INT FrmNr, char *fctl_cmptime,
				 TCD_LONG VerNr);
void    TCDFtID (P_TCD_C_F1 pMyPar, char * AttrName,
                 TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                 TCD_INT *Var) ;

void    TCDSetPS (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                 TCD_DOUBLE *Var1, TCD_INT *Var2, TCD_DOUBLE Var3) ;
void    TCDSetPV (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                  char *Var1, TCD_INT *Var2, char *Var3) ;
void    TCDSetPD (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                  char *Var1, TCD_INT *Var2, char *Var3) ;

TCD_INT TCDGetTb (P_TCD_C_F1 pMyPar, P_P_TCDTAB Var) ;
void    TCDIniPS (P_TCD_C_G) ;

void    TCDIniFC (P_TCD_C_G) ;
void    TCDIniFU (P_TCD_C_G) ;
void    TCDIniFM (P_TCD_C_G) ;

void    TCDRetSk (P_TCD_C_F1 pMyPar, P_TCD_DOUBLE  VarSkal) ;
void    TCDRetTb (P_TCD_C_F1 pF1, P_P_TCDTAB  VarTab) ;

/*-----------------
  TraceFunktionsprototypen und Trace Makros
-------------------*/
#ifdef TRACEFKT
void _TCD_TRACE( const char * ,const char * ,const char *,P_TCD_C_G );
void _TCD_TRVAL( const char * , int , double *, double,P_TCD_C_G  ) ;

#define TCD_TRACE(pack,func,text, pTCDTCD)  \
            _TCD_TRACE(pack,func,text, pTCDTCD);
#define TCD_TRVAL(text,type,val1,val2, pTCDTCD) \
            _TCD_TRVAL(text,type,val1,val2, pTCDTCD);
#endif

#define C_TRACEFILE        "CTRACE.TCD"

#endif
  
/* RWE, 10.06.1997   */
/*-----------------
  Funktionsprototypen fuer Wiederverwendungsprotokoll
-------------------*/ 
#ifdef PROTWV
void     SetProtWV             (P_TCD_C_G pIf, TCD_BOOL bProtWV);   
  /* ^Dieser Prototyp ist auch in commands.c enthalten! */
TCD_BOOL ProtWVEnabled         (P_TCD_C_G pIf);
void     ProtWV1               (P_TCD_C_F1 pMyPar); 
void     ProtWV2               (P_TCD_C_F1   pMyPar, 
                                P_TCDPRCNODE pNode,
                                P_PAARLISTE  pPaarListe, 
                                TCD_INT      iFlag);
void     ProtWVString          (char *s);
                                
#define C_PROTWVFILE       "CPROTWV.TCD"
#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_IOP_H)
#define TCD_IOP_H

#ifndef SUBSYSTEM
  #define IOP_EXPORT 
#else
  #define IOP_EXPORT
#endif
TCD_DOUBLE IOP_EXPORT   TCDABS     (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDFAK     (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDINT     (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDSIGN    (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDDIV     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDEXP     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDMIN     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDMAX     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDZDAYS   (TCD_INT    datefmt, char *val1, 
                                    char *val2);
TCD_DOUBLE IOP_EXPORT   TCDKDAYS   (TCD_INT    datefmt, char *val1, 
                                    char *val2);
TCD_DOUBLE IOP_EXPORT   TCDRND     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDCUT     (TCD_DOUBLE val1, TCD_DOUBLE val2);


#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_FCTL_H)
#define TCD_FCTL_H
/*---------------------------------------------------------------------
  Modul:   TCD_FCTL.H
  f�r RBS: LifeTemplate
---------------------------------------------------------------------*/

void  LifeTemF(P_TCD_C_G pTCDTCD) ;
void  LifeTem1(P_TCD_C_F1  pF1 ) ;
void    TCD3FES (P_TCD_C_F1 pMyPar, char * AttrName, TCD_INT Ix,
                       TCD_LONG ID, TCD_INT AttrTyp, TCD_INT ParIx,
                       P_TCD_DOUBLE Var) ;
void    TCD3FET (P_TCD_C_F1 pMyPar, char * AttrName, TCD_INT Ix,
                      TCD_LONG ID, TCD_INT AttrTyp, P_P_TCDTAB Var);
void    TCD3FED (P_TCD_C_F1 pMyPar, char * AttrName,
                      TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                      TCD_INT ParIx, char *Var) ;
void    TCD3FEV (P_TCD_C_F1 pMyPar, char * AttrName,
                      TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                      TCD_INT ParIx, char *Var) ;
TCD_INT TCD3FE1 (P_TCD_C_F1 pMyPar, TCD_BOOL option, char * Name,
                      TCD_LONG ID, TCD_INT FrmNr, P_TCD_DOUBLE Var) ;
TCD_INT TCD3FE2 (P_TCD_C_F1 pMyPar, TCD_BOOL option, char * Name,
                      TCD_LONG ID, TCD_INT FrmNr, P_P_TCDTAB  Var) ;

TCD_INT TCDChkFrm     (P_TCD_C_F1,void *);
void    ClearOverwriteStack(P_TCD_C_G pTCDTCD );

void       TCD3FESaveResult(P_TCD_C_F1);

#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_PKF_H)
#define TCD_PKF_H
/*---------------------------------------------------------------------
    Modul:        C:\dev\TCD_DB\template\db\R3FE\C\C3E9\lifet143.h

    Beschreibung: Funktionsprototypen der externen Funktionen der
                  Formelsammlungsdatei
    By:           BEGGI
    Generiert am: 16.12.2019 15:07:19
---------------------------------------------------------------------*/
   
      void LifeTe90 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe91 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe92 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe93 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe94 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe95 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe96 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe97 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe98 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe99 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT100 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT101 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT102 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT103 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT104 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT105 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT106 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT107 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT108 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT109 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT110 (P_TCD_C_F1 pMyPar) ;
   

#endif



/*---------------------------------------------------------
   Externe Funktion : LifeT158
   Beschreibung: Die Funktion berechnet die Formel 
                 F_PBxn
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT158 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_1 = 0;
   TCD_DOUBLE  HV_3 = 0;
   TCD_DOUBLE  HV_4 = 0;
   TCD_DOUBLE  HV_6 = 0;
   TCD_DOUBLE  HV_7 = 0;
   TCD_DOUBLE  HV_9 = 0;
   TCD_DOUBLE  HV_11 = 0;
   TCD_DOUBLE  HV_13 = 0;
   TCD_DOUBLE  HV_14 = 0;
   TCD_DOUBLE  HV_15 = 0;
   TCD_DOUBLE  HV_16 = 0;
   TCD_DOUBLE  HV_18 = 0;
   TCD_DOUBLE  HV_19 = 0;
   TCD_DOUBLE  HV_20 = 0;
   TCD_DOUBLE  HV_22 = 0;
   TCD_DOUBLE  HV_24 = 0;
   TCD_DOUBLE  HV_25 = 0;
   TCD_DOUBLE  HV_27 = 0;
   TCD_DOUBLE  HV_29 = 0;
   TCD_DOUBLE  HV_30 = 0;
   TCD_DOUBLE  HV_31 = 0;
   TCD_DOUBLE  HV_32 = 0;
   TCD_DOUBLE  HV_34 = 0;
   TCD_DOUBLE  HV_35 = 0;
   TCD_DOUBLE  HV_37 = 0;
   TCD_DOUBLE  HV_38 = 0;
   TCD_DOUBLE  HV_40 = 0;
   TCD_DOUBLE  HV_42 = 0;
   TCD_DOUBLE  HV_43 = 0;
   TCD_DOUBLE  HV_44 = 0;
   TCD_DOUBLE  HV_45 = 0;
   TCD_DOUBLE  HV_46 = 0;
   TCD_DOUBLE  HV_48 = 0;
   TCD_DOUBLE  HV_49 = 0;
   TCD_DOUBLE  HV_50 = 0;
   TCD_DOUBLE  HV_51 = 0;
   TCD_DOUBLE  HV_52 = 0;
   TCD_DOUBLE  HV_53 = 0;
   TCD_DOUBLE  HV_55 = 0;
   TCD_DOUBLE  HV_57 = 0;
   TCD_DOUBLE  HV_62 = 0;
   TCD_DOUBLE  HV_63 = 0;
   TCD_DOUBLE  HV_64 = 0;
   TCD_DOUBLE  HV_65 = 0;
   TCD_DOUBLE  HV_66 = 0;
   TCD_DOUBLE  HV_68 = 0;
   TCD_DOUBLE  HV_69 = 0;
   TCD_DOUBLE  HV_70 = 0;
   TCD_DOUBLE  HV_71 = 0;
   TCD_DOUBLE  HV_72 = 0;
   TCD_DOUBLE  HV_73 = 0;
   TCD_DOUBLE  HV_75 = 0;
   TCD_DOUBLE  HV_76 = 0;
   TCD_DOUBLE  HV_77 = 0;
   TCD_DOUBLE  HV_79 = 0;
   TCD_DOUBLE  HV_80 = 0;
   TCD_DOUBLE  HV_81 = 0;
   TCD_DOUBLE  HV_82 = 0;
   TCD_DOUBLE  HV_83 = 0;
   TCD_DOUBLE  HV_84 = 0;
   TCD_DOUBLE  HV_85 = 0;
   TCD_INT     HV_0 = 0;
   TCD_INT     HV_2 = 0;
   TCD_INT     HV_5 = 0;
   TCD_INT     HV_8 = 0;
   TCD_INT     HV_10 = 0;
   TCD_INT     HV_12 = 0;
   TCD_INT     HV_17 = 0;
   TCD_INT     HV_21 = 0;
   TCD_INT     HV_23 = 0;
   TCD_INT     HV_26 = 0;
   TCD_INT     HV_28 = 0;
   TCD_INT     HV_33 = 0;
   TCD_INT     HV_36 = 0;
   TCD_INT     HV_39 = 0;
   TCD_INT     HV_41 = 0;
   TCD_INT     HV_47 = 0;
   TCD_INT     HV_54 = 0;
   TCD_INT     HV_56 = 0;
   TCD_INT     HV_58 = 0;
   TCD_INT     HV_59 = 0;
   TCD_INT     HV_60 = 0;
   TCD_INT     HV_67 = 0;
   TCD_INT     HV_74 = 0;
   TCD_INT     HV_78 = 0;
   TCD_INT     HV_86 = 0;
   TCD_INT     HV_87 = 0;
   TCD_INT     HV_88 = 0;
   TCD_INT     HV_89 = 0;
   TCD_INT     HV_90 = 0;
   TCD_INT     HV_91 = 0;
   TCD_INT     HV_92 = 0;
   TCD_INT     HV_93 = 0;
   TCD_INT     HV_94 = 0;
   TCD_INT     HV_95 = 0;
   TCD_INT     HV_96 = 0;
   TCD_INT     HV_97 = 0;
   TCD_INT     HV_98 = 0;
   TCD_INT     HV_99 = 0;
   TCD_INT     HV_100 = 0;
   TCD_INT     HV_101 = 0;
   TCD_INT     HV_102 = 0;
   TCD_INT     HV_103 = 0;
   TCD_INT     HV_104 = 0;
   TCD_INT     HV_105 = 0;
   TCD_INT     HV_106 = 0;
   TCD_INT     HV_107 = 0;
   TCD_INT     HV_108 = 0;
   TCD_INT     HV_109 = 0;
   TCD_INT     HV_110 = 0;
   P_TCDTAB2   HV_61;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT158","Begin F_PBxn",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,158,"12.12.2019 17:29:53",
                       20);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_7);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT158",
              "Ende F_PBxn",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_5 = 0;
      HV_8 = 0;
      HV_10 = 0;
      HV_12 = 0;
      HV_17 = 0;
      HV_21 = 0;
      HV_23 = 0;
      HV_26 = 0;
      HV_28 = 0;
      HV_33 = 0;
      HV_36 = 0;
      HV_39 = 0;
      HV_47 = 0;
      HV_54 = 0;
      HV_56 = 0;
      HV_60 = 0;
      HV_67 = 0;
      HV_74 = 0;
      HV_78 = 0;
      HV_86 = 0;
      HV_87 = 0;
      HV_88 = 0;
      HV_89 = 0;
      HV_90 = 0;
      HV_91 = 0;
      HV_92 = 0;
      HV_93 = 0;
      HV_94 = 0;
      HV_95 = 0;
      HV_96 = 0;
      HV_97 = 0;
      HV_98 = 0;
      HV_99 = 0;
      HV_100 = 0;
      HV_101 = 0;
      HV_102 = 0;
      HV_103 = 0;
      HV_104 = 0;
      HV_105 = 0;
      HV_106 = 0;
      HV_107 = 0;
      HV_108 = 0;
      HV_109 = 0;
      HV_110 = 0;
      if ( HV_2 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "e_tarsumme_ges_o", 11, 134, 6, 11, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_5: 
      HV_4 = HV_3 - 1.0;
      if ( HV_0 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "e_tarsumme_ges_n", 4, 27, 6, 4, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_8: 
      if ( HV_1 >= HV_4 ) goto l_24 ;
      goto l_315 ;
   l_24: 
      if ( HV_5 != 0 ) goto l_11 ;
      rc = TCD3FE1 (pMyPar, 2, "F_PremCashValue", 674, 674, &HV_6);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_5 = 1;
   l_11: 
      if ( HV_6 > 0 ) goto l_36 ;
      goto l_165 ;
   l_36: 
      if ( HV_87 != 0 ) goto l_79 ;
      if ( HV_12 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "F_SecurityLoading", 673, 673, &HV_13);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_12 = 1;
   l_14: 
      HV_14 = 1 + HV_13;
      HV_87 = 1;
   l_79: 
      if ( HV_88 != 0 ) goto l_73 ;
      if ( HV_10 != 0 ) goto l_17 ;
      rc = TCD3FE1 (pMyPar, 2, "F_A1xn", 280, 280, &HV_11);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_10 = 1;
   l_17: 
      HV_15 = HV_11 * HV_14;
      HV_88 = 1;
   l_73: 
      if ( HV_89 != 0 ) goto l_67 ;
      if ( HV_8 != 0 ) goto l_20 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Exn", 258, 258, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_8 = 1;
   l_20: 
      HV_16 = HV_9 + HV_15;
      HV_89 = 1;
   l_67: 
      if ( HV_90 != 0 ) goto l_64 ;
      if ( HV_17 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_Gamma1", 52, 400, 1, 140, &HV_18);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_17 = 1;
   l_23: 
      HV_19 = HV_16 + HV_18;
      HV_90 = 1;
   l_64: 
      if ( HV_91 != 0 ) goto l_61 ;
      if ( HV_0 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "e_tarsumme_ges_n", 4, 27, 6, 4, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_26: 
      HV_20 = HV_19 * HV_1;
      HV_91 = 1;
   l_61: 
      if ( HV_86 != 0 ) goto l_97 ;
      if ( HV_21 != 0 ) goto l_29 ;
      rc = TCD3FE1 (pMyPar, 2, "F_SumsOfPrem_o", 735, 735, &HV_22);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_21 = 1;
   l_29: 
      if ( HV_23 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "i_AddContrib", 33, 355, 1, 121, &HV_24);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_23 = 1;
   l_32: 
      HV_25 = HV_22 + HV_24;
      HV_86 = 1;
   l_97: 
      if ( HV_92 != 0 ) goto l_106 ;
      if ( HV_26 != 0 ) goto l_35 ;
      rc = TCD3FE1 (pMyPar, 2, "F_A2xn_sub", 275, 275, &HV_27);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_26 = 1;
   l_35: 
      if ( HV_28 != 0 ) goto l_38 ;
      TCD3FES (pMyPar, "i_Gamma2", 53, 401, 1, 141, &HV_29);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_28 = 1;
   l_38: 
      HV_30 = HV_27 + HV_29;
      HV_92 = 1;
   l_106: 
      if ( HV_93 != 0 ) goto l_94 ;
      HV_31 = HV_25 * HV_30;
      HV_93 = 1;
   l_94: 
      if ( HV_94 != 0 ) goto l_58 ;
      HV_32 = HV_20 + HV_31;
      HV_94 = 1;
   l_58: 
      if ( HV_95 != 0 ) goto l_55 ;
      if ( HV_33 != 0 ) goto l_41 ;
      TCD3FES (pMyPar, "i_CreditableReseve", 59, 412, 1, 147, &HV_34);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_33 = 1;
   l_41: 
      HV_35 = HV_32 - HV_34;
      HV_95 = 1;
   l_55: 
      if ( HV_96 != 0 ) goto l_52 ;
      if ( HV_36 != 0 ) goto l_44 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AC_CashValue", 779, 779, &HV_37);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_36 = 1;
   l_44: 
      HV_38 = HV_35 + HV_37;
      HV_96 = 1;
   l_52: 
      if ( HV_86 != 0 ) goto l_124 ;
      if ( HV_21 != 0 ) goto l_47 ;
      rc = TCD3FE1 (pMyPar, 2, "F_SumsOfPrem_o", 735, 735, &HV_22);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_21 = 1;
   l_47: 
      if ( HV_23 != 0 ) goto l_50 ;
      TCD3FES (pMyPar, "i_AddContrib", 33, 355, 1, 121, &HV_24);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_23 = 1;
   l_50: 
      HV_25 = HV_22 + HV_24;
      HV_86 = 1;
   l_124: 
      if ( HV_39 != 0 ) goto l_53 ;
      rc = TCD3FE1 (pMyPar, 2, "F_CommReduction_o", 633, 633, &HV_40);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_39 = 1;
   l_53: 
      if ( HV_97 != 0 ) goto l_133 ;
   TCDSetPS (pMyPar, 1, 146, &HV_42, &HV_41, HV_40);
      rc = TCD3FE1 (pMyPar, 4, "F_Alpha2_Permille", 672, 672, &HV_43);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 146, &HV_42, &HV_41, HV_40);
      HV_97 = 1;
   l_133: 
      if ( HV_98 != 0 ) goto l_121 ;
      HV_44 = HV_25 * HV_43;
      HV_98 = 1;
   l_121: 
      HV_45 = HV_38 + HV_44;
      if ( HV_99 != 0 ) goto l_148 ;
      if ( HV_0 != 0 ) goto l_56 ;
      TCD3FES (pMyPar, "e_tarsumme_ges_n", 4, 27, 6, 4, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_56: 
      if ( HV_2 != 0 ) goto l_59 ;
      TCD3FES (pMyPar, "e_tarsumme_ges_o", 11, 134, 6, 11, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_59: 
      HV_46 = HV_1 - HV_3;
      HV_99 = 1;
   l_148: 
      if ( HV_100 != 0 ) goto l_145 ;
      if ( HV_47 != 0 ) goto l_62 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Alpha1_Permille", 671, 671, &HV_48);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_47 = 1;
   l_62: 
      HV_49 = HV_46 * HV_48;
      HV_100 = 1;
   l_145: 
      HV_50 = HV_45 + HV_49;
      if ( HV_5 != 0 ) goto l_65 ;
      rc = TCD3FE1 (pMyPar, 2, "F_PremCashValue", 674, 674, &HV_6);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_5 = 1;
   l_65: 
   if ( HV_6 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_51 = HV_50 / HV_6;
      HV_52 =   TCDRND ( HV_51, 2 ) ;
      HV_7 = HV_52;
      goto l_3 ;
   l_165: 
      if ( HV_87 != 0 ) goto l_205 ;
      if ( HV_12 != 0 ) goto l_68 ;
      rc = TCD3FE1 (pMyPar, 2, "F_SecurityLoading", 673, 673, &HV_13);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_12 = 1;
   l_68: 
      HV_14 = 1 + HV_13;
      HV_87 = 1;
   l_205: 
      if ( HV_88 != 0 ) goto l_199 ;
      if ( HV_10 != 0 ) goto l_71 ;
      rc = TCD3FE1 (pMyPar, 2, "F_A1xn", 280, 280, &HV_11);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_10 = 1;
   l_71: 
      HV_15 = HV_11 * HV_14;
      HV_88 = 1;
   l_199: 
      if ( HV_89 != 0 ) goto l_193 ;
      if ( HV_8 != 0 ) goto l_74 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Exn", 258, 258, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_8 = 1;
   l_74: 
      HV_16 = HV_9 + HV_15;
      HV_89 = 1;
   l_193: 
      if ( HV_90 != 0 ) goto l_190 ;
      if ( HV_17 != 0 ) goto l_77 ;
      TCD3FES (pMyPar, "i_Gamma1", 52, 400, 1, 140, &HV_18);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_17 = 1;
   l_77: 
      HV_19 = HV_16 + HV_18;
      HV_90 = 1;
   l_190: 
      if ( HV_91 != 0 ) goto l_187 ;
      if ( HV_0 != 0 ) goto l_80 ;
      TCD3FES (pMyPar, "e_tarsumme_ges_n", 4, 27, 6, 4, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_80: 
      HV_20 = HV_19 * HV_1;
      HV_91 = 1;
   l_187: 
      if ( HV_86 != 0 ) goto l_223 ;
      if ( HV_21 != 0 ) goto l_83 ;
      rc = TCD3FE1 (pMyPar, 2, "F_SumsOfPrem_o", 735, 735, &HV_22);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_21 = 1;
   l_83: 
      if ( HV_23 != 0 ) goto l_86 ;
      TCD3FES (pMyPar, "i_AddContrib", 33, 355, 1, 121, &HV_24);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_23 = 1;
   l_86: 
      HV_25 = HV_22 + HV_24;
      HV_86 = 1;
   l_223: 
      if ( HV_92 != 0 ) goto l_232 ;
      if ( HV_26 != 0 ) goto l_89 ;
      rc = TCD3FE1 (pMyPar, 2, "F_A2xn_sub", 275, 275, &HV_27);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_26 = 1;
   l_89: 
      if ( HV_28 != 0 ) goto l_92 ;
      TCD3FES (pMyPar, "i_Gamma2", 53, 401, 1, 141, &HV_29);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_28 = 1;
   l_92: 
      HV_30 = HV_27 + HV_29;
      HV_92 = 1;
   l_232: 
      if ( HV_93 != 0 ) goto l_220 ;
      HV_31 = HV_25 * HV_30;
      HV_93 = 1;
   l_220: 
      if ( HV_94 != 0 ) goto l_184 ;
      HV_32 = HV_20 + HV_31;
      HV_94 = 1;
   l_184: 
      if ( HV_95 != 0 ) goto l_181 ;
      if ( HV_33 != 0 ) goto l_95 ;
      TCD3FES (pMyPar, "i_CreditableReseve", 59, 412, 1, 147, &HV_34);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_33 = 1;
   l_95: 
      HV_35 = HV_32 - HV_34;
      HV_95 = 1;
   l_181: 
      if ( HV_96 != 0 ) goto l_178 ;
      if ( HV_36 != 0 ) goto l_98 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AC_CashValue", 779, 779, &HV_37);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_36 = 1;
   l_98: 
      HV_38 = HV_35 + HV_37;
      HV_96 = 1;
   l_178: 
      if ( HV_86 != 0 ) goto l_253 ;
      if ( HV_21 != 0 ) goto l_101 ;
      rc = TCD3FE1 (pMyPar, 2, "F_SumsOfPrem_o", 735, 735, &HV_22);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_21 = 1;
   l_101: 
      if ( HV_23 != 0 ) goto l_104 ;
      TCD3FES (pMyPar, "i_AddContrib", 33, 355, 1, 121, &HV_24);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_23 = 1;
   l_104: 
      HV_25 = HV_22 + HV_24;
      HV_86 = 1;
   l_253: 
      if ( HV_39 != 0 ) goto l_107 ;
      rc = TCD3FE1 (pMyPar, 2, "F_CommReduction_o", 633, 633, &HV_40);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_39 = 1;
   l_107: 
      if ( HV_97 != 0 ) goto l_262 ;
   TCDSetPS (pMyPar, 1, 146, &HV_42, &HV_41, HV_40);
      rc = TCD3FE1 (pMyPar, 4, "F_Alpha2_Permille", 672, 672, &HV_43);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 146, &HV_42, &HV_41, HV_40);
      HV_97 = 1;
   l_262: 
      if ( HV_98 != 0 ) goto l_250 ;
      HV_44 = HV_25 * HV_43;
      HV_98 = 1;
   l_250: 
      if ( HV_39 != 0 ) goto l_110 ;
      rc = TCD3FE1 (pMyPar, 2, "F_CommReduction_o", 633, 633, &HV_40);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_39 = 1;
   l_110: 
   TCDSetPS (pMyPar, 1, 146, &HV_42, &HV_41, HV_40);
      rc = TCD3FE1 (pMyPar, 4, "F_AC_total", 781, 781, &HV_53);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 146, &HV_42, &HV_41, HV_40);
      if ( HV_54 != 0 ) goto l_113 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_55);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_54 = 1;
   l_113: 
      HV_58 = (TCD_INT) ( HV_55) ;
      if ( HV_56 != 0 ) goto l_116 ;
      rc = TCD3FE1 (pMyPar, 2, "_Alpha2", 468, 468, &HV_57);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_56 = 1;
   l_116: 
      HV_59 = (TCD_INT) ( HV_57) ;
      if ( HV_60 != 0 ) goto l_119 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_61);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_60 = 1;
   l_119: 
      if ( HV_59 < 0 || HV_59 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
         1) { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_58 < 0 || HV_58 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_62 = HV_53 * HV_61 [ HV_58 * 110 + HV_59 ] ;
      HV_63 = HV_44 - HV_62;
      HV_64 = HV_38 + HV_63;
      if ( HV_99 != 0 ) goto l_301 ;
      if ( HV_0 != 0 ) goto l_122 ;
      TCD3FES (pMyPar, "e_tarsumme_ges_n", 4, 27, 6, 4, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_122: 
      if ( HV_2 != 0 ) goto l_125 ;
      TCD3FES (pMyPar, "e_tarsumme_ges_o", 11, 134, 6, 11, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_125: 
      HV_46 = HV_1 - HV_3;
      HV_99 = 1;
   l_301: 
      if ( HV_100 != 0 ) goto l_298 ;
      if ( HV_47 != 0 ) goto l_128 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Alpha1_Permille", 671, 671, &HV_48);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_47 = 1;
   l_128: 
      HV_49 = HV_46 * HV_48;
      HV_100 = 1;
   l_298: 
      HV_65 = HV_64 + HV_49;
      HV_66 =   TCDRND ( HV_65, 2 ) ;
      HV_7 = HV_66;
      goto l_3 ;
   l_315: 
      if ( HV_5 != 0 ) goto l_131 ;
      rc = TCD3FE1 (pMyPar, 2, "F_PremCashValue", 674, 674, &HV_6);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_5 = 1;
   l_131: 
      if ( HV_6 > 0 ) goto l_327 ;
      goto l_462 ;
   l_327: 
      if ( HV_87 != 0 ) goto l_367 ;
      if ( HV_12 != 0 ) goto l_134 ;
      rc = TCD3FE1 (pMyPar, 2, "F_SecurityLoading", 673, 673, &HV_13);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_12 = 1;
   l_134: 
      HV_14 = 1 + HV_13;
      HV_87 = 1;
   l_367: 
      if ( HV_88 != 0 ) goto l_361 ;
      if ( HV_10 != 0 ) goto l_137 ;
      rc = TCD3FE1 (pMyPar, 2, "F_A1xn", 280, 280, &HV_11);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_10 = 1;
   l_137: 
      HV_15 = HV_11 * HV_14;
      HV_88 = 1;
   l_361: 
      if ( HV_89 != 0 ) goto l_355 ;
      if ( HV_8 != 0 ) goto l_140 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Exn", 258, 258, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_8 = 1;
   l_140: 
      HV_16 = HV_9 + HV_15;
      HV_89 = 1;
   l_355: 
      if ( HV_101 != 0 ) goto l_352 ;
      if ( HV_67 != 0 ) goto l_143 ;
      TCD3FES (pMyPar, "i_Alpha1", 48, 396, 1, 136, &HV_68);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_67 = 1;
   l_143: 
      HV_69 = HV_16 + HV_68;
      HV_101 = 1;
   l_352: 
      if ( HV_102 != 0 ) goto l_349 ;
      if ( HV_17 != 0 ) goto l_146 ;
      TCD3FES (pMyPar, "i_Gamma1", 52, 400, 1, 140, &HV_18);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_17 = 1;
   l_146: 
      HV_70 = HV_69 + HV_18;
      HV_102 = 1;
   l_349: 
      if ( HV_103 != 0 ) goto l_346 ;
      if ( HV_0 != 0 ) goto l_149 ;
      TCD3FES (pMyPar, "e_tarsumme_ges_n", 4, 27, 6, 4, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_149: 
      HV_71 = HV_70 * HV_1;
      HV_103 = 1;
   l_346: 
      if ( HV_86 != 0 ) goto l_388 ;
      if ( HV_21 != 0 ) goto l_152 ;
      rc = TCD3FE1 (pMyPar, 2, "F_SumsOfPrem_o", 735, 735, &HV_22);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_21 = 1;
   l_152: 
      if ( HV_23 != 0 ) goto l_155 ;
      TCD3FES (pMyPar, "i_AddContrib", 33, 355, 1, 121, &HV_24);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_23 = 1;
   l_155: 
      HV_25 = HV_22 + HV_24;
      HV_86 = 1;
   l_388: 
      if ( HV_92 != 0 ) goto l_397 ;
      if ( HV_26 != 0 ) goto l_158 ;
      rc = TCD3FE1 (pMyPar, 2, "F_A2xn_sub", 275, 275, &HV_27);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_26 = 1;
   l_158: 
      if ( HV_28 != 0 ) goto l_161 ;
      TCD3FES (pMyPar, "i_Gamma2", 53, 401, 1, 141, &HV_29);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_28 = 1;
   l_161: 
      HV_30 = HV_27 + HV_29;
      HV_92 = 1;
   l_397: 
      if ( HV_93 != 0 ) goto l_385 ;
      HV_31 = HV_25 * HV_30;
      HV_93 = 1;
   l_385: 
      if ( HV_104 != 0 ) goto l_343 ;
      HV_72 = HV_71 + HV_31;
      HV_104 = 1;
   l_343: 
      if ( HV_105 != 0 ) goto l_340 ;
      if ( HV_33 != 0 ) goto l_164 ;
      TCD3FES (pMyPar, "i_CreditableReseve", 59, 412, 1, 147, &HV_34);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_33 = 1;
   l_164: 
      HV_73 = HV_72 - HV_34;
      HV_105 = 1;
   l_340: 
      if ( HV_106 != 0 ) goto l_415 ;
      if ( HV_74 != 0 ) goto l_167 ;
      rc = TCD3FE1 (pMyPar, 2, "F_IsProlongation", 662, 662, &HV_75);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_74 = 1;
   l_167: 
      HV_76 = 1 - HV_75;
      HV_106 = 1;
   l_415: 
      if ( HV_107 != 0 ) goto l_412 ;
      HV_77 =   TCDRND ( HV_76, 0 ) ;
      HV_107 = 1;
   l_412: 
      if ( HV_86 != 0 ) goto l_433 ;
      if ( HV_21 != 0 ) goto l_170 ;
      rc = TCD3FE1 (pMyPar, 2, "F_SumsOfPrem_o", 735, 735, &HV_22);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_21 = 1;
   l_170: 
      if ( HV_23 != 0 ) goto l_173 ;
      TCD3FES (pMyPar, "i_AddContrib", 33, 355, 1, 121, &HV_24);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_23 = 1;
   l_173: 
      HV_25 = HV_22 + HV_24;
      HV_86 = 1;
   l_433: 
      if ( HV_39 != 0 ) goto l_176 ;
      rc = TCD3FE1 (pMyPar, 2, "F_CommReduction_o", 633, 633, &HV_40);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_39 = 1;
   l_176: 
      if ( HV_97 != 0 ) goto l_442 ;
   TCDSetPS (pMyPar, 1, 146, &HV_42, &HV_41, HV_40);
      rc = TCD3FE1 (pMyPar, 4, "F_Alpha2_Permille", 672, 672, &HV_43);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 146, &HV_42, &HV_41, HV_40);
      HV_97 = 1;
   l_442: 
      if ( HV_98 != 0 ) goto l_430 ;
      HV_44 = HV_25 * HV_43;
      HV_98 = 1;
   l_430: 
      if ( HV_108 != 0 ) goto l_427 ;
      if ( HV_78 != 0 ) goto l_179 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AC_Original", 777, 777, &HV_79);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_78 = 1;
   l_179: 
      HV_80 = HV_44 - HV_79;
      HV_108 = 1;
   l_427: 
      if ( HV_109 != 0 ) goto l_409 ;
      HV_81 = HV_77 * HV_80;
      HV_109 = 1;
   l_409: 
      if ( HV_110 != 0 ) goto l_337 ;
      HV_82 = HV_73 + HV_81;
      HV_110 = 1;
   l_337: 
      if ( HV_5 != 0 ) goto l_182 ;
      rc = TCD3FE1 (pMyPar, 2, "F_PremCashValue", 674, 674, &HV_6);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_5 = 1;
   l_182: 
   if ( HV_6 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_83 = HV_82 / HV_6;
      HV_84 =   TCDRND ( HV_83, 2 ) ;
      HV_7 = HV_84;
      goto l_3 ;
   l_462: 
      if ( HV_87 != 0 ) goto l_499 ;
      if ( HV_12 != 0 ) goto l_185 ;
      rc = TCD3FE1 (pMyPar, 2, "F_SecurityLoading", 673, 673, &HV_13);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_12 = 1;
   l_185: 
      HV_14 = 1 + HV_13;
      HV_87 = 1;
   l_499: 
      if ( HV_88 != 0 ) goto l_493 ;
      if ( HV_10 != 0 ) goto l_188 ;
      rc = TCD3FE1 (pMyPar, 2, "F_A1xn", 280, 280, &HV_11);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_10 = 1;
   l_188: 
      HV_15 = HV_11 * HV_14;
      HV_88 = 1;
   l_493: 
      if ( HV_89 != 0 ) goto l_487 ;
      if ( HV_8 != 0 ) goto l_191 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Exn", 258, 258, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_8 = 1;
   l_191: 
      HV_16 = HV_9 + HV_15;
      HV_89 = 1;
   l_487: 
      if ( HV_101 != 0 ) goto l_484 ;
      if ( HV_67 != 0 ) goto l_194 ;
      TCD3FES (pMyPar, "i_Alpha1", 48, 396, 1, 136, &HV_68);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_67 = 1;
   l_194: 
      HV_69 = HV_16 + HV_68;
      HV_101 = 1;
   l_484: 
      if ( HV_102 != 0 ) goto l_481 ;
      if ( HV_17 != 0 ) goto l_197 ;
      TCD3FES (pMyPar, "i_Gamma1", 52, 400, 1, 140, &HV_18);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_17 = 1;
   l_197: 
      HV_70 = HV_69 + HV_18;
      HV_102 = 1;
   l_481: 
      if ( HV_103 != 0 ) goto l_478 ;
      if ( HV_0 != 0 ) goto l_200 ;
      TCD3FES (pMyPar, "e_tarsumme_ges_n", 4, 27, 6, 4, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_200: 
      HV_71 = HV_70 * HV_1;
      HV_103 = 1;
   l_478: 
      if ( HV_86 != 0 ) goto l_520 ;
      if ( HV_21 != 0 ) goto l_203 ;
      rc = TCD3FE1 (pMyPar, 2, "F_SumsOfPrem_o", 735, 735, &HV_22);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_21 = 1;
   l_203: 
      if ( HV_23 != 0 ) goto l_206 ;
      TCD3FES (pMyPar, "i_AddContrib", 33, 355, 1, 121, &HV_24);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_23 = 1;
   l_206: 
      HV_25 = HV_22 + HV_24;
      HV_86 = 1;
   l_520: 
      if ( HV_92 != 0 ) goto l_529 ;
      if ( HV_26 != 0 ) goto l_209 ;
      rc = TCD3FE1 (pMyPar, 2, "F_A2xn_sub", 275, 275, &HV_27);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_26 = 1;
   l_209: 
      if ( HV_28 != 0 ) goto l_212 ;
      TCD3FES (pMyPar, "i_Gamma2", 53, 401, 1, 141, &HV_29);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_28 = 1;
   l_212: 
      HV_30 = HV_27 + HV_29;
      HV_92 = 1;
   l_529: 
      if ( HV_93 != 0 ) goto l_517 ;
      HV_31 = HV_25 * HV_30;
      HV_93 = 1;
   l_517: 
      if ( HV_104 != 0 ) goto l_475 ;
      HV_72 = HV_71 + HV_31;
      HV_104 = 1;
   l_475: 
      if ( HV_105 != 0 ) goto l_472 ;
      if ( HV_33 != 0 ) goto l_215 ;
      TCD3FES (pMyPar, "i_CreditableReseve", 59, 412, 1, 147, &HV_34);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_33 = 1;
   l_215: 
      HV_73 = HV_72 - HV_34;
      HV_105 = 1;
   l_472: 
      if ( HV_106 != 0 ) goto l_547 ;
      if ( HV_74 != 0 ) goto l_218 ;
      rc = TCD3FE1 (pMyPar, 2, "F_IsProlongation", 662, 662, &HV_75);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_74 = 1;
   l_218: 
      HV_76 = 1 - HV_75;
      HV_106 = 1;
   l_547: 
      if ( HV_107 != 0 ) goto l_544 ;
      HV_77 =   TCDRND ( HV_76, 0 ) ;
      HV_107 = 1;
   l_544: 
      if ( HV_86 != 0 ) goto l_565 ;
      if ( HV_21 != 0 ) goto l_221 ;
      rc = TCD3FE1 (pMyPar, 2, "F_SumsOfPrem_o", 735, 735, &HV_22);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_21 = 1;
   l_221: 
      if ( HV_23 != 0 ) goto l_224 ;
      TCD3FES (pMyPar, "i_AddContrib", 33, 355, 1, 121, &HV_24);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_23 = 1;
   l_224: 
      HV_25 = HV_22 + HV_24;
      HV_86 = 1;
   l_565: 
      if ( HV_39 != 0 ) goto l_227 ;
      rc = TCD3FE1 (pMyPar, 2, "F_CommReduction_o", 633, 633, &HV_40);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_39 = 1;
   l_227: 
      if ( HV_97 != 0 ) goto l_574 ;
   TCDSetPS (pMyPar, 1, 146, &HV_42, &HV_41, HV_40);
      rc = TCD3FE1 (pMyPar, 4, "F_Alpha2_Permille", 672, 672, &HV_43);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 146, &HV_42, &HV_41, HV_40);
      HV_97 = 1;
   l_574: 
      if ( HV_98 != 0 ) goto l_562 ;
      HV_44 = HV_25 * HV_43;
      HV_98 = 1;
   l_562: 
      if ( HV_108 != 0 ) goto l_559 ;
      if ( HV_78 != 0 ) goto l_230 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AC_Original", 777, 777, &HV_79);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_78 = 1;
   l_230: 
      HV_80 = HV_44 - HV_79;
      HV_108 = 1;
   l_559: 
      if ( HV_109 != 0 ) goto l_541 ;
      HV_81 = HV_77 * HV_80;
      HV_109 = 1;
   l_541: 
      if ( HV_110 != 0 ) goto l_469 ;
      HV_82 = HV_73 + HV_81;
      HV_110 = 1;
   l_469: 
      HV_85 =   TCDRND ( HV_82, 2 ) ;
      HV_7 = HV_85;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_7);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT158","End F_PBxn",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_PBxn", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_PBxn", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_PBxn");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT573
   Beschreibung: Die Funktion berechnet die Formel 
                 F_RateClass
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT573 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_3 = 1;
      TCD_INT     HV_6 = 1;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_8 = 1;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_10 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT573","Begin F_RateClass",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,573,"12.12.2019 17:29:53",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT573",
              "Ende F_RateClass",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "e_RateClass_n", 33, 361, 6, 33, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 1 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 1;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_0 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "e_RateClass_n", 33, 361, 6, 33, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_8: 
      if ( HV_1 == 2 ) goto l_36 ;
      goto l_60 ;
   l_36: 
      if ( HV_4 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "e_BackOffice", 30, 352, 6, 30, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_11: 
      if ( HV_5 == 1 ) goto l_48 ;
      goto l_54 ;
   l_48: 
      HV_6 = 1;
      HV_2 = HV_6;
      goto l_3 ;
   l_54: 
      HV_7 = 0;
      HV_2 = HV_7;
      goto l_3 ;
   l_60: 
      if ( HV_0 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "e_RateClass_n", 33, 361, 6, 33, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_14: 
      if ( HV_1 == 3 ) goto l_72 ;
      goto l_96 ;
   l_72: 
      if ( HV_4 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "e_BackOffice", 30, 352, 6, 30, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_17: 
      if ( HV_5 == 1 ) goto l_84 ;
      goto l_90 ;
   l_84: 
      HV_8 = 1;
      HV_2 = HV_8;
      goto l_3 ;
   l_90: 
      HV_9 = 0;
      HV_2 = HV_9;
      goto l_3 ;
   l_96: 
      HV_10 = 0;
      HV_2 = HV_10;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT573","End F_RateClass",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_RateClass", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_RateClass", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_RateClass");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT581
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Calc_Allowed
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT581 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_11 = 0;
      TCD_INT     HV_14 = 0;
      TCD_INT     HV_16 = 0;
      TCD_INT     HV_20 = 0;
      TCD_INT     HV_22 = 0;
      TCD_INT     HV_25 = 0;
      TCD_INT     HV_27 = 0;
      TCD_INT     HV_29 = 0;
      TCD_INT     HV_30 = 0;
      TCD_INT     HV_31 = 0;
      TCD_INT     HV_35 = 0;
      P_TCDTAB2   HV_32;
      TCD_INT     HV_3 = 1;
      TCD_INT     HV_19 = 4;
      TCD_INT     HV_24 = 2;
      TCD_INT     HV_33 = 1;
      TCD_INT     HV_34 = 2;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT581","Begin F_Calc_Allowed",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,581,"12.12.2019 17:29:53",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT581",
              "Ende F_Calc_Allowed",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      HV_9 = 0;
      HV_14 = 0;
      HV_20 = 0;
      HV_22 = 0;
      HV_25 = 0;
      HV_27 = 0;
      HV_31 = 0;
      HV_35 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "e_BackOffice", 30, 352, 6, 30, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 1 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 1;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_4 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "e_CalcDate", 29, 351, 6, 29, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_8: 
      if ( HV_35 != 0 ) goto l_34 ;
   TCDSetPS (pMyPar, 1, 116, &HV_7, &HV_6, HV_5);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_8);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_7, &HV_6, HV_5);
      HV_35 = 1;
   l_34: 
      if ( HV_9 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "e_currentDate_n", 28, 348, 6, 28, &HV_10);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_9 = 1;
   l_11: 
   TCDSetPS (pMyPar, 1, 116, &HV_12, &HV_11, HV_10);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_13);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_12, &HV_11, HV_10);
      if ( HV_8 <  HV_13 ) goto l_57 ;
      goto l_90 ;
   l_57: 
      if ( HV_4 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "e_CalcDate", 29, 351, 6, 29, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_14: 
      if ( HV_35 != 0 ) goto l_61 ;
   TCDSetPS (pMyPar, 1, 116, &HV_7, &HV_6, HV_5);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_8);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_7, &HV_6, HV_5);
      HV_35 = 1;
   l_61: 
      if ( HV_14 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "e_TBeg_n", 2, 19, 6, 2, &HV_15);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_14 = 1;
   l_17: 
   TCDSetPS (pMyPar, 1, 116, &HV_17, &HV_16, HV_15);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_18);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_17, &HV_16, HV_15);
      if ( HV_8 == HV_18 ) goto l_84 ;
      goto l_90 ;
   l_84: 
      HV_19 = 4;
      HV_2 = HV_19;
      goto l_3 ;
   l_90: 
      if ( HV_20 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_AddContrib", 33, 355, 1, 121, &HV_21);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_20 = 1;
   l_20: 
      if ( HV_21 != 0 ) goto l_114 ;
      goto l_105 ;
   l_105: 
      if ( HV_22 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_PartSurrender", 34, 356, 1, 122, &HV_23);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_22 = 1;
   l_23: 
      if ( HV_23 != 0 ) goto l_114 ;
      goto l_120 ;
   l_114: 
      HV_24 = 2;
      HV_2 = HV_24;
      goto l_3 ;
   l_120: 
      if ( HV_25 != 0 ) goto l_26 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_26);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_25 = 1;
   l_26: 
      HV_29 = (TCD_INT) ( HV_26) ;
      if ( HV_27 != 0 ) goto l_29 ;
      rc = TCD3FE1 (pMyPar, 2, "_Calc_NonBackOffice", 588, 588,
         &HV_28);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_27 = 1;
   l_29: 
      HV_30 = (TCD_INT) ( HV_28) ;
      if ( HV_31 != 0 ) goto l_32 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_32);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_31 = 1;
   l_32: 
      if ( HV_30 < 0 || HV_30 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
         1) { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_29 < 0 || HV_29 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_32 [ HV_29 * 110 + HV_30 ]  == 1 ) goto l_138 ;
      goto l_144 ;
   l_138: 
      HV_33 = 1;
      HV_2 = HV_33;
      goto l_3 ;
   l_144: 
      HV_34 = 2;
      HV_2 = HV_34;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT581","End F_Calc_Allowed",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Calc_Allowed", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Calc_Allowed", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Calc_Allowed");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT614
   Beschreibung: Die Funktion berechnet die Formel 
                 F_HealthSurcharge
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT614 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_DOUBLE  HV_27 = 0;
      TCD_DOUBLE  HV_30 = 0;
      TCD_DOUBLE  HV_32 = 0;
      TCD_DOUBLE  HV_33 = 0;
      TCD_DOUBLE  HV_34 = 0;
      TCD_DOUBLE  HV_35 = 0;
      TCD_DOUBLE  HV_36 = 0;
      TCD_DOUBLE  HV_37 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_15 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_21 = 0;
      TCD_INT     HV_23 = 0;
      TCD_INT     HV_25 = 0;
      TCD_INT     HV_29 = 0;
      TCD_INT     HV_31 = 0;
      P_TCDTAB2   HV_7;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_14 = 2;
      TCD_INT     HV_17 = 0;
      TCD_INT     HV_20 = 0;
      TCD_INT     HV_28 = 0;


   /* Generierung der BeschaffungsFlags: */
      int i_i_PremModifiedQx_IDBeschafft_23 = 0;
   int i_i_PremModifiedQx_ValBeschafft_24 = 0;
   int i_i_Premium_IDBeschafft_31 = 0;
   int i_i_Premium_ValBeschafft_32 = 0;


   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT614","Begin F_HealthSurcharge",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,614,"12.12.2019 17:29:54",
                       6);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_8);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT614",
              "Ende F_HealthSurcharge",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_6 = 0;
      HV_10 = 0;
      HV_25 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_5: 
      HV_4 = (TCD_INT) ( HV_1) ;
      if ( HV_2 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_aj1", 447, 447, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_8: 
      HV_5 = (TCD_INT) ( HV_3) ;
      if ( HV_6 != 0 ) goto l_11 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_11: 
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_4 < 0 || HV_4 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_7 [ HV_4 * 110 + HV_5 ]  == 0 ) goto l_24 ;
      goto l_30 ;
   l_24: 
      HV_9 = 0;
      HV_8 = HV_9;
      goto l_3 ;
   l_30: 
      if ( HV_10 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "F_ModifiedQx", 615, 615, &HV_11);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_10 = 1;
   l_14: 
   TCDSetPS (pMyPar, 1, 133, &HV_13, &HV_12, HV_11);
   TCDSetPS (pMyPar, 1, 118, &HV_16, &HV_15, HV_14);
   TCDSetPS (pMyPar, 1, 126, &HV_19, &HV_18, HV_17);
   TCDSetPS (pMyPar, 1, 127, &HV_22, &HV_21, HV_20);
       if ( !i_i_PremModifiedQx_IDBeschafft_23 &&
       !i_i_PremModifiedQx_ValBeschafft_24 ) {
         if (pMyPar->pTCDTCD->SSAData.pParSkal[134].Level==0) {
            TCDFtID (pMyPar, "i_PremModifiedQx", 46, 386, 1, &HV_23);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_PremModifiedQx_IDBeschafft_23 = 1;
         }
         if ( !i_i_PremModifiedQx_IDBeschafft_23 ) {
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = TCD_RC_OK;
            TCD3FES (pMyPar, "i_PremModifiedQx", 46, 386, 1, 134,
               &HV_24);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_PremModifiedQx_ValBeschafft_24 = 1;
         }
          if ( !i_i_PremModifiedQx_IDBeschafft_23 &&
          !i_i_PremModifiedQx_ValBeschafft_24 ) goto l_ende;
      }
      if (i_i_PremModifiedQx_IDBeschafft_23) {
         rc = TCD3FE1 (pMyPar, 3, "i_PremModifiedQx", 386, HV_23,
            &HV_24);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
      }
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 127, &HV_22, &HV_21, HV_20);
   TCDSetPS (pMyPar, 0, 126, &HV_19, &HV_18, HV_20);
   TCDSetPS (pMyPar, 0, 118, &HV_16, &HV_15, HV_20);
   TCDSetPS (pMyPar, 0, 133, &HV_13, &HV_12, HV_20);
      if ( HV_25 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_26);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_25 = 1;
   l_17: 
   if ( HV_26 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_27 = HV_24 / HV_26;
   TCDSetPS (pMyPar, 1, 133, &HV_30, &HV_29, HV_28);
   TCDSetPS (pMyPar, 1, 118, &HV_16, &HV_15, HV_14);
   TCDSetPS (pMyPar, 1, 126, &HV_19, &HV_18, HV_17);
   TCDSetPS (pMyPar, 1, 127, &HV_22, &HV_21, HV_20);
       if ( !i_i_Premium_IDBeschafft_31 &&
       !i_i_Premium_ValBeschafft_32 ) {
         if (pMyPar->pTCDTCD->SSAData.pParSkal[135].Level==0) {
            TCDFtID (pMyPar, "i_Premium", 47, 387, 1, &HV_31);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_Premium_IDBeschafft_31 = 1;
         }
         if ( !i_i_Premium_IDBeschafft_31 ) {
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = TCD_RC_OK;
            TCD3FES (pMyPar, "i_Premium", 47, 387, 1, 135, &HV_32);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_Premium_ValBeschafft_32 = 1;
         }
          if ( !i_i_Premium_IDBeschafft_31 &&
          !i_i_Premium_ValBeschafft_32 ) goto l_ende;
      }
      if (i_i_Premium_IDBeschafft_31) {
         rc = TCD3FE1 (pMyPar, 3, "i_Premium", 387, HV_31, &HV_32);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
      }
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 127, &HV_22, &HV_21, HV_20);
   TCDSetPS (pMyPar, 0, 126, &HV_19, &HV_18, HV_20);
   TCDSetPS (pMyPar, 0, 118, &HV_16, &HV_15, HV_20);
   TCDSetPS (pMyPar, 0, 133, &HV_30, &HV_29, HV_20);
      if ( HV_25 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_26);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_25 = 1;
   l_20: 
   if ( HV_26 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_33 = HV_32 / HV_26;
      HV_34 = HV_27 - HV_33;
      HV_35 = TCDMAX ( 0.0, HV_34 ) ;
      HV_36 =   TCDRND ( HV_35, 6 ) ;
      HV_37 = HV_36 * 100;
      HV_8 = HV_37;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_8);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT614","End F_HealthSurcharge",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_HealthSurcharge", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_HealthSurcharge", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_HealthSurcharge");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT615
   Beschreibung: Die Funktion berechnet die Formel 
                 F_ModifiedQx
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT615 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_INT     HV_0 = 0;
      TCD_DOUBLE  HV_4 = 0.2;
      TCD_DOUBLE  HV_5 = 0.325;
      TCD_DOUBLE  HV_6 = 0.45;
      TCD_DOUBLE  HV_7 = 0.6;
      TCD_DOUBLE  HV_8 = 0.9;
      TCD_DOUBLE  HV_9 = 1.25;
      TCD_DOUBLE  HV_10 = 1.5;
      TCD_DOUBLE  HV_11 = 1.75;
      TCD_DOUBLE  HV_13 = 2.25;
      TCD_DOUBLE  HV_14 = 2.5;
      TCD_DOUBLE  HV_16 = 3.5;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_12 = 2;
      TCD_INT     HV_15 = 3;
      TCD_INT     HV_17 = 4;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT615","Begin F_ModifiedQx",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,615,"12.12.2019 17:29:55",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT615",
              "Ende F_ModifiedQx",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "e_HealthClass_IP1_n", 46, 381, 6, 46, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 0 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_0 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "e_HealthClass_IP1_n", 46, 381, 6, 46, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_8: 
      if ( HV_1 == 1 ) goto l_36 ;
      goto l_42 ;
   l_36: 
      HV_4 = 0.2;
      HV_2 = HV_4;
      goto l_3 ;
   l_42: 
      if ( HV_0 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "e_HealthClass_IP1_n", 46, 381, 6, 46, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_11: 
      if ( HV_1 == 1.5 ) goto l_54 ;
      goto l_60 ;
   l_54: 
      HV_5 = 0.325;
      HV_2 = HV_5;
      goto l_3 ;
   l_60: 
      if ( HV_0 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "e_HealthClass_IP1_n", 46, 381, 6, 46, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_14: 
      if ( HV_1 == 2 ) goto l_72 ;
      goto l_78 ;
   l_72: 
      HV_6 = 0.45;
      HV_2 = HV_6;
      goto l_3 ;
   l_78: 
      if ( HV_0 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "e_HealthClass_IP1_n", 46, 381, 6, 46, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_17: 
      if ( HV_1 == 3 ) goto l_90 ;
      goto l_96 ;
   l_90: 
      HV_7 = 0.6;
      HV_2 = HV_7;
      goto l_3 ;
   l_96: 
      if ( HV_0 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "e_HealthClass_IP1_n", 46, 381, 6, 46, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_20: 
      if ( HV_1 == 4 ) goto l_108 ;
      goto l_114 ;
   l_108: 
      HV_8 = 0.9;
      HV_2 = HV_8;
      goto l_3 ;
   l_114: 
      if ( HV_0 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "e_HealthClass_IP1_n", 46, 381, 6, 46, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_23: 
      if ( HV_1 == 5 ) goto l_126 ;
      goto l_132 ;
   l_126: 
      HV_9 = 1.25;
      HV_2 = HV_9;
      goto l_3 ;
   l_132: 
      if ( HV_0 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "e_HealthClass_IP1_n", 46, 381, 6, 46, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_26: 
      if ( HV_1 == 6 ) goto l_144 ;
      goto l_150 ;
   l_144: 
      HV_10 = 1.5;
      HV_2 = HV_10;
      goto l_3 ;
   l_150: 
      if ( HV_0 != 0 ) goto l_29 ;
      TCD3FES (pMyPar, "e_HealthClass_IP1_n", 46, 381, 6, 46, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_29: 
      if ( HV_1 == 7 ) goto l_162 ;
      goto l_168 ;
   l_162: 
      HV_11 = 1.75;
      HV_2 = HV_11;
      goto l_3 ;
   l_168: 
      if ( HV_0 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "e_HealthClass_IP1_n", 46, 381, 6, 46, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_32: 
      if ( HV_1 == 8 ) goto l_180 ;
      goto l_186 ;
   l_180: 
      HV_12 = 2;
      HV_2 = HV_12;
      goto l_3 ;
   l_186: 
      if ( HV_0 != 0 ) goto l_35 ;
      TCD3FES (pMyPar, "e_HealthClass_IP1_n", 46, 381, 6, 46, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_35: 
      if ( HV_1 == 9 ) goto l_198 ;
      goto l_204 ;
   l_198: 
      HV_13 = 2.25;
      HV_2 = HV_13;
      goto l_3 ;
   l_204: 
      if ( HV_0 != 0 ) goto l_38 ;
      TCD3FES (pMyPar, "e_HealthClass_IP1_n", 46, 381, 6, 46, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_38: 
      if ( HV_1 == 10 ) goto l_216 ;
      goto l_222 ;
   l_216: 
      HV_14 = 2.5;
      HV_2 = HV_14;
      goto l_3 ;
   l_222: 
      if ( HV_0 != 0 ) goto l_41 ;
      TCD3FES (pMyPar, "e_HealthClass_IP1_n", 46, 381, 6, 46, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_41: 
      if ( HV_1 == 11 ) goto l_234 ;
      goto l_240 ;
   l_234: 
      HV_15 = 3;
      HV_2 = HV_15;
      goto l_3 ;
   l_240: 
      if ( HV_0 != 0 ) goto l_44 ;
      TCD3FES (pMyPar, "e_HealthClass_IP1_n", 46, 381, 6, 46, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_44: 
      if ( HV_1 == 12 ) goto l_252 ;
      goto l_258 ;
   l_252: 
      HV_16 = 3.5;
      HV_2 = HV_16;
      goto l_3 ;
   l_258: 
      if ( HV_0 != 0 ) goto l_47 ;
      TCD3FES (pMyPar, "e_HealthClass_IP1_n", 46, 381, 6, 46, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_47: 
      if ( HV_1 == 13 ) goto l_270 ;
      goto l_276 ;
   l_270: 
      HV_17 = 4;
      HV_2 = HV_17;
      goto l_3 ;
   l_276: 
   pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 900;
   pMyPar->pTCDTCD->pRbsCtl->RCInfo.Errc = 136;
   goto l_ende ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT615","End F_ModifiedQx",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_ModifiedQx", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_ModifiedQx", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_ModifiedQx");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT617
   Beschreibung: Die Funktion berechnet die Formel 
                 F_AddSurcharges
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT617 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_11 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_21 = 0;
      TCD_INT     HV_24 = 0;
      TCD_INT     HV_27 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT617","Begin F_AddSurcharges",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,617,"12.12.2019 17:29:55",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_8);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT617",
              "Ende F_AddSurcharges",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_4 = 0;
      HV_6 = 0;
      HV_9 = 0;
      HV_11 = 0;
      HV_13 = 0;
      HV_18 = 0;
      HV_21 = 0;
      HV_24 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_State", 67, 421, 1, 155, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_2 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_regularPremium", 649, 649, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_8: 
      if ( HV_1 == HV_3 ) goto l_42 ;
      goto l_24 ;
   l_24: 
      if ( HV_0 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_State", 67, 421, 1, 155, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_11: 
      if ( HV_4 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "_premFree", 648, 648, &HV_5);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_4 = 1;
   l_14: 
      if ( HV_1 == HV_5 ) goto l_33 ;
      goto l_84 ;
   l_33: 
      if ( HV_6 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_StateDetail", 68, 422, 1, 156, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_17: 
      if ( HV_7 == 2 ) goto l_42 ;
      goto l_84 ;
   l_42: 
      if ( HV_13 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_NumberOfInsPers", 25, 324, 1, 113, &HV_14);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_13 = 1;
   l_20: 
      HV_15 = HV_14 - 1;
      if ( HV_11 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_addSurcharge_IP2", 39, 376, 1, 127, &HV_12);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_11 = 1;
   l_23: 
      HV_16 = HV_12 * HV_15;
      if ( HV_9 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_addSurcharge_IP1", 38, 375, 1, 126, &HV_10);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_9 = 1;
   l_26: 
      HV_17 = HV_10 + HV_16;
      if ( HV_18 != 0 ) goto l_29 ;
      TCD3FES (pMyPar, "i_SpecialDiscount", 43, 383, 1, 131, &HV_19);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_18 = 1;
   l_29: 
      HV_20 = HV_17 + HV_19;
      if ( HV_21 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "i_w_o_Examnination", 41, 378, 1, 129, &HV_22);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_21 = 1;
   l_32: 
      HV_23 = HV_20 + HV_22;
      if ( HV_24 != 0 ) goto l_35 ;
      TCD3FES (pMyPar, "i_SumDiscount", 44, 384, 1, 132, &HV_25);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_24 = 1;
   l_35: 
      HV_26 = HV_23 + HV_25;
      HV_8 = HV_26;
      goto l_3 ;
   l_84: 
      HV_27 = 0;
      HV_8 = HV_27;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_8);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT617","End F_AddSurcharges",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_AddSurcharges", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_AddSurcharges", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_AddSurcharges");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT664
   Beschreibung: Die Funktion berechnet die Formel 
                 F_PBxn_AccDeath_Dis
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT664 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT664","Begin F_PBxn_AccDeath_Dis",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,664,"12.12.2019 17:29:53",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT664",
              "Ende F_PBxn_AccDeath_Dis",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AccDeathDis_xnt", 666, 666, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
      if ( HV_3 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_8: 
      HV_5 = HV_2 * HV_4;
      HV_6 =   TCDRND ( HV_5, 2 ) ;
      HV_0 = HV_6;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT664","End F_PBxn_AccDeath_Dis",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_PBxn_AccDeath_Dis", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_PBxn_AccDeath_Dis", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_PBxn_AccDeath_Dis");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT665
   Beschreibung: Die Funktion berechnet die Formel 
                 F_PBxn_OccDis
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT665 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_DOUBLE  HV_27 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_DOUBLE  HV_29 = 0;
      TCD_DOUBLE  HV_30 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_11 = 0;
      TCD_INT     HV_14 = 0;
      TCD_INT     HV_19 = 0;
      TCD_INT     HV_23 = 0;
      TCD_INT     HV_31 = 0;
      TCD_INT     HV_32 = 0;
      TCD_INT     HV_33 = 0;
      TCD_INT     HV_34 = 0;
      TCD_INT     HV_35 = 0;
      TCD_INT     HV_36 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT665","Begin F_PBxn_OccDis",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,665,"12.12.2019 17:29:52",
                       7);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_8);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT665",
              "Ende F_PBxn_OccDis",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_5 = 0;
      HV_9 = 0;
      HV_11 = 0;
      HV_14 = 0;
      HV_19 = 0;
      HV_23 = 0;
      HV_31 = 0;
      HV_32 = 0;
      HV_33 = 0;
      HV_34 = 0;
      HV_35 = 0;
      HV_36 = 0;
      if ( HV_31 != 0 ) goto l_16 ;
      if ( HV_0 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_PxnOccDis", 704, 704, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_5: 
      if ( HV_2 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AlphaOccDis_CV", 702, 702, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_8: 
      HV_4 = HV_1 - HV_3;
      HV_31 = 1;
   l_16: 
      if ( HV_32 != 0 ) goto l_13 ;
      if ( HV_5 != 0 ) goto l_11 ;
      rc = TCD3FE1 (pMyPar, 2, "F_BetaOccDis_CV", 703, 703, &HV_6);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_5 = 1;
   l_11: 
      HV_7 = HV_4 - HV_6;
      HV_32 = 1;
   l_13: 
      if ( HV_7 > 0 ) goto l_30 ;
      goto l_102 ;
   l_30: 
      if ( HV_33 != 0 ) goto l_49 ;
      if ( HV_9 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "F_CashValue_OccDis", 715, 715,
         &HV_10);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_9 = 1;
   l_14: 
      if ( HV_11 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_12);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_11 = 1;
   l_17: 
      HV_13 = HV_10 * HV_12;
      HV_33 = 1;
   l_49: 
      if ( HV_34 != 0 ) goto l_46 ;
      if ( HV_14 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_CreditableReseve", 59, 412, 1, 147, &HV_15);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_14 = 1;
   l_20: 
      HV_16 = HV_13 - HV_15;
      HV_34 = 1;
   l_46: 
      if ( HV_31 != 0 ) goto l_70 ;
      if ( HV_0 != 0 ) goto l_23 ;
      rc = TCD3FE1 (pMyPar, 2, "F_PxnOccDis", 704, 704, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_23: 
      if ( HV_2 != 0 ) goto l_26 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AlphaOccDis_CV", 702, 702, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_26: 
      HV_4 = HV_1 - HV_3;
      HV_31 = 1;
   l_70: 
      if ( HV_32 != 0 ) goto l_67 ;
      if ( HV_5 != 0 ) goto l_29 ;
      rc = TCD3FE1 (pMyPar, 2, "F_BetaOccDis_CV", 703, 703, &HV_6);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_5 = 1;
   l_29: 
      HV_7 = HV_4 - HV_6;
      HV_32 = 1;
   l_67: 
      HV_17 = TCDMAX ( 0.000001, HV_7 ) ;
   if ( HV_17 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_18 = HV_16 / HV_17;
      if ( HV_35 != 0 ) goto l_82 ;
      if ( HV_19 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "i_OccSurcharge", 36, 365, 1, 124, &HV_20);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_19 = 1;
   l_32: 
      HV_21 = 1 + HV_20;
      HV_35 = 1;
   l_82: 
      HV_22 = HV_18 * HV_21;
      if ( HV_36 != 0 ) goto l_91 ;
      if ( HV_23 != 0 ) goto l_35 ;
      TCD3FES (pMyPar, "i_SportsSurcharge", 37, 366, 1, 125, &HV_24);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_23 = 1;
   l_35: 
      HV_25 = 1 + HV_24;
      HV_36 = 1;
   l_91: 
      HV_26 = HV_22 * HV_25;
      HV_27 =   TCDRND ( HV_26, 2 ) ;
      HV_8 = HV_27;
      goto l_3 ;
   l_102: 
      if ( HV_33 != 0 ) goto l_118 ;
      if ( HV_9 != 0 ) goto l_38 ;
      rc = TCD3FE1 (pMyPar, 2, "F_CashValue_OccDis", 715, 715,
         &HV_10);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_9 = 1;
   l_38: 
      if ( HV_11 != 0 ) goto l_41 ;
      TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_12);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_11 = 1;
   l_41: 
      HV_13 = HV_10 * HV_12;
      HV_33 = 1;
   l_118: 
      if ( HV_34 != 0 ) goto l_115 ;
      if ( HV_14 != 0 ) goto l_44 ;
      TCD3FES (pMyPar, "i_CreditableReseve", 59, 412, 1, 147, &HV_15);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_14 = 1;
   l_44: 
      HV_16 = HV_13 - HV_15;
      HV_34 = 1;
   l_115: 
      if ( HV_35 != 0 ) goto l_130 ;
      if ( HV_19 != 0 ) goto l_47 ;
      TCD3FES (pMyPar, "i_OccSurcharge", 36, 365, 1, 124, &HV_20);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_19 = 1;
   l_47: 
      HV_21 = 1 + HV_20;
      HV_35 = 1;
   l_130: 
      HV_28 = HV_16 * HV_21;
      if ( HV_36 != 0 ) goto l_139 ;
      if ( HV_23 != 0 ) goto l_50 ;
      TCD3FES (pMyPar, "i_SportsSurcharge", 37, 366, 1, 125, &HV_24);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_23 = 1;
   l_50: 
      HV_25 = 1 + HV_24;
      HV_36 = 1;
   l_139: 
      HV_29 = HV_28 * HV_25;
      HV_30 =   TCDRND ( HV_29, 2 ) ;
      HV_8 = HV_30;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_8);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT665","End F_PBxn_OccDis",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_PBxn_OccDis", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_PBxn_OccDis", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_PBxn_OccDis");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT668
   Beschreibung: Die Funktion berechnet die Formel 
                 F_AuxiliaryNumber
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT668 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_DOUBLE  HV_30 = 0;
      TCD_DOUBLE  HV_32 = 0;
      TCD_DOUBLE  HV_33 = 0;
      TCD_DOUBLE  HV_35 = 0;
      TCD_DOUBLE  HV_38 = 0;
      TCD_DOUBLE  HV_40 = 0;
      TCD_DOUBLE  HV_41 = 0;
      TCD_DOUBLE  HV_43 = 0;
      TCD_DOUBLE  HV_44 = 0;
      TCD_DOUBLE  HV_45 = 0;
      TCD_DOUBLE  HV_47 = 0;
      TCD_DOUBLE  HV_49 = 0;
      TCD_DOUBLE  HV_51 = 0;
      TCD_DOUBLE  HV_52 = 0;
      TCD_DOUBLE  HV_53 = 0;
      TCD_DOUBLE  HV_54 = 0;
      TCD_DOUBLE  HV_56 = 0;
      TCD_DOUBLE  HV_57 = 0;
      TCD_DOUBLE  HV_58 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_15 = 0;
      TCD_INT     HV_17 = 0;
      TCD_INT     HV_19 = 0;
      TCD_INT     HV_21 = 0;
      TCD_INT     HV_24 = 0;
      TCD_INT     HV_27 = 0;
      TCD_INT     HV_29 = 0;
      TCD_INT     HV_31 = 0;
      TCD_INT     HV_34 = 0;
      TCD_INT     HV_37 = 0;
      TCD_INT     HV_39 = 0;
      TCD_INT     HV_42 = 0;
      TCD_INT     HV_46 = 0;
      TCD_INT     HV_48 = 0;
      TCD_INT     HV_50 = 0;
      TCD_INT     HV_55 = 0;
      TCD_INT     HV_60 = 0;
      TCD_INT     HV_61 = 0;
      TCD_INT     HV_62 = 0;
      TCD_INT     HV_63 = 0;
      TCD_INT     HV_64 = 0;
      TCD_INT     HV_65 = 0;
      P_TCDTAB1   HV_23;
      TCD_INT     HV_26 = 0;
      TCD_INT     HV_36 = 0;
      TCD_INT     HV_59 = 0;


   /* Generierung der BeschaffungsFlags: */
      int i_i_Premium_IDBeschafft_39 = 0;
   int i_i_Premium_ValBeschafft_40 = 0;


   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT668","Begin F_AuxiliaryNumber",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,668,"12.12.2019 17:29:54",
                       10);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Besorgen einer freien Tabelle, falls Formel vom Typ TAB1/TAB2 */
   rc =    TCDGetTb (pMyPar, &HV_23);


   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_23);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT668",
              "Ende F_AuxiliaryNumber",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_8 = 0;
      HV_13 = 0;
      HV_15 = 0;
      HV_17 = 0;
      HV_19 = 0;
      HV_21 = 0;
      HV_24 = 0;
      HV_29 = 0;
      HV_31 = 0;
      HV_42 = 0;
      HV_46 = 0;
      HV_48 = 0;
      HV_50 = 0;
      HV_60 = 0;
      HV_61 = 0;
      HV_62 = 0;
      HV_63 = 0;
      HV_64 = 0;
      HV_65 = 0;
      for ( HV_0 = (TCD_INT) (0) ; HV_0 <= 199; HV_0 = HV_0 + 1 ) {
         if ( HV_0 > 1 ) goto l_18 ;
         goto l_21 ;
      l_18: 
      goto l_ende ;
      l_21: 
         if ( HV_0 == 0 ) goto l_33 ;
         goto l_204 ;
      l_33: 
         if ( HV_1 != 0 ) goto l_5 ;
         TCD3FES (pMyPar, "i_StateDetail", 68, 422, 1, 156, &HV_2);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_1 = 1;
      l_5: 
         if ( HV_2 > 0 ) goto l_63 ;
         goto l_144 ;
      l_63: 
         if ( HV_1 != 0 ) goto l_8 ;
         TCD3FES (pMyPar, "i_StateDetail", 68, 422, 1, 156, &HV_2);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_1 = 1;
      l_8: 
         if ( HV_2 != 2 ) goto l_72 ;
         goto l_144 ;
      l_72: 
         if ( HV_3 != 0 ) goto l_11 ;
         TCD3FES (pMyPar, "e_n_n", 0, 4, 6, 0, &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_11: 
         if ( HV_60 != 0 ) goto l_76 ;
      TCDSetPS (pMyPar, 1, 94, &HV_6, &HV_5, HV_4);
         rc = TCD3FE1 (pMyPar, 4, "F_n", 364, 364, &HV_7);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 94, &HV_6, &HV_5, HV_4);
         HV_60 = 1;
      l_76: 
         if ( HV_8 != 0 ) goto l_14 ;
         TCD3FES (pMyPar, "e_n_o", 7, 104, 6, 7, &HV_9);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_8 = 1;
      l_14: 
         if ( HV_61 != 0 ) goto l_88 ;
      TCDSetPS (pMyPar, 1, 94, &HV_11, &HV_10, HV_9);
         rc = TCD3FE1 (pMyPar, 4, "F_n", 364, 364, &HV_12);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 94, &HV_11, &HV_10, HV_9);
         HV_61 = 1;
      l_88: 
         if ( HV_7 == HV_12 ) goto l_99 ;
         goto l_144 ;
      l_99: 
         if ( HV_13 != 0 ) goto l_17 ;
         TCD3FES (pMyPar, "e_tarif_nr_n", 3, 20, 6, 3, &HV_14);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_13 = 1;
      l_17: 
         if ( HV_15 != 0 ) goto l_20 ;
         TCD3FES (pMyPar, "e_tarif_nr_o", 8, 121, 6, 8, &HV_16);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_15 = 1;
      l_20: 
         if ( HV_14 == HV_16 ) goto l_108 ;
         goto l_144 ;
      l_108: 
         if ( HV_17 != 0 ) goto l_23 ;
         TCD3FES (pMyPar, "e_manual_reserve_n", 55, 411, 6, 55,
            &HV_18);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_17 = 1;
      l_23: 
         if ( HV_18 == 0 ) goto l_117 ;
         goto l_144 ;
      l_117: 
         if ( HV_19 != 0 ) goto l_26 ;
         TCD3FES (pMyPar, "i_AddContrib", 33, 355, 1, 121, &HV_20);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_19 = 1;
      l_26: 
         if ( HV_20 == 0 ) goto l_126 ;
         goto l_144 ;
      l_126: 
         if ( HV_21 != 0 ) goto l_29 ;
         TCD3FES (pMyPar, "i_PartSurrender", 34, 356, 1, 122, &HV_22);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_21 = 1;
      l_29: 
         if ( HV_22 == 0 ) goto l_135 ;
         goto l_144 ;
      l_135: 
         if ( HV_24 != 0 ) goto l_32 ;
         TCD3FES (pMyPar, "e_SumRelation", 54, 410, 6, 54, &HV_25);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_24 = 1;
      l_32: 
         HV_23 [ HV_0 ]  = HV_25;
         continue ;
      l_144: 
         if ( HV_29 != 0 ) goto l_35 ;
         TCD3FES (pMyPar, "e_SumOfPremiums_o", 68, 442, 6, 68,
            &HV_30);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_29 = 1;
      l_35: 
         if ( HV_31 != 0 ) goto l_38 ;
         TCD3FES (pMyPar, "e_AddContrib_n", 31, 359, 6, 31, &HV_32);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_31 = 1;
      l_38: 
         HV_33 = HV_30 + HV_32;
      TCDSetPS (pMyPar, 1, 121, &HV_28, &HV_27, HV_26);
      TCDSetPS (pMyPar, 1, 68, &HV_35, &HV_34, HV_33);
      TCDSetPS (pMyPar, 1, 147, &HV_38, &HV_37, HV_36);
          if ( !i_i_Premium_IDBeschafft_39 &&
          !i_i_Premium_ValBeschafft_40 ) {
            if (pMyPar->pTCDTCD->SSAData.pParSkal[135].Level==0) {
               TCDFtID (pMyPar, "i_Premium", 47, 387, 1, &HV_39);
               if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
                i_i_Premium_IDBeschafft_39 = 1;
            }
            if ( !i_i_Premium_IDBeschafft_39 ) {
               pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = TCD_RC_OK;
               TCD3FES (pMyPar, "i_Premium", 47, 387, 1, 135, &HV_40);
               if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
                i_i_Premium_ValBeschafft_40 = 1;
            }
             if ( !i_i_Premium_IDBeschafft_39 &&
             !i_i_Premium_ValBeschafft_40 ) goto l_ende;
         }
         if (i_i_Premium_IDBeschafft_39) {
            rc = TCD3FE1 (pMyPar, 3, "i_Premium", 387, HV_39, &HV_40);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
               l_ende;
         }
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 147, &HV_38, &HV_37, HV_36);
      TCDSetPS (pMyPar, 0, 68, &HV_35, &HV_34, HV_36);
      TCDSetPS (pMyPar, 0, 121, &HV_28, &HV_27, HV_36);
         if ( HV_24 != 0 ) goto l_41 ;
         TCD3FES (pMyPar, "e_SumRelation", 54, 410, 6, 54, &HV_25);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_24 = 1;
      l_41: 
         HV_41 = HV_25 * HV_40;
         if ( HV_42 != 0 ) goto l_44 ;
         TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_43);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_42 = 1;
      l_44: 
      if ( HV_43 == 0) { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
         goto l_ende ;
       } ;
         HV_44 = HV_41 / HV_43;
         HV_45 =   TCDRND ( HV_44, 9 ) ;
         HV_23 [ HV_0 ]  = HV_45;
         continue ;
      l_204: 
         if ( HV_0 == 1 ) goto l_216 ;
         goto l_417 ;
      l_216: 
         if ( HV_1 != 0 ) goto l_47 ;
         TCD3FES (pMyPar, "i_StateDetail", 68, 422, 1, 156, &HV_2);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_1 = 1;
      l_47: 
         if ( HV_2 > 0 ) goto l_246 ;
         goto l_327 ;
      l_246: 
         if ( HV_1 != 0 ) goto l_50 ;
         TCD3FES (pMyPar, "i_StateDetail", 68, 422, 1, 156, &HV_2);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_1 = 1;
      l_50: 
         if ( HV_2 != 2 ) goto l_255 ;
         goto l_327 ;
      l_255: 
         if ( HV_3 != 0 ) goto l_53 ;
         TCD3FES (pMyPar, "e_n_n", 0, 4, 6, 0, &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_53: 
         if ( HV_60 != 0 ) goto l_259 ;
      TCDSetPS (pMyPar, 1, 94, &HV_6, &HV_5, HV_4);
         rc = TCD3FE1 (pMyPar, 4, "F_n", 364, 364, &HV_7);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 94, &HV_6, &HV_5, HV_4);
         HV_60 = 1;
      l_259: 
         if ( HV_8 != 0 ) goto l_56 ;
         TCD3FES (pMyPar, "e_n_o", 7, 104, 6, 7, &HV_9);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_8 = 1;
      l_56: 
         if ( HV_61 != 0 ) goto l_271 ;
      TCDSetPS (pMyPar, 1, 94, &HV_11, &HV_10, HV_9);
         rc = TCD3FE1 (pMyPar, 4, "F_n", 364, 364, &HV_12);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 94, &HV_11, &HV_10, HV_9);
         HV_61 = 1;
      l_271: 
         if ( HV_7 == HV_12 ) goto l_282 ;
         goto l_327 ;
      l_282: 
         if ( HV_13 != 0 ) goto l_59 ;
         TCD3FES (pMyPar, "e_tarif_nr_n", 3, 20, 6, 3, &HV_14);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_13 = 1;
      l_59: 
         if ( HV_15 != 0 ) goto l_62 ;
         TCD3FES (pMyPar, "e_tarif_nr_o", 8, 121, 6, 8, &HV_16);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_15 = 1;
      l_62: 
         if ( HV_14 == HV_16 ) goto l_291 ;
         goto l_327 ;
      l_291: 
         if ( HV_17 != 0 ) goto l_65 ;
         TCD3FES (pMyPar, "e_manual_reserve_n", 55, 411, 6, 55,
            &HV_18);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_17 = 1;
      l_65: 
         if ( HV_18 == 0 ) goto l_300 ;
         goto l_327 ;
      l_300: 
         if ( HV_19 != 0 ) goto l_68 ;
         TCD3FES (pMyPar, "i_AddContrib", 33, 355, 1, 121, &HV_20);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_19 = 1;
      l_68: 
         if ( HV_20 == 0 ) goto l_309 ;
         goto l_327 ;
      l_309: 
         if ( HV_21 != 0 ) goto l_71 ;
         TCD3FES (pMyPar, "i_PartSurrender", 34, 356, 1, 122, &HV_22);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_21 = 1;
      l_71: 
         if ( HV_22 == 0 ) goto l_318 ;
         goto l_327 ;
      l_318: 
         if ( HV_42 != 0 ) goto l_74 ;
         TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_43);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_42 = 1;
      l_74: 
         HV_23 [ HV_0 ]  = HV_43;
         continue ;
      l_327: 
         if ( HV_46 != 0 ) goto l_77 ;
         TCD3FES (pMyPar, "i_PremiumCashValue", 74, 441, 1, 162,
            &HV_47);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_46 = 1;
      l_77: 
         if ( HV_47 > 0 ) goto l_339 ;
         goto l_381 ;
      l_339: 
         if ( HV_62 != 0 ) goto l_370 ;
         if ( HV_48 != 0 ) goto l_80 ;
         rc = TCD3FE1 (pMyPar, 2, "F_Alpha1_Permille", 671, 671,
            &HV_49);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_48 = 1;
      l_80: 
         if ( HV_50 != 0 ) goto l_83 ;
         rc = TCD3FE1 (pMyPar, 2, "F_Alpha2_Permille", 672, 672,
            &HV_51);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_50 = 1;
      l_83: 
         HV_52 = HV_49 + HV_51;
         HV_62 = 1;
      l_370: 
         if ( HV_63 != 0 ) goto l_364 ;
         HV_53 = 1 - HV_52;
         HV_63 = 1;
      l_364: 
         if ( HV_64 != 0 ) goto l_358 ;
         if ( HV_19 != 0 ) goto l_86 ;
         TCD3FES (pMyPar, "i_AddContrib", 33, 355, 1, 121, &HV_20);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_19 = 1;
      l_86: 
         HV_54 = HV_20 * HV_53;
         HV_64 = 1;
      l_358: 
         if ( HV_65 != 0 ) goto l_349 ;
      TCDSetPS (pMyPar, 1, 121, &HV_56, &HV_55, HV_54);
         rc = TCD3FE1 (pMyPar, 4, "F_CreditableReserve", 670, 670,
            &HV_57);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 121, &HV_56, &HV_55, HV_54);
         HV_65 = 1;
      l_349: 
         if ( HV_46 != 0 ) goto l_89 ;
         TCD3FES (pMyPar, "i_PremiumCashValue", 74, 441, 1, 162,
            &HV_47);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_46 = 1;
      l_89: 
      if ( HV_47 == 0) { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
         goto l_ende ;
       } ;
         HV_58 = HV_57 / HV_47;
         HV_23 [ HV_0 ]  = HV_58;
         continue ;
      l_381: 
         if ( HV_62 != 0 ) goto l_409 ;
         if ( HV_48 != 0 ) goto l_92 ;
         rc = TCD3FE1 (pMyPar, 2, "F_Alpha1_Permille", 671, 671,
            &HV_49);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_48 = 1;
      l_92: 
         if ( HV_50 != 0 ) goto l_95 ;
         rc = TCD3FE1 (pMyPar, 2, "F_Alpha2_Permille", 672, 672,
            &HV_51);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_50 = 1;
      l_95: 
         HV_52 = HV_49 + HV_51;
         HV_62 = 1;
      l_409: 
         if ( HV_63 != 0 ) goto l_403 ;
         HV_53 = 1 - HV_52;
         HV_63 = 1;
      l_403: 
         if ( HV_64 != 0 ) goto l_397 ;
         if ( HV_19 != 0 ) goto l_98 ;
         TCD3FES (pMyPar, "i_AddContrib", 33, 355, 1, 121, &HV_20);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_19 = 1;
      l_98: 
         HV_54 = HV_20 * HV_53;
         HV_64 = 1;
      l_397: 
         if ( HV_65 != 0 ) goto l_388 ;
      TCDSetPS (pMyPar, 1, 121, &HV_56, &HV_55, HV_54);
         rc = TCD3FE1 (pMyPar, 4, "F_CreditableReserve", 670, 670,
            &HV_57);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 121, &HV_56, &HV_55, HV_54);
         HV_65 = 1;
      l_388: 
         HV_23 [ HV_0 ]  = HV_57;
         continue ;
      l_417: 
         HV_59 = 0;
         HV_23 [ HV_0 ]  = HV_59;
         continue ;
      }


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetTb (pMyPar, &HV_23);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT668","End F_AuxiliaryNumber",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_AuxiliaryNumber", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_AuxiliaryNumber", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_AuxiliaryNumber");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT669
   Beschreibung: Die Funktion berechnet die Formel 
                 F_AuxNrAccDeathDis
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT669 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      P_TCDTAB1   HV_1;
      TCD_INT     HV_8 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT669","Begin F_AuxNrAccDeathDis",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,669,"12.12.2019 17:29:54",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Besorgen einer freien Tabelle, falls Formel vom Typ TAB1/TAB2 */
   rc =    TCDGetTb (pMyPar, &HV_1);


   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_1);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT669",
              "Ende F_AuxNrAccDeathDis",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_2 = 0;
      HV_4 = 0;
      for ( HV_0 = (TCD_INT) (0) ; HV_0 <= 199; HV_0 = HV_0 + 1 ) {
         if ( HV_0 > 1 ) goto l_18 ;
         goto l_21 ;
      l_18: 
      goto l_ende ;
      l_21: 
         if ( HV_0 == 0 ) goto l_33 ;
         goto l_54 ;
      l_33: 
         if ( HV_2 != 0 ) goto l_5 ;
         TCD3FES (pMyPar, "e_SumRelation", 54, 410, 6, 54, &HV_3);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_2 = 1;
      l_5: 
         if ( HV_4 != 0 ) goto l_8 ;
         rc = TCD3FE1 (pMyPar, 2, "F_AccDeathDis_xnt", 666, 666,
            &HV_5);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_4 = 1;
      l_8: 
         HV_6 = HV_3 * HV_5;
         HV_7 =   TCDRND ( HV_6, 6 ) ;
         HV_1 [ HV_0 ]  = HV_7;
         continue ;
      l_54: 
         HV_8 = 0;
         HV_1 [ HV_0 ]  = HV_8;
         continue ;
      }


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetTb (pMyPar, &HV_1);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT669","End F_AuxNrAccDeathDis",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_AuxNrAccDeathDis", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_AuxNrAccDeathDis", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_AuxNrAccDeathDis");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT674
   Beschreibung: Die Funktion berechnet die Formel 
                 F_PremCashValue
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT674 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_DOUBLE  HV_27 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_14 = 0;
      TCD_INT     HV_17 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_20 = 0;
      TCD_INT     HV_22 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT674","Begin F_PremCashValue",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,674,"12.12.2019 17:29:52",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT674",
              "Ende F_PremCashValue",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_6 = 0;
      HV_9 = 0;
      HV_12 = 0;
      HV_14 = 0;
      HV_18 = 0;
      HV_20 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Pxn", 266, 266, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
      if ( HV_3 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_A2xn", 281, 281, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_3 = 1;
   l_8: 
      HV_5 = HV_2 - HV_4;
      if ( HV_6 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_Alpha3", 50, 398, 1, 138, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_11: 
      HV_8 = HV_5 - HV_7;
      if ( HV_9 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_Beta", 51, 399, 1, 139, &HV_10);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_9 = 1;
   l_14: 
      HV_11 = HV_8 - HV_10;
      if ( HV_12 != 0 ) goto l_17 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Alpha2_Permille", 672, 672, &HV_13);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_12 = 1;
   l_17: 
      if ( HV_14 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_Gamma2", 53, 401, 1, 141, &HV_15);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_14 = 1;
   l_20: 
      HV_16 = HV_13 + HV_15;
      HV_25 = 0;
      if ( HV_18 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_19);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_18 = 1;
   l_23: 
      if ( HV_20 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_21);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_20 = 1;
   l_26: 
      for ( HV_17 = (TCD_INT) (HV_19) ; HV_17 <= HV_21; HV_17 = HV_17 +
         1 ) {
      TCDSetPS (pMyPar, 1, 108, &HV_23, &HV_22, HV_17);
         rc = TCD3FE1 (pMyPar, 4, "F_prj", 268, 268, &HV_24);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 108, &HV_23, &HV_22, HV_17);
         HV_25 = HV_24 + HV_25;
      }
      HV_26 = HV_16 * HV_25;
      HV_27 = HV_11 - HV_26;
      HV_0 = HV_27;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT674","End F_PremCashValue",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_PremCashValue", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_PremCashValue", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_PremCashValue");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT721
   Beschreibung: Die Funktion berechnet die Formel 
                 F_GrossPrem_wo_SD_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT721 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_15 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_21 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT721","Begin F_GrossPrem_wo_SD_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,721,"12.12.2019 17:29:52",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT721",
              "Ende F_GrossPrem_wo_SD_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_5 = 0;
      HV_7 = 0;
      HV_12 = 0;
      HV_15 = 0;
      HV_18 = 0;
      HV_21 = 0;
      if ( HV_7 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "e_NumberOfInsPers_n", 12, 323, 6, 12, &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_5: 
      HV_9 = HV_8 - 1;
      if ( HV_5 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "e_AddSurcharge_IP2_n", 41, 372, 6, 41, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_8: 
      HV_10 = HV_6 * HV_9;
      if ( HV_3 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "e_AddSurcharge_IP1_n", 40, 371, 6, 40, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_11: 
      HV_11 = HV_4 + HV_10;
      if ( HV_12 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "e_SpecialDiscount_n", 49, 390, 6, 49, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_14: 
      HV_14 = HV_11 + HV_13;
      if ( HV_15 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "e_wo_examination_n", 44, 379, 6, 44, &HV_16);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_15 = 1;
   l_17: 
      HV_17 = HV_14 + HV_16;
      if ( HV_18 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "e_SumDiscount_n", 50, 391, 6, 50, &HV_19);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_18 = 1;
   l_20: 
      HV_20 = HV_17 + HV_19;
      if ( HV_21 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "e_tarsumme_ges_n", 4, 27, 6, 4, &HV_22);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_21 = 1;
   l_23: 
      HV_23 = HV_20 * HV_22;
      if ( HV_1 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "e_GrossPremium_n", 84, 461, 6, 84, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_26: 
      HV_24 = HV_2 - HV_23;
      HV_25 =   TCDRND ( HV_24, 2 ) ;
      HV_0 = HV_25;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT721","End F_GrossPrem_wo_SD_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_GrossPrem_wo_SD_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_GrossPrem_wo_SD_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_GrossPrem_wo_SD_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT724
   Beschreibung: Die Funktion berechnet die Formel 
                 F_GrossPrem_wo_SD_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT724 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_15 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_21 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT724","Begin F_GrossPrem_wo_SD_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,724,"12.12.2019 17:29:52",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT724",
              "Ende F_GrossPrem_wo_SD_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_5 = 0;
      HV_7 = 0;
      HV_12 = 0;
      HV_15 = 0;
      HV_18 = 0;
      HV_21 = 0;
      if ( HV_7 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "e_NumberOfInsPers_o", 23, 342, 6, 23, &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_5: 
      HV_9 = HV_8 - 1;
      if ( HV_5 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "e_AddSurcharge_IP2_o", 43, 374, 6, 43, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_8: 
      HV_10 = HV_6 * HV_9;
      if ( HV_3 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "e_AddSurcharge_IP1_o", 42, 373, 6, 42, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_11: 
      HV_11 = HV_4 + HV_10;
      if ( HV_12 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "e_SpecialDiscount_o", 73, 447, 6, 73, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_14: 
      HV_14 = HV_11 + HV_13;
      if ( HV_15 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "e_wo_examination_o", 45, 380, 6, 45, &HV_16);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_15 = 1;
   l_17: 
      HV_17 = HV_14 + HV_16;
      if ( HV_18 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "e_SumDiscount_o", 74, 448, 6, 74, &HV_19);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_18 = 1;
   l_20: 
      HV_20 = HV_17 + HV_19;
      if ( HV_21 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "e_tarsumme_ges_o", 11, 134, 6, 11, &HV_22);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_21 = 1;
   l_23: 
      HV_23 = HV_20 * HV_22;
      if ( HV_1 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "e_GrossPremium_o", 75, 449, 6, 75, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_26: 
      HV_24 = HV_2 - HV_23;
      HV_25 =   TCDRND ( HV_24, 2 ) ;
      HV_0 = HV_25;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT724","End F_GrossPrem_wo_SD_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_GrossPrem_wo_SD_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_GrossPrem_wo_SD_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_GrossPrem_wo_SD_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT768
   Beschreibung: Die Funktion berechnet die Formel 
                 F_GrossPrem_General
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT768 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_27 = 0;
      TCD_DOUBLE  HV_29 = 0;
      TCD_DOUBLE  HV_30 = 0;
      TCD_DOUBLE  HV_31 = 0;
      TCD_DOUBLE  HV_32 = 0;
      TCD_DOUBLE  HV_33 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_14 = 0;
      TCD_INT     HV_16 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_20 = 0;
      TCD_INT     HV_24 = 0;
      TCD_INT     HV_26 = 0;
      TCD_INT     HV_28 = 0;
      TCD_INT     HV_23 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT768","Begin F_GrossPrem_General",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,768,"12.12.2019 17:29:51",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_22);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT768",
              "Ende F_GrossPrem_General",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_7 = 0;
      HV_12 = 0;
      HV_14 = 0;
      HV_16 = 0;
      HV_18 = 0;
      HV_20 = 0;
      HV_24 = 0;
      HV_26 = 0;
      HV_28 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_StateDetail", 68, 422, 1, 156, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 > 0 ) goto l_36 ;
      goto l_114 ;
   l_36: 
      if ( HV_0 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_StateDetail", 68, 422, 1, 156, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_8: 
      if ( HV_1 != 2 ) goto l_45 ;
      goto l_114 ;
   l_45: 
      if ( HV_2 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "e_n_n", 0, 4, 6, 0, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_11: 
   TCDSetPS (pMyPar, 1, 94, &HV_5, &HV_4, HV_3);
      rc = TCD3FE1 (pMyPar, 4, "F_n", 364, 364, &HV_6);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 94, &HV_5, &HV_4, HV_3);
      if ( HV_7 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "e_n_o", 7, 104, 6, 7, &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_14: 
   TCDSetPS (pMyPar, 1, 94, &HV_10, &HV_9, HV_8);
      rc = TCD3FE1 (pMyPar, 4, "F_n", 364, 364, &HV_11);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 94, &HV_10, &HV_9, HV_8);
      if ( HV_6 == HV_11 ) goto l_72 ;
      goto l_114 ;
   l_72: 
      if ( HV_12 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "e_manual_reserve_n", 55, 411, 6, 55, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_17: 
      if ( HV_13 == 0 ) goto l_81 ;
      goto l_114 ;
   l_81: 
      if ( HV_14 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "e_AddContrib_n", 31, 359, 6, 31, &HV_15);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_14 = 1;
   l_20: 
      if ( HV_15 == 0 ) goto l_90 ;
      goto l_114 ;
   l_90: 
      if ( HV_16 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "e_PartSurrender_n", 32, 360, 6, 32, &HV_17);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_16 = 1;
   l_23: 
      if ( HV_17 == 0 ) goto l_99 ;
      goto l_114 ;
   l_99: 
      if ( HV_18 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "e_tarif_nr_n", 3, 20, 6, 3, &HV_19);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_18 = 1;
   l_26: 
      if ( HV_20 != 0 ) goto l_29 ;
      TCD3FES (pMyPar, "e_tarif_nr_o", 8, 121, 6, 8, &HV_21);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_20 = 1;
   l_29: 
      if ( HV_19 == HV_21 ) goto l_108 ;
      goto l_114 ;
   l_108: 
      HV_23 = 0;
      HV_22 = HV_23;
      goto l_3 ;
   l_114: 
      if ( HV_26 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "i_AddSurcharge", 42, 382, 1, 130, &HV_27);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_26 = 1;
   l_32: 
      if ( HV_28 != 0 ) goto l_35 ;
      TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_29);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_28 = 1;
   l_35: 
      HV_30 = HV_27 * HV_29;
      if ( HV_24 != 0 ) goto l_38 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Interpolation", 389, 389, &HV_25);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_24 = 1;
   l_38: 
      HV_31 = HV_25 + HV_30;
      HV_32 =   TCDRND ( HV_31, 2 ) ;
      HV_33 = TCDMAX ( HV_32, 0 ) ;
      HV_22 = HV_33;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_22);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT768","End F_GrossPrem_General",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_GrossPrem_General", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_GrossPrem_General", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_GrossPrem_General");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT770
   Beschreibung: Die Funktion berechnet die Formel 
                 F_CostPremium
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT770 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_11 = 0;
      TCD_INT     HV_14 = 0;
      TCD_INT     HV_19 = 0;
      TCD_INT     HV_21 = 0;
      TCD_INT     HV_25 = 0;
      TCD_INT     HV_18 = 1;


   /* Generierung der BeschaffungsFlags: */
      int i_i_SavingsPrem_IDBeschafft_21 = 0;
   int i_i_SavingsPrem_ValBeschafft_22 = 0;


   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT770","Begin F_CostPremium",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,770,"12.12.2019 17:29:51",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_8);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT770",
              "Ende F_CostPremium",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_4 = 0;
      HV_6 = 0;
      HV_9 = 0;
      HV_11 = 0;
      HV_14 = 0;
      HV_25 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_2 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_m", 366, 366, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_8: 
      if ( HV_1 <  HV_3 ) goto l_21 ;
      goto l_48 ;
   l_21: 
      if ( HV_4 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_State", 67, 421, 1, 155, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_11: 
      if ( HV_6 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "_regularPremium", 649, 649, &HV_7);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_6 = 1;
   l_14: 
      if ( HV_5 == HV_7 ) goto l_30 ;
      goto l_48 ;
   l_30: 
      if ( HV_9 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_Premium", 47, 387, 1, 135, &HV_10);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_9 = 1;
   l_17: 
      if ( HV_11 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_RiskPremium", 83, 471, 1, 171, &HV_12);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_11 = 1;
   l_20: 
      HV_13 = HV_10 - HV_12;
      if ( HV_14 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_SavingsPrem", 84, 472, 1, 172, &HV_15);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_14 = 1;
   l_23: 
      HV_16 = HV_13 - HV_15;
      HV_8 = HV_16;
      goto l_3 ;
   l_48: 
      if ( HV_0 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_26: 
      if ( HV_1 == 0 ) goto l_60 ;
      goto l_87 ;
   l_60: 
      if ( HV_25 != 0 ) goto l_67 ;
      if ( HV_11 != 0 ) goto l_29 ;
      TCD3FES (pMyPar, "i_RiskPremium", 83, 471, 1, 171, &HV_12);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_11 = 1;
   l_29: 
      HV_17 = 0 - HV_12;
      HV_25 = 1;
   l_67: 
   TCDSetPS (pMyPar, 1, 88, &HV_20, &HV_19, HV_18);
       if ( !i_i_SavingsPrem_IDBeschafft_21 &&
       !i_i_SavingsPrem_ValBeschafft_22 ) {
         if (pMyPar->pTCDTCD->SSAData.pParSkal[172].Level==0) {
            TCDFtID (pMyPar, "i_SavingsPrem", 84, 472, 1, &HV_21);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_SavingsPrem_IDBeschafft_21 = 1;
         }
         if ( !i_i_SavingsPrem_IDBeschafft_21 ) {
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = TCD_RC_OK;
            TCD3FES (pMyPar, "i_SavingsPrem", 84, 472, 1, 172,
               &HV_22);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_SavingsPrem_ValBeschafft_22 = 1;
         }
          if ( !i_i_SavingsPrem_IDBeschafft_21 &&
          !i_i_SavingsPrem_ValBeschafft_22 ) goto l_ende;
      }
      if (i_i_SavingsPrem_IDBeschafft_21) {
         rc = TCD3FE1 (pMyPar, 3, "i_SavingsPrem", 472, HV_21,
            &HV_22);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
      }
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 88, &HV_20, &HV_19, HV_18);
      HV_23 = HV_17 - HV_22;
      HV_8 = HV_23;
      goto l_3 ;
   l_87: 
      if ( HV_25 != 0 ) goto l_94 ;
      if ( HV_11 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "i_RiskPremium", 83, 471, 1, 171, &HV_12);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_11 = 1;
   l_32: 
      HV_17 = 0 - HV_12;
      HV_25 = 1;
   l_94: 
      if ( HV_14 != 0 ) goto l_35 ;
      TCD3FES (pMyPar, "i_SavingsPrem", 84, 472, 1, 172, &HV_15);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_14 = 1;
   l_35: 
      HV_24 = HV_17 - HV_15;
      HV_8 = HV_24;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_8);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT770","End F_CostPremium",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_CostPremium", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_CostPremium", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_CostPremium");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT771
   Beschreibung: Die Funktion berechnet die Formel 
                 F_CostPremiumSum
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT771 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_27 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_DOUBLE  HV_29 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_11 = 0;
      TCD_INT     HV_14 = 0;
      TCD_INT     HV_16 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_20 = 0;
      TCD_INT     HV_26 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_10 = 2;
      TCD_INT     HV_13 = 0;


   /* Generierung der BeschaffungsFlags: */
      int i_i_GrossPremium_IDBeschafft_16 = 0;
   int i_i_GrossPremium_ValBeschafft_17 = 0;


   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT771","Begin F_CostPremiumSum",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,771,"12.12.2019 17:29:51",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT771",
              "Ende F_CostPremiumSum",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      HV_6 = 0;
      HV_18 = 0;
      HV_20 = 0;
      HV_26 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_tarif_nr", 24, 321, 1, 112, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 >= 30000 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_6 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "e_pfs_n", 77, 452, 6, 77, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_8: 
      HV_8 = 1 + HV_7;
      if ( HV_4 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "e_GrossPremium_n", 84, 461, 6, 84, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_11: 
      HV_9 = HV_5 * HV_8;
   TCDSetPS (pMyPar, 1, 118, &HV_12, &HV_11, HV_10);
   TCDSetPS (pMyPar, 1, 88, &HV_15, &HV_14, HV_13);
       if ( !i_i_GrossPremium_IDBeschafft_16 &&
       !i_i_GrossPremium_ValBeschafft_17 ) {
         if (pMyPar->pTCDTCD->SSAData.pParSkal[170].Level==0) {
            TCDFtID (pMyPar, "i_GrossPremium", 82, 470, 1, &HV_16);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_GrossPremium_IDBeschafft_16 = 1;
         }
         if ( !i_i_GrossPremium_IDBeschafft_16 ) {
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = TCD_RC_OK;
            TCD3FES (pMyPar, "i_GrossPremium", 82, 470, 1, 170,
               &HV_17);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_GrossPremium_ValBeschafft_17 = 1;
         }
          if ( !i_i_GrossPremium_IDBeschafft_16 &&
          !i_i_GrossPremium_ValBeschafft_17 ) goto l_ende;
      }
      if (i_i_GrossPremium_IDBeschafft_16) {
         rc = TCD3FE1 (pMyPar, 3, "i_GrossPremium", 470, HV_16,
            &HV_17);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
      }
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 88, &HV_15, &HV_14, HV_13);
   TCDSetPS (pMyPar, 0, 118, &HV_12, &HV_11, HV_13);
      if ( HV_18 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Delta", 504, 504, &HV_19);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_18 = 1;
   l_14: 
      if ( HV_20 != 0 ) goto l_17 ;
      rc = TCD3FE1 (pMyPar, 2, "F_IsLiquidAnnuity", 769, 769, &HV_21);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_20 = 1;
   l_17: 
      HV_22 = HV_19 * HV_21;
      HV_23 = 1 + HV_22;
   if ( HV_23 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_24 = HV_17 / HV_23;
      HV_25 = HV_9 - HV_24;
      if ( HV_26 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_m", 4, 166, 1, 92, &HV_27);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_26 = 1;
   l_20: 
      HV_28 = HV_25 * HV_27;
      HV_29 =   TCDRND ( HV_28, 2 ) ;
      HV_2 = HV_29;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT771","End F_CostPremiumSum",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_CostPremiumSum", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_CostPremiumSum", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_CostPremiumSum");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT772
   Beschreibung: Die Funktion berechnet die Formel 
                 F_RiskPremium
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT772 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_27 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_DOUBLE  HV_29 = 0;
      TCD_DOUBLE  HV_31 = 0;
      TCD_DOUBLE  HV_32 = 0;
      TCD_DOUBLE  HV_34 = 0;
      TCD_DOUBLE  HV_35 = 0;
      TCD_DOUBLE  HV_37 = 0;
      TCD_DOUBLE  HV_38 = 0;
      TCD_DOUBLE  HV_39 = 0;
      TCD_DOUBLE  HV_40 = 0;
      TCD_DOUBLE  HV_41 = 0;
      TCD_DOUBLE  HV_42 = 0;
      TCD_DOUBLE  HV_43 = 0;
      TCD_DOUBLE  HV_44 = 0;
      TCD_DOUBLE  HV_45 = 0;
      TCD_DOUBLE  HV_47 = 0;
      TCD_DOUBLE  HV_48 = 0;
      TCD_DOUBLE  HV_49 = 0;
      TCD_DOUBLE  HV_50 = 0;
      TCD_DOUBLE  HV_51 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_20 = 0;
      TCD_INT     HV_23 = 0;
      TCD_INT     HV_26 = 0;
      TCD_INT     HV_30 = 0;
      TCD_INT     HV_33 = 0;
      TCD_INT     HV_36 = 0;
      TCD_INT     HV_46 = 0;
      TCD_INT     HV_52 = 0;
      TCD_INT     HV_53 = 0;
      TCD_INT     HV_54 = 0;
      TCD_INT     HV_55 = 0;
      TCD_INT     HV_56 = 0;
      TCD_INT     HV_57 = 0;
      P_TCDTAB2   HV_7;


   /* Generierung der BeschaffungsFlags: */
      int i_i_Vxnt_IDBeschafft_36 = 0;
   int i_i_Vxnt_ValBeschafft_37 = 0;
   int i_i_Vxnt_ValBeschafft_48 = 0;


   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT772","Begin F_RiskPremium",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,772,"12.12.2019 17:29:50",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_12);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT772",
              "Ende F_RiskPremium",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_6 = 0;
      HV_8 = 0;
      HV_10 = 0;
      HV_13 = 0;
      HV_20 = 0;
      HV_26 = 0;
      HV_30 = 0;
      HV_52 = 0;
      HV_53 = 0;
      HV_54 = 0;
      HV_55 = 0;
      HV_56 = 0;
      HV_57 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_5: 
      HV_4 = (TCD_INT) ( HV_1) ;
      if ( HV_2 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_aj2", 424, 424, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_8: 
      HV_5 = (TCD_INT) ( HV_3) ;
      if ( HV_6 != 0 ) goto l_11 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_11: 
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_4 < 0 || HV_4 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_7 [ HV_4 * 110 + HV_5 ]  > 0 ) goto l_30 ;
      goto l_186 ;
   l_30: 
      if ( HV_8 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "F_PremiumRefundUntil", 699, 699,
         &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_8 = 1;
   l_14: 
      if ( HV_9 == 0 ) goto l_60 ;
      goto l_42 ;
   l_42: 
      if ( HV_8 != 0 ) goto l_17 ;
      rc = TCD3FE1 (pMyPar, 2, "F_PremiumRefundUntil", 699, 699,
         &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_8 = 1;
   l_17: 
      if ( HV_9 > 0 ) goto l_51 ;
      goto l_186 ;
   l_51: 
      if ( HV_10 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_20: 
      if ( HV_8 != 0 ) goto l_23 ;
      rc = TCD3FE1 (pMyPar, 2, "F_PremiumRefundUntil", 699, 699,
         &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_8 = 1;
   l_23: 
      if ( HV_11 <  HV_9 ) goto l_60 ;
      goto l_186 ;
   l_60: 
      if ( HV_52 != 0 ) goto l_94 ;
      if ( HV_10 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_26: 
      HV_15 = HV_11 + 0.99;
      HV_52 = 1;
   l_94: 
      if ( HV_53 != 0 ) goto l_91 ;
      HV_16 = TCDINT ( HV_15 ) ;
      HV_53 = 1;
   l_91: 
      if ( HV_54 != 0 ) goto l_85 ;
      if ( HV_13 != 0 ) goto l_29 ;
      TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_14);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_13 = 1;
   l_29: 
      HV_17 = HV_14 + HV_16;
      HV_54 = 1;
   l_85: 
      if ( HV_52 != 0 ) goto l_118 ;
      if ( HV_10 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_32: 
      HV_15 = HV_11 + 0.99;
      HV_52 = 1;
   l_118: 
      if ( HV_53 != 0 ) goto l_115 ;
      HV_16 = TCDINT ( HV_15 ) ;
      HV_53 = 1;
   l_115: 
      if ( HV_55 != 0 ) goto l_109 ;
      if ( HV_20 != 0 ) goto l_35 ;
      TCD3FES (pMyPar, "i_y", 10, 223, 1, 98, &HV_21);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_20 = 1;
   l_35: 
      HV_22 = HV_21 + HV_16;
      HV_55 = 1;
   l_109: 
   TCDSetPS (pMyPar, 1, 99, &HV_19, &HV_18, HV_17);
   TCDSetPS (pMyPar, 1, 98, &HV_24, &HV_23, HV_22);
      rc = TCD3FE1 (pMyPar, 4, "F_qx", 241, 241, &HV_25);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 98, &HV_24, &HV_23, HV_22);
   TCDSetPS (pMyPar, 0, 99, &HV_19, &HV_18, HV_22);
      if ( HV_56 != 0 ) goto l_127 ;
      if ( HV_26 != 0 ) goto l_38 ;
      rc = TCD3FE1 (pMyPar, 2, "F_SecurityLoading", 673, 673, &HV_27);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_26 = 1;
   l_38: 
      HV_28 = 1 + HV_27;
      HV_56 = 1;
   l_127: 
      HV_29 = HV_25 * HV_28;
      if ( HV_30 != 0 ) goto l_41 ;
      rc = TCD3FE1 (pMyPar, 2, "F_v", 243, 243, &HV_31);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_30 = 1;
   l_41: 
      HV_32 = HV_29 * HV_31;
      if ( HV_52 != 0 ) goto l_154 ;
      if ( HV_10 != 0 ) goto l_44 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_44: 
      HV_15 = HV_11 + 0.99;
      HV_52 = 1;
   l_154: 
      if ( HV_53 != 0 ) goto l_151 ;
      HV_16 = TCDINT ( HV_15 ) ;
      HV_53 = 1;
   l_151: 
      if ( HV_57 != 0 ) goto l_142 ;
   TCDSetPS (pMyPar, 1, 88, &HV_34, &HV_33, HV_16);
      rc = TCD3FE1 (pMyPar, 4, "F_Benefit_Death", 675, 675, &HV_35);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 88, &HV_34, &HV_33, HV_16);
      HV_57 = 1;
   l_142: 
      if ( HV_52 != 0 ) goto l_175 ;
      if ( HV_10 != 0 ) goto l_47 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_47: 
      HV_15 = HV_11 + 0.99;
      HV_52 = 1;
   l_175: 
      if ( HV_53 != 0 ) goto l_172 ;
      HV_16 = TCDINT ( HV_15 ) ;
      HV_53 = 1;
   l_172: 
   TCDSetPS (pMyPar, 1, 88, &HV_34, &HV_33, HV_16);
       if ( !i_i_Vxnt_IDBeschafft_36 &&
       !i_i_Vxnt_ValBeschafft_37 ) {
         if (pMyPar->pTCDTCD->SSAData.pParSkal[102].Level==0) {
            TCDFtID (pMyPar, "i_Vxnt", 14, 278, 1, &HV_36);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_Vxnt_IDBeschafft_36 = 1;
         }
         if ( !i_i_Vxnt_IDBeschafft_36 ) {
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = TCD_RC_OK;
            TCD3FES (pMyPar, "i_Vxnt", 14, 278, 1, 102, &HV_37);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_Vxnt_ValBeschafft_37 = 1;
         }
          if ( !i_i_Vxnt_IDBeschafft_36 &&
          !i_i_Vxnt_ValBeschafft_37 ) goto l_ende;
      }
      if (i_i_Vxnt_IDBeschafft_36) {
         rc = TCD3FE1 (pMyPar, 3, "i_Vxnt", 278, HV_36, &HV_37);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
      }
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 88, &HV_34, &HV_33, HV_16);
      HV_38 = HV_35 - HV_37;
      HV_39 = HV_32 * HV_38;
      HV_40 =   TCDRND ( HV_39, 2 ) ;
      HV_12 = HV_40;
      goto l_3 ;
   l_186: 
      if ( HV_52 != 0 ) goto l_220 ;
      if ( HV_10 != 0 ) goto l_50 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_50: 
      HV_15 = HV_11 + 0.99;
      HV_52 = 1;
   l_220: 
      if ( HV_53 != 0 ) goto l_217 ;
      HV_16 = TCDINT ( HV_15 ) ;
      HV_53 = 1;
   l_217: 
      if ( HV_54 != 0 ) goto l_211 ;
      if ( HV_13 != 0 ) goto l_53 ;
      TCD3FES (pMyPar, "i_x", 11, 233, 1, 99, &HV_14);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_13 = 1;
   l_53: 
      HV_17 = HV_14 + HV_16;
      HV_54 = 1;
   l_211: 
      if ( HV_52 != 0 ) goto l_244 ;
      if ( HV_10 != 0 ) goto l_56 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_56: 
      HV_15 = HV_11 + 0.99;
      HV_52 = 1;
   l_244: 
      if ( HV_53 != 0 ) goto l_241 ;
      HV_16 = TCDINT ( HV_15 ) ;
      HV_53 = 1;
   l_241: 
      if ( HV_55 != 0 ) goto l_235 ;
      if ( HV_20 != 0 ) goto l_59 ;
      TCD3FES (pMyPar, "i_y", 10, 223, 1, 98, &HV_21);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_20 = 1;
   l_59: 
      HV_22 = HV_21 + HV_16;
      HV_55 = 1;
   l_235: 
   TCDSetPS (pMyPar, 1, 99, &HV_19, &HV_18, HV_17);
   TCDSetPS (pMyPar, 1, 98, &HV_24, &HV_23, HV_22);
      rc = TCD3FE1 (pMyPar, 4, "F_qx", 241, 241, &HV_41);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 98, &HV_24, &HV_23, HV_22);
   TCDSetPS (pMyPar, 0, 99, &HV_19, &HV_18, HV_22);
      if ( HV_56 != 0 ) goto l_253 ;
      if ( HV_26 != 0 ) goto l_62 ;
      rc = TCD3FE1 (pMyPar, 2, "F_SecurityLoading", 673, 673, &HV_27);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_26 = 1;
   l_62: 
      HV_28 = 1 + HV_27;
      HV_56 = 1;
   l_253: 
      HV_42 = HV_41 * HV_28;
      if ( HV_30 != 0 ) goto l_65 ;
      rc = TCD3FE1 (pMyPar, 2, "F_v", 243, 243, &HV_31);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_30 = 1;
   l_65: 
      HV_43 = HV_42 * HV_31;
      if ( HV_52 != 0 ) goto l_280 ;
      if ( HV_10 != 0 ) goto l_68 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_68: 
      HV_15 = HV_11 + 0.99;
      HV_52 = 1;
   l_280: 
      if ( HV_53 != 0 ) goto l_277 ;
      HV_16 = TCDINT ( HV_15 ) ;
      HV_53 = 1;
   l_277: 
      if ( HV_57 != 0 ) goto l_268 ;
   TCDSetPS (pMyPar, 1, 88, &HV_34, &HV_33, HV_16);
      rc = TCD3FE1 (pMyPar, 4, "F_Benefit_Death", 675, 675, &HV_35);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 88, &HV_34, &HV_33, HV_16);
      HV_57 = 1;
   l_268: 
      if ( HV_10 != 0 ) goto l_71 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_71: 
      HV_44 = TCDINT ( HV_11 ) ;
      HV_45 = HV_44 + 1;
   TCDSetPS (pMyPar, 1, 88, &HV_47, &HV_46, HV_45);
       if ( !i_i_Vxnt_IDBeschafft_36 &&
       !i_i_Vxnt_ValBeschafft_48 ) {
         if (pMyPar->pTCDTCD->SSAData.pParSkal[102].Level==0) {
            TCDFtID (pMyPar, "i_Vxnt", 14, 278, 1, &HV_36);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_Vxnt_IDBeschafft_36 = 1;
         }
         if ( !i_i_Vxnt_IDBeschafft_36 ) {
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = TCD_RC_OK;
            TCD3FES (pMyPar, "i_Vxnt", 14, 278, 1, 102, &HV_48);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_Vxnt_ValBeschafft_48 = 1;
         }
          if ( !i_i_Vxnt_IDBeschafft_36 &&
          !i_i_Vxnt_ValBeschafft_48 ) goto l_ende;
      }
      if (i_i_Vxnt_IDBeschafft_36) {
         rc = TCD3FE1 (pMyPar, 3, "i_Vxnt", 278, HV_36, &HV_48);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
      }
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 88, &HV_47, &HV_46, HV_45);
      HV_49 = HV_35 - HV_48;
      HV_50 = HV_43 * HV_49;
      HV_51 =   TCDRND ( HV_50, 2 ) ;
      HV_12 = HV_51;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_12);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT772","End F_RiskPremium",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_RiskPremium", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_RiskPremium", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_RiskPremium");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT773
   Beschreibung: Die Funktion berechnet die Formel 
                 F_RiskPremiumSum
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT773 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_DOUBLE  HV_27 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_DOUBLE  HV_29 = 0;
      TCD_DOUBLE  HV_31 = 0;
      TCD_DOUBLE  HV_32 = 0;
      TCD_DOUBLE  HV_33 = 0;
      TCD_DOUBLE  HV_34 = 0;
      TCD_DOUBLE  HV_35 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_16 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_21 = 0;
      TCD_INT     HV_23 = 0;
      TCD_INT     HV_25 = 0;
      TCD_INT     HV_30 = 0;


   /* Generierung der BeschaffungsFlags: */
      int i_i_RiskPremium_IDBeschafft_18 = 0;
   int i_i_RiskPremium_ValBeschafft_19 = 0;


   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT773","Begin F_RiskPremiumSum",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,773,"12.12.2019 17:29:50",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT773",
              "Ende F_RiskPremiumSum",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_3 = 0;
      HV_5 = 0;
      HV_9 = 0;
      HV_13 = 0;
      HV_21 = 0;
      HV_23 = 0;
      HV_25 = 0;
      HV_30 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_tarif_nr", 24, 321, 1, 112, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 >= 30000 ) goto l_18 ;
      goto l_42 ;
   l_18: 
      if ( HV_5 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "e_pfs_n", 77, 452, 6, 77, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_8: 
      HV_7 = 1 + HV_6;
      if ( HV_3 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "e_GrossPremium_n", 84, 461, 6, 84, &HV_4);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_3 = 1;
   l_11: 
      HV_8 = HV_4 * HV_7;
      if ( HV_9 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_m", 4, 166, 1, 92, &HV_10);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_9 = 1;
   l_14: 
      HV_11 = HV_8 * HV_10;
      HV_2 = HV_11;
      goto l_3 ;
   l_42: 
      if ( HV_13 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_14);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_13 = 1;
   l_17: 
      HV_15 = HV_14 - 1;
      HV_20 = 0;
      for ( HV_12 = (TCD_INT) (0) ; HV_12 <= HV_15; HV_12 = HV_12 + 1 )
         {
      TCDSetPS (pMyPar, 1, 88, &HV_17, &HV_16, HV_12);
          if ( !i_i_RiskPremium_IDBeschafft_18 &&
          !i_i_RiskPremium_ValBeschafft_19 ) {
            if (pMyPar->pTCDTCD->SSAData.pParSkal[171].Level==0) {
               TCDFtID (pMyPar, "i_RiskPremium", 83, 471, 1, &HV_18);
               if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
                i_i_RiskPremium_IDBeschafft_18 = 1;
            }
            if ( !i_i_RiskPremium_IDBeschafft_18 ) {
               pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = TCD_RC_OK;
               TCD3FES (pMyPar, "i_RiskPremium", 83, 471, 1, 171,
                  &HV_19);
               if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
                i_i_RiskPremium_ValBeschafft_19 = 1;
            }
             if ( !i_i_RiskPremium_IDBeschafft_18 &&
             !i_i_RiskPremium_ValBeschafft_19 ) goto l_ende;
         }
         if (i_i_RiskPremium_IDBeschafft_18) {
            rc = TCD3FE1 (pMyPar, 3, "i_RiskPremium", 471, HV_18,
               &HV_19);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
               l_ende;
         }
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 88, &HV_17, &HV_16, HV_12);
         HV_20 = HV_19 + HV_20;
      }
      if ( HV_25 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_NumberOfInsPers", 25, 324, 1, 113, &HV_26);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_25 = 1;
   l_20: 
      HV_27 = HV_26 - 1;
      if ( HV_23 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_addSurcharge_IP2", 39, 376, 1, 127, &HV_24);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_23 = 1;
   l_23: 
      HV_28 = HV_24 * HV_27;
      if ( HV_21 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_addSurcharge_IP1", 38, 375, 1, 126, &HV_22);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_21 = 1;
   l_26: 
      HV_29 = HV_22 + HV_28;
      if ( HV_30 != 0 ) goto l_29 ;
      TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_31);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_30 = 1;
   l_29: 
      HV_32 = HV_29 * HV_31;
      if ( HV_9 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "i_m", 4, 166, 1, 92, &HV_10);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_9 = 1;
   l_32: 
      HV_33 = HV_32 * HV_10;
      HV_34 = HV_20 + HV_33;
      HV_35 =   TCDRND ( HV_34, 2 ) ;
      HV_2 = HV_35;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT773","End F_RiskPremiumSum",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_RiskPremiumSum", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_RiskPremiumSum", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_RiskPremiumSum");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT774
   Beschreibung: Die Funktion berechnet die Formel 
                 F_SavingsPremiumSum
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT774 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_3 = 0;


   /* Generierung der BeschaffungsFlags: */
      int i_i_SavingsPrem_IDBeschafft_10 = 0;
   int i_i_SavingsPrem_ValBeschafft_11 = 0;


   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT774","Begin F_SavingsPremiumSum",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,774,"12.12.2019 17:29:50",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT774",
              "Ende F_SavingsPremiumSum",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_5 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_tarif_nr", 24, 321, 1, 112, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 >= 30000 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_5 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_8: 
      HV_7 = HV_6 - 1;
      HV_12 = 0;
      for ( HV_4 = (TCD_INT) (0) ; HV_4 <= HV_7; HV_4 = HV_4 + 1 ) {
      TCDSetPS (pMyPar, 1, 88, &HV_9, &HV_8, HV_4);
          if ( !i_i_SavingsPrem_IDBeschafft_10 &&
          !i_i_SavingsPrem_ValBeschafft_11 ) {
            if (pMyPar->pTCDTCD->SSAData.pParSkal[172].Level==0) {
               TCDFtID (pMyPar, "i_SavingsPrem", 84, 472, 1, &HV_10);
               if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
                i_i_SavingsPrem_IDBeschafft_10 = 1;
            }
            if ( !i_i_SavingsPrem_IDBeschafft_10 ) {
               pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = TCD_RC_OK;
               TCD3FES (pMyPar, "i_SavingsPrem", 84, 472, 1, 172,
                  &HV_11);
               if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
                i_i_SavingsPrem_ValBeschafft_11 = 1;
            }
             if ( !i_i_SavingsPrem_IDBeschafft_10 &&
             !i_i_SavingsPrem_ValBeschafft_11 ) goto l_ende;
         }
         if (i_i_SavingsPrem_IDBeschafft_10) {
            rc = TCD3FE1 (pMyPar, 3, "i_SavingsPrem", 472, HV_10,
               &HV_11);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
               l_ende;
         }
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 88, &HV_9, &HV_8, HV_4);
         HV_12 = HV_11 + HV_12;
      }
      HV_13 =   TCDRND ( HV_12, 2 ) ;
      HV_2 = HV_13;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT774","End F_SavingsPremiumSum",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_SavingsPremiumSum", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_SavingsPremiumSum", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_SavingsPremiumSum");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT775
   Beschreibung: Die Funktion berechnet die Formel 
                 F_SavingsPremium
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT775 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_DOUBLE  HV_29 = 0;
      TCD_DOUBLE  HV_31 = 0;
      TCD_DOUBLE  HV_32 = 0;
      TCD_DOUBLE  HV_33 = 0;
      TCD_DOUBLE  HV_34 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_11 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_15 = 0;
      TCD_INT     HV_20 = 0;
      TCD_INT     HV_23 = 0;
      TCD_INT     HV_27 = 0;
      TCD_INT     HV_30 = 0;
      TCD_INT     HV_35 = 0;
      TCD_INT     HV_36 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_18 = 0;


   /* Generierung der BeschaffungsFlags: */
      int i_i_Vxnt_IDBeschafft_13 = 0;
   int i_i_Vxnt_ValBeschafft_14 = 0;
   int i_i_Vxnt_ValBeschafft_22 = 0;


   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT775","Begin F_SavingsPremium",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,775,"12.12.2019 17:29:50",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT775",
              "Ende F_SavingsPremium",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      HV_7 = 0;
      HV_9 = 0;
      HV_15 = 0;
      HV_23 = 0;
      HV_30 = 0;
      HV_35 = 0;
      HV_36 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_tarif_nr", 24, 321, 1, 112, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 >= 30000 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_35 != 0 ) goto l_34 ;
      if ( HV_4 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_8: 
      HV_6 = TCDINT ( HV_5 ) ;
      HV_35 = 1;
   l_34: 
      if ( HV_6 == 0 ) goto l_42 ;
      goto l_69 ;
   l_42: 
      if ( HV_7 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_State", 67, 421, 1, 155, &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_11: 
      if ( HV_9 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "_premFree", 648, 648, &HV_10);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_9 = 1;
   l_14: 
      if ( HV_8 == HV_10 ) goto l_51 ;
      goto l_69 ;
   l_51: 
      if ( HV_35 != 0 ) goto l_64 ;
      if ( HV_4 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_17: 
      HV_6 = TCDINT ( HV_5 ) ;
      HV_35 = 1;
   l_64: 
      if ( HV_36 != 0 ) goto l_55 ;
   TCDSetPS (pMyPar, 1, 88, &HV_12, &HV_11, HV_6);
       if ( !i_i_Vxnt_IDBeschafft_13 &&
       !i_i_Vxnt_ValBeschafft_14 ) {
         if (pMyPar->pTCDTCD->SSAData.pParSkal[102].Level==0) {
            TCDFtID (pMyPar, "i_Vxnt", 14, 278, 1, &HV_13);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_Vxnt_IDBeschafft_13 = 1;
         }
         if ( !i_i_Vxnt_IDBeschafft_13 ) {
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = TCD_RC_OK;
            TCD3FES (pMyPar, "i_Vxnt", 14, 278, 1, 102, &HV_14);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_Vxnt_ValBeschafft_14 = 1;
         }
          if ( !i_i_Vxnt_IDBeschafft_13 &&
          !i_i_Vxnt_ValBeschafft_14 ) goto l_ende;
      }
      if (i_i_Vxnt_IDBeschafft_13) {
         rc = TCD3FE1 (pMyPar, 3, "i_Vxnt", 278, HV_13, &HV_14);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
      }
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 88, &HV_12, &HV_11, HV_6);
      HV_36 = 1;
   l_55: 
      HV_2 = HV_14;
      goto l_3 ;
   l_69: 
      if ( HV_15 != 0 ) goto l_20 ;
      rc = TCD3FE1 (pMyPar, 2, "F_n", 364, 364, &HV_16);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_15 = 1;
   l_20: 
      HV_17 = HV_16 - 1;
      if ( HV_4 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_23: 
      if ( HV_5 > HV_17 ) goto l_87 ;
      goto l_93 ;
   l_87: 
      HV_18 = 0;
      HV_2 = HV_18;
      goto l_3 ;
   l_93: 
      if ( HV_35 != 0 ) goto l_121 ;
      if ( HV_4 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_26: 
      HV_6 = TCDINT ( HV_5 ) ;
      HV_35 = 1;
   l_121: 
      HV_19 = HV_6 + 1;
   TCDSetPS (pMyPar, 1, 88, &HV_21, &HV_20, HV_19);
       if ( !i_i_Vxnt_IDBeschafft_13 &&
       !i_i_Vxnt_ValBeschafft_22 ) {
         if (pMyPar->pTCDTCD->SSAData.pParSkal[102].Level==0) {
            TCDFtID (pMyPar, "i_Vxnt", 14, 278, 1, &HV_13);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_Vxnt_IDBeschafft_13 = 1;
         }
         if ( !i_i_Vxnt_IDBeschafft_13 ) {
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = TCD_RC_OK;
            TCD3FES (pMyPar, "i_Vxnt", 14, 278, 1, 102, &HV_22);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_Vxnt_ValBeschafft_22 = 1;
         }
          if ( !i_i_Vxnt_IDBeschafft_13 &&
          !i_i_Vxnt_ValBeschafft_22 ) goto l_ende;
      }
      if (i_i_Vxnt_IDBeschafft_13) {
         rc = TCD3FE1 (pMyPar, 3, "i_Vxnt", 278, HV_13, &HV_22);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
      }
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 88, &HV_21, &HV_20, HV_19);
      if ( HV_23 != 0 ) goto l_29 ;
      rc = TCD3FE1 (pMyPar, 2, "F_v", 243, 243, &HV_24);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_23 = 1;
   l_29: 
      HV_25 = HV_22 * HV_24;
      if ( HV_35 != 0 ) goto l_142 ;
      if ( HV_4 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_32: 
      HV_6 = TCDINT ( HV_5 ) ;
      HV_35 = 1;
   l_142: 
      if ( HV_36 != 0 ) goto l_133 ;
   TCDSetPS (pMyPar, 1, 88, &HV_12, &HV_11, HV_6);
       if ( !i_i_Vxnt_IDBeschafft_13 &&
       !i_i_Vxnt_ValBeschafft_14 ) {
         if (pMyPar->pTCDTCD->SSAData.pParSkal[102].Level==0) {
            TCDFtID (pMyPar, "i_Vxnt", 14, 278, 1, &HV_13);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_Vxnt_IDBeschafft_13 = 1;
         }
         if ( !i_i_Vxnt_IDBeschafft_13 ) {
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = TCD_RC_OK;
            TCD3FES (pMyPar, "i_Vxnt", 14, 278, 1, 102, &HV_14);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_Vxnt_ValBeschafft_14 = 1;
         }
          if ( !i_i_Vxnt_IDBeschafft_13 &&
          !i_i_Vxnt_ValBeschafft_14 ) goto l_ende;
      }
      if (i_i_Vxnt_IDBeschafft_13) {
         rc = TCD3FE1 (pMyPar, 3, "i_Vxnt", 278, HV_13, &HV_14);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
      }
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 88, &HV_12, &HV_11, HV_6);
      HV_36 = 1;
   l_133: 
      HV_26 = HV_25 - HV_14;
      if ( HV_35 != 0 ) goto l_160 ;
      if ( HV_4 != 0 ) goto l_35 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_35: 
      HV_6 = TCDINT ( HV_5 ) ;
      HV_35 = 1;
   l_160: 
   TCDSetPS (pMyPar, 1, 108, &HV_28, &HV_27, HV_6);
      rc = TCD3FE1 (pMyPar, 4, "F_ej", 257, 257, &HV_29);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 108, &HV_28, &HV_27, HV_6);
      if ( HV_30 != 0 ) goto l_38 ;
      TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_31);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_30 = 1;
   l_38: 
      HV_32 = HV_29 * HV_31;
      HV_33 = HV_26 + HV_32;
      HV_34 =   TCDRND ( HV_33, 2 ) ;
      HV_2 = HV_34;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT775","End F_SavingsPremium",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_SavingsPremium", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_SavingsPremium", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_SavingsPremium");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT776
   Beschreibung: Die Funktion berechnet die Formel 
                 F_PremiumSplit
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT776 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      P_TCDTAB1   HV_1;
      TCD_INT     HV_8 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT776","Begin F_PremiumSplit",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,776,"12.12.2019 17:29:49",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Besorgen einer freien Tabelle, falls Formel vom Typ TAB1/TAB2 */
   rc =    TCDGetTb (pMyPar, &HV_1);


   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_1);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT776",
              "Ende F_PremiumSplit",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_2 = 0;
      HV_4 = 0;
      HV_6 = 0;
      for ( HV_0 = (TCD_INT) (0) ; HV_0 <= 199; HV_0 = HV_0 + 1 ) {
         if ( HV_0 > 2 ) goto l_18 ;
         goto l_21 ;
      l_18: 
      goto l_ende ;
      l_21: 
         if ( HV_0 == 0 ) goto l_33 ;
         goto l_42 ;
      l_33: 
         if ( HV_2 != 0 ) goto l_5 ;
         rc = TCD3FE1 (pMyPar, 2, "F_SavingsPremiumSum", 774, 774,
            &HV_3);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_2 = 1;
      l_5: 
         HV_1 [ HV_0 ]  = HV_3;
         continue ;
      l_42: 
         if ( HV_0 == 1 ) goto l_54 ;
         goto l_63 ;
      l_54: 
         if ( HV_4 != 0 ) goto l_8 ;
         rc = TCD3FE1 (pMyPar, 2, "F_RiskPremiumSum", 773, 773,
            &HV_5);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_4 = 1;
      l_8: 
         HV_1 [ HV_0 ]  = HV_5;
         continue ;
      l_63: 
         if ( HV_0 == 2 ) goto l_75 ;
         goto l_84 ;
      l_75: 
         if ( HV_6 != 0 ) goto l_11 ;
         rc = TCD3FE1 (pMyPar, 2, "F_CostPremiumSum", 771, 771,
            &HV_7);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_6 = 1;
      l_11: 
         HV_1 [ HV_0 ]  = HV_7;
         continue ;
      l_84: 
         HV_8 = 0;
         HV_1 [ HV_0 ]  = HV_8;
         continue ;
      }


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetTb (pMyPar, &HV_1);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT776","End F_PremiumSplit",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_PremiumSplit", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_PremiumSplit", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_PremiumSplit");
   }                                         
   return ;

   }
}

