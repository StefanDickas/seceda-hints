/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/

#if !defined (TCD_CIMP_H)
#define TCD_CIMP_H
/*---------------------------------------------------------------------
    Name        : TCD_CIMP.H

    Beschreibung: Include File mit Strukturdefinitionen f�r die Import-
                  schnittstelle
    By          : BEGGI
    Datum       : 19.05.94

    Historie:   07.10.95 RON
                Name (f�r Proc) in Struktur S_TCDIMPCTL eingef�gt

                22.12.95 RON
                pRefProc in Contorl-Struktur eingef�hrt.

                28.08.96 KAT
                Union U_TCDIMPDATA durch Struktur S_TCDIMPDATA ersetzt
*--------------------------------------------------------------------*/


/*---------------------------------------------------------------------
  Defines Returncodes
---------------------------------------------------------------------*/
    #define RC_OK                  0
    #define RC_VAL_TRUNCATED       1
    #define RC_ROW_TRUNCATED       2
    #define RC_COL_TRUNCATED       3
    #define RC_PTH_TRUNCATED       4
    #define RC_ATTR_TRUNCATED      5
    #define RC_DESC_TRUNCATED      6
    #define RC_TAB_PTR_0           7
    #define RC_FILE_ERROR          8
    #define RC_ILLEGAL_IMPORT      9
    #define RC_EOT                10
    #define RC_INV_IMPTYP         11
    #define RC_INV_OPC            12
    #define RC_NO_ID              13
    #define RC_NOMEM              14
    #define RC_VERS_CONF          15

    #define RC_SYS_ERROR          -1

/*---------------------------------------------------------------------
  Defines Importtyp
---------------------------------------------------------------------*/
    #define TCD_IMPTYP_TAB1        1
    #define TCD_IMPTYP_TAB2        2
    #define TCD_IMPTYP_PROC        3
    #define TCD_IMPTYP_NODE        4

/*---------------------------------------------------------------------
  Defines Usage
---------------------------------------------------------------------*/
    #define TCD_USAGE_ONCE         1
    #define TCD_USAGE_MULTIPLE     2

/*---------------------------------------------------------------------
  Defines Optionen
---------------------------------------------------------------------*/
    #define TCD_ALLES              1    /* alle Proc-Info uebergeben */
    #define TCD_OHNE_BELEGLISTE    2
    #define TCD_NUR_TABBELEGLISTE  3
    #define TCD_BELEGLISTE_AM_ENDE 4
    #define TCD_COPY_TRPFILE       5

    #define TCD_IMP_TRPFILE        6

/*---------------------------------------------------------------------
  Defines L�ngenangabe
---------------------------------------------------------------------*/
    #define TCD_DESC_LEN          80

/*---------------------------------------------------------------------
  Defines Buffertypes
---------------------------------------------------------------------*/
    #define TCD_FILE               1
    #define TCD_MEM                2

/*---------------------------------------------------------------------
  Defines Statusangaben
---------------------------------------------------------------------*/
   #define TCD_IMPSTAT_INIT        1
   #define TCD_IMPSTAT_NODE        2
   #define TCD_IMPSTAT_PROC        3
   #define TCD_IMPSTAT_EOF        (-1)

/*---------------------------------------------------------------------
  Datenstruktur Importfunktionen
---------------------------------------------------------------------*/
#ifndef DOS_NAME_LNG
   #define DOS_NAME_LNG           257
#endif
   #define MAX_TOKEN_SIZE         1024

typedef struct tagS_TCDATTRDATA 
{            /* Struktur: Knotenattribute */
        char       Name     [TCD_NAME_LNG];
        char       Value    [TCD_NAME_LNG];
        char       DefValue [TCD_NAME_LNG];
} S_TCDATTRDATA ;

typedef  struct tagS_TCDDESCDATA {           /* Descriptorbereich */
         char    Value [TCD_DESC_LEN] ;
} S_TCDDESCDATA ;

typedef  struct tagS_TCDPATHDATA {           /* Pfadknoten */
             char      Path  [TCD_NAME_LNG] ;
} S_TCDPATHDATA ;


typedef struct tagS_TCDNODEDATA 
{                                         
/* Datenbereich: Knotenimport  */
    char          NodeName [TCD_NAME_LNG];
    /* KnotenName                  */
    TCD_LONG      NodeId     ;            
    /* KnotenID                    */
    char          NodeTyp [TCD_NAME_LNG]; 
    /* Knotentyp                   */
    TCD_LONG      NodeTypId  ;            
    /* ID des Knotentyps           */
    TCD_INT       AnzPathEnt ;            
    /* Anzahl Pfadknoten           */
    S_TCDPATHDATA *PathData ;             
    /* Zeiger auf Pfadnamen        */
    TCD_INT       AnzAttrInfo;            
    /* Anzahl Knotenattribute      */
    S_TCDATTRDATA *AttrData ;             
    /* Zeiger auf Knotenattribute  */
    char          *Desc ;                 
    /* Zeiger auf Kommentar        */

} S_TCDNODEDATA ;

typedef S_TCDNODEDATA   * P_TCDNODEDATA ;

typedef struct tagS_TCDTABATTRDATA 
{         /* Struktur: Knotenattribute */
        char       Name     [TCD_NAME_LNG];
        char       Value    [TCD_NAME_LNG];
} S_TCDTABATTRDATA ;


typedef struct tagS_TCDTABINFO 
{            /* Datenbereich: Tabellenimport */
TCD_LONG      NodeId     ;           /* KnotenID                    */
TCD_INT       AnzPathEnt ;           /* Anzahl Pfadknoten           */
S_TCDPATHDATA *PathData ;            /* Zeiger auf Pfadnamen        */
TCD_INT       AnzZeilen ;
TCD_INT       AnzSpalten ;
TCD_INT       AnzStellen ;
TCD_INT       AnzNkStellen ;
TCD_INT       AnzAttrInfo;           /* Anzahl Knotenattribute      */
S_TCDTABATTRDATA *AttrData ;         /* Zeiger auf Knotenattribute  */
char          *Desc ;                /* Zeiger auf Kommentar        */
} S_TCDTABINFO ;

typedef S_TCDTABINFO    *P_TCDTABINFO ;

typedef struct tagS_TCDTABIMPDATA 
{           /* Datenbereich: Tabellenimpor*/
        P_TCDTABINFO   pTabInfo ;
        P_TCDTAB       TabValues ;
} S_TCDTABIMPDATA ;

typedef S_TCDTABIMPDATA * P_TCDTABIMPDATA ;


typedef struct tagS_TCDTREEDATA
{
  TCD_LONG ID;           /*BV-ID*/
  char *sName;      /*BV-Pfad-Name*/
} S_TCDTREEDATA;


typedef struct tagS_TCDTABTREEDATA
{
  TCD_LONG ID;      /*BV-ID        */
  char *sName;      /*Tab-Pfad-Name*/
  int  iCol;        /*Zeilenanzahl */
  int  iRow;        /*Spaltenanzahl*/
  int  iVk;         /*Vorkommastellen*/
  int  iNk;         /*nachkommastellen*/
} S_TCDTABTREEDATA;





typedef struct tagS_TCDIMPDATA 
{             /* Datenbereich import. Daten */
P_TCDNODEDATA    pNodeData;           /* Tarifknotendaten           */
P_TCDPRCELEM     pProcData;           /* Auspr�gungsdaten           */
P_TCDTABIMPDATA  pTabData;            /* Tabellen + Tabknotendaten  */
S_TCDTREEDATA  **   pTreeData;      /* Null-terminierter Vektor von */
                                /* Zeigern auf S_TCDTREEDATAOBJEKTEN*/
S_TCDTABTREEDATA ** pTabTreeData; /* Null-terminierter Vektor von   */
                             /* Zeigern auf S_TCDTABTREEDATAOBJEKTEN*/
} S_TCDIMPDATA ;               


typedef struct tagS_TCDIMPCTL 
{              /* Kontrollstruktur           */
TCD_INT Typ       ;                  /* Import-Typ                 */
                                     /* Wertebereich: Defines Impor*/
TCD_INT  Rc       ;                  /* Returncode                 */
ERRNO_TYPE Errno;                    /* R. wert der I/O-Operationen*/
char     ErrFileName[TCD_FILENAME_LNG];/* Name der Datei, auf der die 
                                        letzte I/O-Operation versucht
                                        wurde */
TCD_INT  AnzZeilen ;                 /* Tabgr��e RBS: Anz. Zeilen  */
TCD_INT  AnzSpalten;                 /* Tabgr��e RBS: Anz. Spalten */
TCD_INT  AnzTabData ;                /* Anzahl der Tabelleneintr�ge*/
                                     /* nur bei Tabs               */
TCD_LONG ID ;                        /* die ID des import. Objects */
                                     /* nur bei Tabs und Procs     */
char       Name     [TCD_NAME_LNG];  /* Name der Prozedur          */
                                     /* RON */
TCD_INT  Dim ;                       /* Dim. 1 /2 , nur bei Tab    */
TCD_INT  Status ;
char *   pRefProc;                   /* 22.12.95, RON,             */
TCD_INT  Option ;                    /* Optionen zum Aufruf        */
FILE    *fpTrpFile;                  /* Ziel-Transport-Datei       */
int  (* ChckFkt)();                  /* Fkt zum Pr�fen erw�nschter */
                                             /* Objekte            */
} S_TCDIMPCTL;

typedef union tagU_TCDIMPBUF
{
    FILE * File;
    char * Mem; 
}   U_TCDIMPBUF;

typedef struct tagS_TCDIMPORT
{
    TCD_INT Type;
    U_TCDIMPBUF Buffer; 
    char   FileName[DOS_NAME_LNG];
    struct tagS_TCDIMPORTSS *pImportSS;
}   S_TCDIMPORT;
typedef S_TCDIMPORT *   P_TCDIMPORT;


typedef struct tagS_PRIVATE
{
	S_TCDIMPORT      ImpBuffer;
	char * 			 TCDImpTreeFNam;
	char             token[MAX_TOKEN_SIZE] ;
	TCD_BOOL         PrcBelegCmpl ;
    int  			 ScanLen ;
    char 			 PathBuf[256];
    P_TCDPRCELEM     pInfo;
    P_TCDRELATTR_IMP pRelAttrs;
	 void *           pSavePtr ; 
} S_PRIVATE;

typedef S_PRIVATE * P_PRIVATE;

typedef struct tagS_TCDIMPORTSS 
{		     				         /* Struktur der Importschnitt-*/
                                     /* stelle                     */
	S_TCDIMPCTL      ICTL ;          /* Kontrollstruktur Importfkt */
	S_TCDIMPDATA     Data ;          /* Datenbereich               */
	S_PRIVATE        Private;        /* private structure          */
} S_TCDIMPORTSS ;

typedef S_TCDIMPORTSS * P_TCDIMPORTSS ;

/*---------------------------------------------------------------------
  Funktions Prototypen
---------------------------------------------------------------------*/
void TCDIMPF  ( P_TCDIMPORTSS req, FILE * ImpStream,\
                char * ImpStreamName );
void TCDIMPB  ( P_TCDIMPORTSS req, char * ImpBuffer );
void TCDIMPNF ( P_TCDIMPORTSS req, char * TreeFNam  );
void TCDCPYNF ( P_TCDIMPORTSS req, char * TreeFNam  );
void TCDIMPR  ( P_TCDIMPORTSS req                   );
void TCDIMPTF ( P_TCDIMPORTSS req, char * TreeFNam  );
void TCDIMPImportTreeData(P_TCDIMPORTSS req, char * TreeFNam);
S_TCDTREEDATA* TCDIMPGetNodeFromID(S_TCDTREEDATA** pTreeData, 
                                    TCD_LONG ID);
S_TCDTREEDATA* TCDIMPGetNodeFromPath(S_TCDTREEDATA **pTree,
                                     char *sPath);
void TCDIMPReleaseTreeData(S_TCDTREEDATA ***pTreeData);
S_TCDTABTREEDATA*
TCDIMPGetTabIDAndTypFromPath(S_TCDTABTREEDATA **pTabTree,
                                     char *sPath);
S_TCDTABTREEDATA*
TCDIMPGetPathAndTypFromID(S_TCDTABTREEDATA **pTabTree, TCD_LONG ID);
void TCDIMPReleaseTabTreeData(S_TCDTABTREEDATA ***pTabTreeData);
void  TCDIMPImportTabTreeData( P_TCDIMPORTSS req, char * TreeFNam);


/* Destruktoren */
void TCDIMPReleaseTabImpData( P_TCDTABIMPDATA * , TCD_BOOL , TCD_BOOL);
void TCDIMPReleaseTabData   ( P_TCDTAB      *ppTabValues );
void TCDIMPReleaseProcData  ( P_TCDPRCELEM  * );
void TCDIMPReleaseNodeData  ( P_TCDNODEDATA * );

#endif
