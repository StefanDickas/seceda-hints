/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_DAT_H)
#define TCD_DAT_H
/*---------------------------------------------------------------------
  Datei:   TCD_DAT.h
  Beschreibung: Schnittstelle zum Datenmanager.
  Historie:       06.03.96  BEG   Datei gefreezt
              06.03.96  BEG   Erweiterungen, neue ext. Funktion TCDDSV
              20.06.96  RWE   neue Prototypen        
              13.10.96  MUB   Schnittstellen um pTCDTCD erweitert
---------------------------------------------------------------------*/
void  TCDDIP (P_TCD_C_G pTCDTCD) ;
void  TCDDGPI(P_TCD_C_G pTCDTCD) ;
void  TCDDGA (P_TCD_C_G pTCDTCD) ;
void  TCDDSA (P_TCD_C_G pTCDTCD) ;
void  TCDDSP (P_TCD_C_G pTCDTCD) ;
void  TCDDRP (P_TCD_C_G pTCDTCD) ;
void  TCDDSV (P_TCD_C_G pTCDTCD) ;

void          ReleasePrcAttrResults   (P_TCDPRCELEM);
void          ReleaseMPrcAttrResults  (P_TCDMPRCADMIN);
P_TCDPRCELEM  MPrcAdminGetPrc         (P_TCDMPRCADMIN,TCD_LONG);

#endif
