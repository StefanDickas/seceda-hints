/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
/*---------------------------------------------------------------------
Program:       TCD_DAT.C

Beschreibung: Daten Manager; zentrales Zugriffsmodul auf die Daten
des Auspr,gungsbaums
By:           BEGGI
Datum:        28.02.94
Historie:     21.03.95  BEGGI Umorganisiert, neue Funktion TCDDSA
09.05.95  BEG   TCDDGA korrigiert: Indexvalidierung erg,nzt
17.05.95  BEG   TCDDIP erweitert: Freigabe bereits ber. proc
31.05.95  BEG   GetFreeEntry korrigiert
06.07.95  BEG   TCDDRP erweitert
27.07.95  BEG   TCDDSA geaendert
04.08.95  BEG   Fehlerkorrekturen : InitPrc unbedingt
29.01.96  BEG   FM: 394 : InitPrcData
20.02.96  BEG   FM: 394 : TCDDIP
06.03.96  BEG   Datei gefreezt
06.03.96  BEG   Erweiterungen, neue ext. Funktion TCDDSV
20.06.96  RWE   3 neue Fkten: ReleaseMPrcAttrResults,
                            ReleasePrcAttrResults,
                            MPrcAdminGetPrc
              Aufruf v. ReleasePrcAttrResults in TCDDRP
02.07.96  MUB   LocalData komplett herausgenommen
03.07.96  MUB   TCDDG auf R�ckgabe Ergebnis aus 
pResultForGetAttr umgestellt
---------------------------------------------------------------------*/

/*---------------------------------------------------------------------
   Includes
---------------------------------------------------------------------*/
/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDPORTAB_H)
#define TCDPORTAB_H

/*-----------------
Name        : TCDPORTAB.H

Beschreibung: externes Include File, das generierumgeungsspezifische
Informationen enthaelt (Makrovorlage).
By          : BEGGI
Datum       : 20.04.94
Historie:     BEG   17.01.95  neues Makro _TCDMEMINI anstatt memset
BEG   02.03.95  bedingte Macros TCDHUGE
BEG   22.06.95  _TCDMEMINI nur im HUGE-Modell redefiniert.
BEG   20.02.96  malloc.h wird nicht mehr inkludiert (FM 451)
RWE   21.06.96  malloc.h wird wieder includiert (aber nur
              fuers HUGE-Modell, d.h. fuer DOS/WIN-Compiler)
RWE   26.06.96  WATCHMEM-Makros eingebaut (fuer TCDALLOC etc)
MUB   17.7.96   Include mit !defined versehen
KFC   02.09.96  #define TCDHUGE vorgezogen

-------------------*/

/* #define TCDHUGE */              /* bei gro�en Tabellen einschalten*/
/* Systemincludes */                  
#include <stdlib.h>                /* atoi, ...       */
#include <stdio.h>                 /* fprintf, ...    */
#include <string.h>                /* strcpy, ...     */
#include <time.h>                  /* time_t, ...     */
#include <math.h>                  /* exp, min, max, ... */

#ifdef TCDHUGE
#include <malloc.h>
#endif

/* Defines */
#define  TCDC_EXT_NAME_LNG    8  /* maximale L�nge von externen 
                                    Bezeichnern*/
/*-----------------
  Definitionen aus standard C-Includes z.B. stdio.h
-------------------*/
#ifndef NULL
#define    NULL    (void *)0
#endif

/*-----------------
  Definitionen von Basistypen
-------------------*/
typedef    short   TCD_BOOL ;
typedef    long    TCD_LONG ;
typedef    int     TCD_INT  ;
typedef    double  TCD_DOUBLE ;


/*-----------------
  modellabhaengige Definitionen von Basistypen
-------------------*/
typedef    TCD_DOUBLE  TCDTAB ;
#ifdef TCDHUGE
typedef    TCDTAB       huge * P_TCDTAB ;
typedef    TCD_DOUBLE   huge * P_TCD_DOUBLE ;
typedef    P_TCD_DOUBLE * P_P_TCD_DOUBLE ;
typedef    char huge    * TCD_LPCHAR ;
#else
typedef    TCDTAB       * P_TCDTAB ;
typedef    TCD_DOUBLE   * P_TCD_DOUBLE ;
typedef    P_TCD_DOUBLE * P_P_TCD_DOUBLE ;
typedef    char         * TCD_LPCHAR ;
#endif

/*-----------------
  weitere (Typ-)Defines 
-------------------*/  
typedef int ERRNO_TYPE;
#define TCD_FILENAME_LNG 128

/*-----------------
  Definitionen von Makros f�r Speicherallokation
-------------------*/  

/* WATCHMEM muss im TCDHUGE-Modus abgeschaltet sein */
#ifdef TCDHUGE
#undef WATCHMEM
#endif

#undef _TCDALLOC
#undef _TCDFREE
#undef _TCDREALLOC

#ifndef WATCHMEM

#define _TCDALLOC(len,size)    malloc( (size_t)(len) * (size)) ;
#define _TCDFREE(ptr)          {free(ptr), ptr = NULL;}
#define _TCDREALLOC(ptr,size)  realloc( ptr, (size_t)(size) ) ;

#else
 
void *MallocAndProt(char *sFile_,int iLine_, size_t size);
#define _TCDALLOC(len,size)\
 MallocAndProt(__FILE__,__LINE__,(len) * (size))

void FreeAndProt(char *sFile_, int iLine_, void *p_);

#define _TCDFREE(ptr)\
       {FreeAndProt(__FILE__, __LINE__, ptr) , ptr = NULL;}

void *ReallocAndProt(char *sFile_,int iLine_, void *p_, size_t size);
#define _TCDREALLOC(ptr,size)\
 ReallocAndProt(__FILE__, __LINE__, ptr,size)

void ResumeWatchmem();

#endif

/*-----------------
  modellabh�ngige Definitionen von Makros f�r Speicherallokation
-------------------*/
#undef _TCDTABALLOC
#undef _TCDTABFREE
#undef _TCDMEMINI

#ifdef TCDHUGE

#define _TCDTABALLOC(len,size)\
  _halloc( (long)(len) , (size_t)(size)) ;
#define _TCDTABFREE(ptr)\
      { _hfree ( (void huge *)ptr); ptr = NULL;}

#else

#ifndef WATCHMEM
#define _TCDTABALLOC(len,size)\
 malloc((size_t)((long)len) * ((size_t)size)) ;
#define _TCDTABFREE(ptr)       {free(ptr), ptr = NULL;}
#else
#define _TCDTABALLOC(len,size)\
 MallocAndProt(__FILE__,__LINE__,(len) * (size))
#define _TCDTABFREE(ptr)\
       FreeAndProt(__FILE__, __LINE__, ptr)
#endif

#endif


#ifdef TCDHUGE
#define _TCDMEMINI(ptr,size,nr)\
{\
   long       j;\
   TCD_LPCHAR lp;\
   for (j= 0 , lp = (TCD_LPCHAR)ptr;\
        j < ((long)(size) * (long)(nr)); j++, lp++) \
      *lp = 0;\
}  

#else
#define _TCDMEMINI(ptr,size,nr)\
 { memset (ptr, 0, (size_t) ((size) * (nr))) ; }
#endif
/*---------------------------------
  NON-Ansi-Namen mit oder ohne "_"
----------------------------------*/

/* #define NON_ANSI_WITHOUT__ */

#ifdef NON_ANSI_WITHOUT__
#define _fcvt fcvt
#endif

/*---------------------------
  ggf. Verkuerzung der Namen
-----------------------------*/
#ifdef TCD_NAMLEN8

#define TCDIMPReleaseProcData       TCD_0001
#define TCDIMPReleaseNodeData       TCD_0002
#define TCDIMPReleaseTabImpData     TCD_0003   

#define FetchFromGlobalErgebnisPool TCD_0004

#define DelEltFromSVect             TCD_0005
#define DelEltFromSVectByIndex      TCD_0006

#define DelEltFromVect              TCD_0007
#define DelEltFromVectByIndex       TCD_0008
                                
                                
#define ReleaseGlobalErgebnisPool   TCD_0009
#define ReleaseGlobalErgebnis       TCD_0010
#define ReleaseLocalErgebnisPool    TCD_0011

#define GetPrcDataSkal              TCD_0012
#define GetPrcDataTab               TCD_0013
#define GetPrcDataDat               TCD_0014
#define GetPrcDataFrm               TCD_0015

#define GetPrcAttrSkal              TCD_0016
#define GetPrcAttrTab               TCD_0017

#define GetSSAttrSkal               TCD_0018
#define GetSSAttrTab                TCD_0019

#define ErgPoolGetFirstInfo         TCD_0020
#define ErgPoolGetNextInfo          TCD_0021

#define DConstrAttrs                TCD_0022
#define DConstrAttrsResults         TCD_0023

#define GetRelAttrs                 TCD_0024

#define GetIndexToGlobalErgPool     TCD_0025
#define GetIndexToPaarListElt       TCD_0026

#define GetIndexToSS                TCD_0027
#define GetIndexToUes               TCD_0028
#define GetFromSS                   TCD_0029
#define GetFromUes                  TCD_0030

#define TCDIMPImportTreeData        TCD_0031
#define TCDIMPNFIntl                TCD_0032
#define TCDIMPGetNodeFromID         TCD_0033
#define TCDIMPGetNodeFromPath       TCD_0034
#define compBsearch                 TCD_0035
#define TCDIMPReleaseTreeData       TCD_0036 
#define TCDIMPReleaseTabData        TCD_0037  
#define DConstrTCD_C_G              TCD_0038
#define DDestrTCD_C_G               TCD_0039 
#define SConstrTCD_C_G              TCD_0040
#define DConstrTCDRbsSS             TCD_0041
#define SConstrTCDRbsSS             TCD_0042
#define SConstrTCDISSADATA          TCD_0043
#define SDestrTCD_C_G               TCD_0044
#define DDestrTCDRbsSS              TCD_0045
#define SDestrTCDRbsSS              TCD_0046
#define SDestrTCDISSADATA           TCD_0047
#define GetRbsSSFkt                 TCD_0048
#define TCDIMPGetTabIDAndTypFromPath TCD_0049
#define TCDIMPGetPathAndTypFromID    TCD_0050
#define TCDIMPReleaseTabTreeData     TCD_0051
#define TCDIMPImportTabTreeData      TCD_0052
#endif

#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDC_H)
#define TCDC_H

#ifdef TCDV2_5
#define TCDVERS 25
#endif
#ifdef TCDV3_0
#define TCDVERS 30
#endif
#ifndef TCDVERS
#error TCD Version muss in Makefiles angegeben werden.
#endif

/*---------
Name        : TCDC.H

Beschreibung: Zentrales Include File fuer die Anwendung
TCD weit gueltig
*----------*/

#include "p09115.h" /* direkte Vektoren */

#define  TCD_TRUE                1
#define  TCD_FALSE               0

/*---------
  Definitionen Opcodes
*----------*/
#define  TCD_OPC_INIT_RBS                    1
#define  TCD_OPC_CALC_FRM                    2
#define  TCD_OPC_CALC_PRC                    3
#define  TCD_OPC_GETNUM_FRM                  4
#define  TCD_OPC_GET_ATTR_VAL                5
#define  TCD_OPC_RESET_RBS                   6
#define  TCD_OPC_SET_PRC                     7
#define  TCD_OPC_RESET_PRC                   8
#define  TCD_OPC_SET_POOLTAB                 9
#define  TCD_OPC_RESET_POOLTAB              10
#define  TCD_OPC_SET_ATTR_VAL               11
#define  TCD_OPC_GET_PRC_INFO               12
#define  TCD_OPC_SET_POOLTAB_I              13
#define  TCD_OPC_RESET_POOLTAB_I            14
#define  TCD_OPC_SET_ATTR_IN_PRC            15
#define  TCD_OPC_SET_TRACE_ON               16
#define  TCD_OPC_SET_TRACE_OFF              17
#define  TCD_OPC_REMOVE_RESULTS             18
#define  TCD_OPC_GET_FIRST_RESULTS_INFO     19
#define  TCD_OPC_GET_NEXT_RESULTS_INFO      20

/*---------
  Definitionen Returncodes
*----------*/
#define  TCD_RC_NOT_OK              0
#define  TCD_RC_OK                  1
#define  TCD_RC_ILLOPC              2
#define  TCD_RC_VERSION_CONFLICT    3
#define  TCD_RC_UNKNOWN_FORM        4
#define  TCD_RC_ILLEGAL_FORM        5
#define  TCD_RC_ILLEGAL_PARAM       6
#define  TCD_RC_UNKNOWN_ATTR        7
#define  TCD_RC_NOT_FOUND           8
#define  TCD_RC_INPUT_MISSING       9
#define  TCD_RC_ILLEGAL_DIVISION   10
#define  TCD_RC_ILLEGAL_TAB_RANGE  11
#define  TCD_RC_STACK_OVERFLOW     12
#define  TCD_RC_CONDITION_FAIL     15
#define  TCD_RC_PAR_ERROR          20
#define  TCD_RC_TAB_IN_POOL        21
#define  TCD_RC_TAB_NOT_IN_POOL    22
#define  TCD_RC_PRC_IN_POOL        23
#define  TCD_RC_PRC_NOT_IN_POOL    24
#define  TCD_RC_UNKNOWN_PROC       25
#define  TCD_RC_PAARLISTEN_ERROR   26
#define  TCD_RC_NO_VALUE_AVAIL     30
#define  TCD_RC_USER_SET_ERROR    900
#define  TCD_RC_INTERNAL_ERR      999
#define  TCD_RC_NO_RETURN         888

/*---------
  allgemeine globale Konstanten
*----------*/
#define TCD_INIT_VARSETLEVEL    9999

/*---------
  Konfigurationsangaben
*----------*/
#define TCD_POOLADMIN_SIZE        20
#define TCD_C_MIN_USER_TYPE_ID    0
#define TCD_C_TABLISTLEN          10
#define TCD_C_MAXPRCCALLNR        2147483647

/*---------
  Definitionen Laengenangaben
*----------*/
#define TCD_DATUM_LNG              9
#define TCD_FRM_DATUM_LNG         20
#define TCD_VGLOP_LNG              3
#define TCD_NAME_LNG              26

/*---------
  Definitionen Aufrufart: (Aufzaehlungstyp)
-----------*/
#define TCD_CALLTYP_ATTR        1
#define TCD_CALLTYP_STA         2
#define TCD_CALLTYP_DYN         3
#define TCD_CALLTYP_STA_UE      4

/*---------
  Definitionen Prefix
-----------*/
#define TCD_PREFIX_TAB            '&'
#define TCD_PREFIX_PRC            '$'
#define TCD_PREFIX_FRM            'F'
#define TCD_PREFIX_ATTR           'A'

/*---------
  Definitionen Formeltypen (Aufzaehlungstyp, Wertevergabe analog Cobol)
-----------*/
#define TCD_FRMTYP_SKAL        1
#define TCD_FRMTYP_TAB1        2
#define TCD_FRMTYP_TAB2        3

/*---------
  Definitionen Belegungswerte PoolEntry
-----------*/
#define  TCD_POOLENT_INIT          0
#define  TCD_POOLENT_USED          1
#define  TCD_POOLENT_I_USED        2
#define  TCD_POOLENT_E_USED        3

/*---------
  Definitionen Assigntype
*----------*/
#define  TCD_DC_USE_NOT            0
#define  TCD_DC_USE_FRM            1
#define  TCD_DC_USE_PRC            2
#define  TCD_DC_USE_TAB            3
#define  TCD_DC_USE_VAL            4

/*----------
  Definitionen Formattypen
-----------*/
#define  TCD_ATTRFMT_SKAL          1
#define  TCD_ATTRFMT_TAB1          2
#define  TCD_ATTRFMT_TAB2          3
#define  TCD_ATTRFMT_VGLO          4
#define  TCD_ATTRFMT_DATE          5

/*----------
  Struktur Bestandsattributtabelle
 ----------*/
  typedef struct tagS_TCDATAB {
        char          Name [TCD_NAME_LNG] ;
        TCD_LONG      ID         ;
        TCD_INT       Index      ;
        TCD_INT       AttrTyp    ;
  } S_TCDATAB     ;

 typedef S_TCDATAB     * P_TCDATAB     ;

/*----------
  Struktur Tabelle aller Attribute
 ----------*/
  typedef struct tagS_ATTRTAB
  {
    TCD_LONG  ID    ;
    TCD_INT   Index ;
  } S_ATTRTAB ;

  typedef S_ATTRTAB    * P_ATTRTAB     ;

/*----------
  Typdefinition systemunabhanegiger Typen
 ----------*/
   typedef  char  TCD_VGLOP [TCD_VGLOP_LNG] ;
   typedef  char  TCD_DATUM [TCD_DATUM_LNG] ;

   typedef TCD_DOUBLE TCDTAB1 ;
   typedef P_TCDTAB   P_TCDTAB1 ;

   typedef TCD_DOUBLE TCDTAB2 ;
   typedef P_TCDTAB   P_TCDTAB2 ;

   typedef P_P_TCD_DOUBLE P_P_TCDTAB ;

/*---------
  Union Attributbelegung
 ----------*/
  typedef  union tagU_TCDVALUE {
           TCD_DOUBLE        Skalar;
           P_TCDTAB1         pTab1 ;
           P_TCDTAB2         pTab2 ;
   } U_TCDVALUE ;

  typedef  union tagU_TCDGVALUE {
           TCD_DOUBLE        Skalar;
           P_TCDTAB          pTab  ;
           TCD_VGLOP         VglOp ;
           TCD_DATUM         Datum ;
   } U_TCDGVALUE ;

/* --
 MUB 2.7.96: neu eingefuehrt, weil wir die TabellenID brauchen
--  */
  typedef  union tagU_TCDWVALUE
  {
           TCD_DOUBLE        Skalar;

           TCD_LONG          TabID ;  /*  die relevanten Attribute */
           P_TCDTAB1         pTab  ;  /*  das Ergebnis */

           TCD_VGLOP         VglOp ;
           TCD_DATUM         Datum ;
   } U_TCDWVALUE ;

  typedef struct tagS_TCDPRCVAL {
          TCD_LONG   PrcID ;
          TCD_LONG   FormelNr ;
          TCD_INT    FormelIx ;
          char       FormelName [TCD_NAME_LNG] ;
          TCD_INT    PoolIx ;
#if TCDVERS > 25
/* Version der Formel zur Pruefung 
		  Formel-Generat gegen Transport-Format */
          TCD_INT    FormelVers;
#endif

 } S_TCDPRCVAL ;

  typedef union  tagU_TCDNDVALUE {
          struct   tagTabData {
             TCD_LONG  TabID ;
             TCD_INT   PoolIx ;
          } TabData  ;
          TCD_DOUBLE Skalar ;
          char       Datum [TCD_DATUM_LNG] ;
          char       VglOp [TCD_VGLOP_LNG];
 } U_TCDNDVALUE ;


  typedef struct tagS_TCDFORMEL {
           TCD_LONG  FormelNr ;
           TCD_INT  FormelIx ;
           char     FormelName [TCD_NAME_LNG] ;
           TCD_INT  IsStaRef ;                                 
#if TCDVERS > 25
/* Version der Formel zur Pruefung 
		   Formel-Generat gegen Transport-Format */
		   TCD_INT  FormelVers;
#endif
 } S_TCDFORMEL ;

  typedef union  tagU_TCDASSIGNVAL {

       S_TCDPRCVAL  Prc    ;
       U_TCDNDVALUE Val    ;
       S_TCDFORMEL  Formel  ;

 } U_TCDASSIGNVAL ;

#define TYP3_NOT_OVERWRITTEN 2

typedef struct tagS_TCDREL_ATTR
{                                 
   TCD_LONG    iBerechnungsNummer;
   /* ID des Attributs                            */
   TCD_LONG    AttrID                  ;  
   /* Typ der Belegung SKALAR, TAB, DATUM , VGLOP */
   TCD_INT     AttrType              :4;  
   /* Flag, ob ein geerbter Wert vorhanden ist    */
   TCD_INT     bGeerbterWertVorhanden:2;  
   /* Flag, ob ein geerbter Wert vorhanden ist    */
   TCD_INT     bNotOverwritten         ;
   /* GGf. Wert hierzu                            */
   U_TCDWVALUE Belegung                ;  

}  S_TCDRELATTR;

typedef S_TCDRELATTR * P_TCDRELATTR ;

/* --
   S_TCDRELATTR_IMP    Relevantes Attribut fuer den Import
--  */
typedef struct tagS_TCDREL_ATTR_IMP
{
   TCD_LONG AttrID;
   TCD_INT  AttrType               : 4;
   TCD_INT  iIndex;

}  S_TCDRELATTR_IMP;

typedef S_TCDRELATTR_IMP * P_TCDRELATTR_IMP ;

/* --
   S_PAARLISTEN_EL    Struktur fuer ein PaarlistenElement
--  */
typedef struct tagS_PAARLISTEN_EL
{
   /* Vektor der relevanten Attribute mit der aktuellen Belegung     */
   LP_VECT          pAttrs;        
   /* lfde. Nummer der aktuellen Berechnung                          */
   TCD_LONG         iBerechnungsNummer; 
   
   TCD_LONG         lTabZeilen;         
   TCD_LONG         lTabSpalten;
   
   /* Typ des Ergebnisses (kann 'NOT_OVERWRITTEN' sein)              */
   TCD_INT          iType;              
   /* Ergebnis hierzu                                                */
   U_TCDWVALUE      Ergebnis;           

}  S_PAARLISTEN_EL;

typedef S_PAARLISTEN_EL * P_PAARLISTEN_EL ;

/* --
   S_PAARLISTE     Struktur zu einem Belegknoten einer BV
   Sie enthaelt 1 sortierten Vektor, 1 Liste und eine maximale Laenge
   fuer die Anzahl Elemente der Paarliste (Belegung,Ergebnis)
--  */
typedef struct tagS_PAARLISTE
{
   TCD_INT iWiederVerwendungsTyp;   /* KnotenTyp 1/2/3     */
   TCD_INT iWiederVerwListenLaenge; /* ListenLaenge maximal */
   TCD_INT iAct ;                   /* letztes Element     */

   /* direkter Vektor von S_ATTR_EL's   */
   LP_VECT pAttrs;                  
   /* direkter Vektor von S_PAARLISTEN_EL's */
   LP_VECT pPaarListenElts;         

}  S_PAARLISTE;

typedef S_PAARLISTE * P_PAARLISTE ; 

/* --
   S_ERGEBNIS_POOL_ELT Element eines PoolErgebnisses
--  */
typedef struct tagS_ERGEBNIS_POOL_ELT
{
   TCD_LONG    ID;
   P_PAARLISTE pPaarListe;

}  S_ERGEBNIS_POOL_ELT;

typedef S_ERGEBNIS_POOL_ELT * P_ERGEBNIS_POOL_ELT ;

/*-----------
  Struktur     Belegungsknoten
------------*/
  typedef struct tagS_TCDPRCNODE
  {
      TCD_LONG         AttrID                  ;
      TCD_INT          NodeID                  ;
      TCD_INT          AttrType                ;
      TCD_INT          AssignType              ;
      U_TCDASSIGNVAL   AssignVal               ;
      TCD_INT          SuccNodeIx              ;
      TCD_INT          AnzSuccNodes            ;
      TCD_INT          Usage                   ;

      P_PAARLISTE      pPaarListe              ;
      P_PAARLISTEN_EL  pResultForGetAttr       ;

      TCD_INT          iWiederVerwendungsTyp   ;
      TCD_INT          iWiederVerwListenLaenge ;
      TCD_INT          iAnzRelAttrs            ;
      TCD_INT          iFirstRelAttrIx         ;

  }   S_TCDPRCNODE ;

 typedef S_TCDPRCNODE  * P_TCDPRCNODE ;

/*-----------
  Struktur Auspraegungs-Belegungs-Information
------------*/
  typedef struct tagS_TCDPRCINFO {
         char  Name [TCD_NAME_LNG] ;
         TCD_LONG  ID ;
         TCD_INT   Formattyp ;
         TCD_INT   Typ ;
         TCD_INT   Klasse ;
         TCD_INT   AnzBeleg ;
         TCD_INT   TabIx ;
         TCD_LONG  RefNodeId ;
 } S_TCDPRCINFO ;

 typedef S_TCDPRCINFO  * P_TCDPRCINFO ;

/*--------
  Struktur LocalData MUB 2.7.96: wird nicht mehr verwendet!
 --------*/
  typedef struct tagS_TCDPRCLOCD {
          TCD_LONG FormelNr     ;
          TCD_INT  Usage        ;
          TCD_INT  Typ          ;
          union   {
              TCD_INT    PoolIx ;
              TCD_DOUBLE Val    ;
          } Data ;
          TCD_LONG  CalcByCallNr ;
   } S_TCDPRCLOCD ;

   typedef S_TCDPRCLOCD * P_TCDPRCLOCD ;

/*---------
  Struktur Header Auspraegungsbaum
----------*/
  typedef struct tagS_TCDPRCHDR {
    TCD_LONG       PrcID        ;
    TCD_LONG       FormelNr     ;
    TCD_INT        AnzPrcTree   ;
    TCD_INT        AnzBelegInfo ;
    TCD_INT        AnzRelAttrs  ;
    TCD_BOOL       FlSetAttrSkal;
    TCD_BOOL       FlSetAttrTab ;
    TCD_BOOL       FlSetAttrVgl ;
    TCD_BOOL       FlSetAttrDat ;
    TCD_BOOL       FlPrcCompl   ;
    TCD_LONG       PrcResIx     ;
    TCD_LONG       PrcCallNr    ;

 } S_TCDPRCHDR     ;


/*---------
  Struktur Auspraegungselement
-----------*/
  typedef union  tagU_TCDPRCELEM
  {
     S_TCDPRCHDR      TreeHdr;
     S_TCDPRCNODE     Node ;
     S_TCDPRCINFO     Info ;     
  }  U_TCDPRCELEM ;

 typedef U_TCDPRCELEM  * P_TCDPRCELEM ;

#define TCDPRCSIZE(pPrc)    (pPrc ? sizeof(S_TCDRELATTR_IMP)*\
                            (TCD_LONG)pPrc->TreeHdr.AnzRelAttrs +\
                            sizeof(U_TCDPRCELEM)*\
                            ( (TCD_LONG)pPrc->TreeHdr.AnzPrcTree +\
                             (TCD_LONG)pPrc->TreeHdr.AnzBelegInfo) : 0)


/*-------
  Datenstruktur Mehrfach-Auspraegung (MultiProc)
 --------*/
  typedef struct tagS_TCDMPRCENTRY {
        TCD_INT              PrcBelegt ;
        TCD_LONG             ID ;
        P_TCDPRCELEM         pPrcData ;
 } S_TCDMPRCENTRY ;

  typedef S_TCDMPRCENTRY * P_TCDMPRCENTRY ;

  typedef struct tagS_TCDMPRCADMIN {
        TCD_INT          Anzahl  ;
        P_TCDMPRCENTRY   Data    ;
 } S_TCDMPRCADMIN ;

 typedef S_TCDMPRCADMIN * P_TCDMPRCADMIN ;

/*--------
  Datenstruktur PoolAdmin
--------*/
  typedef struct tagS_TCDPOOLENTRY {
        TCD_LONG     ID ;
        TCD_INT      Usage ;
        TCD_INT      Typ ;
        TCD_INT      Fmttyp ;
        P_TCD_DOUBLE pData ;
  } S_TCDPOOLENTRY ;

  typedef S_TCDPOOLENTRY * P_TCDPOOLENTRY ;

  typedef struct tagS_TCDPOOLADMIN {
        TCD_INT          Anzahl  ;
        TCD_INT          AnzTabs ;
        TCD_INT          AnzProcs ;
        TCD_INT          AnzTemp  ;
        S_TCDPOOLENTRY * Data    ;
 } S_TCDPOOLADMIN ;

  typedef S_TCDPOOLADMIN * P_TCDPOOLADMIN ;

/*------
  Datenstruktur Kontrollstruktur
--------*/
  typedef struct tagS_TCDRBSINFO {
       char TcdVersion [TCD_DATUM_LNG]   ;
       char TcdRelease [TCD_DATUM_LNG]   ;
       char RbsInterf  [TCD_DATUM_LNG]   ;
       TCD_LONG RbsId ;
   } S_TCDRBSINFO ;

   typedef struct tagS_TCDRCINFO {
       TCD_INT   Rc ;
       TCD_INT   Errc ;
       char FormelName [TCD_NAME_LNG] ;
       TCD_INT   FormelNr ;
       char AttrName   [TCD_NAME_LNG] ;
   } S_TCDRCINFO          ;

   typedef S_TCDRCINFO * P_TCDRCINFO ;


   typedef struct tagS_TCDCTLPAR {

/*-
  Opcode:   TCD_OPC_GET_ATTR_VAL, TCD_OPC_SET_ATTR_VAL
--*/
        struct tagS_TCDPARGA {
           TCD_LONG    ProcID;
           TCD_LONG    ID;
           TCD_LONG    TabID;
           TCD_INT     TabIx ;
           U_TCDGVALUE Val ;
           TCD_INT     Typ ;
           TCD_INT     ProcIx;
        }            GA ;

/*-
  Opcode:   TCD_OPC_SET_POOLTAB
--*/
        struct tagS_TCDPARST {
            TCD_LONG  ID;
            TCD_INT   Dim ;
            P_TCDTAB  pTab ;
            TCD_INT    TabIx ;
        }            ST ;

/*-
  Opcode:   TCD_OPC_RESET_POOLTAB
--*/
        struct tagS_TCDPARRT{
            TCD_LONG  ID;
            P_TCDTAB  pTab ;
        }            RT ;

/*-
  Opcode:   TCD_OPC_SET_PRC
--*/
        struct tagS_TCDPARSP {
            TCD_LONG      ProcID;
            P_TCDPRCELEM  pProc;
            TCD_INT       ProcIx;
        }            SP;

/*-
  Opcode:   TCD_OPC_RESET_PRC
--*/
        struct tagS_TCDPARRP {
            TCD_LONG  ProcID;
            P_TCDPRCELEM  pProc;
        }            RP;

/*-
  Opcode:   TCD_OPC_CALC_FRM , TCD_OPC_CALC_PRC
--*/
        struct tagS_TCDPARCFP {
            TCD_LONG       FormelNr ;
            TCD_LONG       ProcID;
            TCD_INT        Typ ;
            U_TCDVALUE     Value ;
            TCD_INT        ProcIx;
        }            CFP ;

/*-
  Opcode:   TCD_OPC_GETNUM_FRM
--*/
        struct tagS_TCDPARGF {
            char  Name [TCD_NAME_LNG] ;
            TCD_LONG  FormelNr ;
        }            GF ;

/*-
  Opcode:   TCD_OPC_GET_PRC_INFO
--*/
        struct tagS_TCDPRCBINFO {
            TCD_LONG        ProcID;
            TCD_INT         ProcIx;
            P_TCDPRCELEM    pProcInfo;
            TCD_INT         AnzProcInfo ;
        }            PI ;

/*-
  Opcode:   TCD_OPC_REMOVE_RESULTS,
            TCD_OPC_GET_FIRST_RESULTS_INFO,
            TCD_OPC_GET_NEXT_RESULTS_INFO
--*/
        struct tagS_TCDPAR_RESULTPOOL {
            TCD_LONG        ProcID;
            TCD_LONG        lNumOfResults;
            TCD_INT         bFinished;
        }            RESP ;

   } S_TCDCTLPAR ;

   typedef S_TCDCTLPAR * P_TCDCTLPAR ;

   typedef struct tagS_TCDRBSCTL {
          TCD_INT       Opc     ;
          S_TCDRBSINFO  RbsInfo ;
          S_TCDRCINFO   RCInfo  ;
          S_TCDCTLPAR   Par     ;
  } S_TCDRBSCTL ;

   typedef S_TCDRBSCTL * P_TCDRBSCTL ;

/*------
  Datenstruktur Rechenbausteinschnittstelle
 --------*/
   typedef struct tagS_TCDV_F_FLAGS {
         TCD_BOOL       V_In   ;
         TCD_BOOL       F_In   ;
         TCD_BOOL       V_Comp ;
         TCD_BOOL       V_Use  ;
         TCD_BOOL       F_Use  ;
         TCD_BOOL       V_Miss ;
         TCD_BOOL       F_Miss ;
   } S_TCDV_F_FLAGS ;

   typedef S_TCDV_F_FLAGS * P_TCDV_F_FLAGS ;

   typedef struct tagS_TCDV_FLAGS {
         TCD_BOOL       V_In   ;
         TCD_BOOL       V_Use  ;
         TCD_BOOL       V_Miss ;
   } S_TCDV_FLAGS ;

   typedef S_TCDV_FLAGS   * P_TCDV_FLAGS   ;

   typedef struct tagS_TCDSKAL_DATA
   {
        TCD_DOUBLE      Val    ;
        TCD_LONG        Formel ;
        S_TCDV_F_FLAGS  Flags  ;
   } S_TCDSKAL_DATA ;

   typedef S_TCDSKAL_DATA * P_TCDSKAL_DATA ;

   typedef struct tagS_TCDTAB1_DATA
   {
     TCD_LONG        TabID;
     P_TCDTAB1       pVal ;
     TCD_LONG        Formel ;
     S_TCDV_F_FLAGS  Flags ;

   } S_TCDTAB1_DATA ;
   typedef S_TCDTAB1_DATA  * P_TCDTAB1_DATA  ;

   typedef struct tagS_TCDTAB2_DATA
   {
     TCD_LONG        TabID;
     P_TCDTAB2       pVal ;
     TCD_LONG        Formel ;
     S_TCDV_F_FLAGS  Flags ;

   } S_TCDTAB2_DATA ;
   typedef S_TCDTAB2_DATA * P_TCDTAB2_DATA ;

   typedef struct tagS_TCDDAT_DATA {
        char             Val [TCD_DATUM_LNG] ;
        S_TCDV_FLAGS     Flags ;
   } S_TCDDAT_DATA ;

   typedef S_TCDDAT_DATA * P_TCDDAT_DATA ;

   typedef struct tagS_TCDVGL_DATA {
        char            Val [TCD_VGLOP_LNG] ;
        S_TCDV_FLAGS    Flags ;
   } S_TCDVGL_DATA ;

   typedef S_TCDVGL_DATA * P_TCDVGL_DATA ;

   typedef struct tagS_TCD_RBS_SSA
   {
        P_TCDSKAL_DATA    pSkal ;
        P_TCDTAB1_DATA    pTab1 ;
        P_TCDTAB2_DATA    pTab2 ;
        P_TCDDAT_DATA     pDat  ;
        P_TCDVGL_DATA     pVgl  ;
   } S_TCD_RBS_SSA ;

   typedef S_TCD_RBS_SSA  * P_TCD_RBS_SSA ;


   typedef struct tagS_TCDRBS_SS {
       S_TCDRBSCTL       RCTL ;
       S_TCD_RBS_SSA     SSAData   ;
       S_TCDPOOLADMIN    PoolAdmin ;
       S_TCDMPRCADMIN    MPrcAdmin ;
 } S_TCDRBS_SS ;

 typedef S_TCDRBS_SS  * P_TCDRBS_SS ;

  typedef struct tagS_TCDPARATTR_SK {
        TCD_INT      Level ;
        TCD_DOUBLE   Val ;
 } S_TCDPARATTR_SK   ;

 typedef S_TCDPARATTR_SK  * P_TCDPARATTR_SK ;

  typedef struct tagS_TCDPARATTR_VGL {
        TCD_INT      Level;
        char         Val  [TCD_VGLOP_LNG] ;
 } S_TCDPARATTR_VGL  ;

 typedef S_TCDPARATTR_VGL * P_TCDPARATTR_VGL ;

  typedef struct tagS_TCDPARATTR_DAT
  {
        TCD_INT      Level;
        char         Val  [TCD_DATUM_LNG] ;
 } S_TCDPARATTR_DAT  ;

 typedef S_TCDPARATTR_DAT * P_TCDPARATTR_DAT ;

/*-----------
  Struktur Schnittstellendaten (interne Sicht)
-----------*/
  typedef struct tagS_TCDISSADATA
  {
     TCD_INT      AnzSSASkal ;
     TCD_INT      AnzSSATab1 ;
     TCD_INT      AnzSSATab2 ;
     TCD_INT      AnzSSADat ;
     TCD_INT      AnzSSAVgl ;
     TCD_INT      AnzParSkal;
     TCD_INT      AnzParVgl ;
     TCD_INT      AnzParDat ;
     TCD_INT      AnzZeilen ;
     TCD_INT      AnzSpalten ;
     P_TCDSKAL_DATA    pSkal ;
     P_TCDTAB1_DATA    pTab1 ;
     P_TCDTAB2_DATA    pTab2 ;
     P_TCDDAT_DATA     pDat ;
     P_TCDVGL_DATA     pVgl ;
     P_TCDPARATTR_SK   pParSkal ;
     P_TCDPARATTR_VGL  pParVgl;
     P_TCDPARATTR_DAT  pParDat;

 }   S_TCDISSADATA ;
 typedef S_TCDISSADATA * P_TCDISSADATA ;



/*------
Datenstruktur globale Daten des Rechenbausteins;
diese Datenstruktur enthaelt Informationen und Teilstrukturen, die
in den programmierten Funktionen benoetigt werden.
Initialisierung dieser Daten erfolgt mehrstufig.
- beim Init: globaler Pointer pTCDTCD initialisiert (zeigt auf die Str)
pRbsSS zeigt auf die RBS-Schnittstelle
- bei auspraegungsspez. Opcodes werden die Teilstrukturen fuer die
Auspraegung initialisiert, ...
- bei einer neuen Berechnung werden die internen Aufrufschnittstellen
initialisiert
--------*/
  typedef struct tagS_TCD_C_G
  {
      P_TCDRBS_SS      pRbsSS      ;
      P_TCDPRCELEM     pPrcData    ;
      S_TCDPRCHDR *    pPrcHdr     ;
      P_TCDPRCELEM     pPrcTreeNode;
      P_TCDPRCELEM     pInfo       ;
      P_TCDRELATTR_IMP pRelAttrs   ;
      P_TCDMPRCADMIN   pMPrcAdmin  ;
      P_TCDRBSCTL      pRbsCtl     ;
      S_TCDISSADATA    SSAData     ;
      P_TCDPOOLADMIN   pPoolAdmin  ;
      TCD_INT          GlbVarSet   ;
      TCD_LONG         RBS_ID      ;
      TCD_BOOL         ValFound    ;
      TCD_BOOL         FrmFound    ;
      TCD_BOOL         V_Comp      ;
      TCD_BOOL         PrcChg      ;
      void *           pApplIf     ;
      P_TCDTAB         ResTab      ;
      TCD_DOUBLE       ResSkal     ;
      
      TCD_LONG         LastCalcPrcID;
      LP_VECT          pErgebnisPool;
      TCD_LONG         iBerechnungsNummer;
      TCD_INT          iErgPoolIteratorGl;                       
      P_PAARLISTE      pPaarListeNotToSave;
      
      TCD_BOOL         btrace_open;
      TCD_BOOL         btrace_enabled;
      
/* RWE, 10.06.1997: Neues Datenelement fuer Beobachtung
   der Wiederverwendung (ehemals WatchPol-Funktionalitaet) */
      TCD_BOOL         bProtWV;
      
  }   S_TCD_C_G ;
  typedef S_TCD_C_G   * P_TCD_C_G ;
#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDI_H)
#define TCDI_H
/*--------------
    Name        : TCDI.H

    Beschreibung: Include File intern nur f�r C- Generator
                  wird von den fest programmierten Moduln und
                  generierten Moduln benoetigt
    By          : BEGGI
    Datum       : 22.02.94
    Historie    : BEG   28.11.95   Definition Attributklassen
*--------------*/

/*-------------
  Returncodes FrmRet und ValRet (Definitionen analog Cobol) fuer
  Attributmanager
---------------*/
#define TCD_AIRC_CALLVIAFRM    4

/*-------------
  Definitionen Attributtypen (Aufzaehlungstyp)
---------------*/
#define TCD_ATTYP_TAR_SKAL      1
#define TCD_ATTYP_TAR_TAB1      2
#define TCD_ATTYP_TAR_TAB2      3
#define TCD_ATTYP_TAR_DATE      4
#define TCD_ATTYP_TAR_VGLO      5
#define TCD_ATTYP_BST_SKAL      6
#define TCD_ATTYP_BST_TAB1      7
#define TCD_ATTYP_BST_TAB2      8
#define TCD_ATTYP_BST_DATE      9
#define TCD_ATTYP_BST_VGLO     10

#define TCD_ATTRTYP_SKAL        0
#define TCD_ATTRTYP_TAB1        1
#define TCD_ATTRTYP_TAB2        2
#define TCD_ATTRTYP_DATE        3
#define TCD_ATTRTYP_VGLO        4

/*--------------
  Definitionen Attributklasse
---------------*/
#define TCD_ATTRCLASS_TAR       1
#define TCD_ATTRCLASS_BST       6

/*-------------
  Definitionen Errorcodes
---------------*/
#define TCD_UNKNOWN_OPCODE       1
#define TCD_NO_SPACE_IN_TLIST    2
#define TCD_ERR_GETMEM           3
#define TCD_GETEMPTYENTRY        4
#define TCD_NOPOOLADMIN          5
#define TCD_ILLTABFMT            6
#define TCD_UNK_ASSIGNTYP        7
#define TCD_NO_MPRCADMIN         8
#define TCD_EXPPOOLADMIN         9
#define TCD_NO_MEMORY           10
#define TCD_NO_PRCREF           11
#define TCD_ILLFRM_ID           12
#define TCD_ILLFRM_CMP          13
#define TCD_ERR_INIT_FORMEL     14
#define TCD_FRMGEN_OUT_OF_DATE	15
#define TCD_TRPFMT_OUT_OF_DATE	16

/*----------
  Datenstruktur Freigabeliste  Hilfsvariablentabellen
 ------------*/
  typedef struct tagS_TCDTABLIST    {
         TCD_INT        CallOvw ;
         TCD_LONG       CallerID ;
         TCD_LONG       CallFrmNr ;
         TCD_INT        CallType  ;
         P_TCD_DOUBLE   Adr ;
 } S_TCDTABLIST   ;

 typedef  S_TCDTABLIST  * P_TCDTABLIST  ;

/*----------
  Datenstruktur Formelparameter
 ------------*/
  typedef struct tagS_TCD_C_F1 
  {
     char         * FormelName     ;
     TCD_INT        FrmTyp         ;
     TCD_LONG       FrmNr          ;
     TCD_INT        FrmIx          ;
     char         * AttrName       ;
     TCD_INT        CallType       ;
     TCD_LONG       AttrID         ;
     TCD_INT        AttrTyp        ;
     TCD_INT        AttrIx         ;
     TCD_INT        ParIx          ;
     TCD_INT        Ret            ;
     TCD_INT        ExecCond       ;
     P_TCDPRCNODE   PrcFNode       ;
     P_TCDPRCNODE   pNode          ;
     TCD_INT        MinVarSet      ;
     TCD_INT        BegVarSet      ;
     char         * CmpTime        ;
     TCD_INT        Level          ;
     P_TCD_DOUBLE   pVarSkal       ;
     P_P_TCDTAB     pVarTab        ;
     char         * VarDatVgl      ;
     TCD_INT      * VarIndex       ;
     P_TCDTABLIST   FreeList       ;
     TCD_INT        AnzTabList     ;
     TCD_INT        AnzTabListEnt  ;
     P_TCDPRCNODE   NextFNode      ;
     TCD_INT        NextExecCond   ;
     TCD_INT        NextCallType   ;
     struct tagS_TCD_C_F1 * pPrevLevelInfo ;
     P_TCD_C_G      pTCDTCD ;
  } S_TCD_C_F1 ;

  typedef  S_TCD_C_F1 *   P_TCD_C_F1 ;

  typedef struct tagS_TCDFTAB {
        char          FrmName [TCD_NAME_LNG] ;
        void          (* pFormelFunc ) ( P_TCD_C_F1);
        TCD_LONG      FrmNr      ;
        TCD_INT       FrmTyp     ;
        char          Datum [TCD_FRM_DATUM_LNG] ;
  } S_TCDFTAB     ;

 typedef S_TCDFTAB     * P_TCDFTAB     ;

/* extern P_TCD_C_G pTCDTCD ; */

#endif


/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_DAT_H)
#define TCD_DAT_H
/*---------------------------------------------------------------------
  Datei:   TCD_DAT.h
  Beschreibung: Schnittstelle zum Datenmanager.
  Historie:       06.03.96  BEG   Datei gefreezt
              06.03.96  BEG   Erweiterungen, neue ext. Funktion TCDDSV
              20.06.96  RWE   neue Prototypen        
              13.10.96  MUB   Schnittstellen um pTCDTCD erweitert
---------------------------------------------------------------------*/
void  TCDDIP (P_TCD_C_G pTCDTCD) ;
void  TCDDGPI(P_TCD_C_G pTCDTCD) ;
void  TCDDGA (P_TCD_C_G pTCDTCD) ;
void  TCDDSA (P_TCD_C_G pTCDTCD) ;
void  TCDDSP (P_TCD_C_G pTCDTCD) ;
void  TCDDRP (P_TCD_C_G pTCDTCD) ;
void  TCDDSV (P_TCD_C_G pTCDTCD) ;

void          ReleasePrcAttrResults   (P_TCDPRCELEM);
void          ReleaseMPrcAttrResults  (P_TCDMPRCADMIN);
P_TCDPRCELEM  MPrcAdminGetPrc         (P_TCDMPRCADMIN,TCD_LONG);

#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_POOL_H)
#define TCD_POOL_H
/*---------------------------------------------------------------------
  Datei      : TCD_POOL.h
  Generiert am 16.12.2019 15:07:18
  Historie      : 27.7.95    BEG neuer Prefix fuer Tabellenentry
---------------------------------------------------------------------*/
void    TCDPIT   (P_TCD_C_G);
void    TCDPRP   (P_TCD_C_G) ;
void    TCDPST   (P_TCD_C_G) ;
void    TCDPRT   (P_TCD_C_G) ;
void    TCDPSAT  (P_TCD_C_G) ;
void    TCDPRTA  (P_TCD_C_G) ;
TCD_INT TCDPGF   (P_TCD_C_G,P_TCD_DOUBLE Var, TCD_INT *PIndex) ;

#endif


#include "p09201.h"

/*---------------------------------------------------------------------
   Prototypen der internen Funktionen
---------------------------------------------------------------------*/
 void     SearchAttr   (P_TCD_C_G,TCD_LONG,TCD_INT *);
 int      GetFreeEntry (P_TCD_C_G);
 void     GetPrcData   (P_TCD_C_G,TCD_INT *,TCD_LONG);
 TCD_INT  FindPrc      (P_TCD_C_G,TCD_LONG);
 void     InitPrcData  (P_TCD_C_G);
 void     SetPrcData   (P_TCD_C_G,TCD_LONG);
 void *   GetResultFromWV ( P_TCD_C_G    pTCDTCD, 
                            P_TCDPRCNODE pNode , 
                            P_TCDCTLPAR  pTcdPar);

/*---------------------------------------------------------------------
   Externe Funktion: TCDDIP
   Beschreibung  :   Funktion initialisiert die auspr,gungsspezifischen
                     Teile der Aufrufschnittstelle
   Parameter     :
   Returnwerte   :   pTCDTCD->PrcCtl.Rc
                     OK,                 Daten wurde �bernommen.
                     TCD_RC_PRC_IN_POOL  Ist schon da.
                     TCD_RC_INTERNAL_ERR Kein Memory mehr?
---------------------------------------------------------------------*/
void  TCDDIP (P_TCD_C_G pTCDTCD)
{
   P_TCDPOOLENTRY pPoolData ;

   P_TCDCTLPAR    pTcdPar    = &(pTCDTCD->pRbsSS->RCTL.Par) ;
   P_TCDRCINFO    pTcdRcInfo = &(pTCDTCD->pRbsSS->RCTL.RCInfo) ;
   P_TCDMPRCADMIN pMPrcAdmin = pTCDTCD->pMPrcAdmin ;

   /* Bereitstellen der Auspraegung und Init. Schnittst.parameters */
   GetPrcData (pTCDTCD,&(pTcdPar->CFP.ProcIx), pTcdPar->CFP.ProcID) ;

   if (pTcdRcInfo->Rc != TCD_RC_OK)
      return ;

    /* Falls Proc schon berechnet und Ergebnis noch im Pool steht,
       -> Freigabe */
    if ( pTCDTCD->pPrcHdr->FlPrcCompl    && 
         pTCDTCD->pPrcHdr->PrcResIx >= 0 && 
         pTCDTCD->pPoolAdmin->Anzahl > 0)
    {
         pPoolData = 
            (&pTCDTCD->pPoolAdmin->Data[pTCDTCD->pPrcHdr->PrcResIx]);
         if (pPoolData->ID == pTCDTCD->pPrcHdr->PrcID && 
             pPoolData->Usage != TCD_POOLENT_INIT) 
         {
             _TCDTABFREE(pPoolData->pData) ;
             pTCDTCD->pPoolAdmin->AnzProcs -- ;
             pPoolData->Usage = TCD_POOLENT_INIT ;
             pTCDTCD->pPrcHdr->PrcResIx = -1 ;
         }
    }
   return ;
}


/*---------------------------------------------------------------------
Externe Funktion: TCDDGA
Beschreibung  : Funktion besorgt die Attributbelegung eines Attributes
Parameter     :
Returnwerte   : pTCDTCD->PrcCtl.Rc
OK,             Daten wurde �bernommen.
TCD_RC_PRC_IN_POOL  Ist schon da.
TCD_RC_INTERNAL_ERR Kein Memory mehr?
---------------------------------------------------------------------*/
void  TCDDGA (P_TCD_C_G pTCDTCD)
{
   P_TCDPRCNODE     pNode  ;
   P_TCDPOOLENTRY   pPoolData ;
   TCD_INT          index  ;
   P_TCDRCINFO      pTcdRcInfo = &(pTCDTCD->pRbsSS->RCTL.RCInfo) ;
   P_TCDCTLPAR      pTcdPar = &(pTCDTCD->pRbsSS->RCTL.Par) ;

   /* Bereitstellen der Auspraegung und Init. Schnittst.parameters */

   GetPrcData (pTCDTCD,&(pTcdPar->GA.ProcIx), pTcdPar->GA.ProcID) ;
   if (pTcdRcInfo->Rc != TCD_RC_OK)      return ;

   /* Suche nach der Attributbelegung in der Belegungsinfo der Ausp. */
   SearchAttr (pTCDTCD,pTcdPar->GA.ID, &index) ;
   if (pTcdRcInfo->Rc != TCD_RC_OK)      return ;

  pNode = & (pTCDTCD->pPrcTreeNode [index - 1].Node) ;
  pTcdPar->GA.Typ = pNode->AttrType ;

   /* R�ckgabe der Belegung */
  switch (pNode->AssignType)
  {
      case TCD_DC_USE_VAL:
           switch (pNode->AttrType)
           {
               case TCD_ATTRFMT_SKAL :
                    pTcdPar->GA.Val.Skalar=pNode->AssignVal.Val.Skalar;
                    break ;

               case TCD_ATTRFMT_TAB1 :
               case TCD_ATTRFMT_TAB2 :
                     index  = pNode->AssignVal.Val.TabData.PoolIx ;
                     pPoolData = &(pTCDTCD->pPoolAdmin->Data [index]) ;
                     pTcdPar->GA.Val.pTab = pPoolData->pData ;
                     break ;

               case TCD_ATTRFMT_VGLO :
                     strcpy (pTcdPar->GA.Val.VglOp,
                             pNode->AssignVal.Val.VglOp) ;
                     break ;

               case TCD_ATTRFMT_DATE :
                     strcpy (pTcdPar->GA.Val.Datum,
                             pNode->AssignVal.Val.Datum) ;
                     break ;
           } ;
           break ;


      case TCD_DC_USE_PRC :
      case TCD_DC_USE_FRM:

   /* -----------------------------------------------------------------
      Das Ergebnis kommt aus einem der ErgebnisPools 
      (global oder lokal)
   ------------------------------------------------------------------*/
      {
           void * p = GetResultFromWV (pTCDTCD,pNode,pTcdPar);
           if( p )
           {
               switch ( pTcdPar->GA.Typ )
               {
                      case TCD_ATTRFMT_SKAL :
                      {
                           double * f = (double *) p; 
                           pTcdPar->GA.Val.Skalar = *f;

                           break ;
                      }
                      
                      case TCD_ATTRFMT_TAB1 :
                      case TCD_ATTRFMT_TAB2 :
                           pTcdPar->GA.Val.pTab = 
                           (double *)p;
                           break ;

                      case TCD_ATTRFMT_VGLO :
                      {
                           TCD_VGLOP * v = (TCD_VGLOP *)p;
                           strcpy(pTcdPar->GA.Val.VglOp,*v);
                      }                          

                      case TCD_ATTRFMT_DATE :
                      {
                           TCD_DATUM * d = (TCD_DATUM *)p;
                           strcpy(pTcdPar->GA.Val.Datum,*d);
                      }
               }
           }
           else
           {
              memset((void *)&pTcdPar->GA.Val,0,sizeof(U_TCDGVALUE));
              pTcdPar->GA.Typ = 0;
              pTcdRcInfo->Rc  = TCD_RC_NO_VALUE_AVAIL ;
           }     
           
           break;
      }   
  }
  return  ;
}

/*---------------------------------------------------------------------
Externe Funktion: TCDDSA
Beschreibung :Funktion belegt in der Auspraegung ein Attribut mit einem
             gegebenen Wert. Vor der Attributbelegung im Baum wird
             anhand der Belegliste ermittelt, ob das Attribut
             ueberhaupt vorkommt und ob es belegt ist.
Parameter     :
Returnwerte   :   pTCDTCD->PrcCtl.Rc
             OK,                 Daten wurde �bernommen.
             TCD_RC_UNKNOWN_ATTR Attribut kommt in derProc nicht vor
             TCD_RC_NOT_FOUND    Attribut in Proc nicht belegt
---------------------------------------------------------------------*/
void  TCDDSA (P_TCD_C_G pTCDTCD)
{
   TCD_INT          index  ;
   P_TCDRCINFO      pTcdRcInfo = &(pTCDTCD->pRbsSS->RCTL.RCInfo) ;
   P_TCDCTLPAR      pTcdPar = &(pTCDTCD->pRbsSS->RCTL.Par) ;
   TCD_LONG         AttrID = pTcdPar->GA.ID ;

   /* Bereitstellen der Auspraegung und Init. Schnittst.parameters */
   GetPrcData (pTCDTCD,&(pTcdPar->GA.ProcIx), pTcdPar->GA.ProcID) ;
   if (pTcdRcInfo->Rc != TCD_RC_OK)      return ;

   /* Suche nach der Attributbelegung in der Belegungsinfo der Ausp. */
   SearchAttr (pTCDTCD,AttrID, &index) ;
   switch (pTcdRcInfo->Rc) 
   {
      case TCD_RC_UNKNOWN_ATTR :
           return ;
      case TCD_RC_NOT_FOUND :
      default:
           break ;
   }

   /* Funktion aufrufen, die alle Knoten im Baum mit der AttrID mit 
      neuem Wert belegen */
   SetPrcData ( pTCDTCD,AttrID) ;
   return ;
}

/*---------------------------------------------------------------------
Externe Funktion: TCDDSV
Beschreibung:Funktion setzt in der Auspraegung ein Attribut mit einem
             gegebenen Wert. Auch falls das Attribut in der Berech.
             vorschrift nicht vorkommt oder nicht belegt ist,
             wird OK zurueckgeliefert.
             arbeitet auf der aktuellen Proc
   Parameter     :
   Returnwerte   :   pTCDTCD->PrcCtl.Rc
                     OK
                     TCD_RC_UNKNOWN_PROC : falls keine aktuelle Proc
---------------------------------------------------------------------*/
void  TCDDSV (P_TCD_C_G pTCDTCD)
{
   P_TCDRCINFO      pTcdRcInfo = &(pTCDTCD->pRbsSS->RCTL.RCInfo) ;
   P_TCDCTLPAR      pTcdPar = &(pTCDTCD->pRbsSS->RCTL.Par) ;
   TCD_LONG         AttrID = pTcdPar->GA.ID ;

   /* nur Aufruf zum Belegen der Proc */
   if (pTcdRcInfo->Rc != TCD_RC_OK)      return ;
   if (! pTCDTCD->pPrcHdr)
   {
       pTcdRcInfo->Rc = TCD_RC_UNKNOWN_PROC  ;
       return ;
   }
   SetPrcData (pTCDTCD,AttrID) ;
   return ;
}


/*---------------------------------------------------------------------
   Externe Funktion: TCDDGPI
   Beschreibung  :   Funktion besorgt die Belegungsinformation zu einer
                     Auspraegung
   Parameter     :
   Returnwerte   :   pTCDTCD->PrcCtl.Rc
                     OK,                 Daten wurde �bernommen.
                     TCD_RC_PRC_IN_POOL  Ist schon da.
                     TCD_RC_INTERNAL_ERR Kein Memory mehr?
---------------------------------------------------------------------*/
void  TCDDGPI (P_TCD_C_G pTCDTCD)
{
   P_TCDRCINFO      pTcdRcInfo = &(pTCDTCD->pRbsSS->RCTL.RCInfo) ;
   P_TCDCTLPAR      pTcdPar = &(pTCDTCD->pRbsSS->RCTL.Par) ;

   /* Bereitstellen der Auspraegung und Init. Schnittst.parameters */
   GetPrcData (pTCDTCD,&(pTcdPar->PI.ProcIx), pTcdPar->PI.ProcID ) ;

   if (pTcdRcInfo->Rc != TCD_RC_OK)  
      return ;

   /* Belegung der Rueckgabewerte */
   pTcdPar->PI.pProcInfo = pTCDTCD->pInfo ;
   pTcdPar->PI.AnzProcInfo =  pTCDTCD->pPrcHdr->AnzBelegInfo ;
}


/*---------------------------------------------------------------------
   Externe Funktion: TCDPSP
   Beschreibung  :Funktion �bernimmmt eine Auspr,gung in die MultiProc.
   Parameter     :
   Input         :   S_TCD_IPRC_CTL
                     S_TCDMPRCADMIN
                     S_TCD_C_G
   Returnwerte   :   pTCDTCD->PrcCtl.Rc
                     OK,                 Daten wurde �bernommen.
                     TCD_RC_PRC_IN_POOL  Ist schon da.
                     TCD_RC_INTERNAL_ERR Kein Memory mehr?
---------------------------------------------------------------------*/
void  TCDDSP (P_TCD_C_G pTCDTCD)
{
   int     index ;
   P_TCDMPRCENTRY pMPrcEntry ;
   P_TCDRCINFO    pTcdRcInfo = &(pTCDTCD->pRbsSS->RCTL.RCInfo) ;
   P_TCDCTLPAR    pTcdPar    = &(pTCDTCD->pRbsSS->RCTL.Par) ;

  /* Freien Eintrag in MultiProc suchen */
   if ((index = GetFreeEntry (pTCDTCD)) < 0)    return ;

   pMPrcEntry = &(pTCDTCD->pMPrcAdmin->Data[index]) ;
   if ( pMPrcEntry->PrcBelegt == TCD_POOLENT_USED) 
   {
       pTcdRcInfo->Rc = TCD_RC_PRC_IN_POOL ;
       return ;
   }
   
   /* Auspr,gung in Multiproc uebernehmen */
   pMPrcEntry->PrcBelegt = TCD_POOLENT_USED ;
   pMPrcEntry->ID        = pTcdPar->SP.ProcID ;
   pMPrcEntry->pPrcData  = pTcdPar->SP.pProc ;

   pTcdRcInfo->Rc     = TCD_RC_OK ;
   pTcdPar->SP.ProcIx = index ;

   /* Index der Auspr,gung als Parameter in der CalcProc / GAV setzen*/
   pTcdPar->GA.ProcIx = index ;
   pTcdPar->CFP.ProcIx = index ;
   pTCDTCD->pPrcData = pMPrcEntry->pPrcData ;
}

/*---------------------------------------------------------------------
   Externe Funktion: TCDDRP
   Beschreibung  :   Funktion l"scht eine Auspr,gung aus der MultiProc
   Parameter     :
   Input         :   S_TCD_IPRC_CTL
                     S_TCD_C_G
   Returnwerte   :   pTCDTCD->PrcCtl.Rc =
                     OK         Eintrag wurde als "frei" markiert.
                     TCD_RC_PRC_NOT_IN_POOL
---------------------------------------------------------------------*/
void  TCDDRP (P_TCD_C_G pTCDTCD)
{
   int         i    ;
   P_TCDMPRCENTRY pMPrcEntry = pTCDTCD->pMPrcAdmin->Data ;

   /* Suche nach ProcID oder nach freiem Eintrag */
   for (i = 0 ; i < pTCDTCD->pMPrcAdmin->Anzahl; i++, pMPrcEntry ++) 
   {
        if (pMPrcEntry->ID == pTCDTCD->pRbsSS->RCTL.Par.RP.ProcID) 
        {
            pMPrcEntry->PrcBelegt = TCD_POOLENT_INIT ;
            pTCDTCD->pRbsSS->RCTL.Par.RP.pProc = pMPrcEntry->pPrcData ;

            ReleasePrcAttrResults ( pMPrcEntry->pPrcData );
            return ;
        }
   }
   pTCDTCD->pRbsSS->RCTL.RCInfo.Rc   = TCD_RC_PRC_NOT_IN_POOL ;
}

/*---------------------------------------------------------------------
   Externe Funktion: ReleasePrcAttrResults
   Beschreibung  :   Gibt f�r eine gegebene Prc die pAttrResults frei
   Parameter     :   die Prc
---------------------------------------------------------------------*/
void  ReleasePrcAttrResults ( P_TCDPRCELEM pPrc )
{
   int       n     = 0;
   P_TCDPRCNODE pNode = NULL;
   for ( ; n < pPrc[0].TreeHdr.AnzPrcTree; n++ )
   {
      pNode = (P_TCDPRCNODE)&(pPrc[n].Node);
      if ( pNode->iWiederVerwendungsTyp == 3 && pNode->pPaarListe )
      {
         ReleaseLocalErgebnisPool(pNode->pPaarListe);

         pNode->pPaarListe     = NULL;
         pNode->pResultForGetAttr = NULL;
      }
   }
}

/*---------------------------------------------------------------------
   Externe Funktion: ReleaseMPrcAttrResults
   Beschreibung  :   Gibt f�r alle Prc's einer gegebenen MultiPrc die
                     pAttrResults frei
   Parameter     :   die MultiPrc
---------------------------------------------------------------------*/
void  ReleaseMPrcAttrResults (P_TCDMPRCADMIN pMPrcAdmin )
{
   int i=0;
   for ( ; i < pMPrcAdmin->Anzahl; i++ )     
     if (pMPrcAdmin->Data[i].PrcBelegt!= TCD_POOLENT_INIT)   
        ReleasePrcAttrResults ( pMPrcAdmin->Data[i].pPrcData );
}

/*---------------------------------------------------------------------
   Externe Funktion: MPrcAdminGetPrc
   Beschreibung  :   Gibt Zeiger auf Prc oder NULL zur�ck
   Parameter     :   die MultiPrc und die PrcID
---------------------------------------------------------------------*/
P_TCDPRCELEM  MPrcAdminGetPrc (P_TCDMPRCADMIN pMPrcAdmin, 
                               TCD_LONG PrcID )
{
int i=0;
for ( ; i < pMPrcAdmin->Anzahl; i++ )
{
if ( pMPrcAdmin->Data[i].PrcBelegt               != TCD_POOLENT_INIT &&
   pMPrcAdmin->Data[i].pPrcData->TreeHdr.PrcID == PrcID             )

 return pMPrcAdmin->Data[i].pPrcData;
}
return NULL;
}

/*---------------------------------------------------------------------
   Interne Funktion: GetFreeEntry
Beschreibung  :   Sucht einen freien Eintrag in der MultiPorc.
                 Falls Auspr,gung schon vorhanden, wird der Index auf
                 diesen Eintrag zur�ckgegeben.
                     Falls nix frei ist, wird das Array vergr"�ert.
   Parameter     :
   Input         :   S_TCD_IPRC_CTL
                     S_TCD_C_G
   Returnwerte   :   pTCDTCD->PrcCtl.Rc
                     OK,        Daten wurde gl"scht,
                     andernfalls Systemfehler.
---------------------------------------------------------------------*/
 int   GetFreeEntry (P_TCD_C_G pTCDTCD)
{
   int            i     ;
   int            free_index ;
   void           * mem ;
   P_TCDMPRCENTRY pMPrcEntry ;
   P_TCDRCINFO    pTcdRcInfo = &(pTCDTCD->pRbsSS->RCTL.RCInfo) ;
   P_TCDCTLPAR    pTcdPar    = &(pTCDTCD->pRbsSS->RCTL.Par) ;

   free_index = - 1 ;
   i = pTCDTCD->pMPrcAdmin->Anzahl - 1 ;

   pMPrcEntry = pTCDTCD->pMPrcAdmin->Data ;

   /* Suche nach ProcID oder nach freiem Eintrag */
   for (i = 0 ; i < pTCDTCD->pMPrcAdmin->Anzahl; i++) 
   {
       if (pMPrcEntry[i].ID == pTcdPar->SP.ProcID)
          return (i) ;

       if (pMPrcEntry[i].PrcBelegt == TCD_POOLENT_INIT) 
          free_index = i ;
   }

   /* Freier Eintrag gefunden , ProcID noch nicht in der PoolAdmin */
   if ( free_index >= 0 )
       return ( free_index ) ;

   /* kein freier Eintrag gefunden, PoolAdmin erweitern */
   if ( pTCDTCD->pMPrcAdmin->Anzahl == 0)  
   {
       mem = _TCDALLOC ( 1, sizeof( * pMPrcEntry ) ) ;
   }
   else {
       mem = _TCDREALLOC (pMPrcEntry ,
                          sizeof( * pMPrcEntry ) *
                          ( pTCDTCD->pMPrcAdmin->Anzahl + 1 ) ) ;
   }

   if ( mem == NULL ) 
   {
       pTcdRcInfo->Rc = TCD_RC_INTERNAL_ERR ;
       pTcdRcInfo->Errc = TCD_NO_MEMORY ;
       return ( - 1 ) ;
   }

   pMPrcEntry                = ( P_TCDMPRCENTRY ) mem ;
   pTCDTCD->pMPrcAdmin->Data = pMPrcEntry ;
   i                         = pTCDTCD->pMPrcAdmin->Anzahl ;
   
   pTCDTCD->pMPrcAdmin->Anzahl ++ ;
   pMPrcEntry[i].PrcBelegt   = TCD_POOLENT_INIT ;
   
   return ( i) ;
}

/*---------------------------------------------------------------------
   Interne Funktion: SetPrcData
Beschreibung  :Funktion ueberschreibt die Attributbelegungen des Attr.
             AttrID im Berechnungsvorschriftenbaum mit neuem Wert
   Parameter     :
   Returnwerte   :   -
---------------------------------------------------------------------*/
 void SetPrcData   (P_TCD_C_G pTCDTCD,TCD_LONG AttrID)
{
   P_TCDPRCELEM     pNode ;
   P_TCDPOOLENTRY   pPoolData ;
   P_TCDRCINFO      pTcdRcInfo = &(pTCDTCD->pRbsSS->RCTL.RCInfo) ;
   P_TCDCTLPAR      pTcdPar = &(pTCDTCD->pRbsSS->RCTL.Par) ;
   TCD_INT          index  ;
   TCD_INT          i      ;

   pNode = pTCDTCD->pPrcTreeNode ;
   for (i = 0 ; i < pTCDTCD->pPrcHdr->AnzPrcTree - 1; i ++, pNode ++) 
   {
    if ( (pNode->Node.AttrID == AttrID &&
         (pNode->Node.AssignType == TCD_DC_USE_VAL ||
          pNode->Node.AssignType == TCD_DC_USE_TAB)))

 /*-------------------------------------------------------------------
Belegungsknoten fuer Attr gefunden und Attr ist mit Wert belegt
bei Tabellen:ID umsetzen und Index im Pool auf die neue Attributtabelle
setzen
--------------------------------------------------------------------*/
   switch (pNode->Node.AttrType) 
   {
      case TCD_ATTRFMT_SKAL :
       pNode->Node.AssignVal.Val.Skalar = pTcdPar->GA.Val.Skalar ;
       break ;

      case TCD_ATTRFMT_TAB1 :
      case TCD_ATTRFMT_TAB2 :
       pNode->Node.AssignVal.Val.TabData.TabID  = pTcdPar->GA.TabID ;
       pNode->Node.AssignVal.Val.TabData.PoolIx = pTcdPar->GA.TabIx ;
       index  = pNode->Node.AssignVal.Val.TabData.PoolIx ;
       pPoolData = &(pTCDTCD->pPoolAdmin->Data [index]) ;
       pTcdPar->GA.Val.pTab = pPoolData->pData ;
       break ;

       case TCD_ATTRFMT_VGLO :
       strcpy (pNode->Node.AssignVal.Val.VglOp, pTcdPar->GA.Val.VglOp);
       break ;

       case TCD_ATTRFMT_DATE :
        strcpy (pNode->Node.AssignVal.Val.Datum,pTcdPar->GA.Val.Datum);
        break ;
   } 
   } 
   return ;
}

/*---------------------------------------------------------------------
   Interne Funktion: Find_Attr
   Beschreibung  :   Funktion sucht in der Belegungsinformationstabelle
                     nach dem Attribut mit der gegebenen ID.
   Parameter     :
   Input         :
   Returnwerte   :   pTCDTCD->PrcCtl.Rc
                     OK,                 Attribut ist belegt
                     TCD_RC_NOT FOUND    Attribut ist nicht belegt
                     TCD_RC_UNKNOWN_ATTR Attribut kommt nicht vor
--------------------------------------------------------------------*/
 void  SearchAttr (P_TCD_C_G pTCDTCD,TCD_LONG AttrID, TCD_INT * Index)
{
   TCD_INT         i;
   P_TCDPRCELEM    pPrcElem = pTCDTCD->pInfo ;
   P_TCDRCINFO     pTcdRcInfo = &(pTCDTCD->pRbsSS->RCTL.RCInfo) ;

   pTcdRcInfo->Rc = TCD_RC_OK ;

  /* Belegliste abnudeln */
   for (i = 0; i < pTCDTCD->pPrcHdr->AnzBelegInfo ; pPrcElem ++, i++ ) 
   {
        if (pPrcElem->Info.ID  == AttrID         &&
            pPrcElem->Info.Typ != TCD_PREFIX_TAB  )
        break ;
   }

   if (i == pTCDTCD->pPrcHdr->AnzBelegInfo) 
   {
       pTcdRcInfo->Rc = TCD_RC_UNKNOWN_ATTR ;
       return ;
   }

   if (pPrcElem->Info.AnzBeleg == 0) 
   {
      pTcdRcInfo->Rc = TCD_RC_NOT_FOUND ;
      return ;
   }

   * Index = (TCD_INT) pPrcElem->Info.RefNodeId ;
   return ;
}

/*---------------------------------------------------------------------
Interne Funktion: GetPrcData
Beschreibung  :   Funktion stellt die auspraegungsspezifischen Daten
             bereit. Falls die Auspraegung mit der im Kontext stehenden
             �bereinstimmt, ist nichts zu tun, ansonsten wird in
             der MPrc die Auspraegung gesucht und der Kontext
             aktualisiert
Parameter :   * ProcIx: Index in MultiProc der aktuellen Proc  (INOUT)
                 ProcID  : ID der Auspraegung, mit der gerechnet wird
Input     :
Returnwerte   :   pTCDTCD->PrcCtl.Rc
                 OK,                 OK, ProcIX aktualisiert
                 TCD_NO_MPRCADMIN    keine MultiProc
                 TCD_RC_UNKNOWN_PROC Proc  kommt in MPrc nicht vor
---------------------------------------------------------------------*/
 void GetPrcData   (P_TCD_C_G pTCDTCD,TCD_INT * ProcIx, 
                    TCD_LONG ProcID)
{
   P_TCDRCINFO      pTcdRcInfo = &(pTCDTCD->pRbsSS->RCTL.RCInfo) ;
   P_TCDMPRCADMIN   pMPrcAdmin = pTCDTCD->pMPrcAdmin ;

   /* Wenns keine MultiProc gibt, ist jetzt schon Schluss !! */
  if (pMPrcAdmin == NULL) 
  {
       pTcdRcInfo->Rc   = TCD_RC_INTERNAL_ERR ;
       pTcdRcInfo->Errc = TCD_NO_MPRCADMIN    ;
       return ;
   }

/*---------------------------------------------------------------------
   Suche nach Auspr,gung in MultiProc falls an der durch den ProcIx
   referenzierten Adresse in der MultiProc nicht die ProcID steht
---------------------------------------------------------------------*/
   if (* ProcIx                       <  0                  ||
       * ProcIx                       >= pMPrcAdmin->Anzahl ||
       pTCDTCD->pPrcData              == NULL               ||
       pMPrcAdmin->Data [* ProcIx].ID != ProcID              ) 
   {

      if ((* ProcIx = FindPrc (pTCDTCD,ProcID)) < 0) 
      {
          pTcdRcInfo->Rc = TCD_RC_UNKNOWN_PROC ;
          return ;
      }
   }
   /* fuer den Fall, dass obige Bed. alle  erfuellt sind,
      aber pPrcData (noch) nicht auf gesuchte Prc zeigt */
   else 
   {
      pTCDTCD->pPrcData = pMPrcAdmin->Data[ *ProcIx ].pPrcData;
   }
   InitPrcData (pTCDTCD) ;
   return ;
}

/*---------------------------------------------------------------------
   Interne Funktion: FindPrc
   Beschreibung  :   Funktion sucht die Auspr,gung mit dem gegebenen
                     Namen in der Multiporc-Struktur und setzt die
                     auspr,gungsspezifischen Parameter in der pTCDTCD
                     Struktur, wenn die Auspr,gung gefunden ist.
   Parameter     :   PrcID : ID der gesuchten Auspr,gung
   Returnwert    :   -1 : falls Auspr,gung nicht gefunden
                     Index in MultiProc, an der die Auspr,gung steht
---------------------------------------------------------------------*/
 TCD_INT FindPrc    (P_TCD_C_G pTCDTCD,TCD_LONG PrcID)
{
   P_TCDMPRCADMIN  pMPrcAdmin ;
   P_TCDMPRCENTRY  pMPrcEntry ;
   TCD_INT         i ;

   pMPrcAdmin = pTCDTCD->pMPrcAdmin ;
   pTCDTCD->pPrcData   = 0;
   pMPrcEntry = pMPrcAdmin->Data ;


   for (i = 0; i < pMPrcAdmin->Anzahl; pMPrcEntry++, i++) 
   {
        if (pMPrcEntry->ID == PrcID) 
        {
            pTCDTCD->pPrcData = pMPrcEntry->pPrcData ;
            return (i) ;
        }
   }
   return (-1) ;
}

/*---------------------------------------------------------------------
   Interne Funktion: InitPrcData
   Beschreibung  :   Funktion initialisiert die Daten in der Local Data
                     Struktur der zu berechnenden Auspr,gung
                     Voraussetzung daf�r: die auspr,ungsspezifischen
                     Parameter in der pTCDTCD-> Struktur sind gesetzt
                     (macht Funktion Find_prc)
   Parameter     :
   Returnwerte   :   pTCDTCD->PrcCtl.Rc =
                     OK         Eintrag wurde als "frei" markiert.
                     TCD_RC_PRC_NOT_IN_POOL
---------------------------------------------------------------------*/
 void InitPrcData  (P_TCD_C_G pTCDTCD)
{
   TCD_INT         Info_Ix ;
   TCD_INT         RelAttrs_Ix ;

   pTCDTCD->pPrcHdr       = &(pTCDTCD->pPrcData[0].TreeHdr) ;

   Info_Ix     = pTCDTCD->pPrcHdr->AnzPrcTree ;
   RelAttrs_Ix = pTCDTCD->pPrcHdr->AnzPrcTree   + 
                 pTCDTCD->pPrcHdr->AnzBelegInfo ;

   pTCDTCD->pPrcTreeNode  = &(pTCDTCD->pPrcData [1]);
   pTCDTCD->pInfo         = &(pTCDTCD->pPrcData [Info_Ix]) ;
   pTCDTCD->pRelAttrs     = (P_TCDRELATTR_IMP)
                             &pTCDTCD->pPrcData [RelAttrs_Ix];
}


void * GetResultFromWV ( P_TCD_C_G    pTCDTCD, 
                                   P_TCDPRCNODE pNode , 
                                   P_TCDCTLPAR  pTcdPar)

{               
    P_PAARLISTEN_EL p = NULL;
    switch ( pNode->iWiederVerwendungsTyp )
    {
        case 1:
        case 2:
            return (void *)FetchFromGlobalErgebnisPool 
                (pTCDTCD, pNode->AssignVal.Prc.PrcID,pTcdPar->GA.Typ);

        case 3: 
            if ( pNode->pPaarListe )
            {                                                        
                /* das 0-te Element nehmen ... */
                if((p=FindPaarListElt(pNode->pPaarListe,0)) == NULL )
                    return NULL;

                switch ( p->iType )
                {
                    case TCD_ATTRFMT_SKAL :
                        return (void *)&p->Ergebnis.Skalar ;

                    case TCD_ATTRFMT_TAB1 :
                    case TCD_ATTRFMT_TAB2 :
                        return (void *)p->Ergebnis.pTab;

                    case TCD_ATTRFMT_VGLO :
                        return (void *)&p->Ergebnis.VglOp;

                    case TCD_ATTRFMT_DATE :
                        return (void *)&p->Ergebnis.Datum;

                    default :
                        return NULL;    
                }
            }           
        default:
            return NULL;
    }
}                    
