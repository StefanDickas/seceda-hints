/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_FRT_H)
#define TCD_FRT_H
/*---------------------------------------------------------------------
    Datei:        TCD_FRT.H

Beschreibung: Modul zur allgemeinen Endebehandlung einer Formelfunktion
By:           BEGGI
Datum:        30.03.94
Historie:     BEG    28.11.95  neue Funktion: TCDSetPD
---------------------------------------------------------------------*/
TCD_INT TCDInit (P_TCD_C_F1 pMyPar, TCD_INT FrmNr, char *fctl_cmptime,
				 TCD_LONG VerNr);
void    TCDFtID (P_TCD_C_F1 pMyPar, char * AttrName,
                 TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                 TCD_INT *Var) ;

void    TCDSetPS (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                 TCD_DOUBLE *Var1, TCD_INT *Var2, TCD_DOUBLE Var3) ;
void    TCDSetPV (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                  char *Var1, TCD_INT *Var2, char *Var3) ;
void    TCDSetPD (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                  char *Var1, TCD_INT *Var2, char *Var3) ;

TCD_INT TCDGetTb (P_TCD_C_F1 pMyPar, P_P_TCDTAB Var) ;
void    TCDIniPS (P_TCD_C_G) ;

void    TCDIniFC (P_TCD_C_G) ;
void    TCDIniFU (P_TCD_C_G) ;
void    TCDIniFM (P_TCD_C_G) ;

void    TCDRetSk (P_TCD_C_F1 pMyPar, P_TCD_DOUBLE  VarSkal) ;
void    TCDRetTb (P_TCD_C_F1 pF1, P_P_TCDTAB  VarTab) ;

/*-----------------
  TraceFunktionsprototypen und Trace Makros
-------------------*/
#ifdef TRACEFKT
void _TCD_TRACE( const char * ,const char * ,const char *,P_TCD_C_G );
void _TCD_TRVAL( const char * , int , double *, double,P_TCD_C_G  ) ;

#define TCD_TRACE(pack,func,text, pTCDTCD)  \
            _TCD_TRACE(pack,func,text, pTCDTCD);
#define TCD_TRVAL(text,type,val1,val2, pTCDTCD) \
            _TCD_TRVAL(text,type,val1,val2, pTCDTCD);
#endif

#define C_TRACEFILE        "CTRACE.TCD"

#endif
  
/* RWE, 10.06.1997   */
/*-----------------
  Funktionsprototypen fuer Wiederverwendungsprotokoll
-------------------*/ 
#ifdef PROTWV
void     SetProtWV             (P_TCD_C_G pIf, TCD_BOOL bProtWV);   
  /* ^Dieser Prototyp ist auch in commands.c enthalten! */
TCD_BOOL ProtWVEnabled         (P_TCD_C_G pIf);
void     ProtWV1               (P_TCD_C_F1 pMyPar); 
void     ProtWV2               (P_TCD_C_F1   pMyPar, 
                                P_TCDPRCNODE pNode,
                                P_PAARLISTE  pPaarListe, 
                                TCD_INT      iFlag);
void     ProtWVString          (char *s);
                                
#define C_PROTWVFILE       "CPROTWV.TCD"
#endif
