/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_PKF_H)
#define TCD_PKF_H
/*---------------------------------------------------------------------
    Modul:        C:\dev\TCD_DB\template\db\R3FE\C\C3E9\lifet428.h

    Beschreibung: Funktionsprototypen der externen Funktionen der
                  Formelsammlungsdatei
    By:           BEGGI
    Generiert am: 16.12.2019 15:07:19
---------------------------------------------------------------------*/
   
      void LifeT213 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT214 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT215 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT216 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT217 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT218 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT219 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT220 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT221 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT222 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT223 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT224 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT225 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT226 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT227 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT228 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT229 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT230 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT231 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT232 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT233 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT234 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT235 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT236 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT237 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT238 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT239 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT240 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT241 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT242 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT243 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT244 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT245 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT246 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT247 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT248 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT249 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT250 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT251 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT252 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT253 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT254 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT255 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT256 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT257 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT258 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT259 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT260 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT261 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT262 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT263 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT264 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT265 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT266 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT267 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT268 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT269 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT270 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT271 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT272 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT273 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT274 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT275 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT276 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT277 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT278 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT279 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT280 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT281 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT282 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT283 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT284 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT285 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT286 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT287 (P_TCD_C_F1 pMyPar) ;
   

#endif
