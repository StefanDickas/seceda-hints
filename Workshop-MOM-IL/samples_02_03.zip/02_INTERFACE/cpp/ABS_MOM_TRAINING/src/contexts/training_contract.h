#pragma once

#include <tcdsharedcontext.h>

class ContractContextTraining : public TcdSharedContext , public RootObjectCtx
{
public:
	ContractContextTraining(const std::string &key, bool load = true);
	virtual ~ContractContextTraining();

	void TcdSharedContext::InitTCDTableMap(void) {}
	Attribute *TcdSharedContext::GetVRateKey(const std::string &) { return NULL; }
	Attribute *TcdSharedContext::GetProductTemplateKey(bool) { return NULL; }
	Attribute *TcdSharedContext::GetHsppKey(void) { return NULL; }
	int TcdSharedContext::Get_TAB1_ID_BASE(void) { return 0; }
	int TcdSharedContext::Get_TAB2_ID_BASE(void) { return 1; }
	int TcdSharedContext::Get_DATUM_ID_BASE(void) { return 2; }
};



