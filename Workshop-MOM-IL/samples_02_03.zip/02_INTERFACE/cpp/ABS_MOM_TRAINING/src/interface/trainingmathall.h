
#ifndef CMATHALL_H
#define CMATHALL_H

#ifdef __linux__
	#define __stdcall
#endif

#include <cstddef>

typedef std::size_t math_if_handle_t;

//-----------------------------------------------------------------------------
extern "C" {
int	__stdcall init(const char *pszType,
				   const char *pszPClassTop,
				   const char *pszPKeyTop,
				   const char *pszDASource,
				   const char *pszDATarget,
				   const char *pszIniFileName,
                   math_if_handle_t *instance);

int	__stdcall init2(const char *pszType,
				    const char *pszPClassTop,
				    const char *pszPKeyTop,
				    const char *pszDASource,
				    const char *pszDATarget,
				    const char *sessionId,
				    math_if_handle_t *instance);

int	__stdcall init3(const char *pszType,
				    const char *pszPClassTop,
				    const char *pszPKeyTop,
				    const char *pszDASource,
				    const char *pszDATarget,
				    const char* ggrlSessionId,
				    const char* opSessionId,
				    math_if_handle_t *instance);

int  __stdcall init_rest(   const char *,
                            const char * operationalData,
                            math_if_handle_t *handle);

int	__stdcall compute(math_if_handle_t instance,
					  const char *pszPClass,
					  const char *pszPKey,
					  const char *pszAttribute);

int	__stdcall	uninit(math_if_handle_t instance);

int	__stdcall	getlasterror(math_if_handle_t instance, char *pszCategory, int *code, char *pszAddOn);
int	__stdcall	getmathtrace(math_if_handle_t instance, char *pzsAttribute, char *pszValue);

int	__stdcall	forget(math_if_handle_t instance);
int	__stdcall	get(math_if_handle_t instance, const char *option, char *value, size_t * length);
int	__stdcall	getlibraryoption(math_if_handle_t instance, const char *option, char *value, size_t * length);
int	__stdcall	set_param(math_if_handle_t handle, const char *param_name, const char *param_value);
}

#endif	// CMATHALL_H
