#include <math_utils.h>
#include <tcdid.h>

#include "training_context.h"
#include "training_const.h"


/// 
/// Constructor BaseContextTraining
/// 
BaseContextTraining::BaseContextTraining(std::string const& name, AttributeContext * parent, bool use_for_search)
	: TcdSharedContext(name, parent, use_for_search)
{
}

/// 
/// Destructor BaseContextTraining
/// 
BaseContextTraining::~BaseContextTraining()
{
}


// ================================ BaseContextTraining customization ================================
/// 
/// fetches the insurance rate based on the parameter/name VTAR_ID
/// 
Attribute* BaseContextTraining::GetVRateKey(std::string const & description)
{
	Attribute *pVtarKey = FindAttribute(VTAR_ID, true);
	return pVtarKey;
}

/// 
/// fetches the product template key based on the parameter/name PSCHABL_ID
/// 
Attribute* BaseContextTraining::GetProductTemplateKey(bool bUseKlPschabl)
{
	Attribute *pPSchablKey = FindAttribute(PSCHABL_ID, true);
	return pPSchablKey;
}

/// 
/// fetches the main product key based on the parameter/name HSPP_ID
/// 
Attribute* BaseContextTraining::GetHsppKey()
{
	Attribute *pHsppKey = FindAttribute(HSPP_ID, true);
	return pHsppKey;
}

/// 
/// initializes the TCD Table Map
/// 
void BaseContextTraining::InitTCDTableMap()
{
	REQUIRE(Parent());
	static_cast<BaseContextTraining*>(Parent())->InitTCDTableMap();
}

TCD::DependenciesMap BaseContextTraining::s_TLTarBeschrDependencies =
{
	{ "RIPRE",{ { RATE_STATE_ID } } },
};

static constexpr const char* RISK_GROUP_DEFAULT_VALUE = "XXXXX";
static const auto RISK_GROUP_DEPENDENCY = TCD::Dependency(e_RiskGroup_IP1_n_SKIX, RISK_GROUP_DEFAULT_VALUE);

static const auto MAIN_INSURED_PERSON_DEPENDENCY = TCD::Dependency{ FLAG_MAININSURED };

TCD::DependenciesMap BaseContextTraining::s_TProdSchGrenzWDependencies =
{
	{ "EINAL",{ RISK_GROUP_DEPENDENCY, MAIN_INSURED_PERSON_DEPENDENCY } },
	{ "PRALT",{ RISK_GROUP_DEPENDENCY, MAIN_INSURED_PERSON_DEPENDENCY } },
	{ "EAVD",{ RISK_GROUP_DEPENDENCY, MAIN_INSURED_PERSON_DEPENDENCY } },
	{ "EALEI",{ RISK_GROUP_DEPENDENCY, MAIN_INSURED_PERSON_DEPENDENCY } },
	{ "EAPD",{ RISK_GROUP_DEPENDENCY, MAIN_INSURED_PERSON_DEPENDENCY } },
	{ "AF",{ RISK_GROUP_DEPENDENCY, MAIN_INSURED_PERSON_DEPENDENCY } },
	{ "EARA",{ RISK_GROUP_DEPENDENCY, MAIN_INSURED_PERSON_DEPENDENCY } },
};

TCD::TcdDependencyTableContainer BaseContextTraining::s_TcdDependencyTableContainer;

