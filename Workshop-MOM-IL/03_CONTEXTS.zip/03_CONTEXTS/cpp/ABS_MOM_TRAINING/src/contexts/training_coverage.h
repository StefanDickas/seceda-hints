#pragma once

#include <vector>

#include "training_context.h"
#include "training_const.h"

class ContractContextTraining;
class CoverageItemContextTraining;

class CoverageContextTraining : public BaseContextTraining
{
public:
	CoverageContextTraining(const std::string &key, ContractContextTraining* pContract, bool load= true);
	virtual ~CoverageContextTraining();
	virtual void Load() override;
	
private:
	Record m_CoverageRecord;
	ContractContextTraining * m_pContract;
	
	std::vector<CoverageItemContextTraining *> m_vCoverageItem;
};


