#pragma once

#include "training_context.h"
#include "training_const.h"

class CoverageContextTraining;
class InsuredPersonContextTraining;

class CoverageItemContextTraining : public BaseContextTraining
{
public:
	CoverageItemContextTraining(const std::string &key, CoverageContextTraining* pCoverage, bool load= true);
	virtual ~CoverageItemContextTraining();
	virtual void Load() override;
	
private:
	Record m_CoverageItemRecord;

	CoverageContextTraining * m_pCoverage;
	InsuredPersonContextTraining * m_pInsuredPerson;
};


