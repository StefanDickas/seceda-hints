#include "training_coverage_item.h"
#include "training_insured_person.h"
#include "training_coverage.h"

CoverageItemContextTraining::CoverageItemContextTraining(const std::string &key, CoverageContextTraining* pCoverage, bool load/*= true*/)
    : BaseContextTraining(key, (AttributeContext*)pCoverage)
	
	//Records
    , m_CoverageItemRecord	(key, "PAP#", "TPRODAUS", this)
{
	if (load) {
		Load();
	}
	else {
		SetAttribute("TPRODAUS.PAP#", m_CoverageItemRecord.Key());
		SetAttribute("TPRODAUS.VERSV#", m_pCoverage->GetAttribute("TVERSVERTRAG.VERSV#"));                                                                           
	}
}

CoverageItemContextTraining::~CoverageItemContextTraining()
{
    m_pCoverage->RemoveSubContext(this);
}

void CoverageItemContextTraining::Load ()
{
	Relation relationToInsuredPerson(&m_CoverageItemRecord, "TVERSPERS", "PAP#\tNP#", e_Current);
	for (int i = 0; i < relationToInsuredPerson.size(); i++) {
		m_pInsuredPerson = new InsuredPersonContextTraining(relationToInsuredPerson.Value(i), this);
	}
}
