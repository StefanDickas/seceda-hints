#include "training_coverage.h"
#include "training_contract.h"
#include "training_coverage_item.h"

CoverageContextTraining::CoverageContextTraining(const std::string &key, ContractContextTraining* pContract, bool load/*= true*/) 
    : BaseContextTraining(key, (AttributeContext*)pContract)
	
	//Records
    , m_CoverageRecord	(key, "VERSV#", "TVERSVERTRAG", this)
{
	if (load) {
		Load();
	}
	else {
		SetAttribute("TVERSVERTRAG.VERSV#", m_CoverageRecord.Key());
		SetAttribute("TVERSVERTRAG.VERTR#", m_pContract->GetAttribute("TVERTRAG.VERTR#"));                                                                           
	}
}

CoverageContextTraining::~CoverageContextTraining()
{
    m_pContract->RemoveSubContext(this);
}

void CoverageContextTraining::Load ()
{
	Relation relationToCoverageItem(&m_CoverageRecord, "TPRODAUS", "PAP#", e_Current);
	for (int i = 0; i < relationToCoverageItem.size(); i++) {
		CoverageItemContextTraining *pCoverageItem = new CoverageItemContextTraining(relationToCoverageItem.Value(i), this);
		m_vCoverageItem.push_back(pCoverageItem);
	}
}
