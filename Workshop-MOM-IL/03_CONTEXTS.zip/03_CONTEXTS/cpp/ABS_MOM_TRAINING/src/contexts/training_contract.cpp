#include <iomanip>
#include <boost/foreach.hpp>

#include "math_utils.h"
#include "lookup.h"

#include "training_contract.h"
#include "training_coverage.h"


ContractContextTraining::ContractContextTraining(const std::string & key, bool load)
        : BaseContextTraining(key, NULL)

		// Records
		, m_ContractRecord(key, "VERTR#", "TVERTRAG", this)

{
	m_ContextType = "ContractContext";
	m_bLoad = load;

	if (!load) {
		SetAttribute(std::string("TVERTRAG.VERTR#"), m_ContractRecord.Key());
	}

}

ContractContextTraining::~ContractContextTraining()
{
}


void ContractContextTraining::Load()
{
	Relation relationToCoverage(&m_ContractRecord, "TVERSVERTRAG", "VERSV#", e_Current);
	for (int i = 0; i < relationToCoverage.size(); i++) {
		CoverageContextTraining *pCoverage = new CoverageContextTraining(relationToCoverage.Value(i), this);
		m_vCoverage.push_back(pCoverage);
	}
}