#ifndef TLIFE_CONST_H
#define TLIFE_CONST_H 1

#include <string>
#include "math_utils.h"
#include "baseutilities.h"
#include "tcdid.h"

// ---------------------------- const values and function for sums, duration and age at maturity START --------------------------

// List of possible Fundsclasses
static std::set<std::string> setFundsClasses = boost::assign::list_of("AF")("SF")("GK")("CF")("OF")("DF");

// Quecktypes
enum QueckTypes {STANDARD, PREMIUMDURATION_MT, INSURANCEPERIOD_MT, INSURANCEPERIOD, BENEFITDURATION_MT};

// ZUSKO_SPEZ - Types
typedef enum {ujzm, ujzh, ujzv, vst} ZusKo_Det_Desc;

const int BACKOFFICE = 1;
// predefined text messages - used within different error texts
const std::string GENERAL_EXCLAMATION						= "Calculation was aborted! ";
const std::string GENERAL_SUM_EXCLAMATION					= "The limiting value for the insured sum within tariff ";

const std::string GENERAL_INSURANCEPERIOD_EXCLAMATION		= "The limiting value for the insurance duration within tariff ";
const std::string GENERAL_IP_ENDAGE_EXCLAMATION				= "The limiting value for the end age of the insurance duration within tariff ";

const std::string GENERAL_PREMIUMPAYMENTPERIOD_EXCLAMATION	= "The limiting value for the premium payment duration within tariff ";
const std::string GENERAL_PP_ENDAGE_EXCLAMATION				= "The limiting value for the end age of the premium payment duration within tariff ";

const std::string GENERAL_BENEFITPERIOD_EXCLAMATION			= "The limiting value for the benefit duration within tariff ";
const std::string GENERAL_BP_ENDAGE_EXCLAMATION				= "The limiting value for the end age of the benefit duration within tariff ";

const std::string GENERAL_DEFERMENTPERIOD_EXCLAMATION		= "The limiting value for the annuity deferral duration within tariff ";
const std::string GENERAL_DP_ENDAGE_EXCLAMATION				= "The limiting value for the end age of the annuity deferral duration within tariff ";
// ---------------------------- const values and function for sums, duration and age at maturity END --------------------------

// ----------------------------  general const values START	----------------------------------------------------
enum mathstate {
					INQUIRE = 0,		COMPUTE,		PREMIUMTARGET,		SPECIAL_CALCULATION, 
					PREMIUMFREE_FMZ,	SUPRESS_CHECKS,	ADDITIONAL_CALC
			   };

const int PROV_VECTORSIZE	 =	10;

const double EPS			= 0.00001;
const long LENGTH_INQRESULT = 20000;

#define NON_RECURRING_REPAYMENT		'E'
#define CURRENT_REPAYMENT			'L'

enum stateAnnuitization { RESET = 0, GUARANTEE, INCLGUARANTEEYIELD, INCLYIELD };

enum ICTYP { NOWERTANP = 0,	ISTANDARD,	ICTYP_VMZ,	ICTYP_SURPLUS_ALLOCATION,	ICTYP_WAIVER_LACKOFPAYMENT,	 ICTYP_ENDOF_PREMIUMPAYMENT,	ICTYP_WAIVER_DUE_TO_DISABILITY,	ICTYP_INDEXADJUSTMENT,			
			 ICTYP_WAIVER_DUE_TO_DEATH, ICTYP_EXTEND_CONTRACTDURATION,	ICTYP_POLICYLOAN, ICTYP_COMPUTE_PREMIUMFREE, ICTYP_ANNUITIZATION
		   };

// Definition of event types for the claim/benefit integration.
// the german text must be replaced with the corresponding definition of the product modelling
// it is possible to delete and add new types

const std::string EVENTTYPE_DEATH		=	"ABLEB";
const std::string EVENTTYPE_SURVIVAL	=	"ERLEB";
const std::string EVENTTYPE_OC_DIS      =   "BUNFK"; // occupational disability
const std::string EVENTTYPE_MARRIAGE	=   "HEIRT";
const std::string EVENTTYPE_ACCDEATH	=	"UNFTD"; // accidental death
const std::string EVENTTYPE_ILLNESS		=	"KRANK";
const std::string EVENTTYPE_ACC_DIS		=	"INVAL"; // accidental disability
const std::string EVENTTYPE_NURSING		=	"PFLEG";

// ---------------------------- general const values END	----------------------------------------------------

// ---------------------------- state definitions START	----------------------------------------------------
// the state and state details are defined in the domains "ZUSTAND" and "ZUSTANDSDETAIL"
// STATE_PF means "state premium free" and STATE_CA means "state cancelation"
#define STATE_PF_LACKOFPAYMENT		"FMZ"
#define STATE_PF_ENDOFPREMPAYMENT	"FAP"
#define STATE_PF_ANNUITY			"FLR"  // state detail for annuity phase
#define STATE_PF_SINGLEPREM			"FEE"  // state detail for single premium 
#define STATE_PF_OC_DIS				"FBU"  // state detail for occupational disability
#define	STATE_PF_SURRENDER			"FRK"
#define STATE_PF_DEATH				"FTD"
#define STATE_PF_NURSING		    "FPF"
#define STATE_CA_LACKOFPAYMENT		"SMZ"
#define STATE_CA_WITHDRAWAL_PH		"SRV"
#define STATE_CA_SURRENDER			"SRK"
#define STATE_CA_DEATH				"STD"
#define STATE_CA_POLICYHOLDER		"SVN"
#define STATE_CA_VIOLATION			"SVU"  // Withdrawal due to violation of initial duty of notification
#define STATE_CA_MARRIAGE			"SHT"
#define STATE_CA_DREADDISEASE		"SDD"
#define CANCELATION					"S"
#define PREMIUMFREE					"F"
#define ACTIVE						"A"
// ----------------------------  state definitions END	----------------------------------------------------
const int RATE_STATE_ID = VTAR_ID_RECHVTARVORGABE + 1; //VTAR_ID_RECHVTARVORGABE is defined in tcdid.h an represents the last constant there
const int FLAG_MAININSURED = VTAR_ID_RECHVTARVORGABE + 2;
const std::string RATE_STATE_ACTIVE   = "P";
const std::string RATE_STATE_PREMFREE = "F";

// ----------------------------  component sequence numbers START	------------------------------------------------
// Define here all necessary sequence numbers which have references in the code - the mentioned ones are examples only
const int SEQNR_FUNDPRAEMDYN		=	01234;
const int SEQNR_PRAEMDYN			=	56789;

// examples for clauses which have references in the code
const int SEQNR_INTERESTRATE	=	50386;
// ----------------------------  component sequence numbers END	------------------------------------------------

#endif //TLIFE_CONST_H

