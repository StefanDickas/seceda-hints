#pragma once

#include <vector>
#include <training_context.h>

class CoverageContextTraining;

class ContractContextTraining : public BaseContextTraining , public RootObjectCtx
{
public:
	ContractContextTraining(const std::string &key, bool load = true);
	virtual ~ContractContextTraining();

	virtual void Load() override;

private:
	Record m_ContractRecord;

	std::vector<CoverageContextTraining *> m_vCoverage;
};



