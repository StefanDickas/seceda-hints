
#include "training_orma.h"

#include <trainingmathall.h>
#include <math_if_impl.h>


//-----------------------------------------------------------------------------
int	DLL_CALLING_CONVENTION LINUX_EXPORT  init(const char *,
	const char *top_class,
	const char *top_pkey,
	const char *da_source,
	const char *da_target,
	const char *iniFileNmae,
	math_if_handle_t *handle)
{
    return -1;
}
	
//-----------------------------------------------------------------------------
int  DLL_CALLING_CONVENTION LINUX_EXPORT  init2(const char *,
	const char *top_class,
	const char *top_pkey,
	const char *da_source,
	const char *da_target,
	const char *session_id,
	math_if_handle_t *handle)
{
    return -1;
}
	
//-----------------------------------------------------------------------------
int  DLL_CALLING_CONVENTION LINUX_EXPORT  init3(const char *,
	const char *top_class,
	const char *top_pkey,
	const char *da_source,
	const char *da_target,
	const char *defSession_id,
	const char *opSession_id,
	math_if_handle_t *handle)
{
    return -1;
}

int  DLL_CALLING_CONVENTION LINUX_EXPORT init_rest(const char *,
    const char * operationalData,
    math_if_handle_t *handle)
{
    TRACE_START(NULL, "init_rest");
    return init_rest_impl<InterfaceMathTraining>(operationalData, handle);
}

	
//-----------------------------------------------------------------------------
int DLL_CALLING_CONVENTION LINUX_EXPORT  compute(math_if_handle_t handle, const char *pclass, const char *pkey, const char *attribute)
{
	return compute_impl<InterfaceMathTraining>(handle, pclass, pkey, attribute);
}
	
//-----------------------------------------------------------------------------
int DLL_CALLING_CONVENTION LINUX_EXPORT  uninit(math_if_handle_t handle)
{
	return uninit_impl<InterfaceMathTraining>(handle);
}
	
//-----------------------------------------------------------------------------
int DLL_CALLING_CONVENTION LINUX_EXPORT  getlasterror(math_if_handle_t handle,
	char *pszCategory,
	int *code,
	char *pszAddOn)
{

    strcpy(pszCategory, "ERROR");
    *code = 999;
    strcpy(pszAddOn, "LIBRARY INTERFACE NOT SUPPORTED");

	return getlasterror_impl<InterfaceMathTraining>(handle, pszCategory, code, pszAddOn);
}
	
//-----------------------------------------------------------------------------
int DLL_CALLING_CONVENTION LINUX_EXPORT  getmathtrace(math_if_handle_t handle, char *pszAttribute, char *pszValue)
{
	return getmathtrace_impl<InterfaceMathTraining>(handle, pszAttribute, pszValue);
}

int	DLL_CALLING_CONVENTION LINUX_EXPORT  set_param(math_if_handle_t handle,
    const char *param_name,
    const char *param_value)
{
    std::cerr << __FUNCTION__ << std::endl;
    return set_param_impl<InterfaceMathTraining>(handle, param_name, param_value);
}

int DLL_CALLING_CONVENTION LINUX_EXPORT  get(math_if_handle_t handle, const char * option, char *value, size_t * length)
{
    return get_impl<InterfaceMathTraining>(handle, option, value, length);
}

int	DLL_CALLING_CONVENTION LINUX_EXPORT  getlibraryoption(math_if_handle_t instance, const char *option, char *value, size_t * length)
{
    if (length == nullptr) {
        return -1;
    }

    std::string optionValue = GlobalOptions::Instance().getOptions().get(option);
    if (optionValue.length() > *length) {
        *length = optionValue.length();
        return -2;
    }

    if (value) {
        strcpy(value, optionValue.c_str());
    }

    return  0;
}

