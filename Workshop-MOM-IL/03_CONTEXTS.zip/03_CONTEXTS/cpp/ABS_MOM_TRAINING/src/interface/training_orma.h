#ifndef MATH_TLIFE_ORMA_H
#define MATH_TLIFE_ORMA_H

#include <math_orbit.h>
#include <exception_container.h>

#include "training_math.hpp"
#include "training_errmg.h"

class InterfaceMathTraining : public OrbitMath<mathContractTraining>
{
	///
	/// Class InterfaceMathTraining
	/// This class implements the interface of a calculation call
	///
public:
	typedef OrbitMath<mathContractTraining> MyBase;
	
	InterfaceMathTraining(const char *operational_data)
        : MyBase(operational_data)
    {
    }

	~InterfaceMathTraining()
	{
		m_pMathIF->unsetConfiguration();
	}
	
    long Compute(const char *pclass_, const char *pkey_, const char *attribute)
	{
		std::string pclass(pclass_ == NULL || *pclass_ == 0 ? m_pTopClass : pclass_);
		std::string pkey(pkey_ == NULL || *pkey_ == 0 ? m_pTopPKey : pkey_);
	
		TRACE_START(NULL, "COMPUTE: " + std::string(attribute));
	
        bool bInquireOnly = (ParameterManager::Instance().GetStringValWithDefault("INQUIRE_ONLY", "SWITCHES", GlobalOptions::Instance().CurrentSession(), "false") == "true");
        if (!bInquireOnly && m_pMathIF->compute(pclass.c_str(), pkey.c_str(), attribute) < 0) {
            return -1;
        }

        if (!bInquireOnly && (attribute == NULL || !strlen(attribute))) {
            if (m_pMathIF->save() < 0) {
                return -1;
            }
        }

        Record recContract(pkey, "VERTR#", "TVERTRAG");
        Relation relInquiries(&recContract, "TINQUIRY_LIST", "INQLIST#", e_Current);
        for (const auto& inqkey : relInquiries) {
            Record recInquire(inqkey, "INQLIST#", "TINQUIRY_LIST");
            const auto& inqName = recInquire.GetValue("INQUIRYNAME");
            auto inquireResult = m_pMathIF->getcontract_type_impl()->Inquire(inqName);

            Trace::Info(NULL, std::string("Result : ").append(inquireResult));
            recInquire.SetValue("INQRESULT", inquireResult);
        }

		return 0;
	}
	
    void InitExceptionStore()
	{
		ExceptionStore::SetInstance(boost::shared_ptr<ExceptionStore>(new ExceptionStoreTraining));
	}

    static void setParamStatic(const char *paramName_, const char *paramValue_)
    {
        // not needed for now
    }

    void setParam(const char *paramName_, const char *paramValue_)
    {
        ParameterManager::Instance().SetStringVal(math::to_upper_copy(paramName_), paramValue_, "SWITCHES", 0);
    }
};

#endif // MATH_TLIFE_ORMA_H
