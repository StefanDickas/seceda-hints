#ifndef MATH_TLIFE_ERRMG_H
#define MATH_TLIFE_ERRMG_H

#include <exception_container.h>
#include <exception.h>
#include <map>

class ExceptionStoreTraining : public ExceptionStore
{
	///
	/// Class ExceptionStoreTraining
	/// This class can be used to transform CPL - errors, which are typically exceptions, into "nice" validations or warnings
	/// If such feature is not needed the class can be removed
	///
public:
	ExceptionStoreTraining() : ExceptionStore()
	{
	}

	void Save(const Exception& e)
	{
		if (std::string(e.Category()) == "TCD_Fehler")
		{
			Exception& nce = const_cast<Exception&>(e);
			int hcode = e.m_Code % 1000;

			if (hcode >= 700) {
				nce.m_Code = hcode -= 400;
			}

			// errors from TCD are changed to a "nice" error message 
			// content errorMap: 1. int = TCD-code, 2. int = Eingabefehler-Code

			static std::map<int, int> errorMap;

			if (errorMap.find(hcode) != errorMap.end()) {
				nce.m_Category = "EingabeFehler";
				nce.m_Code = errorMap[hcode];
			}

		}
		ExceptionStore::Save(e);
	}
};
#endif	// MATH_TLIFE_ERRMG_H
