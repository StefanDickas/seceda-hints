/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
 /*--------------------------------------------------------------------
    Modul:        TCD_PKF.c

    Beschreibung: Funktionen C-Generator, die vom Makrogenerator
                  aufgerufen werden
    By:           BEGGI
    Datum:        16.12.2019 15:07:19
    Historie :    BEG  22.11.95      FM: 384
  MUB  21.5.96 Optimierung begonnen, Beschaffungsflags etc.
  MUB          Pr�fung, ob Ergebnis schon berechnet wurde.
  MUB 17.7.96  Abweisungen zwischen #ifdef TRACEFKT #endif korrigiert
  MUB 26.7.96  Erfolgreiche Wiederverwendung eines Ergebnisses
               ins Tracefile schreiben
---------------------------------------------------------------------*/

/* Includes */
/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDPORTAB_H)
#define TCDPORTAB_H

/*-----------------
Name        : TCDPORTAB.H

Beschreibung: externes Include File, das generierumgeungsspezifische
Informationen enthaelt (Makrovorlage).
By          : BEGGI
Datum       : 20.04.94
Historie:     BEG   17.01.95  neues Makro _TCDMEMINI anstatt memset
BEG   02.03.95  bedingte Macros TCDHUGE
BEG   22.06.95  _TCDMEMINI nur im HUGE-Modell redefiniert.
BEG   20.02.96  malloc.h wird nicht mehr inkludiert (FM 451)
RWE   21.06.96  malloc.h wird wieder includiert (aber nur
              fuers HUGE-Modell, d.h. fuer DOS/WIN-Compiler)
RWE   26.06.96  WATCHMEM-Makros eingebaut (fuer TCDALLOC etc)
MUB   17.7.96   Include mit !defined versehen
KFC   02.09.96  #define TCDHUGE vorgezogen

-------------------*/

/* #define TCDHUGE */              /* bei gro�en Tabellen einschalten*/
/* Systemincludes */                  
#include <stdlib.h>                /* atoi, ...       */
#include <stdio.h>                 /* fprintf, ...    */
#include <string.h>                /* strcpy, ...     */
#include <time.h>                  /* time_t, ...     */
#include <math.h>                  /* exp, min, max, ... */

#ifdef TCDHUGE
#include <malloc.h>
#endif

/* Defines */
#define  TCDC_EXT_NAME_LNG    8  /* maximale L�nge von externen 
                                    Bezeichnern*/
/*-----------------
  Definitionen aus standard C-Includes z.B. stdio.h
-------------------*/
#ifndef NULL
#define    NULL    (void *)0
#endif

/*-----------------
  Definitionen von Basistypen
-------------------*/
typedef    short   TCD_BOOL ;
typedef    long    TCD_LONG ;
typedef    int     TCD_INT  ;
typedef    double  TCD_DOUBLE ;


/*-----------------
  modellabhaengige Definitionen von Basistypen
-------------------*/
typedef    TCD_DOUBLE  TCDTAB ;
#ifdef TCDHUGE
typedef    TCDTAB       huge * P_TCDTAB ;
typedef    TCD_DOUBLE   huge * P_TCD_DOUBLE ;
typedef    P_TCD_DOUBLE * P_P_TCD_DOUBLE ;
typedef    char huge    * TCD_LPCHAR ;
#else
typedef    TCDTAB       * P_TCDTAB ;
typedef    TCD_DOUBLE   * P_TCD_DOUBLE ;
typedef    P_TCD_DOUBLE * P_P_TCD_DOUBLE ;
typedef    char         * TCD_LPCHAR ;
#endif

/*-----------------
  weitere (Typ-)Defines 
-------------------*/  
typedef int ERRNO_TYPE;
#define TCD_FILENAME_LNG 128

/*-----------------
  Definitionen von Makros f�r Speicherallokation
-------------------*/  

/* WATCHMEM muss im TCDHUGE-Modus abgeschaltet sein */
#ifdef TCDHUGE
#undef WATCHMEM
#endif

#undef _TCDALLOC
#undef _TCDFREE
#undef _TCDREALLOC

#ifndef WATCHMEM

#define _TCDALLOC(len,size)    malloc( (size_t)(len) * (size)) ;
#define _TCDFREE(ptr)          {free(ptr), ptr = NULL;}
#define _TCDREALLOC(ptr,size)  realloc( ptr, (size_t)(size) ) ;

#else
 
void *MallocAndProt(char *sFile_,int iLine_, size_t size);
#define _TCDALLOC(len,size)\
 MallocAndProt(__FILE__,__LINE__,(len) * (size))

void FreeAndProt(char *sFile_, int iLine_, void *p_);

#define _TCDFREE(ptr)\
       {FreeAndProt(__FILE__, __LINE__, ptr) , ptr = NULL;}

void *ReallocAndProt(char *sFile_,int iLine_, void *p_, size_t size);
#define _TCDREALLOC(ptr,size)\
 ReallocAndProt(__FILE__, __LINE__, ptr,size)

void ResumeWatchmem();

#endif

/*-----------------
  modellabh�ngige Definitionen von Makros f�r Speicherallokation
-------------------*/
#undef _TCDTABALLOC
#undef _TCDTABFREE
#undef _TCDMEMINI

#ifdef TCDHUGE

#define _TCDTABALLOC(len,size)\
  _halloc( (long)(len) , (size_t)(size)) ;
#define _TCDTABFREE(ptr)\
      { _hfree ( (void huge *)ptr); ptr = NULL;}

#else

#ifndef WATCHMEM
#define _TCDTABALLOC(len,size)\
 malloc((size_t)((long)len) * ((size_t)size)) ;
#define _TCDTABFREE(ptr)       {free(ptr), ptr = NULL;}
#else
#define _TCDTABALLOC(len,size)\
 MallocAndProt(__FILE__,__LINE__,(len) * (size))
#define _TCDTABFREE(ptr)\
       FreeAndProt(__FILE__, __LINE__, ptr)
#endif

#endif


#ifdef TCDHUGE
#define _TCDMEMINI(ptr,size,nr)\
{\
   long       j;\
   TCD_LPCHAR lp;\
   for (j= 0 , lp = (TCD_LPCHAR)ptr;\
        j < ((long)(size) * (long)(nr)); j++, lp++) \
      *lp = 0;\
}  

#else
#define _TCDMEMINI(ptr,size,nr)\
 { memset (ptr, 0, (size_t) ((size) * (nr))) ; }
#endif
/*---------------------------------
  NON-Ansi-Namen mit oder ohne "_"
----------------------------------*/

/* #define NON_ANSI_WITHOUT__ */

#ifdef NON_ANSI_WITHOUT__
#define _fcvt fcvt
#endif

/*---------------------------
  ggf. Verkuerzung der Namen
-----------------------------*/
#ifdef TCD_NAMLEN8

#define TCDIMPReleaseProcData       TCD_0001
#define TCDIMPReleaseNodeData       TCD_0002
#define TCDIMPReleaseTabImpData     TCD_0003   

#define FetchFromGlobalErgebnisPool TCD_0004

#define DelEltFromSVect             TCD_0005
#define DelEltFromSVectByIndex      TCD_0006

#define DelEltFromVect              TCD_0007
#define DelEltFromVectByIndex       TCD_0008
                                
                                
#define ReleaseGlobalErgebnisPool   TCD_0009
#define ReleaseGlobalErgebnis       TCD_0010
#define ReleaseLocalErgebnisPool    TCD_0011

#define GetPrcDataSkal              TCD_0012
#define GetPrcDataTab               TCD_0013
#define GetPrcDataDat               TCD_0014
#define GetPrcDataFrm               TCD_0015

#define GetPrcAttrSkal              TCD_0016
#define GetPrcAttrTab               TCD_0017

#define GetSSAttrSkal               TCD_0018
#define GetSSAttrTab                TCD_0019

#define ErgPoolGetFirstInfo         TCD_0020
#define ErgPoolGetNextInfo          TCD_0021

#define DConstrAttrs                TCD_0022
#define DConstrAttrsResults         TCD_0023

#define GetRelAttrs                 TCD_0024

#define GetIndexToGlobalErgPool     TCD_0025
#define GetIndexToPaarListElt       TCD_0026

#define GetIndexToSS                TCD_0027
#define GetIndexToUes               TCD_0028
#define GetFromSS                   TCD_0029
#define GetFromUes                  TCD_0030

#define TCDIMPImportTreeData        TCD_0031
#define TCDIMPNFIntl                TCD_0032
#define TCDIMPGetNodeFromID         TCD_0033
#define TCDIMPGetNodeFromPath       TCD_0034
#define compBsearch                 TCD_0035
#define TCDIMPReleaseTreeData       TCD_0036 
#define TCDIMPReleaseTabData        TCD_0037  
#define DConstrTCD_C_G              TCD_0038
#define DDestrTCD_C_G               TCD_0039 
#define SConstrTCD_C_G              TCD_0040
#define DConstrTCDRbsSS             TCD_0041
#define SConstrTCDRbsSS             TCD_0042
#define SConstrTCDISSADATA          TCD_0043
#define SDestrTCD_C_G               TCD_0044
#define DDestrTCDRbsSS              TCD_0045
#define SDestrTCDRbsSS              TCD_0046
#define SDestrTCDISSADATA           TCD_0047
#define GetRbsSSFkt                 TCD_0048
#define TCDIMPGetTabIDAndTypFromPath TCD_0049
#define TCDIMPGetPathAndTypFromID    TCD_0050
#define TCDIMPReleaseTabTreeData     TCD_0051
#define TCDIMPImportTabTreeData      TCD_0052
#endif

#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDC_H)
#define TCDC_H

#ifdef TCDV2_5
#define TCDVERS 25
#endif
#ifdef TCDV3_0
#define TCDVERS 30
#endif
#ifndef TCDVERS
#error TCD Version muss in Makefiles angegeben werden.
#endif

/*---------
Name        : TCDC.H

Beschreibung: Zentrales Include File fuer die Anwendung
TCD weit gueltig
*----------*/

#include "p09115.h" /* direkte Vektoren */

#define  TCD_TRUE                1
#define  TCD_FALSE               0

/*---------
  Definitionen Opcodes
*----------*/
#define  TCD_OPC_INIT_RBS                    1
#define  TCD_OPC_CALC_FRM                    2
#define  TCD_OPC_CALC_PRC                    3
#define  TCD_OPC_GETNUM_FRM                  4
#define  TCD_OPC_GET_ATTR_VAL                5
#define  TCD_OPC_RESET_RBS                   6
#define  TCD_OPC_SET_PRC                     7
#define  TCD_OPC_RESET_PRC                   8
#define  TCD_OPC_SET_POOLTAB                 9
#define  TCD_OPC_RESET_POOLTAB              10
#define  TCD_OPC_SET_ATTR_VAL               11
#define  TCD_OPC_GET_PRC_INFO               12
#define  TCD_OPC_SET_POOLTAB_I              13
#define  TCD_OPC_RESET_POOLTAB_I            14
#define  TCD_OPC_SET_ATTR_IN_PRC            15
#define  TCD_OPC_SET_TRACE_ON               16
#define  TCD_OPC_SET_TRACE_OFF              17
#define  TCD_OPC_REMOVE_RESULTS             18
#define  TCD_OPC_GET_FIRST_RESULTS_INFO     19
#define  TCD_OPC_GET_NEXT_RESULTS_INFO      20

/*---------
  Definitionen Returncodes
*----------*/
#define  TCD_RC_NOT_OK              0
#define  TCD_RC_OK                  1
#define  TCD_RC_ILLOPC              2
#define  TCD_RC_VERSION_CONFLICT    3
#define  TCD_RC_UNKNOWN_FORM        4
#define  TCD_RC_ILLEGAL_FORM        5
#define  TCD_RC_ILLEGAL_PARAM       6
#define  TCD_RC_UNKNOWN_ATTR        7
#define  TCD_RC_NOT_FOUND           8
#define  TCD_RC_INPUT_MISSING       9
#define  TCD_RC_ILLEGAL_DIVISION   10
#define  TCD_RC_ILLEGAL_TAB_RANGE  11
#define  TCD_RC_STACK_OVERFLOW     12
#define  TCD_RC_CONDITION_FAIL     15
#define  TCD_RC_PAR_ERROR          20
#define  TCD_RC_TAB_IN_POOL        21
#define  TCD_RC_TAB_NOT_IN_POOL    22
#define  TCD_RC_PRC_IN_POOL        23
#define  TCD_RC_PRC_NOT_IN_POOL    24
#define  TCD_RC_UNKNOWN_PROC       25
#define  TCD_RC_PAARLISTEN_ERROR   26
#define  TCD_RC_NO_VALUE_AVAIL     30
#define  TCD_RC_USER_SET_ERROR    900
#define  TCD_RC_INTERNAL_ERR      999
#define  TCD_RC_NO_RETURN         888

/*---------
  allgemeine globale Konstanten
*----------*/
#define TCD_INIT_VARSETLEVEL    9999

/*---------
  Konfigurationsangaben
*----------*/
#define TCD_POOLADMIN_SIZE        20
#define TCD_C_MIN_USER_TYPE_ID    0
#define TCD_C_TABLISTLEN          10
#define TCD_C_MAXPRCCALLNR        2147483647

/*---------
  Definitionen Laengenangaben
*----------*/
#define TCD_DATUM_LNG              9
#define TCD_FRM_DATUM_LNG         20
#define TCD_VGLOP_LNG              3
#define TCD_NAME_LNG              26

/*---------
  Definitionen Aufrufart: (Aufzaehlungstyp)
-----------*/
#define TCD_CALLTYP_ATTR        1
#define TCD_CALLTYP_STA         2
#define TCD_CALLTYP_DYN         3
#define TCD_CALLTYP_STA_UE      4

/*---------
  Definitionen Prefix
-----------*/
#define TCD_PREFIX_TAB            '&'
#define TCD_PREFIX_PRC            '$'
#define TCD_PREFIX_FRM            'F'
#define TCD_PREFIX_ATTR           'A'

/*---------
  Definitionen Formeltypen (Aufzaehlungstyp, Wertevergabe analog Cobol)
-----------*/
#define TCD_FRMTYP_SKAL        1
#define TCD_FRMTYP_TAB1        2
#define TCD_FRMTYP_TAB2        3

/*---------
  Definitionen Belegungswerte PoolEntry
-----------*/
#define  TCD_POOLENT_INIT          0
#define  TCD_POOLENT_USED          1
#define  TCD_POOLENT_I_USED        2
#define  TCD_POOLENT_E_USED        3

/*---------
  Definitionen Assigntype
*----------*/
#define  TCD_DC_USE_NOT            0
#define  TCD_DC_USE_FRM            1
#define  TCD_DC_USE_PRC            2
#define  TCD_DC_USE_TAB            3
#define  TCD_DC_USE_VAL            4

/*----------
  Definitionen Formattypen
-----------*/
#define  TCD_ATTRFMT_SKAL          1
#define  TCD_ATTRFMT_TAB1          2
#define  TCD_ATTRFMT_TAB2          3
#define  TCD_ATTRFMT_VGLO          4
#define  TCD_ATTRFMT_DATE          5

/*----------
  Struktur Bestandsattributtabelle
 ----------*/
  typedef struct tagS_TCDATAB {
        char          Name [TCD_NAME_LNG] ;
        TCD_LONG      ID         ;
        TCD_INT       Index      ;
        TCD_INT       AttrTyp    ;
  } S_TCDATAB     ;

 typedef S_TCDATAB     * P_TCDATAB     ;

/*----------
  Struktur Tabelle aller Attribute
 ----------*/
  typedef struct tagS_ATTRTAB
  {
    TCD_LONG  ID    ;
    TCD_INT   Index ;
  } S_ATTRTAB ;

  typedef S_ATTRTAB    * P_ATTRTAB     ;

/*----------
  Typdefinition systemunabhanegiger Typen
 ----------*/
   typedef  char  TCD_VGLOP [TCD_VGLOP_LNG] ;
   typedef  char  TCD_DATUM [TCD_DATUM_LNG] ;

   typedef TCD_DOUBLE TCDTAB1 ;
   typedef P_TCDTAB   P_TCDTAB1 ;

   typedef TCD_DOUBLE TCDTAB2 ;
   typedef P_TCDTAB   P_TCDTAB2 ;

   typedef P_P_TCD_DOUBLE P_P_TCDTAB ;

/*---------
  Union Attributbelegung
 ----------*/
  typedef  union tagU_TCDVALUE {
           TCD_DOUBLE        Skalar;
           P_TCDTAB1         pTab1 ;
           P_TCDTAB2         pTab2 ;
   } U_TCDVALUE ;

  typedef  union tagU_TCDGVALUE {
           TCD_DOUBLE        Skalar;
           P_TCDTAB          pTab  ;
           TCD_VGLOP         VglOp ;
           TCD_DATUM         Datum ;
   } U_TCDGVALUE ;

/* --
 MUB 2.7.96: neu eingefuehrt, weil wir die TabellenID brauchen
--  */
  typedef  union tagU_TCDWVALUE
  {
           TCD_DOUBLE        Skalar;

           TCD_LONG          TabID ;  /*  die relevanten Attribute */
           P_TCDTAB1         pTab  ;  /*  das Ergebnis */

           TCD_VGLOP         VglOp ;
           TCD_DATUM         Datum ;
   } U_TCDWVALUE ;

  typedef struct tagS_TCDPRCVAL {
          TCD_LONG   PrcID ;
          TCD_LONG   FormelNr ;
          TCD_INT    FormelIx ;
          char       FormelName [TCD_NAME_LNG] ;
          TCD_INT    PoolIx ;
#if TCDVERS > 25
/* Version der Formel zur Pruefung 
		  Formel-Generat gegen Transport-Format */
          TCD_INT    FormelVers;
#endif

 } S_TCDPRCVAL ;

  typedef union  tagU_TCDNDVALUE {
          struct   tagTabData {
             TCD_LONG  TabID ;
             TCD_INT   PoolIx ;
          } TabData  ;
          TCD_DOUBLE Skalar ;
          char       Datum [TCD_DATUM_LNG] ;
          char       VglOp [TCD_VGLOP_LNG];
 } U_TCDNDVALUE ;


  typedef struct tagS_TCDFORMEL {
           TCD_LONG  FormelNr ;
           TCD_INT  FormelIx ;
           char     FormelName [TCD_NAME_LNG] ;
           TCD_INT  IsStaRef ;                                 
#if TCDVERS > 25
/* Version der Formel zur Pruefung 
		   Formel-Generat gegen Transport-Format */
		   TCD_INT  FormelVers;
#endif
 } S_TCDFORMEL ;

  typedef union  tagU_TCDASSIGNVAL {

       S_TCDPRCVAL  Prc    ;
       U_TCDNDVALUE Val    ;
       S_TCDFORMEL  Formel  ;

 } U_TCDASSIGNVAL ;

#define TYP3_NOT_OVERWRITTEN 2

typedef struct tagS_TCDREL_ATTR
{                                 
   TCD_LONG    iBerechnungsNummer;
   /* ID des Attributs                            */
   TCD_LONG    AttrID                  ;  
   /* Typ der Belegung SKALAR, TAB, DATUM , VGLOP */
   TCD_INT     AttrType              :4;  
   /* Flag, ob ein geerbter Wert vorhanden ist    */
   TCD_INT     bGeerbterWertVorhanden:2;  
   /* Flag, ob ein geerbter Wert vorhanden ist    */
   TCD_INT     bNotOverwritten         ;
   /* GGf. Wert hierzu                            */
   U_TCDWVALUE Belegung                ;  

}  S_TCDRELATTR;

typedef S_TCDRELATTR * P_TCDRELATTR ;

/* --
   S_TCDRELATTR_IMP    Relevantes Attribut fuer den Import
--  */
typedef struct tagS_TCDREL_ATTR_IMP
{
   TCD_LONG AttrID;
   TCD_INT  AttrType               : 4;
   TCD_INT  iIndex;

}  S_TCDRELATTR_IMP;

typedef S_TCDRELATTR_IMP * P_TCDRELATTR_IMP ;

/* --
   S_PAARLISTEN_EL    Struktur fuer ein PaarlistenElement
--  */
typedef struct tagS_PAARLISTEN_EL
{
   /* Vektor der relevanten Attribute mit der aktuellen Belegung     */
   LP_VECT          pAttrs;        
   /* lfde. Nummer der aktuellen Berechnung                          */
   TCD_LONG         iBerechnungsNummer; 
   
   TCD_LONG         lTabZeilen;         
   TCD_LONG         lTabSpalten;
   
   /* Typ des Ergebnisses (kann 'NOT_OVERWRITTEN' sein)              */
   TCD_INT          iType;              
   /* Ergebnis hierzu                                                */
   U_TCDWVALUE      Ergebnis;           

}  S_PAARLISTEN_EL;

typedef S_PAARLISTEN_EL * P_PAARLISTEN_EL ;

/* --
   S_PAARLISTE     Struktur zu einem Belegknoten einer BV
   Sie enthaelt 1 sortierten Vektor, 1 Liste und eine maximale Laenge
   fuer die Anzahl Elemente der Paarliste (Belegung,Ergebnis)
--  */
typedef struct tagS_PAARLISTE
{
   TCD_INT iWiederVerwendungsTyp;   /* KnotenTyp 1/2/3     */
   TCD_INT iWiederVerwListenLaenge; /* ListenLaenge maximal */
   TCD_INT iAct ;                   /* letztes Element     */

   /* direkter Vektor von S_ATTR_EL's   */
   LP_VECT pAttrs;                  
   /* direkter Vektor von S_PAARLISTEN_EL's */
   LP_VECT pPaarListenElts;         

}  S_PAARLISTE;

typedef S_PAARLISTE * P_PAARLISTE ; 

/* --
   S_ERGEBNIS_POOL_ELT Element eines PoolErgebnisses
--  */
typedef struct tagS_ERGEBNIS_POOL_ELT
{
   TCD_LONG    ID;
   P_PAARLISTE pPaarListe;

}  S_ERGEBNIS_POOL_ELT;

typedef S_ERGEBNIS_POOL_ELT * P_ERGEBNIS_POOL_ELT ;

/*-----------
  Struktur     Belegungsknoten
------------*/
  typedef struct tagS_TCDPRCNODE
  {
      TCD_LONG         AttrID                  ;
      TCD_INT          NodeID                  ;
      TCD_INT          AttrType                ;
      TCD_INT          AssignType              ;
      U_TCDASSIGNVAL   AssignVal               ;
      TCD_INT          SuccNodeIx              ;
      TCD_INT          AnzSuccNodes            ;
      TCD_INT          Usage                   ;

      P_PAARLISTE      pPaarListe              ;
      P_PAARLISTEN_EL  pResultForGetAttr       ;

      TCD_INT          iWiederVerwendungsTyp   ;
      TCD_INT          iWiederVerwListenLaenge ;
      TCD_INT          iAnzRelAttrs            ;
      TCD_INT          iFirstRelAttrIx         ;

  }   S_TCDPRCNODE ;

 typedef S_TCDPRCNODE  * P_TCDPRCNODE ;

/*-----------
  Struktur Auspraegungs-Belegungs-Information
------------*/
  typedef struct tagS_TCDPRCINFO {
         char  Name [TCD_NAME_LNG] ;
         TCD_LONG  ID ;
         TCD_INT   Formattyp ;
         TCD_INT   Typ ;
         TCD_INT   Klasse ;
         TCD_INT   AnzBeleg ;
         TCD_INT   TabIx ;
         TCD_LONG  RefNodeId ;
 } S_TCDPRCINFO ;

 typedef S_TCDPRCINFO  * P_TCDPRCINFO ;

/*--------
  Struktur LocalData MUB 2.7.96: wird nicht mehr verwendet!
 --------*/
  typedef struct tagS_TCDPRCLOCD {
          TCD_LONG FormelNr     ;
          TCD_INT  Usage        ;
          TCD_INT  Typ          ;
          union   {
              TCD_INT    PoolIx ;
              TCD_DOUBLE Val    ;
          } Data ;
          TCD_LONG  CalcByCallNr ;
   } S_TCDPRCLOCD ;

   typedef S_TCDPRCLOCD * P_TCDPRCLOCD ;

/*---------
  Struktur Header Auspraegungsbaum
----------*/
  typedef struct tagS_TCDPRCHDR {
    TCD_LONG       PrcID        ;
    TCD_LONG       FormelNr     ;
    TCD_INT        AnzPrcTree   ;
    TCD_INT        AnzBelegInfo ;
    TCD_INT        AnzRelAttrs  ;
    TCD_BOOL       FlSetAttrSkal;
    TCD_BOOL       FlSetAttrTab ;
    TCD_BOOL       FlSetAttrVgl ;
    TCD_BOOL       FlSetAttrDat ;
    TCD_BOOL       FlPrcCompl   ;
    TCD_LONG       PrcResIx     ;
    TCD_LONG       PrcCallNr    ;

 } S_TCDPRCHDR     ;


/*---------
  Struktur Auspraegungselement
-----------*/
  typedef union  tagU_TCDPRCELEM
  {
     S_TCDPRCHDR      TreeHdr;
     S_TCDPRCNODE     Node ;
     S_TCDPRCINFO     Info ;     
  }  U_TCDPRCELEM ;

 typedef U_TCDPRCELEM  * P_TCDPRCELEM ;

#define TCDPRCSIZE(pPrc)    (pPrc ? sizeof(S_TCDRELATTR_IMP)*\
                            (TCD_LONG)pPrc->TreeHdr.AnzRelAttrs +\
                            sizeof(U_TCDPRCELEM)*\
                            ( (TCD_LONG)pPrc->TreeHdr.AnzPrcTree +\
                             (TCD_LONG)pPrc->TreeHdr.AnzBelegInfo) : 0)


/*-------
  Datenstruktur Mehrfach-Auspraegung (MultiProc)
 --------*/
  typedef struct tagS_TCDMPRCENTRY {
        TCD_INT              PrcBelegt ;
        TCD_LONG             ID ;
        P_TCDPRCELEM         pPrcData ;
 } S_TCDMPRCENTRY ;

  typedef S_TCDMPRCENTRY * P_TCDMPRCENTRY ;

  typedef struct tagS_TCDMPRCADMIN {
        TCD_INT          Anzahl  ;
        P_TCDMPRCENTRY   Data    ;
 } S_TCDMPRCADMIN ;

 typedef S_TCDMPRCADMIN * P_TCDMPRCADMIN ;

/*--------
  Datenstruktur PoolAdmin
--------*/
  typedef struct tagS_TCDPOOLENTRY {
        TCD_LONG     ID ;
        TCD_INT      Usage ;
        TCD_INT      Typ ;
        TCD_INT      Fmttyp ;
        P_TCD_DOUBLE pData ;
  } S_TCDPOOLENTRY ;

  typedef S_TCDPOOLENTRY * P_TCDPOOLENTRY ;

  typedef struct tagS_TCDPOOLADMIN {
        TCD_INT          Anzahl  ;
        TCD_INT          AnzTabs ;
        TCD_INT          AnzProcs ;
        TCD_INT          AnzTemp  ;
        S_TCDPOOLENTRY * Data    ;
 } S_TCDPOOLADMIN ;

  typedef S_TCDPOOLADMIN * P_TCDPOOLADMIN ;

/*------
  Datenstruktur Kontrollstruktur
--------*/
  typedef struct tagS_TCDRBSINFO {
       char TcdVersion [TCD_DATUM_LNG]   ;
       char TcdRelease [TCD_DATUM_LNG]   ;
       char RbsInterf  [TCD_DATUM_LNG]   ;
       TCD_LONG RbsId ;
   } S_TCDRBSINFO ;

   typedef struct tagS_TCDRCINFO {
       TCD_INT   Rc ;
       TCD_INT   Errc ;
       char FormelName [TCD_NAME_LNG] ;
       TCD_INT   FormelNr ;
       char AttrName   [TCD_NAME_LNG] ;
   } S_TCDRCINFO          ;

   typedef S_TCDRCINFO * P_TCDRCINFO ;


   typedef struct tagS_TCDCTLPAR {

/*-
  Opcode:   TCD_OPC_GET_ATTR_VAL, TCD_OPC_SET_ATTR_VAL
--*/
        struct tagS_TCDPARGA {
           TCD_LONG    ProcID;
           TCD_LONG    ID;
           TCD_LONG    TabID;
           TCD_INT     TabIx ;
           U_TCDGVALUE Val ;
           TCD_INT     Typ ;
           TCD_INT     ProcIx;
        }            GA ;

/*-
  Opcode:   TCD_OPC_SET_POOLTAB
--*/
        struct tagS_TCDPARST {
            TCD_LONG  ID;
            TCD_INT   Dim ;
            P_TCDTAB  pTab ;
            TCD_INT    TabIx ;
        }            ST ;

/*-
  Opcode:   TCD_OPC_RESET_POOLTAB
--*/
        struct tagS_TCDPARRT{
            TCD_LONG  ID;
            P_TCDTAB  pTab ;
        }            RT ;

/*-
  Opcode:   TCD_OPC_SET_PRC
--*/
        struct tagS_TCDPARSP {
            TCD_LONG      ProcID;
            P_TCDPRCELEM  pProc;
            TCD_INT       ProcIx;
        }            SP;

/*-
  Opcode:   TCD_OPC_RESET_PRC
--*/
        struct tagS_TCDPARRP {
            TCD_LONG  ProcID;
            P_TCDPRCELEM  pProc;
        }            RP;

/*-
  Opcode:   TCD_OPC_CALC_FRM , TCD_OPC_CALC_PRC
--*/
        struct tagS_TCDPARCFP {
            TCD_LONG       FormelNr ;
            TCD_LONG       ProcID;
            TCD_INT        Typ ;
            U_TCDVALUE     Value ;
            TCD_INT        ProcIx;
        }            CFP ;

/*-
  Opcode:   TCD_OPC_GETNUM_FRM
--*/
        struct tagS_TCDPARGF {
            char  Name [TCD_NAME_LNG] ;
            TCD_LONG  FormelNr ;
        }            GF ;

/*-
  Opcode:   TCD_OPC_GET_PRC_INFO
--*/
        struct tagS_TCDPRCBINFO {
            TCD_LONG        ProcID;
            TCD_INT         ProcIx;
            P_TCDPRCELEM    pProcInfo;
            TCD_INT         AnzProcInfo ;
        }            PI ;

/*-
  Opcode:   TCD_OPC_REMOVE_RESULTS,
            TCD_OPC_GET_FIRST_RESULTS_INFO,
            TCD_OPC_GET_NEXT_RESULTS_INFO
--*/
        struct tagS_TCDPAR_RESULTPOOL {
            TCD_LONG        ProcID;
            TCD_LONG        lNumOfResults;
            TCD_INT         bFinished;
        }            RESP ;

   } S_TCDCTLPAR ;

   typedef S_TCDCTLPAR * P_TCDCTLPAR ;

   typedef struct tagS_TCDRBSCTL {
          TCD_INT       Opc     ;
          S_TCDRBSINFO  RbsInfo ;
          S_TCDRCINFO   RCInfo  ;
          S_TCDCTLPAR   Par     ;
  } S_TCDRBSCTL ;

   typedef S_TCDRBSCTL * P_TCDRBSCTL ;

/*------
  Datenstruktur Rechenbausteinschnittstelle
 --------*/
   typedef struct tagS_TCDV_F_FLAGS {
         TCD_BOOL       V_In   ;
         TCD_BOOL       F_In   ;
         TCD_BOOL       V_Comp ;
         TCD_BOOL       V_Use  ;
         TCD_BOOL       F_Use  ;
         TCD_BOOL       V_Miss ;
         TCD_BOOL       F_Miss ;
   } S_TCDV_F_FLAGS ;

   typedef S_TCDV_F_FLAGS * P_TCDV_F_FLAGS ;

   typedef struct tagS_TCDV_FLAGS {
         TCD_BOOL       V_In   ;
         TCD_BOOL       V_Use  ;
         TCD_BOOL       V_Miss ;
   } S_TCDV_FLAGS ;

   typedef S_TCDV_FLAGS   * P_TCDV_FLAGS   ;

   typedef struct tagS_TCDSKAL_DATA
   {
        TCD_DOUBLE      Val    ;
        TCD_LONG        Formel ;
        S_TCDV_F_FLAGS  Flags  ;
   } S_TCDSKAL_DATA ;

   typedef S_TCDSKAL_DATA * P_TCDSKAL_DATA ;

   typedef struct tagS_TCDTAB1_DATA
   {
     TCD_LONG        TabID;
     P_TCDTAB1       pVal ;
     TCD_LONG        Formel ;
     S_TCDV_F_FLAGS  Flags ;

   } S_TCDTAB1_DATA ;
   typedef S_TCDTAB1_DATA  * P_TCDTAB1_DATA  ;

   typedef struct tagS_TCDTAB2_DATA
   {
     TCD_LONG        TabID;
     P_TCDTAB2       pVal ;
     TCD_LONG        Formel ;
     S_TCDV_F_FLAGS  Flags ;

   } S_TCDTAB2_DATA ;
   typedef S_TCDTAB2_DATA * P_TCDTAB2_DATA ;

   typedef struct tagS_TCDDAT_DATA {
        char             Val [TCD_DATUM_LNG] ;
        S_TCDV_FLAGS     Flags ;
   } S_TCDDAT_DATA ;

   typedef S_TCDDAT_DATA * P_TCDDAT_DATA ;

   typedef struct tagS_TCDVGL_DATA {
        char            Val [TCD_VGLOP_LNG] ;
        S_TCDV_FLAGS    Flags ;
   } S_TCDVGL_DATA ;

   typedef S_TCDVGL_DATA * P_TCDVGL_DATA ;

   typedef struct tagS_TCD_RBS_SSA
   {
        P_TCDSKAL_DATA    pSkal ;
        P_TCDTAB1_DATA    pTab1 ;
        P_TCDTAB2_DATA    pTab2 ;
        P_TCDDAT_DATA     pDat  ;
        P_TCDVGL_DATA     pVgl  ;
   } S_TCD_RBS_SSA ;

   typedef S_TCD_RBS_SSA  * P_TCD_RBS_SSA ;


   typedef struct tagS_TCDRBS_SS {
       S_TCDRBSCTL       RCTL ;
       S_TCD_RBS_SSA     SSAData   ;
       S_TCDPOOLADMIN    PoolAdmin ;
       S_TCDMPRCADMIN    MPrcAdmin ;
 } S_TCDRBS_SS ;

 typedef S_TCDRBS_SS  * P_TCDRBS_SS ;

  typedef struct tagS_TCDPARATTR_SK {
        TCD_INT      Level ;
        TCD_DOUBLE   Val ;
 } S_TCDPARATTR_SK   ;

 typedef S_TCDPARATTR_SK  * P_TCDPARATTR_SK ;

  typedef struct tagS_TCDPARATTR_VGL {
        TCD_INT      Level;
        char         Val  [TCD_VGLOP_LNG] ;
 } S_TCDPARATTR_VGL  ;

 typedef S_TCDPARATTR_VGL * P_TCDPARATTR_VGL ;

  typedef struct tagS_TCDPARATTR_DAT
  {
        TCD_INT      Level;
        char         Val  [TCD_DATUM_LNG] ;
 } S_TCDPARATTR_DAT  ;

 typedef S_TCDPARATTR_DAT * P_TCDPARATTR_DAT ;

/*-----------
  Struktur Schnittstellendaten (interne Sicht)
-----------*/
  typedef struct tagS_TCDISSADATA
  {
     TCD_INT      AnzSSASkal ;
     TCD_INT      AnzSSATab1 ;
     TCD_INT      AnzSSATab2 ;
     TCD_INT      AnzSSADat ;
     TCD_INT      AnzSSAVgl ;
     TCD_INT      AnzParSkal;
     TCD_INT      AnzParVgl ;
     TCD_INT      AnzParDat ;
     TCD_INT      AnzZeilen ;
     TCD_INT      AnzSpalten ;
     P_TCDSKAL_DATA    pSkal ;
     P_TCDTAB1_DATA    pTab1 ;
     P_TCDTAB2_DATA    pTab2 ;
     P_TCDDAT_DATA     pDat ;
     P_TCDVGL_DATA     pVgl ;
     P_TCDPARATTR_SK   pParSkal ;
     P_TCDPARATTR_VGL  pParVgl;
     P_TCDPARATTR_DAT  pParDat;

 }   S_TCDISSADATA ;
 typedef S_TCDISSADATA * P_TCDISSADATA ;



/*------
Datenstruktur globale Daten des Rechenbausteins;
diese Datenstruktur enthaelt Informationen und Teilstrukturen, die
in den programmierten Funktionen benoetigt werden.
Initialisierung dieser Daten erfolgt mehrstufig.
- beim Init: globaler Pointer pTCDTCD initialisiert (zeigt auf die Str)
pRbsSS zeigt auf die RBS-Schnittstelle
- bei auspraegungsspez. Opcodes werden die Teilstrukturen fuer die
Auspraegung initialisiert, ...
- bei einer neuen Berechnung werden die internen Aufrufschnittstellen
initialisiert
--------*/
  typedef struct tagS_TCD_C_G
  {
      P_TCDRBS_SS      pRbsSS      ;
      P_TCDPRCELEM     pPrcData    ;
      S_TCDPRCHDR *    pPrcHdr     ;
      P_TCDPRCELEM     pPrcTreeNode;
      P_TCDPRCELEM     pInfo       ;
      P_TCDRELATTR_IMP pRelAttrs   ;
      P_TCDMPRCADMIN   pMPrcAdmin  ;
      P_TCDRBSCTL      pRbsCtl     ;
      S_TCDISSADATA    SSAData     ;
      P_TCDPOOLADMIN   pPoolAdmin  ;
      TCD_INT          GlbVarSet   ;
      TCD_LONG         RBS_ID      ;
      TCD_BOOL         ValFound    ;
      TCD_BOOL         FrmFound    ;
      TCD_BOOL         V_Comp      ;
      TCD_BOOL         PrcChg      ;
      void *           pApplIf     ;
      P_TCDTAB         ResTab      ;
      TCD_DOUBLE       ResSkal     ;
      
      TCD_LONG         LastCalcPrcID;
      LP_VECT          pErgebnisPool;
      TCD_LONG         iBerechnungsNummer;
      TCD_INT          iErgPoolIteratorGl;                       
      P_PAARLISTE      pPaarListeNotToSave;
      
      TCD_BOOL         btrace_open;
      TCD_BOOL         btrace_enabled;
      
/* RWE, 10.06.1997: Neues Datenelement fuer Beobachtung
   der Wiederverwendung (ehemals WatchPol-Funktionalitaet) */
      TCD_BOOL         bProtWV;
      
  }   S_TCD_C_G ;
  typedef S_TCD_C_G   * P_TCD_C_G ;
#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDI_H)
#define TCDI_H
/*--------------
    Name        : TCDI.H

    Beschreibung: Include File intern nur f�r C- Generator
                  wird von den fest programmierten Moduln und
                  generierten Moduln benoetigt
    By          : BEGGI
    Datum       : 22.02.94
    Historie    : BEG   28.11.95   Definition Attributklassen
*--------------*/

/*-------------
  Returncodes FrmRet und ValRet (Definitionen analog Cobol) fuer
  Attributmanager
---------------*/
#define TCD_AIRC_CALLVIAFRM    4

/*-------------
  Definitionen Attributtypen (Aufzaehlungstyp)
---------------*/
#define TCD_ATTYP_TAR_SKAL      1
#define TCD_ATTYP_TAR_TAB1      2
#define TCD_ATTYP_TAR_TAB2      3
#define TCD_ATTYP_TAR_DATE      4
#define TCD_ATTYP_TAR_VGLO      5
#define TCD_ATTYP_BST_SKAL      6
#define TCD_ATTYP_BST_TAB1      7
#define TCD_ATTYP_BST_TAB2      8
#define TCD_ATTYP_BST_DATE      9
#define TCD_ATTYP_BST_VGLO     10

#define TCD_ATTRTYP_SKAL        0
#define TCD_ATTRTYP_TAB1        1
#define TCD_ATTRTYP_TAB2        2
#define TCD_ATTRTYP_DATE        3
#define TCD_ATTRTYP_VGLO        4

/*--------------
  Definitionen Attributklasse
---------------*/
#define TCD_ATTRCLASS_TAR       1
#define TCD_ATTRCLASS_BST       6

/*-------------
  Definitionen Errorcodes
---------------*/
#define TCD_UNKNOWN_OPCODE       1
#define TCD_NO_SPACE_IN_TLIST    2
#define TCD_ERR_GETMEM           3
#define TCD_GETEMPTYENTRY        4
#define TCD_NOPOOLADMIN          5
#define TCD_ILLTABFMT            6
#define TCD_UNK_ASSIGNTYP        7
#define TCD_NO_MPRCADMIN         8
#define TCD_EXPPOOLADMIN         9
#define TCD_NO_MEMORY           10
#define TCD_NO_PRCREF           11
#define TCD_ILLFRM_ID           12
#define TCD_ILLFRM_CMP          13
#define TCD_ERR_INIT_FORMEL     14
#define TCD_FRMGEN_OUT_OF_DATE	15
#define TCD_TRPFMT_OUT_OF_DATE	16

/*----------
  Datenstruktur Freigabeliste  Hilfsvariablentabellen
 ------------*/
  typedef struct tagS_TCDTABLIST    {
         TCD_INT        CallOvw ;
         TCD_LONG       CallerID ;
         TCD_LONG       CallFrmNr ;
         TCD_INT        CallType  ;
         P_TCD_DOUBLE   Adr ;
 } S_TCDTABLIST   ;

 typedef  S_TCDTABLIST  * P_TCDTABLIST  ;

/*----------
  Datenstruktur Formelparameter
 ------------*/
  typedef struct tagS_TCD_C_F1 
  {
     char         * FormelName     ;
     TCD_INT        FrmTyp         ;
     TCD_LONG       FrmNr          ;
     TCD_INT        FrmIx          ;
     char         * AttrName       ;
     TCD_INT        CallType       ;
     TCD_LONG       AttrID         ;
     TCD_INT        AttrTyp        ;
     TCD_INT        AttrIx         ;
     TCD_INT        ParIx          ;
     TCD_INT        Ret            ;
     TCD_INT        ExecCond       ;
     P_TCDPRCNODE   PrcFNode       ;
     P_TCDPRCNODE   pNode          ;
     TCD_INT        MinVarSet      ;
     TCD_INT        BegVarSet      ;
     char         * CmpTime        ;
     TCD_INT        Level          ;
     P_TCD_DOUBLE   pVarSkal       ;
     P_P_TCDTAB     pVarTab        ;
     char         * VarDatVgl      ;
     TCD_INT      * VarIndex       ;
     P_TCDTABLIST   FreeList       ;
     TCD_INT        AnzTabList     ;
     TCD_INT        AnzTabListEnt  ;
     P_TCDPRCNODE   NextFNode      ;
     TCD_INT        NextExecCond   ;
     TCD_INT        NextCallType   ;
     struct tagS_TCD_C_F1 * pPrevLevelInfo ;
     P_TCD_C_G      pTCDTCD ;
  } S_TCD_C_F1 ;

  typedef  S_TCD_C_F1 *   P_TCD_C_F1 ;

  typedef struct tagS_TCDFTAB {
        char          FrmName [TCD_NAME_LNG] ;
        void          (* pFormelFunc ) ( P_TCD_C_F1);
        TCD_LONG      FrmNr      ;
        TCD_INT       FrmTyp     ;
        char          Datum [TCD_FRM_DATUM_LNG] ;
  } S_TCDFTAB     ;

 typedef S_TCDFTAB     * P_TCDFTAB     ;

/* extern P_TCD_C_G pTCDTCD ; */

#endif


/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_POOL_H)
#define TCD_POOL_H
/*---------------------------------------------------------------------
  Datei      : TCD_POOL.h
  Generiert am 16.12.2019 15:07:18
  Historie      : 27.7.95    BEG neuer Prefix fuer Tabellenentry
---------------------------------------------------------------------*/
void    TCDPIT   (P_TCD_C_G);
void    TCDPRP   (P_TCD_C_G) ;
void    TCDPST   (P_TCD_C_G) ;
void    TCDPRT   (P_TCD_C_G) ;
void    TCDPSAT  (P_TCD_C_G) ;
void    TCDPRTA  (P_TCD_C_G) ;
TCD_INT TCDPGF   (P_TCD_C_G,P_TCD_DOUBLE Var, TCD_INT *PIndex) ;

#endif

/*---------------------------------------------------------------------------

(C) Copyright 1993-2002, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------------*/
#if !defined (TCD_ATTR_H)
#define TCD_ATTR_H
/*---------------------------------------------------------------------
  Datei:        TCD_ATTR.H
  Beschreibung: Attributmanager
---------------------------------------------------------------------*/
TCD_INT   TCDAATS (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAATT (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAABS (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAABT (P_TCD_C_F1 pF1) ;
void      TCDAATD (P_TCD_C_F1 pF1) ;
void      TCDAABD (P_TCD_C_F1 pF1) ;
void      TCDAATV (P_TCD_C_F1 pF1) ;
void      TCDAABV (P_TCD_C_F1 pF1) ;
void      TCDAFT  (P_TCD_C_F1 pF1) ;
void      TCDAFBS (P_TCD_C_F1 pF1) ;
void      TCDAFBT (P_TCD_C_F1 pF1) ;

#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_FRT_H)
#define TCD_FRT_H
/*---------------------------------------------------------------------
    Datei:        TCD_FRT.H

Beschreibung: Modul zur allgemeinen Endebehandlung einer Formelfunktion
By:           BEGGI
Datum:        30.03.94
Historie:     BEG    28.11.95  neue Funktion: TCDSetPD
---------------------------------------------------------------------*/
TCD_INT TCDInit (P_TCD_C_F1 pMyPar, TCD_INT FrmNr, char *fctl_cmptime,
				 TCD_LONG VerNr);
void    TCDFtID (P_TCD_C_F1 pMyPar, char * AttrName,
                 TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                 TCD_INT *Var) ;

void    TCDSetPS (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                 TCD_DOUBLE *Var1, TCD_INT *Var2, TCD_DOUBLE Var3) ;
void    TCDSetPV (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                  char *Var1, TCD_INT *Var2, char *Var3) ;
void    TCDSetPD (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                  char *Var1, TCD_INT *Var2, char *Var3) ;

TCD_INT TCDGetTb (P_TCD_C_F1 pMyPar, P_P_TCDTAB Var) ;
void    TCDIniPS (P_TCD_C_G) ;

void    TCDIniFC (P_TCD_C_G) ;
void    TCDIniFU (P_TCD_C_G) ;
void    TCDIniFM (P_TCD_C_G) ;

void    TCDRetSk (P_TCD_C_F1 pMyPar, P_TCD_DOUBLE  VarSkal) ;
void    TCDRetTb (P_TCD_C_F1 pF1, P_P_TCDTAB  VarTab) ;

/*-----------------
  TraceFunktionsprototypen und Trace Makros
-------------------*/
#ifdef TRACEFKT
void _TCD_TRACE( const char * ,const char * ,const char *,P_TCD_C_G );
void _TCD_TRVAL( const char * , int , double *, double,P_TCD_C_G  ) ;

#define TCD_TRACE(pack,func,text, pTCDTCD)  \
            _TCD_TRACE(pack,func,text, pTCDTCD);
#define TCD_TRVAL(text,type,val1,val2, pTCDTCD) \
            _TCD_TRVAL(text,type,val1,val2, pTCDTCD);
#endif

#define C_TRACEFILE        "CTRACE.TCD"

#endif
  
/* RWE, 10.06.1997   */
/*-----------------
  Funktionsprototypen fuer Wiederverwendungsprotokoll
-------------------*/ 
#ifdef PROTWV
void     SetProtWV             (P_TCD_C_G pIf, TCD_BOOL bProtWV);   
  /* ^Dieser Prototyp ist auch in commands.c enthalten! */
TCD_BOOL ProtWVEnabled         (P_TCD_C_G pIf);
void     ProtWV1               (P_TCD_C_F1 pMyPar); 
void     ProtWV2               (P_TCD_C_F1   pMyPar, 
                                P_TCDPRCNODE pNode,
                                P_PAARLISTE  pPaarListe, 
                                TCD_INT      iFlag);
void     ProtWVString          (char *s);
                                
#define C_PROTWVFILE       "CPROTWV.TCD"
#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_IOP_H)
#define TCD_IOP_H

#ifndef SUBSYSTEM
  #define IOP_EXPORT 
#else
  #define IOP_EXPORT
#endif
TCD_DOUBLE IOP_EXPORT   TCDABS     (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDFAK     (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDINT     (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDSIGN    (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDDIV     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDEXP     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDMIN     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDMAX     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDZDAYS   (TCD_INT    datefmt, char *val1, 
                                    char *val2);
TCD_DOUBLE IOP_EXPORT   TCDKDAYS   (TCD_INT    datefmt, char *val1, 
                                    char *val2);
TCD_DOUBLE IOP_EXPORT   TCDRND     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDCUT     (TCD_DOUBLE val1, TCD_DOUBLE val2);


#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_FCTL_H)
#define TCD_FCTL_H
/*---------------------------------------------------------------------
  Modul:   TCD_FCTL.H
  f�r RBS: LifeTemplate
---------------------------------------------------------------------*/

void  LifeTemF(P_TCD_C_G pTCDTCD) ;
void  LifeTem1(P_TCD_C_F1  pF1 ) ;
void    TCD3FES (P_TCD_C_F1 pMyPar, char * AttrName, TCD_INT Ix,
                       TCD_LONG ID, TCD_INT AttrTyp, TCD_INT ParIx,
                       P_TCD_DOUBLE Var) ;
void    TCD3FET (P_TCD_C_F1 pMyPar, char * AttrName, TCD_INT Ix,
                      TCD_LONG ID, TCD_INT AttrTyp, P_P_TCDTAB Var);
void    TCD3FED (P_TCD_C_F1 pMyPar, char * AttrName,
                      TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                      TCD_INT ParIx, char *Var) ;
void    TCD3FEV (P_TCD_C_F1 pMyPar, char * AttrName,
                      TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                      TCD_INT ParIx, char *Var) ;
TCD_INT TCD3FE1 (P_TCD_C_F1 pMyPar, TCD_BOOL option, char * Name,
                      TCD_LONG ID, TCD_INT FrmNr, P_TCD_DOUBLE Var) ;
TCD_INT TCD3FE2 (P_TCD_C_F1 pMyPar, TCD_BOOL option, char * Name,
                      TCD_LONG ID, TCD_INT FrmNr, P_P_TCDTAB  Var) ;

TCD_INT TCDChkFrm     (P_TCD_C_F1,void *);
void    ClearOverwriteStack(P_TCD_C_G pTCDTCD );

void       TCD3FESaveResult(P_TCD_C_F1);

#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_PKF_H)
#define TCD_PKF_H
/*---------------------------------------------------------------------
    Modul:        C:\dev\TCD_DB\template\db\R3FE\C\C3E9\lifet428.h

    Beschreibung: Funktionsprototypen der externen Funktionen der
                  Formelsammlungsdatei
    By:           BEGGI
    Generiert am: 16.12.2019 15:07:19
---------------------------------------------------------------------*/
   
      void LifeT213 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT214 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT215 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT216 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT217 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT218 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT219 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT220 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT221 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT222 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT223 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT224 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT225 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT226 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT227 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT228 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT229 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT230 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT231 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT232 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT233 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT234 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT235 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT236 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT237 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT238 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT239 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT240 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT241 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT242 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT243 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT244 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT245 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT246 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT247 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT248 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT249 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT250 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT251 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT252 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT253 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT254 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT255 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT256 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT257 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT258 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT259 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT260 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT261 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT262 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT263 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT264 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT265 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT266 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT267 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT268 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT269 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT270 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT271 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT272 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT273 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT274 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT275 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT276 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT277 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT278 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT279 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT280 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT281 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT282 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT283 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT284 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT285 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT286 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT287 (P_TCD_C_F1 pMyPar) ;
   

#endif



/*---------------------------------------------------------
   Externe Funktion : LifeT389
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Interpolation
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT389 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_1 = 0;
   TCD_DOUBLE  HV_3 = 0;
   TCD_DOUBLE  HV_4 = 0;
   TCD_DOUBLE  HV_6 = 0;
   TCD_DOUBLE  HV_7 = 0;
   TCD_DOUBLE  HV_8 = 0;
   TCD_DOUBLE  HV_9 = 0;
   TCD_DOUBLE  HV_11 = 0;
   TCD_DOUBLE  HV_13 = 0;
   TCD_DOUBLE  HV_14 = 0;
   TCD_DOUBLE  HV_15 = 0;
   TCD_DOUBLE  HV_16 = 0;
   TCD_DOUBLE  HV_18 = 0;
   TCD_DOUBLE  HV_19 = 0;
   TCD_DOUBLE  HV_20 = 0;
   TCD_DOUBLE  HV_21 = 0;
   TCD_DOUBLE  HV_23 = 0;
   TCD_DOUBLE  HV_24 = 0;
   TCD_DOUBLE  HV_25 = 0;
   TCD_DOUBLE  HV_26 = 0;
   TCD_DOUBLE  HV_27 = 0;
   TCD_DOUBLE  HV_28 = 0;
   TCD_DOUBLE  HV_29 = 0;
   TCD_INT     HV_0 = 0;
   TCD_INT     HV_2 = 0;
   TCD_INT     HV_10 = 0;
   TCD_INT     HV_12 = 0;
   TCD_INT     HV_17 = 0;
   TCD_INT     HV_22 = 0;
   TCD_INT     HV_30 = 0;
   TCD_INT     HV_31 = 0;
   TCD_INT     HV_32 = 0;
   TCD_INT     HV_33 = 0;
   TCD_INT     HV_34 = 0;
   TCD_INT     HV_5 = 0;


   /* Generierung der BeschaffungsFlags: */
      int i_i_WertIpol_IDBeschafft_12 = 0;
   int i_i_WertIpol_ValBeschafft_13 = 0;
   int i_i_WertIpol_ValBeschafft_19 = 0;


   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT389","Begin F_Interpolation",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,389,"12.12.2019 17:29:20",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_4);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT389",
              "Ende F_Interpolation",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_22 = 0;
      HV_30 = 0;
      HV_31 = 0;
      HV_32 = 0;
      HV_33 = 0;
      HV_34 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_2 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_8: 
      if ( HV_1 > HV_3 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_5 = 0;
      HV_4 = HV_5;
      goto l_3 ;
   l_24: 
      if ( HV_30 != 0 ) goto l_37 ;
      if ( HV_0 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_11: 
      HV_6 = TCDINT ( HV_1 ) ;
      HV_30 = 1;
   l_37: 
      if ( HV_31 != 0 ) goto l_31 ;
      if ( HV_0 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_14: 
      HV_7 = HV_1 - HV_6;
      HV_31 = 1;
   l_31: 
      if ( HV_7 > 0 ) goto l_45 ;
      goto l_291 ;
   l_45: 
      if ( HV_33 != 0 ) goto l_52 ;
      if ( HV_2 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_17: 
      HV_8 = TCDINT ( HV_3 ) ;
      HV_33 = 1;
   l_52: 
      if ( HV_0 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_20: 
      if ( HV_8 > HV_1 ) goto l_60 ;
      goto l_168 ;
   l_60: 
      if ( HV_30 != 0 ) goto l_94 ;
      if ( HV_0 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_23: 
      HV_6 = TCDINT ( HV_1 ) ;
      HV_30 = 1;
   l_94: 
      if ( HV_31 != 0 ) goto l_88 ;
      if ( HV_0 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_26: 
      HV_7 = HV_1 - HV_6;
      HV_31 = 1;
   l_88: 
      if ( HV_32 != 0 ) goto l_82 ;
      if ( HV_0 != 0 ) goto l_29 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_29: 
      HV_9 = HV_1 - HV_7;
      HV_32 = 1;
   l_82: 
      if ( HV_34 != 0 ) goto l_73 ;
   TCDSetPS (pMyPar, 1, 88, &HV_11, &HV_10, HV_9);
       if ( !i_i_WertIpol_IDBeschafft_12 &&
       !i_i_WertIpol_ValBeschafft_13 ) {
         if (pMyPar->pTCDTCD->SSAData.pParSkal[107].Level==0) {
            TCDFtID (pMyPar, "i_WertIpol", 19, 309, 1, &HV_12);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_WertIpol_IDBeschafft_12 = 1;
         }
         if ( !i_i_WertIpol_IDBeschafft_12 ) {
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = TCD_RC_OK;
            TCD3FES (pMyPar, "i_WertIpol", 19, 309, 1, 107, &HV_13);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_WertIpol_ValBeschafft_13 = 1;
         }
          if ( !i_i_WertIpol_IDBeschafft_12 &&
          !i_i_WertIpol_ValBeschafft_13 ) goto l_ende;
      }
      if (i_i_WertIpol_IDBeschafft_12) {
         rc = TCD3FE1 (pMyPar, 3, "i_WertIpol", 309, HV_12, &HV_13);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
      }
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 88, &HV_11, &HV_10, HV_9);
      HV_34 = 1;
   l_73: 
      if ( HV_30 != 0 ) goto l_112 ;
      if ( HV_0 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_32: 
      HV_6 = TCDINT ( HV_1 ) ;
      HV_30 = 1;
   l_112: 
      if ( HV_31 != 0 ) goto l_106 ;
      if ( HV_0 != 0 ) goto l_35 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_35: 
      HV_7 = HV_1 - HV_6;
      HV_31 = 1;
   l_106: 
      HV_14 = 1 - HV_7;
      HV_15 = HV_13 * HV_14;
      if ( HV_30 != 0 ) goto l_145 ;
      if ( HV_0 != 0 ) goto l_38 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_38: 
      HV_6 = TCDINT ( HV_1 ) ;
      HV_30 = 1;
   l_145: 
      if ( HV_31 != 0 ) goto l_139 ;
      if ( HV_0 != 0 ) goto l_41 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_41: 
      HV_7 = HV_1 - HV_6;
      HV_31 = 1;
   l_139: 
      if ( HV_32 != 0 ) goto l_133 ;
      if ( HV_0 != 0 ) goto l_44 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_44: 
      HV_9 = HV_1 - HV_7;
      HV_32 = 1;
   l_133: 
      HV_16 = HV_9 + 1;
   TCDSetPS (pMyPar, 1, 88, &HV_18, &HV_17, HV_16);
       if ( !i_i_WertIpol_IDBeschafft_12 &&
       !i_i_WertIpol_ValBeschafft_19 ) {
         if (pMyPar->pTCDTCD->SSAData.pParSkal[107].Level==0) {
            TCDFtID (pMyPar, "i_WertIpol", 19, 309, 1, &HV_12);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_WertIpol_IDBeschafft_12 = 1;
         }
         if ( !i_i_WertIpol_IDBeschafft_12 ) {
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = TCD_RC_OK;
            TCD3FES (pMyPar, "i_WertIpol", 19, 309, 1, 107, &HV_19);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_WertIpol_ValBeschafft_19 = 1;
         }
          if ( !i_i_WertIpol_IDBeschafft_12 &&
          !i_i_WertIpol_ValBeschafft_19 ) goto l_ende;
      }
      if (i_i_WertIpol_IDBeschafft_12) {
         rc = TCD3FE1 (pMyPar, 3, "i_WertIpol", 309, HV_12, &HV_19);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
      }
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 88, &HV_18, &HV_17, HV_16);
      if ( HV_30 != 0 ) goto l_160 ;
      if ( HV_0 != 0 ) goto l_47 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_47: 
      HV_6 = TCDINT ( HV_1 ) ;
      HV_30 = 1;
   l_160: 
      if ( HV_31 != 0 ) goto l_154 ;
      if ( HV_0 != 0 ) goto l_50 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_50: 
      HV_7 = HV_1 - HV_6;
      HV_31 = 1;
   l_154: 
      HV_20 = HV_19 * HV_7;
      HV_21 = HV_15 + HV_20;
      if ( HV_22 != 0 ) goto l_53 ;
      TCD3FES (pMyPar, "i_rnd_IPol", 18, 286, 1, 106, &HV_23);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_22 = 1;
   l_53: 
      HV_24 =   TCDRND ( HV_21, HV_23 ) ;
      HV_4 = HV_24;
      goto l_3 ;
   l_168: 
      if ( HV_33 != 0 ) goto l_178 ;
      if ( HV_2 != 0 ) goto l_56 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_56: 
      HV_8 = TCDINT ( HV_3 ) ;
      HV_33 = 1;
   l_178: 
      if ( HV_8 > 0 ) goto l_186 ;
      goto l_261 ;
   l_186: 
      if ( HV_33 != 0 ) goto l_190 ;
      if ( HV_2 != 0 ) goto l_59 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_59: 
      HV_8 = TCDINT ( HV_3 ) ;
      HV_33 = 1;
   l_190: 
      if ( HV_0 != 0 ) goto l_62 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_62: 
      if ( HV_8 <  HV_1 ) goto l_198 ;
      goto l_261 ;
   l_198: 
      if ( HV_2 != 0 ) goto l_65 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_65: 
      if ( HV_0 != 0 ) goto l_68 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_68: 
      HV_25 = HV_3 - HV_1;
      if ( HV_33 != 0 ) goto l_226 ;
      if ( HV_2 != 0 ) goto l_71 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_71: 
      HV_8 = TCDINT ( HV_3 ) ;
      HV_33 = 1;
   l_226: 
      if ( HV_2 != 0 ) goto l_74 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_74: 
      HV_26 = HV_3 - HV_8;
   if ( HV_26 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_27 = HV_25 / HV_26;
      if ( HV_30 != 0 ) goto l_253 ;
      if ( HV_0 != 0 ) goto l_77 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_77: 
      HV_6 = TCDINT ( HV_1 ) ;
      HV_30 = 1;
   l_253: 
      if ( HV_31 != 0 ) goto l_247 ;
      if ( HV_0 != 0 ) goto l_80 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_80: 
      HV_7 = HV_1 - HV_6;
      HV_31 = 1;
   l_247: 
      if ( HV_32 != 0 ) goto l_241 ;
      if ( HV_0 != 0 ) goto l_83 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_83: 
      HV_9 = HV_1 - HV_7;
      HV_32 = 1;
   l_241: 
      if ( HV_34 != 0 ) goto l_232 ;
   TCDSetPS (pMyPar, 1, 88, &HV_11, &HV_10, HV_9);
       if ( !i_i_WertIpol_IDBeschafft_12 &&
       !i_i_WertIpol_ValBeschafft_13 ) {
         if (pMyPar->pTCDTCD->SSAData.pParSkal[107].Level==0) {
            TCDFtID (pMyPar, "i_WertIpol", 19, 309, 1, &HV_12);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_WertIpol_IDBeschafft_12 = 1;
         }
         if ( !i_i_WertIpol_IDBeschafft_12 ) {
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = TCD_RC_OK;
            TCD3FES (pMyPar, "i_WertIpol", 19, 309, 1, 107, &HV_13);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_WertIpol_ValBeschafft_13 = 1;
         }
          if ( !i_i_WertIpol_IDBeschafft_12 &&
          !i_i_WertIpol_ValBeschafft_13 ) goto l_ende;
      }
      if (i_i_WertIpol_IDBeschafft_12) {
         rc = TCD3FE1 (pMyPar, 3, "i_WertIpol", 309, HV_12, &HV_13);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
      }
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 88, &HV_11, &HV_10, HV_9);
      HV_34 = 1;
   l_232: 
      HV_28 = HV_27 * HV_13;
      if ( HV_22 != 0 ) goto l_86 ;
      TCD3FES (pMyPar, "i_rnd_IPol", 18, 286, 1, 106, &HV_23);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_22 = 1;
   l_86: 
      HV_29 =   TCDRND ( HV_28, HV_23 ) ;
      HV_4 = HV_29;
      goto l_3 ;
   l_261: 
      if ( HV_30 != 0 ) goto l_286 ;
      if ( HV_0 != 0 ) goto l_89 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_89: 
      HV_6 = TCDINT ( HV_1 ) ;
      HV_30 = 1;
   l_286: 
      if ( HV_31 != 0 ) goto l_280 ;
      if ( HV_0 != 0 ) goto l_92 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_92: 
      HV_7 = HV_1 - HV_6;
      HV_31 = 1;
   l_280: 
      if ( HV_32 != 0 ) goto l_274 ;
      if ( HV_0 != 0 ) goto l_95 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_95: 
      HV_9 = HV_1 - HV_7;
      HV_32 = 1;
   l_274: 
      if ( HV_34 != 0 ) goto l_265 ;
   TCDSetPS (pMyPar, 1, 88, &HV_11, &HV_10, HV_9);
       if ( !i_i_WertIpol_IDBeschafft_12 &&
       !i_i_WertIpol_ValBeschafft_13 ) {
         if (pMyPar->pTCDTCD->SSAData.pParSkal[107].Level==0) {
            TCDFtID (pMyPar, "i_WertIpol", 19, 309, 1, &HV_12);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_WertIpol_IDBeschafft_12 = 1;
         }
         if ( !i_i_WertIpol_IDBeschafft_12 ) {
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = TCD_RC_OK;
            TCD3FES (pMyPar, "i_WertIpol", 19, 309, 1, 107, &HV_13);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_WertIpol_ValBeschafft_13 = 1;
         }
          if ( !i_i_WertIpol_IDBeschafft_12 &&
          !i_i_WertIpol_ValBeschafft_13 ) goto l_ende;
      }
      if (i_i_WertIpol_IDBeschafft_12) {
         rc = TCD3FE1 (pMyPar, 3, "i_WertIpol", 309, HV_12, &HV_13);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
      }
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 88, &HV_11, &HV_10, HV_9);
      HV_34 = 1;
   l_265: 
      HV_4 = HV_13;
      goto l_3 ;
   l_291: 
      if ( HV_30 != 0 ) goto l_316 ;
      if ( HV_0 != 0 ) goto l_98 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_98: 
      HV_6 = TCDINT ( HV_1 ) ;
      HV_30 = 1;
   l_316: 
      if ( HV_31 != 0 ) goto l_310 ;
      if ( HV_0 != 0 ) goto l_101 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_101: 
      HV_7 = HV_1 - HV_6;
      HV_31 = 1;
   l_310: 
      if ( HV_32 != 0 ) goto l_304 ;
      if ( HV_0 != 0 ) goto l_104 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_104: 
      HV_9 = HV_1 - HV_7;
      HV_32 = 1;
   l_304: 
      if ( HV_34 != 0 ) goto l_295 ;
   TCDSetPS (pMyPar, 1, 88, &HV_11, &HV_10, HV_9);
       if ( !i_i_WertIpol_IDBeschafft_12 &&
       !i_i_WertIpol_ValBeschafft_13 ) {
         if (pMyPar->pTCDTCD->SSAData.pParSkal[107].Level==0) {
            TCDFtID (pMyPar, "i_WertIpol", 19, 309, 1, &HV_12);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_WertIpol_IDBeschafft_12 = 1;
         }
         if ( !i_i_WertIpol_IDBeschafft_12 ) {
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = TCD_RC_OK;
            TCD3FES (pMyPar, "i_WertIpol", 19, 309, 1, 107, &HV_13);
            if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
             i_i_WertIpol_ValBeschafft_13 = 1;
         }
          if ( !i_i_WertIpol_IDBeschafft_12 &&
          !i_i_WertIpol_ValBeschafft_13 ) goto l_ende;
      }
      if (i_i_WertIpol_IDBeschafft_12) {
         rc = TCD3FE1 (pMyPar, 3, "i_WertIpol", 309, HV_12, &HV_13);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
      }
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 88, &HV_11, &HV_10, HV_9);
      HV_34 = 1;
   l_295: 
      HV_4 = HV_13;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_4);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT389","End F_Interpolation",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Interpolation", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Interpolation", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Interpolation");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT419
   Beschreibung: Die Funktion berechnet die Formel 
                 _Beta
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT419 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 11;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT419","Begin _Beta",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,419,"12.12.2019 17:29:27",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT419",
              "Ende _Beta",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 11;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT419","End _Beta",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_Beta", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_Beta", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_Beta");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT424
   Beschreibung: Die Funktion berechnet die Formel 
                 _aj2
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT424 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 6;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT424","Begin _aj2",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,424,"12.12.2019 17:29:27",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT424",
              "Ende _aj2",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 6;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT424","End _aj2",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_aj2", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_aj2", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_aj2");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT425
   Beschreibung: Die Funktion berechnet die Formel 
                 _Alpha1
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT425 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 8;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT425","Begin _Alpha1",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,425,"12.12.2019 17:29:27",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT425",
              "Ende _Alpha1",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 8;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT425","End _Alpha1",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_Alpha1", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_Alpha1", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_Alpha1");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT439
   Beschreibung: Die Funktion berechnet die Formel 
                 _Gamma2
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT439 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 15;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT439","Begin _Gamma2",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,439,"12.12.2019 17:29:27",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT439",
              "Ende _Gamma2",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 15;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT439","End _Gamma2",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_Gamma2", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_Gamma2", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_Gamma2");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT442
   Beschreibung: Die Funktion berechnet die Formel 
                 _Alpha3
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT442 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 10;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT442","Begin _Alpha3",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,442,"12.12.2019 17:29:27",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT442",
              "Ende _Alpha3",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 10;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT442","End _Alpha3",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_Alpha3", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_Alpha3", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_Alpha3");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT447
   Beschreibung: Die Funktion berechnet die Formel 
                 _aj1
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT447 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 5;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT447","Begin _aj1",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,447,"12.12.2019 17:29:27",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT447",
              "Ende _aj1",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 5;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT447","End _aj1",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_aj1", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_aj1", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_aj1");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT455
   Beschreibung: Die Funktion berechnet die Formel 
                 _Delta
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT455 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 23;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT455","Begin _Delta",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,455,"12.12.2019 17:29:27",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT455",
              "Ende _Delta",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 23;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT455","End _Delta",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_Delta", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_Delta", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_Delta");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT464
   Beschreibung: Die Funktion berechnet die Formel 
                 _Gamma1
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT464 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 12;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT464","Begin _Gamma1",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,464,"12.12.2019 17:29:27",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT464",
              "Ende _Gamma1",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 12;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT464","End _Gamma1",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_Gamma1", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_Gamma1", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_Gamma1");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT467
   Beschreibung: Die Funktion berechnet die Formel 
                 _aj3
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT467 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 7;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT467","Begin _aj3",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,467,"12.12.2019 17:29:27",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT467",
              "Ende _aj3",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 7;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT467","End _aj3",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_aj3", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_aj3", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_aj3");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT468
   Beschreibung: Die Funktion berechnet die Formel 
                 _Alpha2
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT468 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 9;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT468","Begin _Alpha2",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,468,"12.12.2019 17:29:27",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT468",
              "Ende _Alpha2",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 9;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT468","End _Alpha2",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_Alpha2", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_Alpha2", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_Alpha2");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT474
   Beschreibung: Die Funktion berechnet die Formel 
                 _ej
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT474 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 4;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT474","Begin _ej",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,474,"12.12.2019 17:29:27",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT474",
              "Ende _ej",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 4;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT474","End _ej",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_ej", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_ej", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_ej");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT504
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Delta
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT504 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_7 = 0;
      P_TCDTAB2   HV_8;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT504","Begin F_Delta",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,504,"12.12.2019 17:29:27",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT504",
              "Ende F_Delta",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_7 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
      HV_5 = (TCD_INT) ( HV_2) ;
      if ( HV_3 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_Delta", 455, 455, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_3 = 1;
   l_8: 
      HV_6 = (TCD_INT) ( HV_4) ;
      if ( HV_7 != 0 ) goto l_11 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_11: 
      if ( HV_6 < 0 || HV_6 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_0 = HV_8 [ HV_5 * 110 + HV_6 ] ;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT504","End F_Delta",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Delta", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Delta", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Delta");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT512
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Gamma3
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT512 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_11 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_14 = 0;
      TCD_INT     HV_15 = 0;
      P_TCDTAB2   HV_16;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_8 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT512","Begin F_Gamma3",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,512,"12.12.2019 17:29:26",
                       4);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT512",
              "Ende F_Gamma3",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      HV_6 = 0;
      HV_9 = 0;
      HV_11 = 0;
      HV_15 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_RateClass", 30, 347, 1, 118, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 2 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_4 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_8: 
      if ( HV_6 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_11: 
      if ( HV_5 >= HV_7 ) goto l_39 ;
      goto l_54 ;
   l_39: 
      if ( HV_4 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_14: 
      if ( HV_5 > 0 ) goto l_48 ;
      goto l_54 ;
   l_48: 
      HV_8 = 0;
      HV_2 = HV_8;
      goto l_3 ;
   l_54: 
      if ( HV_9 != 0 ) goto l_17 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_10);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_9 = 1;
   l_17: 
      HV_13 = (TCD_INT) ( HV_10) ;
      if ( HV_11 != 0 ) goto l_20 ;
      rc = TCD3FE1 (pMyPar, 2, "_Gamma3", 640, 640, &HV_12);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_11 = 1;
   l_20: 
      HV_14 = (TCD_INT) ( HV_12) ;
      if ( HV_15 != 0 ) goto l_23 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_16);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_15 = 1;
   l_23: 
      if ( HV_14 < 0 || HV_14 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
         1) { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_13 < 0 || HV_13 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_2 = HV_16 [ HV_13 * 110 + HV_14 ] ;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT512","End F_Gamma3",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Gamma3", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Gamma3", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Gamma3");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT524
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Gamma
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT524 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_15 = 0;
      TCD_INT     HV_17 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_19 = 0;
      P_TCDTAB2   HV_20;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_14 = 0;
      TCD_INT     HV_21 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT524","Begin F_Gamma",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,524,"12.12.2019 17:29:26",
                       7);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT524",
              "Ende F_Gamma",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      HV_6 = 0;
      HV_8 = 0;
      HV_10 = 0;
      HV_12 = 0;
      HV_15 = 0;
      HV_19 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_RateClass", 30, 347, 1, 118, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 2 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_4 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_Column", 55, 403, 1, 143, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_8: 
      if ( HV_6 != 0 ) goto l_11 ;
      rc = TCD3FE1 (pMyPar, 2, "_Gamma1", 464, 464, &HV_7);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_6 = 1;
   l_11: 
      if ( HV_5 == HV_7 ) goto l_48 ;
      goto l_39 ;
   l_39: 
      if ( HV_4 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_Column", 55, 403, 1, 143, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_14: 
      if ( HV_8 != 0 ) goto l_17 ;
      rc = TCD3FE1 (pMyPar, 2, "_Gamma2", 439, 439, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_8 = 1;
   l_17: 
      if ( HV_5 == HV_9 ) goto l_48 ;
      goto l_90 ;
   l_48: 
      if ( HV_10 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_20: 
      if ( HV_12 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_23: 
      if ( HV_11 >= HV_13 ) goto l_63 ;
      goto l_78 ;
   l_63: 
      if ( HV_10 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_26: 
      if ( HV_11 > 0 ) goto l_72 ;
      goto l_78 ;
   l_72: 
      HV_14 = 0;
      HV_2 = HV_14;
      goto l_3 ;
   l_78: 
      if ( HV_15 != 0 ) goto l_29 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_16);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_15 = 1;
   l_29: 
      HV_17 = (TCD_INT) ( HV_16) ;
      if ( HV_4 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "i_Column", 55, 403, 1, 143, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_32: 
      HV_18 = (TCD_INT) ( HV_5) ;
      if ( HV_19 != 0 ) goto l_35 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_20);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_19 = 1;
   l_35: 
      if ( HV_18 < 0 || HV_18 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
         1) { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_17 < 0 || HV_17 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_2 = HV_20 [ HV_17 * 110 + HV_18 ] ;
      goto l_3 ;
   l_90: 
      HV_21 = 0;
      HV_2 = HV_21;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT524","End F_Gamma",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Gamma", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Gamma", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Gamma");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT545
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Alpha
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT545 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_DOUBLE  HV_31 = 0;
      TCD_DOUBLE  HV_33 = 0;
      TCD_DOUBLE  HV_36 = 0;
      TCD_DOUBLE  HV_37 = 0;
      TCD_DOUBLE  HV_38 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_15 = 0;
      TCD_INT     HV_16 = 0;
      TCD_INT     HV_17 = 0;
      TCD_INT     HV_19 = 0;
      TCD_INT     HV_22 = 0;
      TCD_INT     HV_25 = 0;
      TCD_INT     HV_27 = 0;
      TCD_INT     HV_30 = 0;
      TCD_INT     HV_32 = 0;
      TCD_INT     HV_35 = 0;
      TCD_INT     HV_40 = 0;
      TCD_INT     HV_41 = 0;
      P_TCDTAB2   HV_18;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_24 = 0;
      TCD_INT     HV_29 = 0;
      TCD_INT     HV_34 = 0;
      TCD_INT     HV_39 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT545","Begin F_Alpha",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,545,"12.12.2019 17:29:26",
                       6);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT545",
              "Ende F_Alpha",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      HV_6 = 0;
      HV_8 = 0;
      HV_10 = 0;
      HV_13 = 0;
      HV_17 = 0;
      HV_19 = 0;
      HV_22 = 0;
      HV_25 = 0;
      HV_27 = 0;
      HV_30 = 0;
      HV_40 = 0;
      HV_41 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_RateClass", 30, 347, 1, 118, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 2 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_4 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_Column", 55, 403, 1, 143, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_8: 
      if ( HV_6 != 0 ) goto l_11 ;
      rc = TCD3FE1 (pMyPar, 2, "_Alpha1", 425, 425, &HV_7);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_6 = 1;
   l_11: 
      if ( HV_5 == HV_7 ) goto l_36 ;
      goto l_72 ;
   l_36: 
      if ( HV_8 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_9);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_8 = 1;
   l_14: 
      if ( HV_10 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_17: 
      if ( HV_9 >= HV_11 ) goto l_48 ;
      goto l_54 ;
   l_48: 
      HV_12 = 0;
      HV_2 = HV_12;
      goto l_3 ;
   l_54: 
      if ( HV_13 != 0 ) goto l_20 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_14);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_13 = 1;
   l_20: 
      HV_15 = (TCD_INT) ( HV_14) ;
      if ( HV_4 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_Column", 55, 403, 1, 143, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_23: 
      HV_16 = (TCD_INT) ( HV_5) ;
      if ( HV_41 != 0 ) goto l_58 ;
      if ( HV_17 != 0 ) goto l_26 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_18);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_17 = 1;
   l_26: 
      if ( HV_19 != 0 ) goto l_29 ;
      rc = TCD3FE1 (pMyPar, 2, "F_CommReductionFact", 636, 636,
         &HV_20);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_19 = 1;
   l_29: 
      if ( HV_16 < 0 || HV_16 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
         1) { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_15 < 0 || HV_15 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_21 = HV_18 [ HV_15 * 110 + HV_16 ]  * HV_20;
      HV_41 = 1;
   l_58: 
      HV_2 = HV_21;
      goto l_3 ;
   l_72: 
      if ( HV_4 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "i_Column", 55, 403, 1, 143, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_32: 
      if ( HV_22 != 0 ) goto l_35 ;
      rc = TCD3FE1 (pMyPar, 2, "_Alpha3", 442, 442, &HV_23);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_22 = 1;
   l_35: 
      if ( HV_5 == HV_23 ) goto l_84 ;
      goto l_132 ;
   l_84: 
      if ( HV_8 != 0 ) goto l_38 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_9);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_8 = 1;
   l_38: 
      if ( HV_10 != 0 ) goto l_41 ;
      TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_41: 
      if ( HV_9 >= HV_11 ) goto l_99 ;
      goto l_114 ;
   l_99: 
      if ( HV_8 != 0 ) goto l_44 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_9);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_8 = 1;
   l_44: 
      if ( HV_9 > 0 ) goto l_108 ;
      goto l_114 ;
   l_108: 
      HV_24 = 0;
      HV_2 = HV_24;
      goto l_3 ;
   l_114: 
      if ( HV_13 != 0 ) goto l_47 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_14);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_13 = 1;
   l_47: 
      HV_15 = (TCD_INT) ( HV_14) ;
      if ( HV_4 != 0 ) goto l_50 ;
      TCD3FES (pMyPar, "i_Column", 55, 403, 1, 143, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_50: 
      HV_16 = (TCD_INT) ( HV_5) ;
      if ( HV_41 != 0 ) goto l_118 ;
      if ( HV_17 != 0 ) goto l_53 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_18);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_17 = 1;
   l_53: 
      if ( HV_19 != 0 ) goto l_56 ;
      rc = TCD3FE1 (pMyPar, 2, "F_CommReductionFact", 636, 636,
         &HV_20);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_19 = 1;
   l_56: 
      if ( HV_16 < 0 || HV_16 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
         1) { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_15 < 0 || HV_15 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_21 = HV_18 [ HV_15 * 110 + HV_16 ]  * HV_20;
      HV_41 = 1;
   l_118: 
      HV_2 = HV_21;
      goto l_3 ;
   l_132: 
      if ( HV_4 != 0 ) goto l_59 ;
      TCD3FES (pMyPar, "i_Column", 55, 403, 1, 143, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_59: 
      if ( HV_25 != 0 ) goto l_62 ;
      rc = TCD3FE1 (pMyPar, 2, "_Alpha2", 468, 468, &HV_26);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_25 = 1;
   l_62: 
      if ( HV_5 == HV_26 ) goto l_144 ;
      goto l_234 ;
   l_144: 
      if ( HV_8 != 0 ) goto l_65 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_9);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_8 = 1;
   l_65: 
      if ( HV_27 != 0 ) goto l_68 ;
      TCD3FES (pMyPar, "i_k", 1, 163, 1, 89, &HV_28);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_27 = 1;
   l_68: 
      if ( HV_9 >= HV_28 ) goto l_162 ;
      goto l_171 ;
   l_162: 
      if ( HV_8 != 0 ) goto l_71 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_9);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_8 = 1;
   l_71: 
      if ( HV_9 > 0 ) goto l_186 ;
      goto l_171 ;
   l_171: 
      if ( HV_13 != 0 ) goto l_74 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_14);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_13 = 1;
   l_74: 
      HV_15 = (TCD_INT) ( HV_14) ;
      if ( HV_4 != 0 ) goto l_77 ;
      TCD3FES (pMyPar, "i_Column", 55, 403, 1, 143, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_77: 
      HV_16 = (TCD_INT) ( HV_5) ;
      if ( HV_17 != 0 ) goto l_80 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_18);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_17 = 1;
   l_80: 
      if ( HV_16 < 0 || HV_16 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
         1) { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_15 < 0 || HV_15 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_18 [ HV_15 * 110 + HV_16 ]  == 0 ) goto l_186 ;
      goto l_192 ;
   l_186: 
      HV_29 = 0;
      HV_2 = HV_29;
      goto l_3 ;
   l_192: 
      if ( HV_13 != 0 ) goto l_83 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_14);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_13 = 1;
   l_83: 
      HV_15 = (TCD_INT) ( HV_14) ;
      if ( HV_4 != 0 ) goto l_86 ;
      TCD3FES (pMyPar, "i_Column", 55, 403, 1, 143, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_86: 
      HV_16 = (TCD_INT) ( HV_5) ;
      if ( HV_41 != 0 ) goto l_199 ;
      if ( HV_17 != 0 ) goto l_89 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_18);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_17 = 1;
   l_89: 
      if ( HV_19 != 0 ) goto l_92 ;
      rc = TCD3FE1 (pMyPar, 2, "F_CommReductionFact", 636, 636,
         &HV_20);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_19 = 1;
   l_92: 
      if ( HV_16 < 0 || HV_16 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
         1) { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_15 < 0 || HV_15 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_21 = HV_18 [ HV_15 * 110 + HV_16 ]  * HV_20;
      HV_41 = 1;
   l_199: 
      if ( HV_30 != 0 ) goto l_95 ;
      rc = TCD3FE1 (pMyPar, 2, "F_k", 373, 373, &HV_31);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_30 = 1;
   l_95: 
   TCDSetPS (pMyPar, 1, 93, &HV_33, &HV_32, HV_31);
   TCDSetPS (pMyPar, 1, 88, &HV_36, &HV_35, HV_34);
      rc = TCD3FE1 (pMyPar, 4, "F_aePV", 316, 316, &HV_37);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 88, &HV_36, &HV_35, HV_34);
   TCDSetPS (pMyPar, 0, 93, &HV_33, &HV_32, HV_34);
   if ( HV_37 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_38 = HV_21 / HV_37;
      HV_2 = HV_38;
      goto l_3 ;
   l_234: 
      HV_39 = 0;
      HV_2 = HV_39;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT545","End F_Alpha",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Alpha", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Alpha", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Alpha");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT551
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Beta
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT551 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_11 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_14 = 0;
      TCD_INT     HV_15 = 0;
      P_TCDTAB2   HV_16;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_8 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT551","Begin F_Beta",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,551,"12.12.2019 17:29:26",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT551",
              "Ende F_Beta",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      HV_6 = 0;
      HV_9 = 0;
      HV_11 = 0;
      HV_15 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_RateClass", 30, 347, 1, 118, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 2 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_4 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_8: 
      if ( HV_6 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_m", 4, 166, 1, 92, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_11: 
      if ( HV_5 >= HV_7 ) goto l_39 ;
      goto l_54 ;
   l_39: 
      if ( HV_4 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_14: 
      if ( HV_5 > 0 ) goto l_48 ;
      goto l_54 ;
   l_48: 
      HV_8 = 0;
      HV_2 = HV_8;
      goto l_3 ;
   l_54: 
      if ( HV_9 != 0 ) goto l_17 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_10);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_9 = 1;
   l_17: 
      HV_13 = (TCD_INT) ( HV_10) ;
      if ( HV_11 != 0 ) goto l_20 ;
      rc = TCD3FE1 (pMyPar, 2, "_Beta", 419, 419, &HV_12);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_11 = 1;
   l_20: 
      HV_14 = (TCD_INT) ( HV_12) ;
      if ( HV_15 != 0 ) goto l_23 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_16);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_15 = 1;
   l_23: 
      if ( HV_14 < 0 || HV_14 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
         1) { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_13 < 0 || HV_13 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_2 = HV_16 [ HV_13 * 110 + HV_14 ] ;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT551","End F_Beta",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Beta", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Beta", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Beta");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT553
   Beschreibung: Die Funktion berechnet die Formel 
                 F_DifYears
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT553 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_8 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT553","Begin F_DifYears",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,553,"12.12.2019 17:29:22",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT553",
              "Ende F_DifYears",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_6 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_date_to", 27, 327, 1, 115, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
   TCDSetPS (pMyPar, 1, 116, &HV_4, &HV_3, HV_2);
      rc = TCD3FE1 (pMyPar, 4, "F_Year", 554, 554, &HV_5);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_4, &HV_3, HV_2);
      if ( HV_6 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_date_from", 29, 329, 1, 117, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_8: 
   TCDSetPS (pMyPar, 1, 116, &HV_9, &HV_8, HV_7);
      rc = TCD3FE1 (pMyPar, 4, "F_Year", 554, 554, &HV_10);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_9, &HV_8, HV_7);
      HV_11 = HV_5 - HV_10;
      HV_12 =   TCDRND ( HV_11, 0 ) ;
      HV_0 = HV_12;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT553","End F_DifYears",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_DifYears", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_DifYears", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_DifYears");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT554
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Year
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT554 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT554","Begin F_Year",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,554,"12.12.2019 17:29:22",
                       4);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT554",
              "Ende F_Year",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_date", 28, 328, 1, 116, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
   if ( 10000 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_3 = HV_2 / 10000;
      HV_4 =   TCDRND ( HV_3, 4 ) ;
      if ( HV_1 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_date", 28, 328, 1, 116, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_8: 
   if ( 10000 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_5 = HV_2 / 10000;
      HV_6 =   TCDRND ( HV_5, 4 ) ;
      HV_7 = TCDINT ( HV_6 ) ;
      HV_8 = HV_4 - HV_7;
      HV_9 = 10000 * HV_8;
      HV_10 =   TCDRND ( HV_9, 0 ) ;
      HV_0 = HV_10;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT554","End F_Year",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Year", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Year", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Year");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT575
   Beschreibung: Die Funktion berechnet die Formel 
                 F_delta_Years
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT575 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT575","Begin F_delta_Years",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,575,"12.12.2019 17:29:22",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT575",
              "Ende F_delta_Years",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Years", 576, 576, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
      HV_3 = TCDMAX ( 0, HV_2 ) ;
      HV_0 = HV_3;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT575","End F_delta_Years",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_delta_Years", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_delta_Years", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_delta_Years");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT576
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Years
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT576 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT576","Begin F_Years",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,576,"12.12.2019 17:29:22",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT576",
              "Ende F_Years",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Months", 577, 577, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
   if ( 12 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_3 = HV_2 / 12;
      HV_4 =   TCDRND ( HV_3, 6 ) ;
      HV_0 = HV_4;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT576","End F_Years",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Years", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Years", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Years");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT577
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Months
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT577 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_17 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT577","Begin F_Months",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,577,"12.12.2019 17:29:22",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT577",
              "Ende F_Months",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_6 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_date_to", 27, 327, 1, 115, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
   TCDSetPS (pMyPar, 1, 116, &HV_4, &HV_3, HV_2);
      rc = TCD3FE1 (pMyPar, 4, "F_Year", 554, 554, &HV_5);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_4, &HV_3, HV_2);
      if ( HV_6 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_date_from", 29, 329, 1, 117, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_8: 
   TCDSetPS (pMyPar, 1, 116, &HV_9, &HV_8, HV_7);
      rc = TCD3FE1 (pMyPar, 4, "F_Year", 554, 554, &HV_10);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_9, &HV_8, HV_7);
      HV_11 = HV_5 - HV_10;
      HV_12 = 12 * HV_11;
      if ( HV_1 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_date_to", 27, 327, 1, 115, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_11: 
   TCDSetPS (pMyPar, 1, 116, &HV_14, &HV_13, HV_2);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_15);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_14, &HV_13, HV_2);
      HV_16 = HV_12 + HV_15;
      if ( HV_6 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_date_from", 29, 329, 1, 117, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_14: 
   TCDSetPS (pMyPar, 1, 116, &HV_18, &HV_17, HV_7);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_19);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_18, &HV_17, HV_7);
      HV_20 = HV_16 - HV_19;
      HV_21 =   TCDRND ( HV_20, 6 ) ;
      HV_0 = HV_21;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT577","End F_Months",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Months", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Months", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Months");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT578
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Month
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT578 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT578","Begin F_Month",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,578,"12.12.2019 17:29:21",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT578",
              "Ende F_Month",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_date", 28, 328, 1, 116, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
   if ( 10000 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_3 = HV_2 / 10000;
      HV_4 = TCDINT ( HV_3 ) ;
   if ( 100 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_5 = HV_4 / 100;
      if ( HV_1 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_date", 28, 328, 1, 116, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_8: 
   if ( 10000 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_6 = HV_2 / 10000;
      HV_7 = TCDINT ( HV_6 ) ;
   if ( 100 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_8 = HV_7 / 100;
      HV_9 = TCDINT ( HV_8 ) ;
      HV_10 = HV_5 - HV_9;
      HV_11 = 100 * HV_10;
      HV_12 =   TCDRND ( HV_11, 0 ) ;
      HV_0 = HV_12;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT578","End F_Month",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Month", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Month", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Month");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT579
   Beschreibung: Die Funktion berechnet die Formel 
                 F_DDMMYYYY_plus_i_t
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT579 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_11 = 0;
      TCD_INT     HV_20 = 0;
      TCD_INT     HV_21 = 0;
      TCD_INT     HV_22 = 0;
      TCD_INT     HV_23 = 0;
      TCD_INT     HV_24 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT579","Begin F_DDMMYYYY_plus_i_t",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,579,"12.12.2019 17:29:21",
                       6);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_10);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT579",
              "Ende F_DDMMYYYY_plus_i_t",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_11 = 0;
      HV_20 = 0;
      HV_21 = 0;
      HV_22 = 0;
      HV_23 = 0;
      HV_24 = 0;
      if ( HV_20 != 0 ) goto l_34 ;
      if ( HV_2 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_duration", 31, 349, 1, 119, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_5: 
      HV_4 = TCDINT ( HV_3 ) ;
      HV_20 = 1;
   l_34: 
      if ( HV_21 != 0 ) goto l_28 ;
      if ( HV_2 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_duration", 31, 349, 1, 119, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_8: 
      HV_5 = HV_3 - HV_4;
      HV_21 = 1;
   l_28: 
      if ( HV_22 != 0 ) goto l_25 ;
      HV_6 = HV_5 * 12;
      HV_22 = 1;
   l_25: 
      if ( HV_23 != 0 ) goto l_22 ;
      HV_7 =   TCDRND ( HV_6, 0 ) ;
      HV_23 = 1;
   l_22: 
      if ( HV_0 != 0 ) goto l_11 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Month", 578, 578, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_11: 
      HV_8 = HV_1 + HV_7;
      HV_9 =   TCDRND ( HV_8, 0 ) ;
      if ( HV_9 > 12 ) goto l_51 ;
      goto l_111 ;
   l_51: 
      if ( HV_20 != 0 ) goto l_67 ;
      if ( HV_2 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_duration", 31, 349, 1, 119, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_14: 
      HV_4 = TCDINT ( HV_3 ) ;
      HV_20 = 1;
   l_67: 
      if ( HV_24 != 0 ) goto l_61 ;
      if ( HV_11 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_date", 28, 328, 1, 116, &HV_12);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_11 = 1;
   l_17: 
      HV_13 = HV_12 + HV_4;
      HV_24 = 1;
   l_61: 
      HV_14 = HV_13 + 1;
      if ( HV_20 != 0 ) goto l_94 ;
      if ( HV_2 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_duration", 31, 349, 1, 119, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_20: 
      HV_4 = TCDINT ( HV_3 ) ;
      HV_20 = 1;
   l_94: 
      if ( HV_21 != 0 ) goto l_88 ;
      if ( HV_2 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_duration", 31, 349, 1, 119, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_23: 
      HV_5 = HV_3 - HV_4;
      HV_21 = 1;
   l_88: 
      if ( HV_22 != 0 ) goto l_85 ;
      HV_6 = HV_5 * 12;
      HV_22 = 1;
   l_85: 
      if ( HV_23 != 0 ) goto l_82 ;
      HV_7 =   TCDRND ( HV_6, 0 ) ;
      HV_23 = 1;
   l_82: 
      HV_15 = HV_7 - 12;
      HV_16 = HV_15 * 10000;
      HV_17 = HV_14 + HV_16;
      HV_10 = HV_17;
      goto l_3 ;
   l_111: 
      if ( HV_20 != 0 ) goto l_124 ;
      if ( HV_2 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_duration", 31, 349, 1, 119, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_26: 
      HV_4 = TCDINT ( HV_3 ) ;
      HV_20 = 1;
   l_124: 
      if ( HV_24 != 0 ) goto l_118 ;
      if ( HV_11 != 0 ) goto l_29 ;
      TCD3FES (pMyPar, "i_date", 28, 328, 1, 116, &HV_12);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_11 = 1;
   l_29: 
      HV_13 = HV_12 + HV_4;
      HV_24 = 1;
   l_118: 
      if ( HV_20 != 0 ) goto l_145 ;
      if ( HV_2 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "i_duration", 31, 349, 1, 119, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_32: 
      HV_4 = TCDINT ( HV_3 ) ;
      HV_20 = 1;
   l_145: 
      if ( HV_21 != 0 ) goto l_139 ;
      if ( HV_2 != 0 ) goto l_35 ;
      TCD3FES (pMyPar, "i_duration", 31, 349, 1, 119, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_35: 
      HV_5 = HV_3 - HV_4;
      HV_21 = 1;
   l_139: 
      if ( HV_22 != 0 ) goto l_136 ;
      HV_6 = HV_5 * 12;
      HV_22 = 1;
   l_136: 
      if ( HV_23 != 0 ) goto l_133 ;
      HV_7 =   TCDRND ( HV_6, 0 ) ;
      HV_23 = 1;
   l_133: 
      HV_18 = HV_7 * 10000;
      HV_19 = HV_13 + HV_18;
      HV_10 = HV_19;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_10);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT579","End F_DDMMYYYY_plus_i_t",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_DDMMYYYY_plus_i_t", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_DDMMYYYY_plus_i_t", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_DDMMYYYY_plus_i_t");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT580
   Beschreibung: Die Funktion berechnet die Formel 
                 F_DDMMYYYY
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT580 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT580","Begin F_DDMMYYYY",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,580,"12.12.2019 17:29:21",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT580",
              "Ende F_DDMMYYYY",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_date_yyyymmdd", 32, 350, 1, 120, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
   if ( 100 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_3 = HV_2 / 100;
      HV_4 =   TCDRND ( HV_3, 2 ) ;
      if ( HV_1 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_date_yyyymmdd", 32, 350, 1, 120, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_8: 
   if ( 100 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_5 = HV_2 / 100;
      HV_6 = TCDINT ( HV_5 ) ;
      HV_7 = HV_4 - HV_6;
      HV_8 = HV_7 * 100;
      HV_9 = HV_8 * 1000000;
      if ( HV_1 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_date_yyyymmdd", 32, 350, 1, 120, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_11: 
   if ( 10000 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_10 = HV_2 / 10000;
      HV_11 =   TCDRND ( HV_10, 4 ) ;
      if ( HV_1 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_date_yyyymmdd", 32, 350, 1, 120, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_14: 
   if ( 10000 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_12 = HV_2 / 10000;
      HV_13 = TCDINT ( HV_12 ) ;
      HV_14 = HV_11 - HV_13;
      HV_15 = HV_14 * 100;
      HV_16 = TCDINT ( HV_15 ) ;
      HV_17 = HV_16 * 10000;
      HV_18 = HV_9 + HV_17;
      if ( HV_1 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_date_yyyymmdd", 32, 350, 1, 120, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_17: 
   if ( 10000 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_19 = HV_2 / 10000;
      HV_20 = TCDINT ( HV_19 ) ;
      HV_21 = HV_18 + HV_20;
      HV_22 =   TCDRND ( HV_21, 0 ) ;
      HV_0 = HV_22;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT580","End F_DDMMYYYY",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_DDMMYYYY", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_DDMMYYYY", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_DDMMYYYY");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT582
   Beschreibung: Die Funktion berechnet die Formel 
                 F_YYYYMMDD
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT582 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_8 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT582","Begin F_YYYYMMDD",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,582,"12.12.2019 17:29:21",
                       4);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT582",
              "Ende F_YYYYMMDD",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_4 = 0;
      HV_8 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Year", 554, 554, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
      HV_3 = HV_2 * 10000;
      if ( HV_4 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Month", 578, 578, &HV_5);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_4 = 1;
   l_8: 
      HV_6 = HV_5 * 100;
      HV_7 = HV_3 + HV_6;
      if ( HV_8 != 0 ) goto l_11 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Day", 583, 583, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_8 = 1;
   l_11: 
      HV_10 = HV_7 + HV_9;
      HV_11 =   TCDRND ( HV_10, 0 ) ;
      HV_0 = HV_11;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT582","End F_YYYYMMDD",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_YYYYMMDD", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_YYYYMMDD", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_YYYYMMDD");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT583
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Day
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT583 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT583","Begin F_Day",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,583,"12.12.2019 17:29:21",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT583",
              "Ende F_Day",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_date", 28, 328, 1, 116, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
   if ( 1000000 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_3 = HV_2 / 1000000;
      HV_4 = TCDINT ( HV_3 ) ;
      HV_5 =   TCDRND ( HV_4, 0 ) ;
      HV_0 = HV_5;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT583","End F_Day",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Day", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Day", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Day");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT588
   Beschreibung: Die Funktion berechnet die Formel 
                 _Calc_NonBackOffice
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT588 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 46;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT588","Begin _Calc_NonBackOffice",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,588,"12.12.2019 17:29:27",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT588",
              "Ende _Calc_NonBackOffice",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 46;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT588","End _Calc_NonBackOffice",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_Calc_NonBackOffice", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_Calc_NonBackOffice", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_Calc_NonBackOffice");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT591
   Beschreibung: Die Funktion berechnet die Formel 
                 F_RowIndex
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT591 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_4 = 1;
      TCD_INT     HV_5 = 2;
      TCD_INT     HV_6 = 3;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT591","Begin F_RowIndex",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,591,"12.12.2019 17:29:25",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT591",
              "Ende F_RowIndex",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_tarif_nr", 24, 321, 1, 112, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 12345 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_0 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_tarif_nr", 24, 321, 1, 112, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_8: 
      if ( HV_1 == 30000 ) goto l_36 ;
      goto l_42 ;
   l_36: 
      HV_4 = 1;
      HV_2 = HV_4;
      goto l_3 ;
   l_42: 
      if ( HV_0 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_tarif_nr", 24, 321, 1, 112, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_11: 
      if ( HV_1 == 30100 ) goto l_54 ;
      goto l_60 ;
   l_54: 
      HV_5 = 2;
      HV_2 = HV_5;
      goto l_3 ;
   l_60: 
      if ( HV_0 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_tarif_nr", 24, 321, 1, 112, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_14: 
      if ( HV_1 >= 50000 ) goto l_75 ;
   pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 15;
   goto l_ende ;
   l_75: 
      if ( HV_0 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_tarif_nr", 24, 321, 1, 112, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_17: 
      if ( HV_1 <  60000 ) goto l_84 ;
   pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 15;
   goto l_ende ;
   l_84: 
      HV_6 = 3;
      HV_2 = HV_6;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT591","End F_RowIndex",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_RowIndex", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_RowIndex", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_RowIndex");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT596
   Beschreibung: Die Funktion berechnet die Formel 
                 _Has_Factor_Demise
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT596 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 47;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT596","Begin _Has_Factor_Demise",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,596,"12.12.2019 17:29:27",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT596",
              "Ende _Has_Factor_Demise",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 47;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT596","End _Has_Factor_Demise",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_Has_Factor_Demise", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_Has_Factor_Demise", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_Has_Factor_Demise");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT597
   Beschreibung: Die Funktion berechnet die Formel 
                 _Has_Decrea_SumIns
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT597 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 58;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT597","Begin _Has_Decrea_SumIns",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,597,"12.12.2019 17:29:27",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT597",
              "Ende _Has_Decrea_SumIns",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 58;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT597","End _Has_Decrea_SumIns",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_Has_Decrea_SumIns", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_Has_Decrea_SumIns", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_Has_Decrea_SumIns");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT598
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Is_TermFix
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT598 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_7 = 0;
      P_TCDTAB2   HV_8;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT598","Begin F_Is_TermFix",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,598,"12.12.2019 17:29:25",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT598",
              "Ende F_Is_TermFix",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_7 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
      HV_5 = (TCD_INT) ( HV_2) ;
      if ( HV_3 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_Is_TermFix", 599, 599, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_3 = 1;
   l_8: 
      HV_6 = (TCD_INT) ( HV_4) ;
      if ( HV_7 != 0 ) goto l_11 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_11: 
      if ( HV_6 < 0 || HV_6 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_0 = HV_8 [ HV_5 * 110 + HV_6 ] ;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT598","End F_Is_TermFix",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Is_TermFix", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Is_TermFix", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Is_TermFix");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT599
   Beschreibung: Die Funktion berechnet die Formel 
                 _Is_TermFix
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT599 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 64;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT599","Begin _Is_TermFix",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,599,"12.12.2019 17:29:28",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT599",
              "Ende _Is_TermFix",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 64;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT599","End _Is_TermFix",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_Is_TermFix", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_Is_TermFix", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_Is_TermFix");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT626
   Beschreibung: Die Funktion berechnet die Formel 
                 F_FlagOCDisBenefit
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT626 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_7 = 0;
      P_TCDTAB2   HV_8;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT626","Begin F_FlagOCDisBenefit",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,626,"12.12.2019 17:29:25",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT626",
              "Ende F_FlagOCDisBenefit",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_7 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
      HV_5 = (TCD_INT) ( HV_2) ;
      if ( HV_3 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_OCDisBenefit", 627, 627, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_3 = 1;
   l_8: 
      HV_6 = (TCD_INT) ( HV_4) ;
      if ( HV_7 != 0 ) goto l_11 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_11: 
      if ( HV_6 < 0 || HV_6 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_0 = HV_8 [ HV_5 * 110 + HV_6 ] ;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT626","End F_FlagOCDisBenefit",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_FlagOCDisBenefit", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_FlagOCDisBenefit", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_FlagOCDisBenefit");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT627
   Beschreibung: Die Funktion berechnet die Formel 
                 _OCDisBenefit
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT627 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 37;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT627","Begin _OCDisBenefit",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,627,"12.12.2019 17:29:28",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT627",
              "Ende _OCDisBenefit",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 37;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT627","End _OCDisBenefit",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_OCDisBenefit", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_OCDisBenefit", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_OCDisBenefit");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT629
   Beschreibung: Die Funktion berechnet die Formel 
                 F_year_plus_x
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT629 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_10 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT629","Begin F_year_plus_x",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,629,"12.12.2019 17:29:21",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT629",
              "Ende F_year_plus_x",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_4 = 0;
      HV_8 = 0;
      HV_10 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Day", 583, 583, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
      HV_3 = HV_2 * 1000000;
      if ( HV_4 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Month", 578, 578, &HV_5);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_4 = 1;
   l_8: 
      HV_6 = HV_5 * 10000;
      HV_7 = HV_3 + HV_6;
      if ( HV_8 != 0 ) goto l_11 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Year", 554, 554, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_8 = 1;
   l_11: 
      if ( HV_10 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_plus_x", 23, 318, 1, 111, &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_14: 
      HV_12 = HV_9 + HV_11;
      HV_13 = HV_7 + HV_12;
      HV_0 = HV_13;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT629","End F_year_plus_x",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_year_plus_x", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_year_plus_x", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_year_plus_x");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT630
   Beschreibung: Die Funktion berechnet die Formel 
                 F_INT_From_Year
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT630 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT630","Begin F_INT_From_Year",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,630,"12.12.2019 17:29:21",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT630",
              "Ende F_INT_From_Year",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Months", 577, 577, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
   if ( 12 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_3 = HV_2 / 12;
      HV_4 =   TCDRND ( HV_3, 0 ) ;
      HV_0 = HV_4;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT630","End F_INT_From_Year",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_INT_From_Year", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_INT_From_Year", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_INT_From_Year");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT639
   Beschreibung: Die Funktion berechnet die Formel 
                 _FirstYieldAlloc
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT639 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 63;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT639","Begin _FirstYieldAlloc",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,639,"12.12.2019 17:29:28",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT639",
              "Ende _FirstYieldAlloc",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 63;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT639","End _FirstYieldAlloc",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_FirstYieldAlloc", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_FirstYieldAlloc", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_FirstYieldAlloc");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT640
   Beschreibung: Die Funktion berechnet die Formel 
                 _Gamma3
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT640 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 13;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT640","Begin _Gamma3",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,640,"12.12.2019 17:29:28",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT640",
              "Ende _Gamma3",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 13;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT640","End _Gamma3",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_Gamma3", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_Gamma3", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_Gamma3");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT641
   Beschreibung: Die Funktion berechnet die Formel 
                 _Offset_Mortality
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT641 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 26;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT641","Begin _Offset_Mortality",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,641,"12.12.2019 17:29:28",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT641",
              "Ende _Offset_Mortality",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 26;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT641","End _Offset_Mortality",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_Offset_Mortality", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_Offset_Mortality", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_Offset_Mortality");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT642
   Beschreibung: Die Funktion berechnet die Formel 
                 _wo_examination
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT642 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 43;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT642","Begin _wo_examination",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,642,"12.12.2019 17:29:28",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT642",
              "Ende _wo_examination",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 43;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT642","End _wo_examination",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_wo_examination", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_wo_examination", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_wo_examination");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT643
   Beschreibung: Die Funktion berechnet die Formel 
                 _MinPremFreeSum
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT643 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 34;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT643","Begin _MinPremFreeSum",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,643,"12.12.2019 17:29:28",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT643",
              "Ende _MinPremFreeSum",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 34;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT643","End _MinPremFreeSum",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_MinPremFreeSum", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_MinPremFreeSum", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_MinPremFreeSum");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT644
   Beschreibung: Die Funktion berechnet die Formel 
                 _MinSurrenderValue
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT644 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 69;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT644","Begin _MinSurrenderValue",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,644,"12.12.2019 17:29:28",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT644",
              "Ende _MinSurrenderValue",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 69;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT644","End _MinSurrenderValue",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_MinSurrenderValue", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_MinSurrenderValue", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_MinSurrenderValue");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT645
   Beschreibung: Die Funktion berechnet die Formel 
                 _Alpha_Distribution
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT645 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 33;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT645","Begin _Alpha_Distribution",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,645,"12.12.2019 17:29:28",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT645",
              "Ende _Alpha_Distribution",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 33;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT645","End _Alpha_Distribution",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_Alpha_Distribution", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_Alpha_Distribution", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_Alpha_Distribution");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT646
   Beschreibung: Die Funktion berechnet die Formel 
                 _lifelong
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT646 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_1 = 9999;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT646","Begin _lifelong",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,646,"12.12.2019 17:29:28",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT646",
              "Ende _lifelong",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 9999;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT646","End _lifelong",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_lifelong", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_lifelong", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_lifelong");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT647
   Beschreibung: Die Funktion berechnet die Formel 
                 _InterestRate
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT647 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT647","Begin _InterestRate",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,647,"12.12.2019 17:29:28",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT647",
              "Ende _InterestRate",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT647","End _InterestRate",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_InterestRate", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_InterestRate", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_InterestRate");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT648
   Beschreibung: Die Funktion berechnet die Formel 
                 _premFree
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT648 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 1;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT648","Begin _premFree",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,648,"12.12.2019 17:29:28",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT648",
              "Ende _premFree",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 1;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT648","End _premFree",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_premFree", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_premFree", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_premFree");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT649
   Beschreibung: Die Funktion berechnet die Formel 
                 _regularPremium
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT649 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT649","Begin _regularPremium",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,649,"12.12.2019 17:29:28",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT649",
              "Ende _regularPremium",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT649","End _regularPremium",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_regularPremium", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_regularPremium", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_regularPremium");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT650
   Beschreibung: Die Funktion berechnet die Formel 
                 _HasSumDiscount
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT650 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 44;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT650","Begin _HasSumDiscount",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,650,"12.12.2019 17:29:28",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT650",
              "Ende _HasSumDiscount",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 44;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT650","End _HasSumDiscount",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_HasSumDiscount", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_HasSumDiscount", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_HasSumDiscount");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT651
   Beschreibung: Die Funktion berechnet die Formel 
                 _CancFac_to
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT651 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 2;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT651","Begin _CancFac_to",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,651,"12.12.2019 17:29:29",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT651",
              "Ende _CancFac_to",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 2;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT651","End _CancFac_to",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_CancFac_to", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_CancFac_to", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_CancFac_to");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT652
   Beschreibung: Die Funktion berechnet die Formel 
                 _CancFac_from
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT652 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 1;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT652","Begin _CancFac_from",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,652,"12.12.2019 17:29:29",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT652",
              "Ende _CancFac_from",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 1;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT652","End _CancFac_from",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_CancFac_from", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_CancFac_from", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_CancFac_from");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT653
   Beschreibung: Die Funktion berechnet die Formel 
                 _SecurityLoading
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT653 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 32;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT653","Begin _SecurityLoading",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,653,"12.12.2019 17:29:29",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT653",
              "Ende _SecurityLoading",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 32;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT653","End _SecurityLoading",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_SecurityLoading", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_SecurityLoading", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_SecurityLoading");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT654
   Beschreibung: Die Funktion berechnet die Formel 
                 _HasAnnuityValue
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT654 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 66;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT654","Begin _HasAnnuityValue",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,654,"12.12.2019 17:29:29",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT654",
              "Ende _HasAnnuityValue",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 66;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT654","End _HasAnnuityValue",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_HasAnnuityValue", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_HasAnnuityValue", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_HasAnnuityValue");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT655
   Beschreibung: Die Funktion berechnet die Formel 
                 _RecurringComm
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT655 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 48;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT655","Begin _RecurringComm",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,655,"12.12.2019 17:29:29",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT655",
              "Ende _RecurringComm",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 48;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT655","End _RecurringComm",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_RecurringComm", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_RecurringComm", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_RecurringComm");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT656
   Beschreibung: Die Funktion berechnet die Formel 
                 _PremRefund
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT656 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 65;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT656","Begin _PremRefund",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,656,"12.12.2019 17:29:29",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT656",
              "Ende _PremRefund",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 65;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT656","End _PremRefund",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_PremRefund", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_PremRefund", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_PremRefund");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT657
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Comm_Percentage
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT657 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_10 = 0;
      P_TCDTAB2   HV_11;
      TCD_INT     HV_3 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT657","Begin F_Comm_Percentage",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,657,"12.12.2019 17:29:25",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT657",
              "Ende F_Comm_Percentage",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      HV_6 = 0;
      HV_10 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_RateClass", 30, 347, 1, 118, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 2 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_4 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_5);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_4 = 1;
   l_8: 
      HV_8 = (TCD_INT) ( HV_5) ;
      if ( HV_6 != 0 ) goto l_11 ;
      rc = TCD3FE1 (pMyPar, 2, "_CommPercent", 658, 658, &HV_7);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_6 = 1;
   l_11: 
      HV_9 = (TCD_INT) ( HV_7) ;
      if ( HV_10 != 0 ) goto l_14 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_14: 
      if ( HV_9 < 0 || HV_9 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_8 < 0 || HV_8 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
   if ( 100 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_12 = HV_11 [ HV_8 * 110 + HV_9 ]  / 100;
      HV_2 = HV_12;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT657","End F_Comm_Percentage",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Comm_Percentage", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Comm_Percentage", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Comm_Percentage");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT658
   Beschreibung: Die Funktion berechnet die Formel 
                 _CommPercent
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT658 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 55;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT658","Begin _CommPercent",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,658,"12.12.2019 17:29:29",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT658",
              "Ende _CommPercent",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 55;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT658","End _CommPercent",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_CommPercent", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_CommPercent", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_CommPercent");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT659
   Beschreibung: Die Funktion berechnet die Formel 
                 _CommAddConPercent
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT659 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 56;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT659","Begin _CommAddConPercent",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,659,"12.12.2019 17:29:29",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT659",
              "Ende _CommAddConPercent",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 56;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT659","End _CommAddConPercent",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_CommAddConPercent", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_CommAddConPercent", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_CommAddConPercent");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT660
   Beschreibung: Die Funktion berechnet die Formel 
                 F_CommAddContrib
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT660 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_10 = 0;
      P_TCDTAB2   HV_11;
      TCD_INT     HV_3 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT660","Begin F_CommAddContrib",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,660,"12.12.2019 17:29:25",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT660",
              "Ende F_CommAddContrib",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      HV_6 = 0;
      HV_10 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_RateClass", 30, 347, 1, 118, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 2 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_4 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_5);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_4 = 1;
   l_8: 
      HV_8 = (TCD_INT) ( HV_5) ;
      if ( HV_6 != 0 ) goto l_11 ;
      rc = TCD3FE1 (pMyPar, 2, "_CommAddConPercent", 659, 659, &HV_7);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_6 = 1;
   l_11: 
      HV_9 = (TCD_INT) ( HV_7) ;
      if ( HV_10 != 0 ) goto l_14 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_14: 
      if ( HV_9 < 0 || HV_9 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_8 < 0 || HV_8 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
   if ( 100 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_12 = HV_11 [ HV_8 * 110 + HV_9 ]  / 100;
      HV_2 = HV_12;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT660","End F_CommAddContrib",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_CommAddContrib", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_CommAddContrib", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_CommAddContrib");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT663
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Alpha_Distribution
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT663 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_7 = 0;
      P_TCDTAB2   HV_8;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT663","Begin F_Alpha_Distribution",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,663,"12.12.2019 17:29:25",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT663",
              "Ende F_Alpha_Distribution",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_7 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
      HV_5 = (TCD_INT) ( HV_2) ;
      if ( HV_3 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_Alpha_Distribution", 645, 645,
         &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_3 = 1;
   l_8: 
      HV_6 = (TCD_INT) ( HV_4) ;
      if ( HV_7 != 0 ) goto l_11 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_11: 
      if ( HV_6 < 0 || HV_6 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_0 = HV_8 [ HV_5 * 110 + HV_6 ] ;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT663","End F_Alpha_Distribution",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Alpha_Distribution", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Alpha_Distribution", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Alpha_Distribution");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT671
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Alpha1_Permille
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT671 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_12 = 0;
      P_TCDTAB2   HV_11;
      TCD_INT     HV_3 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT671","Begin F_Alpha1_Permille",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,671,"12.12.2019 17:29:25",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT671",
              "Ende F_Alpha1_Permille",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      HV_6 = 0;
      HV_10 = 0;
      HV_12 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_RateClass", 30, 347, 1, 118, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 2 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_4 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_5);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_4 = 1;
   l_8: 
      HV_8 = (TCD_INT) ( HV_5) ;
      if ( HV_6 != 0 ) goto l_11 ;
      rc = TCD3FE1 (pMyPar, 2, "_Alpha1", 425, 425, &HV_7);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_6 = 1;
   l_11: 
      HV_9 = (TCD_INT) ( HV_7) ;
      if ( HV_10 != 0 ) goto l_14 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_14: 
      if ( HV_12 != 0 ) goto l_17 ;
      rc = TCD3FE1 (pMyPar, 2, "F_CommReductionFact", 636, 636,
         &HV_13);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_12 = 1;
   l_17: 
      if ( HV_9 < 0 || HV_9 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_8 < 0 || HV_8 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_14 = HV_11 [ HV_8 * 110 + HV_9 ]  * HV_13;
      HV_2 = HV_14;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT671","End F_Alpha1_Permille",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Alpha1_Permille", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Alpha1_Permille", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Alpha1_Permille");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT672
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Alpha2_Permille
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT672 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_12 = 0;
      P_TCDTAB2   HV_11;
      TCD_INT     HV_3 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT672","Begin F_Alpha2_Permille",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,672,"12.12.2019 17:29:24",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT672",
              "Ende F_Alpha2_Permille",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      HV_6 = 0;
      HV_10 = 0;
      HV_12 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_RateClass", 30, 347, 1, 118, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 2 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_4 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_5);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_4 = 1;
   l_8: 
      HV_8 = (TCD_INT) ( HV_5) ;
      if ( HV_6 != 0 ) goto l_11 ;
      rc = TCD3FE1 (pMyPar, 2, "_Alpha2", 468, 468, &HV_7);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_6 = 1;
   l_11: 
      HV_9 = (TCD_INT) ( HV_7) ;
      if ( HV_10 != 0 ) goto l_14 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_14: 
      if ( HV_12 != 0 ) goto l_17 ;
      rc = TCD3FE1 (pMyPar, 2, "F_CommReductionFact", 636, 636,
         &HV_13);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_12 = 1;
   l_17: 
      if ( HV_9 < 0 || HV_9 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_8 < 0 || HV_8 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_14 = HV_11 [ HV_8 * 110 + HV_9 ]  * HV_13;
      HV_2 = HV_14;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT672","End F_Alpha2_Permille",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Alpha2_Permille", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Alpha2_Permille", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Alpha2_Permille");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT673
   Beschreibung: Die Funktion berechnet die Formel 
                 F_SecurityLoading
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT673 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_7 = 0;
      P_TCDTAB2   HV_8;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT673","Begin F_SecurityLoading",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,673,"12.12.2019 17:29:24",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT673",
              "Ende F_SecurityLoading",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_7 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
      HV_5 = (TCD_INT) ( HV_2) ;
      if ( HV_3 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_SecurityLoading", 653, 653, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_3 = 1;
   l_8: 
      HV_6 = (TCD_INT) ( HV_4) ;
      if ( HV_7 != 0 ) goto l_11 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_11: 
      if ( HV_6 < 0 || HV_6 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_0 = HV_8 [ HV_5 * 110 + HV_6 ] ;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT673","End F_SecurityLoading",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_SecurityLoading", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_SecurityLoading", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_SecurityLoading");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT682
   Beschreibung: Die Funktion berechnet die Formel 
                 _Accrual
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT682 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_1 = 1;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT682","Begin _Accrual",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,682,"12.12.2019 17:29:29",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT682",
              "Ende _Accrual",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 1;
      HV_0 = HV_1;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT682","End _Accrual",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("_Accrual", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("_Accrual", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "_Accrual");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT686
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Interpol_Surrender
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT686 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_8 = 0;
      P_TCDTAB2   HV_9;
      TCD_INT     HV_11 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT686","Begin F_Interpol_Surrender",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,686,"12.12.2019 17:29:21",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_10);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT686",
              "Ende F_Interpol_Surrender",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_4 = 0;
      HV_8 = 0;
      if ( HV_2 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_5: 
      HV_6 = (TCD_INT) ( HV_3) ;
      if ( HV_4 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_MinSurrenderValue", 644, 644, &HV_5);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_4 = 1;
   l_8: 
      HV_7 = (TCD_INT) ( HV_5) ;
      if ( HV_0 != 0 ) goto l_11 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Interpolation", 389, 389, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_11: 
      if ( HV_8 != 0 ) goto l_14 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_9);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_8 = 1;
   l_14: 
      if ( HV_7 < 0 || HV_7 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_6 < 0 || HV_6 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_1 <  HV_9 [ HV_6 * 110 + HV_7 ]  ) goto l_24 ;
      goto l_30 ;
   l_24: 
      HV_11 = 0;
      HV_10 = HV_11;
      goto l_3 ;
   l_30: 
      if ( HV_0 != 0 ) goto l_17 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Interpolation", 389, 389, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_17: 
      HV_10 = HV_1;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_10);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT686","End F_Interpol_Surrender",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Interpol_Surrender", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Interpol_Surrender", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Interpol_Surrender");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT687
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Interpol_Reduction
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT687 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_8 = 0;
      P_TCDTAB2   HV_9;
      TCD_INT     HV_11 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT687","Begin F_Interpol_Reduction",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,687,"12.12.2019 17:29:21",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_10);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT687",
              "Ende F_Interpol_Reduction",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_4 = 0;
      HV_8 = 0;
      if ( HV_2 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_5: 
      HV_6 = (TCD_INT) ( HV_3) ;
      if ( HV_4 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_MinPremFreeSum", 643, 643, &HV_5);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_4 = 1;
   l_8: 
      HV_7 = (TCD_INT) ( HV_5) ;
      if ( HV_0 != 0 ) goto l_11 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Interpolation", 389, 389, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_11: 
      if ( HV_8 != 0 ) goto l_14 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_9);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_8 = 1;
   l_14: 
      if ( HV_7 < 0 || HV_7 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_6 < 0 || HV_6 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_1 <  HV_9 [ HV_6 * 110 + HV_7 ]  ) goto l_24 ;
      goto l_30 ;
   l_24: 
      HV_11 = 0;
      HV_10 = HV_11;
      goto l_3 ;
   l_30: 
      if ( HV_0 != 0 ) goto l_17 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Interpolation", 389, 389, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_17: 
      HV_10 = HV_1;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_10);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT687","End F_Interpol_Reduction",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Interpol_Reduction", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Interpol_Reduction", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Interpol_Reduction");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT688
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Interest
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT688 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_7 = 0;
      P_TCDTAB2   HV_8;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT688","Begin F_Interest",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,688,"12.12.2019 17:29:24",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT688",
              "Ende F_Interest",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_7 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
      HV_5 = (TCD_INT) ( HV_2) ;
      if ( HV_3 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_InterestRate", 647, 647, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_3 = 1;
   l_8: 
      HV_6 = (TCD_INT) ( HV_4) ;
      if ( HV_7 != 0 ) goto l_11 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_11: 
      if ( HV_6 < 0 || HV_6 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_0 = HV_8 [ HV_5 * 110 + HV_6 ] ;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT688","End F_Interest",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Interest", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Interest", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Interest");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT701
   Beschreibung: Die Funktion berechnet die Formel 
                 F_Alpha_OccDis
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT701 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_11 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_14 = 0;
      TCD_INT     HV_15 = 0;
      TCD_INT     HV_17 = 0;
      P_TCDTAB2   HV_16;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_8 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT701","Begin F_Alpha_OccDis",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,701,"12.12.2019 17:29:24",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT701",
              "Ende F_Alpha_OccDis",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      HV_6 = 0;
      HV_9 = 0;
      HV_11 = 0;
      HV_15 = 0;
      HV_17 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_RateClass", 30, 347, 1, 118, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 2 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_4 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_8: 
      if ( HV_6 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_m", 4, 166, 1, 92, &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_11: 
      if ( HV_5 >= HV_7 ) goto l_39 ;
      goto l_54 ;
   l_39: 
      if ( HV_4 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_j", 20, 311, 1, 108, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_14: 
      if ( HV_5 > 0 ) goto l_48 ;
      goto l_54 ;
   l_48: 
      HV_8 = 0;
      HV_2 = HV_8;
      goto l_3 ;
   l_54: 
      if ( HV_9 != 0 ) goto l_17 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_10);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_9 = 1;
   l_17: 
      HV_13 = (TCD_INT) ( HV_10) ;
      if ( HV_11 != 0 ) goto l_20 ;
      rc = TCD3FE1 (pMyPar, 2, "_Alpha3", 442, 442, &HV_12);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_11 = 1;
   l_20: 
      HV_14 = (TCD_INT) ( HV_12) ;
      if ( HV_15 != 0 ) goto l_23 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_16);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_15 = 1;
   l_23: 
      if ( HV_17 != 0 ) goto l_26 ;
      rc = TCD3FE1 (pMyPar, 2, "F_CommReductionFact", 636, 636,
         &HV_18);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_17 = 1;
   l_26: 
      if ( HV_14 < 0 || HV_14 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
         1) { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_13 < 0 || HV_13 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_19 = HV_16 [ HV_13 * 110 + HV_14 ]  * HV_18;
      HV_2 = HV_19;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT701","End F_Alpha_OccDis",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_Alpha_OccDis", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_Alpha_OccDis", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_Alpha_OccDis");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT733
   Beschreibung: Die Funktion berechnet die Formel 
                 F_WO_Examination
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT733 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_6 = 0;
      P_TCDTAB2   HV_7;
      TCD_DOUBLE  HV_10 = 0.05;
      TCD_INT     HV_9 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT733","Begin F_WO_Examination",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,733,"12.12.2019 17:29:24",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_8);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT733",
              "Ende F_WO_Examination",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_6 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_5: 
      HV_4 = (TCD_INT) ( HV_1) ;
      if ( HV_2 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_wo_examination", 642, 642, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_8: 
      HV_5 = (TCD_INT) ( HV_3) ;
      if ( HV_6 != 0 ) goto l_11 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_11: 
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_4 < 0 || HV_4 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_7 [ HV_4 * 110 + HV_5 ]  == 0 ) goto l_24 ;
      goto l_30 ;
   l_24: 
      HV_9 = 0;
      HV_8 = HV_9;
      goto l_3 ;
   l_30: 
      HV_10 = 0.05;
      HV_8 = HV_10;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_8);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT733","End F_WO_Examination",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_WO_Examination", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_WO_Examination", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_WO_Examination");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT734
   Beschreibung: Die Funktion berechnet die Formel 
                 F_SumDiscount
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT734 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_10 = 0;
      P_TCDTAB2   HV_11;
      TCD_INT     HV_3 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT734","Begin F_SumDiscount",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,734,"12.12.2019 17:29:24",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT734",
              "Ende F_SumDiscount",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      HV_6 = 0;
      HV_10 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_RateClass", 30, 347, 1, 118, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 2 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_4 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_5);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_4 = 1;
   l_8: 
      HV_8 = (TCD_INT) ( HV_5) ;
      if ( HV_6 != 0 ) goto l_11 ;
      rc = TCD3FE1 (pMyPar, 2, "_HasSumDiscount", 650, 650, &HV_7);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_6 = 1;
   l_11: 
      HV_9 = (TCD_INT) ( HV_7) ;
      if ( HV_10 != 0 ) goto l_14 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_11);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_10 = 1;
   l_14: 
      if ( HV_9 < 0 || HV_9 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_8 < 0 || HV_8 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_2 = HV_11 [ HV_8 * 110 + HV_9 ] ;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT734","End F_SumDiscount",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_SumDiscount", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_SumDiscount", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_SumDiscount");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT777
   Beschreibung: Die Funktion berechnet die Formel 
                 F_AC_Original
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT777 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_5 = 0;
      P_TCDTAB1   HV_6;
      TCD_INT     HV_3 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT777","Begin F_AC_Original",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,777,"12.12.2019 17:29:23",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT777",
              "Ende F_AC_Original",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_5 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_RateClass", 30, 347, 1, 118, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 2 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      HV_7 = 0;
      for ( HV_4 = (TCD_INT) (0) ; HV_4 <= 60; HV_4 = HV_4 + 1 ) {
         if ( HV_5 != 0 ) goto l_8 ;
         rc = TCD3FE2 (pMyPar, 2, "F_AC_Layer_Original", 778, 778,
            &HV_6);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_5 = 1;
      l_8: 
         HV_7 = HV_6 [ HV_4 ]  + HV_7;
      }
      HV_8 = TCDMAX ( 0, HV_7 ) ;
      HV_2 = HV_8;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT777","End F_AC_Original",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_AC_Original", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_AC_Original", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_AC_Original");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT778
   Beschreibung: Die Funktion berechnet die Formel 
                 F_AC_Layer_Original
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT778 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_DOUBLE  HV_29 = 0;
      TCD_DOUBLE  HV_30 = 0;
      TCD_DOUBLE  HV_31 = 0;
      TCD_DOUBLE  HV_33 = 0;
      TCD_DOUBLE  HV_35 = 0;
      TCD_DOUBLE  HV_40 = 0;
      TCD_DOUBLE  HV_42 = 0;
      TCD_DOUBLE  HV_43 = 0;
      TCD_DOUBLE  HV_44 = 0;
      TCD_DOUBLE  HV_46 = 0;
      TCD_DOUBLE  HV_47 = 0;
      TCD_DOUBLE  HV_48 = 0;
      TCD_DOUBLE  HV_50 = 0;
      TCD_DOUBLE  HV_51 = 0;
      TCD_DOUBLE  HV_52 = 0;
      TCD_DOUBLE  HV_53 = 0;
      TCD_DOUBLE  HV_54 = 0;
      TCD_DOUBLE  HV_55 = 0;
      TCD_DOUBLE  HV_56 = 0;
      TCD_DOUBLE  HV_58 = 0;
      TCD_DOUBLE  HV_59 = 0;
      TCD_DOUBLE  HV_60 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_15 = 0;
      TCD_INT     HV_19 = 0;
      TCD_INT     HV_24 = 0;
      TCD_INT     HV_28 = 0;
      TCD_INT     HV_32 = 0;
      TCD_INT     HV_34 = 0;
      TCD_INT     HV_36 = 0;
      TCD_INT     HV_37 = 0;
      TCD_INT     HV_38 = 0;
      TCD_INT     HV_41 = 0;
      TCD_INT     HV_45 = 0;
      TCD_INT     HV_49 = 0;
      TCD_INT     HV_57 = 0;
      TCD_INT     HV_62 = 0;
      TCD_INT     HV_63 = 0;
      TCD_INT     HV_64 = 0;
      TCD_INT     HV_65 = 0;
      TCD_INT     HV_66 = 0;
      TCD_INT     HV_67 = 0;
      P_TCDTAB1   HV_4;
      P_TCDTAB2   HV_3;
      P_TCDTAB2   HV_39;
      TCD_INT     HV_1 = 1;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_27 = 2;
      TCD_INT     HV_61 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT778","Begin F_AC_Layer_Original",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,778,"12.12.2019 17:29:23",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Besorgen einer freien Tabelle, falls Formel vom Typ TAB1/TAB2 */
   rc =    TCDGetTb (pMyPar, &HV_4);


   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_4);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT778",
              "Ende F_AC_Layer_Original",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_2 = 0;
      HV_6 = 0;
      HV_10 = 0;
      HV_32 = 0;
      HV_34 = 0;
      HV_38 = 0;
      HV_66 = 0;
      for ( HV_0 = (TCD_INT) (0) ; HV_0 <= 199; HV_0 = HV_0 + 1 ) {
         HV_62 = 0;
         HV_63 = 0;
         HV_64 = 0;
         HV_65 = 0;
         HV_67 = 0;
         if ( HV_0 > 60 ) goto l_18 ;
         goto l_21 ;
      l_18: 
      goto l_ende ;
      l_21: 
         if ( HV_2 != 0 ) goto l_5 ;
         TCD3FET (pMyPar, "AlphaCostMatrix", 1, 393, 8,  (P_TCDTAB *)
            &HV_3);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_2 = 1;
      l_5: 
         if ( HV_1 < 0 || HV_1 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
            1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         if ( HV_3 [ HV_0 * 110 + HV_1 ]  == 0 ) goto l_39 ;
         goto l_48 ;
      l_39: 
         HV_5 = 0;
         HV_4 [ HV_0 ]  = HV_5;
         continue ;
      l_48: 
         if ( HV_6 != 0 ) goto l_8 ;
         TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_7);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_6 = 1;
      l_8: 
         if ( HV_10 != 0 ) goto l_11 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_11);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_10 = 1;
      l_11: 
      TCDSetPS (pMyPar, 1, 116, &HV_9, &HV_8, HV_7);
      TCDSetPS (pMyPar, 1, 119, &HV_13, &HV_12, HV_11);
         rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY_plus_i_t", 579, 579,
            &HV_14);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 119, &HV_13, &HV_12, HV_11);
      TCDSetPS (pMyPar, 0, 116, &HV_9, &HV_8, HV_11);
      TCDSetPS (pMyPar, 1, 116, &HV_16, &HV_15, HV_14);
         rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_17);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 116, &HV_16, &HV_15, HV_14);
         if ( HV_2 != 0 ) goto l_14 ;
         TCD3FET (pMyPar, "AlphaCostMatrix", 1, 393, 8,  (P_TCDTAB *)
            &HV_3);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_2 = 1;
      l_14: 
         if ( HV_18 < 0 || HV_18 > pMyPar->pTCDTCD->SSAData.AnzSpalten
            - 1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         HV_21 = HV_3 [ HV_0 * 110 + HV_18 ] ;
      TCDSetPS (pMyPar, 1, 116, &HV_20, &HV_19, HV_21);
         rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_22);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 116, &HV_20, &HV_19, HV_21);
         if ( HV_17 >= HV_22 ) goto l_105 ;
         goto l_279 ;
      l_105: 
         if ( HV_6 != 0 ) goto l_17 ;
         TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_7);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_6 = 1;
      l_17: 
         if ( HV_10 != 0 ) goto l_20 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_11);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_10 = 1;
      l_20: 
      TCDSetPS (pMyPar, 1, 116, &HV_9, &HV_8, HV_7);
      TCDSetPS (pMyPar, 1, 119, &HV_13, &HV_12, HV_11);
         rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY_plus_i_t", 579, 579,
            &HV_23);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 119, &HV_13, &HV_12, HV_11);
      TCDSetPS (pMyPar, 0, 116, &HV_9, &HV_8, HV_11);
      TCDSetPS (pMyPar, 1, 116, &HV_25, &HV_24, HV_23);
         rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_26);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 116, &HV_25, &HV_24, HV_23);
         if ( HV_2 != 0 ) goto l_23 ;
         TCD3FET (pMyPar, "AlphaCostMatrix", 1, 393, 8,  (P_TCDTAB *)
            &HV_3);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_2 = 1;
      l_23: 
         if ( HV_27 < 0 || HV_27 > pMyPar->pTCDTCD->SSAData.AnzSpalten
            - 1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         HV_30 = HV_3 [ HV_0 * 110 + HV_27 ] ;
         if ( HV_65 != 0 ) goto l_139 ;
      TCDSetPS (pMyPar, 1, 116, &HV_29, &HV_28, HV_30);
         rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_31);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 116, &HV_29, &HV_28, HV_30);
         HV_65 = 1;
      l_139: 
         if ( HV_26 <  HV_31 ) goto l_156 ;
         goto l_279 ;
      l_156: 
         if ( HV_32 != 0 ) goto l_26 ;
         rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_33);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_32 = 1;
      l_26: 
         HV_36 = (TCD_INT) ( HV_33) ;
         if ( HV_34 != 0 ) goto l_29 ;
         rc = TCD3FE1 (pMyPar, 2, "_Alpha2", 468, 468, &HV_35);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_34 = 1;
      l_29: 
         HV_37 = (TCD_INT) ( HV_35) ;
         if ( HV_67 != 0 ) goto l_172 ;
         if ( HV_2 != 0 ) goto l_32 ;
         TCD3FET (pMyPar, "AlphaCostMatrix", 1, 393, 8,  (P_TCDTAB *)
            &HV_3);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_2 = 1;
      l_32: 
         if ( HV_38 != 0 ) goto l_35 ;
         TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_39);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_38 = 1;
      l_35: 
         if ( HV_1 < 0 || HV_1 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
            1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         if ( HV_37 < 0 || HV_37 > pMyPar->pTCDTCD->SSAData.AnzSpalten
            - 1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         if ( HV_36 < 0 || HV_36 > pMyPar->pTCDTCD->SSAData.AnzZeilen -
            1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         HV_40 = HV_3 [ HV_0 * 110 + HV_1 ]  * HV_39 [ HV_36 * 110 +
            HV_37 ] ;
         HV_67 = 1;
      l_172: 
         if ( HV_2 != 0 ) goto l_38 ;
         TCD3FET (pMyPar, "AlphaCostMatrix", 1, 393, 8,  (P_TCDTAB *)
            &HV_3);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_2 = 1;
      l_38: 
         if ( HV_18 < 0 || HV_18 > pMyPar->pTCDTCD->SSAData.AnzSpalten
            - 1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         HV_43 = HV_3 [ HV_0 * 110 + HV_18 ] ;
         if ( HV_6 != 0 ) goto l_41 ;
         TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_7);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_6 = 1;
      l_41: 
         if ( HV_10 != 0 ) goto l_44 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_11);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_10 = 1;
      l_44: 
      TCDSetPS (pMyPar, 1, 116, &HV_9, &HV_8, HV_7);
      TCDSetPS (pMyPar, 1, 119, &HV_13, &HV_12, HV_11);
         rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY_plus_i_t", 579, 579,
            &HV_44);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 119, &HV_13, &HV_12, HV_11);
      TCDSetPS (pMyPar, 0, 116, &HV_9, &HV_8, HV_11);
      TCDSetPS (pMyPar, 1, 117, &HV_42, &HV_41, HV_43);
      TCDSetPS (pMyPar, 1, 115, &HV_46, &HV_45, HV_44);
         rc = TCD3FE1 (pMyPar, 4, "F_Months", 577, 577, &HV_47);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 115, &HV_46, &HV_45, HV_44);
      TCDSetPS (pMyPar, 0, 117, &HV_42, &HV_41, HV_44);
         HV_48 = HV_40 * HV_47;
         if ( HV_2 != 0 ) goto l_47 ;
         TCD3FET (pMyPar, "AlphaCostMatrix", 1, 393, 8,  (P_TCDTAB *)
            &HV_3);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_2 = 1;
      l_47: 
         if ( HV_18 < 0 || HV_18 > pMyPar->pTCDTCD->SSAData.AnzSpalten
            - 1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         HV_43 = HV_3 [ HV_0 * 110 + HV_18 ] ;
         if ( HV_2 != 0 ) goto l_50 ;
         TCD3FET (pMyPar, "AlphaCostMatrix", 1, 393, 8,  (P_TCDTAB *)
            &HV_3);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_2 = 1;
      l_50: 
         if ( HV_27 < 0 || HV_27 > pMyPar->pTCDTCD->SSAData.AnzSpalten
            - 1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         HV_51 = HV_3 [ HV_0 * 110 + HV_27 ] ;
      TCDSetPS (pMyPar, 1, 117, &HV_42, &HV_41, HV_43);
      TCDSetPS (pMyPar, 1, 115, &HV_50, &HV_49, HV_51);
         rc = TCD3FE1 (pMyPar, 4, "F_Months", 577, 577, &HV_52);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 115, &HV_50, &HV_49, HV_51);
      TCDSetPS (pMyPar, 0, 117, &HV_42, &HV_41, HV_51);
         HV_53 = TCDMAX ( 1, HV_52 ) ;
      if ( HV_53 == 0) { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
         goto l_ende ;
       } ;
         HV_54 = HV_48 / HV_53;
         HV_55 =   TCDRND ( HV_54, 2 ) ;
         HV_4 [ HV_0 ]  = HV_55;
         continue ;
      l_279: 
         if ( HV_6 != 0 ) goto l_53 ;
         TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_7);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_6 = 1;
      l_53: 
         if ( HV_10 != 0 ) goto l_56 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_11);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_10 = 1;
      l_56: 
      TCDSetPS (pMyPar, 1, 116, &HV_9, &HV_8, HV_7);
      TCDSetPS (pMyPar, 1, 119, &HV_13, &HV_12, HV_11);
         rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY_plus_i_t", 579, 579,
            &HV_56);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 119, &HV_13, &HV_12, HV_11);
      TCDSetPS (pMyPar, 0, 116, &HV_9, &HV_8, HV_11);
      TCDSetPS (pMyPar, 1, 116, &HV_58, &HV_57, HV_56);
         rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_59);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 116, &HV_58, &HV_57, HV_56);
         if ( HV_2 != 0 ) goto l_59 ;
         TCD3FET (pMyPar, "AlphaCostMatrix", 1, 393, 8,  (P_TCDTAB *)
            &HV_3);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_2 = 1;
      l_59: 
         if ( HV_27 < 0 || HV_27 > pMyPar->pTCDTCD->SSAData.AnzSpalten
            - 1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         HV_30 = HV_3 [ HV_0 * 110 + HV_27 ] ;
         if ( HV_65 != 0 ) goto l_316 ;
      TCDSetPS (pMyPar, 1, 116, &HV_29, &HV_28, HV_30);
         rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_31);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 116, &HV_29, &HV_28, HV_30);
         HV_65 = 1;
      l_316: 
         if ( HV_59 >= HV_31 ) goto l_333 ;
         goto l_366 ;
      l_333: 
         if ( HV_32 != 0 ) goto l_62 ;
         rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_33);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_32 = 1;
      l_62: 
         HV_36 = (TCD_INT) ( HV_33) ;
         if ( HV_34 != 0 ) goto l_65 ;
         rc = TCD3FE1 (pMyPar, 2, "_Alpha2", 468, 468, &HV_35);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_34 = 1;
      l_65: 
         HV_37 = (TCD_INT) ( HV_35) ;
         if ( HV_67 != 0 ) goto l_343 ;
         if ( HV_2 != 0 ) goto l_68 ;
         TCD3FET (pMyPar, "AlphaCostMatrix", 1, 393, 8,  (P_TCDTAB *)
            &HV_3);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_2 = 1;
      l_68: 
         if ( HV_38 != 0 ) goto l_71 ;
         TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_39);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_38 = 1;
      l_71: 
         if ( HV_1 < 0 || HV_1 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
            1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         if ( HV_37 < 0 || HV_37 > pMyPar->pTCDTCD->SSAData.AnzSpalten
            - 1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         if ( HV_36 < 0 || HV_36 > pMyPar->pTCDTCD->SSAData.AnzZeilen -
            1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         HV_40 = HV_3 [ HV_0 * 110 + HV_1 ]  * HV_39 [ HV_36 * 110 +
            HV_37 ] ;
         HV_67 = 1;
      l_343: 
         HV_60 =   TCDRND ( HV_40, 2 ) ;
         HV_4 [ HV_0 ]  = HV_60;
         continue ;
      l_366: 
         HV_61 = 0;
         HV_4 [ HV_0 ]  = HV_61;
         continue ;
      }


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetTb (pMyPar, &HV_4);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT778","End F_AC_Layer_Original",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_AC_Layer_Original", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_AC_Layer_Original", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_AC_Layer_Original");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT779
   Beschreibung: Die Funktion berechnet die Formel 
                 F_AC_CashValue
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT779 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_5 = 0;
      P_TCDTAB1   HV_6;
      TCD_INT     HV_3 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT779","Begin F_AC_CashValue",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,779,"12.12.2019 17:29:23",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT779",
              "Ende F_AC_CashValue",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_5 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_RateClass", 30, 347, 1, 118, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 2 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      HV_7 = 0;
      for ( HV_4 = (TCD_INT) (0) ; HV_4 <= 60; HV_4 = HV_4 + 1 ) {
         if ( HV_5 != 0 ) goto l_8 ;
         rc = TCD3FE2 (pMyPar, 2, "F_AC_Layer_CashValue", 780, 780,
            &HV_6);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_5 = 1;
      l_8: 
         HV_7 = HV_6 [ HV_4 ]  + HV_7;
      }
      HV_8 = TCDMAX ( 0, HV_7 ) ;
      HV_2 = HV_8;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT779","End F_AC_CashValue",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_AC_CashValue", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_AC_CashValue", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_AC_CashValue");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT780
   Beschreibung: Die Funktion berechnet die Formel 
                 F_AC_Layer_CashValue
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT780 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_DOUBLE  HV_29 = 0;
      TCD_DOUBLE  HV_30 = 0;
      TCD_DOUBLE  HV_31 = 0;
      TCD_DOUBLE  HV_32 = 0;
      TCD_DOUBLE  HV_34 = 0;
      TCD_DOUBLE  HV_35 = 0;
      TCD_DOUBLE  HV_36 = 0;
      TCD_DOUBLE  HV_37 = 0;
      TCD_DOUBLE  HV_39 = 0;
      TCD_DOUBLE  HV_40 = 0;
      TCD_DOUBLE  HV_41 = 0;
      TCD_DOUBLE  HV_42 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_17 = 0;
      TCD_INT     HV_24 = 0;
      TCD_INT     HV_27 = 0;
      TCD_INT     HV_33 = 0;
      TCD_INT     HV_38 = 0;
      TCD_INT     HV_43 = 0;
      TCD_INT     HV_44 = 0;
      TCD_INT     HV_45 = 0;
      P_TCDTAB1   HV_2;
      P_TCDTAB1   HV_3;
      P_TCDTAB2   HV_11;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_9 = 2;
      TCD_INT     HV_16 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT780","Begin F_AC_Layer_CashValue",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,780,"12.12.2019 17:29:23",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Besorgen einer freien Tabelle, falls Formel vom Typ TAB1/TAB2 */
   rc =    TCDGetTb (pMyPar, &HV_3);


   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_3);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT780",
              "Ende F_AC_Layer_CashValue",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_5 = 0;
      HV_10 = 0;
      HV_38 = 0;
      for ( HV_0 = (TCD_INT) (0) ; HV_0 <= 199; HV_0 = HV_0 + 1 ) {
         HV_43 = 0;
         HV_44 = 0;
         HV_45 = 0;
         if ( HV_1 != 0 ) goto l_5 ;
         rc = TCD3FE2 (pMyPar, 2, "F_AC_Layer_Original", 778, 778,
            &HV_2);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_1 = 1;
      l_5: 
         if ( HV_2 [ HV_0 ]  == 0 ) goto l_21 ;
         goto l_30 ;
      l_21: 
         HV_4 = 0;
         HV_3 [ HV_0 ]  = HV_4;
         continue ;
      l_30: 
         if ( HV_5 != 0 ) goto l_8 ;
         TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_6);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_5 = 1;
      l_8: 
         if ( HV_10 != 0 ) goto l_11 ;
         TCD3FET (pMyPar, "AlphaCostMatrix", 1, 393, 8,  (P_TCDTAB *)
            &HV_11);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_10 = 1;
      l_11: 
         if ( HV_9 < 0 || HV_9 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
            1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         HV_14 = HV_11 [ HV_0 * 110 + HV_9 ] ;
      TCDSetPS (pMyPar, 1, 117, &HV_8, &HV_7, HV_6);
      TCDSetPS (pMyPar, 1, 115, &HV_13, &HV_12, HV_14);
         rc = TCD3FE1 (pMyPar, 4, "F_DifYears", 553, 553, &HV_15);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 115, &HV_13, &HV_12, HV_14);
      TCDSetPS (pMyPar, 0, 117, &HV_8, &HV_7, HV_14);
         if ( HV_5 != 0 ) goto l_14 ;
         TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_6);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_5 = 1;
      l_14: 
         if ( HV_10 != 0 ) goto l_17 ;
         TCD3FET (pMyPar, "AlphaCostMatrix", 1, 393, 8,  (P_TCDTAB *)
            &HV_11);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_10 = 1;
      l_17: 
         if ( HV_16 < 0 || HV_16 > pMyPar->pTCDTCD->SSAData.AnzSpalten
            - 1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         HV_19 = HV_11 [ HV_0 * 110 + HV_16 ] ;
      TCDSetPS (pMyPar, 1, 117, &HV_8, &HV_7, HV_6);
      TCDSetPS (pMyPar, 1, 115, &HV_18, &HV_17, HV_19);
         rc = TCD3FE1 (pMyPar, 4, "F_DifYears", 553, 553, &HV_20);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 115, &HV_18, &HV_17, HV_19);
      TCDSetPS (pMyPar, 0, 117, &HV_8, &HV_7, HV_19);
         HV_21 = HV_15 - HV_20;
         if ( HV_1 != 0 ) goto l_20 ;
         rc = TCD3FE2 (pMyPar, 2, "F_AC_Layer_Original", 778, 778,
            &HV_2);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_1 = 1;
      l_20: 
         HV_22 = HV_2 [ HV_0 ]  * HV_21;
         if ( HV_5 != 0 ) goto l_23 ;
         TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_6);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_5 = 1;
      l_23: 
         if ( HV_10 != 0 ) goto l_26 ;
         TCD3FET (pMyPar, "AlphaCostMatrix", 1, 393, 8,  (P_TCDTAB *)
            &HV_11);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_10 = 1;
      l_26: 
         if ( HV_16 < 0 || HV_16 > pMyPar->pTCDTCD->SSAData.AnzSpalten
            - 1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         HV_19 = HV_11 [ HV_0 * 110 + HV_16 ] ;
      TCDSetPS (pMyPar, 1, 117, &HV_8, &HV_7, HV_6);
      TCDSetPS (pMyPar, 1, 115, &HV_18, &HV_17, HV_19);
         rc = TCD3FE1 (pMyPar, 4, "F_DifYears", 553, 553, &HV_23);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 115, &HV_18, &HV_17, HV_19);
      TCDSetPS (pMyPar, 0, 117, &HV_8, &HV_7, HV_19);
         if ( HV_5 != 0 ) goto l_29 ;
         TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_6);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_5 = 1;
      l_29: 
         if ( HV_10 != 0 ) goto l_32 ;
         TCD3FET (pMyPar, "AlphaCostMatrix", 1, 393, 8,  (P_TCDTAB *)
            &HV_11);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_10 = 1;
      l_32: 
         if ( HV_9 < 0 || HV_9 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
            1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         HV_14 = HV_11 [ HV_0 * 110 + HV_9 ] ;
      TCDSetPS (pMyPar, 1, 117, &HV_8, &HV_7, HV_6);
      TCDSetPS (pMyPar, 1, 115, &HV_13, &HV_12, HV_14);
         rc = TCD3FE1 (pMyPar, 4, "F_DifYears", 553, 553, &HV_26);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 115, &HV_13, &HV_12, HV_14);
      TCDSetPS (pMyPar, 0, 117, &HV_8, &HV_7, HV_14);
      TCDSetPS (pMyPar, 1, 88, &HV_25, &HV_24, HV_23);
      TCDSetPS (pMyPar, 1, 89, &HV_28, &HV_27, HV_26);
         rc = TCD3FE1 (pMyPar, 4, "F_aePV", 316, 316, &HV_29);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 89, &HV_28, &HV_27, HV_26);
      TCDSetPS (pMyPar, 0, 88, &HV_25, &HV_24, HV_26);
         HV_30 = TCDMAX ( 1, HV_29 ) ;
      if ( HV_30 == 0) { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
         goto l_ende ;
       } ;
         HV_31 = HV_22 / HV_30;
         if ( HV_5 != 0 ) goto l_35 ;
         TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_6);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_5 = 1;
      l_35: 
         if ( HV_10 != 0 ) goto l_38 ;
         TCD3FET (pMyPar, "AlphaCostMatrix", 1, 393, 8,  (P_TCDTAB *)
            &HV_11);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_10 = 1;
      l_38: 
         if ( HV_9 < 0 || HV_9 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
            1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         HV_14 = HV_11 [ HV_0 * 110 + HV_9 ] ;
      TCDSetPS (pMyPar, 1, 117, &HV_8, &HV_7, HV_6);
      TCDSetPS (pMyPar, 1, 115, &HV_13, &HV_12, HV_14);
         rc = TCD3FE1 (pMyPar, 4, "F_DifYears", 553, 553, &HV_32);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 115, &HV_13, &HV_12, HV_14);
      TCDSetPS (pMyPar, 0, 117, &HV_8, &HV_7, HV_14);
      TCDSetPS (pMyPar, 1, 89, &HV_34, &HV_33, HV_32);
         rc = TCD3FE1 (pMyPar, 4, "F_aePV", 316, 316, &HV_35);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 89, &HV_34, &HV_33, HV_32);
         HV_36 = HV_31 * HV_35;
         if ( HV_5 != 0 ) goto l_41 ;
         TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_6);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_5 = 1;
      l_41: 
         if ( HV_10 != 0 ) goto l_44 ;
         TCD3FET (pMyPar, "AlphaCostMatrix", 1, 393, 8,  (P_TCDTAB *)
            &HV_11);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_10 = 1;
      l_44: 
         if ( HV_9 < 0 || HV_9 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
            1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         HV_14 = HV_11 [ HV_0 * 110 + HV_9 ] ;
      TCDSetPS (pMyPar, 1, 117, &HV_8, &HV_7, HV_6);
      TCDSetPS (pMyPar, 1, 115, &HV_13, &HV_12, HV_14);
         rc = TCD3FE1 (pMyPar, 4, "F_DifYears", 553, 553, &HV_37);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 115, &HV_13, &HV_12, HV_14);
      TCDSetPS (pMyPar, 0, 117, &HV_8, &HV_7, HV_14);
         if ( HV_38 != 0 ) goto l_47 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_39);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_38 = 1;
      l_47: 
         HV_40 = HV_37 - HV_39;
         HV_41 = TCDMAX ( 1, HV_40 ) ;
      if ( HV_41 == 0) { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
         goto l_ende ;
       } ;
         HV_42 = HV_36 / HV_41;
         HV_3 [ HV_0 ]  = HV_42;
         continue ;
      }


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetTb (pMyPar, &HV_3);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT780","End F_AC_Layer_CashValue",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_AC_Layer_CashValue", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_AC_Layer_CashValue", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_AC_Layer_CashValue");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT781
   Beschreibung: Die Funktion berechnet die Formel 
                 F_AC_total
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT781 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_9 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_15 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_6 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT781","Begin F_AC_total",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,781,"12.12.2019 17:29:22",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT781",
              "Ende F_AC_total",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_4 = 0;
      HV_7 = 0;
      HV_15 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_RateClass", 30, 347, 1, 118, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_1 == 2 ) goto l_18 ;
      goto l_24 ;
   l_18: 
      HV_3 = 0;
      HV_2 = HV_3;
      goto l_3 ;
   l_24: 
      if ( HV_4 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "e_method", 53, 409, 6, 53, &HV_5);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_4 = 1;
   l_8: 
      if ( HV_5 == 0 ) goto l_36 ;
      goto l_42 ;
   l_36: 
      HV_6 = 0;
      HV_2 = HV_6;
      goto l_3 ;
   l_42: 
      if ( HV_7 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "e_n_o", 7, 104, 6, 7, &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_11: 
   TCDSetPS (pMyPar, 1, 94, &HV_10, &HV_9, HV_8);
      rc = TCD3FE1 (pMyPar, 4, "F_n", 364, 364, &HV_11);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 94, &HV_10, &HV_9, HV_8);
   TCDSetPS (pMyPar, 1, 88, &HV_13, &HV_12, HV_11);
      rc = TCD3FE1 (pMyPar, 4, "F_SumsOfPrem_o", 735, 735, &HV_14);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 88, &HV_13, &HV_12, HV_11);
      if ( HV_15 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "F_CommReductionFact", 636, 636,
         &HV_16);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_15 = 1;
   l_14: 
      HV_17 = HV_14 * HV_16;
      HV_2 = HV_17;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT781","End F_AC_total",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_AC_total", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_AC_total", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_AC_total");
   }                                         
   return ;

   }
}

