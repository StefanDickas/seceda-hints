#ifndef TCD6_H
#define TCD6_H
/*---------------------------------------------------------------------------

(C) Copyright 1993-2002, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------
  Modul:   TCD_ATTX.h
  TCD-Version: 1
  RBS-Name   : LifeTemplate
  Generiert am 16.12.2019 15:07:19
  Beschreibung: Defines f�r indizierten Zugriff auf die 
                Bestandsattribute des Rechenbausteins
---------------------------------------------------------------------*/



/*  Definition der Attributtabelle */
#include "c90.h"
#ifdef INCL_S_TCDATAB
S_TCDATAB  s_LifeTemp_AttrTab [] = {
 {"e_n_n", 4, 0, 0 },
 {"e_m_n", 8, 1, 0 },
 {"e_TBeg_n", 19, 2, 0 },
 {"e_tarif_nr_n", 20, 3, 0 },
 {"e_tarsumme_ges_n", 27, 4, 0 },
 {"e_tarsumme_pfr_n", 33, 5, 0 },
 {"e_m_o", 103, 6, 0 },
 {"e_n_o", 104, 7, 0 },
 {"e_tarif_nr_o", 121, 8, 0 },
 {"e_TBeg_o", 122, 9, 0 },
 {"e_reserve_o", 125, 10, 0 },
 {"e_tarsumme_ges_o", 134, 11, 0 },
 {"e_NumberOfInsPers_n", 323, 12, 0 },
 {"e_BirthDate_IP1_n", 330, 13, 0 },
 {"e_ea_IP1_n", 332, 14, 0 },
 {"e_ea_IP2_n", 333, 15, 0 },
 {"e_gender_IP1_n", 334, 16, 0 },
 {"e_gender_IP2_n", 335, 17, 0 },
 {"e_BirthDate_IP1_o", 336, 18, 0 },
 {"e_RiskGroup_IP1_n", 338, 19, 0 },
 {"e_RiskGroup_IP2_n", 339, 20, 0 },
 {"e_RiskGroup_IP1_o", 340, 21, 0 },
 {"e_RiskGroup_IP2_o", 341, 22, 0 },
 {"e_NumberOfInsPers_o", 342, 23, 0 },
 {"e_x_IP1_o", 343, 24, 0 },
 {"e_x_IP2_o", 344, 25, 0 },
 {"e_x_IP1_n", 345, 26, 0 },
 {"e_x_IP2_n", 346, 27, 0 },
 {"e_currentDate_n", 348, 28, 0 },
 {"e_CalcDate", 351, 29, 0 },
 {"e_BackOffice", 352, 30, 0 },
 {"CostTab", 357, 0, 2 },
 {"e_AddContrib_n", 359, 31, 0 },
 {"e_PartSurrender_n", 360, 32, 0 },
 {"e_RateClass_n", 361, 33, 0 },
 {"e_RateClass_o", 362, 34, 0 },
 {"e_OccuClass_n", 364, 35, 0 },
 {"e_OccuSurcha_IP1_n", 367, 36, 0 },
 {"e_SportsSurcha_IP1_n", 368, 37, 0 },
 {"e_SportsSurcha_IP1_o", 369, 38, 0 },
 {"e_OccuSurcha_IP1_o", 370, 39, 0 },
 {"e_AddSurcharge_IP1_n", 371, 40, 0 },
 {"e_AddSurcharge_IP2_n", 372, 41, 0 },
 {"e_AddSurcharge_IP1_o", 373, 42, 0 },
 {"e_AddSurcharge_IP2_o", 374, 43, 0 },
 {"e_wo_examination_n", 379, 44, 0 },
 {"e_wo_examination_o", 380, 45, 0 },
 {"e_HealthClass_IP1_n", 381, 46, 0 },
 {"e_HealthSurch_IP1_n", 388, 47, 0 },
 {"e_HealthSurch_IP1_o", 389, 48, 0 },
 {"e_SpecialDiscount_n", 390, 49, 0 },
 {"e_SumDiscount_n", 391, 50, 0 },
 {"AlphaCostMatrix", 393, 1, 2 },
 {"YieldFactorTab", 394, 2, 2 },
 {"MortalityTab", 395, 3, 2 },
 {"e_CommReduction_n", 407, 51, 0 },
 {"e_CommReduction_o", 408, 52, 0 },
 {"e_method", 409, 53, 0 },
 {"e_SumRelation", 410, 54, 0 },
 {"e_manual_reserve_n", 411, 55, 0 },
 {"e_state_n", 423, 56, 0 },
 {"e_StateDetail_n", 424, 57, 0 },
 {"e_DeathBenFactor_n", 425, 58, 0 },
 {"e_benefitPeriod_n", 432, 59, 0 },
 {"e_annutyPayFreq_n", 433, 60, 0 },
 {"e_state_o", 434, 61, 0 },
 {"e_StateDetail_o", 435, 62, 0 },
 {"e_benefitPeriod_o", 436, 63, 0 },
 {"e_annutyPayFreq_o", 437, 64, 0 },
 {"e_DeathBenFactor_o", 438, 65, 0 },
 {"e_guaranteePeriod_n", 439, 66, 0 },
 {"e_guaranteePeriod_o", 440, 67, 0 },
 {"e_SumOfPremiums_o", 442, 68, 0 },
 {"e_SumOfPremiums_n", 443, 69, 0 },
 {"e_manualSumsOfPrem", 444, 70, 0 },
 {"e_manual_LEBK_BWS_n", 445, 71, 0 },
 {"e_manual_LEBK_MON_n", 446, 72, 0 },
 {"e_SpecialDiscount_o", 447, 73, 0 },
 {"e_SumDiscount_o", 448, 74, 0 },
 {"e_GrossPremium_o", 449, 75, 0 },
 {"e_InterestRate", 451, 76, 0 },
 {"e_pfs_n", 452, 77, 0 },
 {"e_pst_n", 453, 78, 0 },
 {"e_pst_o", 454, 79, 0 },
 {"e_StartDateYield_n", 455, 80, 0 },
 {"e_YieldValue_o", 458, 81, 0 },
 {"e_YieldDate_o", 459, 82, 0 },
 {"e_StartDateYield_o", 460, 83, 0 },
 {"e_GrossPremium_n", 461, 84, 0 },
 {"e_YieldValue_n", 462, 85, 0 },
 {"e_YieldDate_n", 463, 86, 0 },
 {"e_AnnuityAmount_n", 475, 87, 0 },
 { "", 0, 0, 0 }
} ;
#else
extern S_TCDATAB  s_LifeTemp_AttrTab [];
#endif

#define LifeTemp_ATAB_SIZE 93

/* Definition der Attributindizes */
/* skalare Attribute */
 #define e_n_n_SKIX 0
 #define e_m_n_SKIX 1
 #define e_TBeg_n_SKIX 2
 #define e_tarif_nr_n_SKIX 3
 #define e_tarsumme_ges_n_SKIX 4
 #define e_tarsumme_pfr_n_SKIX 5
 #define e_m_o_SKIX 6
 #define e_n_o_SKIX 7
 #define e_tarif_nr_o_SKIX 8
 #define e_TBeg_o_SKIX 9
 #define e_reserve_o_SKIX 10
 #define e_tarsumme_ges_o_SKIX 11
 #define e_NumberOfInsPers_n_SKIX 12
 #define e_BirthDate_IP1_n_SKIX 13
 #define e_ea_IP1_n_SKIX 14
 #define e_ea_IP2_n_SKIX 15
 #define e_gender_IP1_n_SKIX 16
 #define e_gender_IP2_n_SKIX 17
 #define e_BirthDate_IP1_o_SKIX 18
 #define e_RiskGroup_IP1_n_SKIX 19
 #define e_RiskGroup_IP2_n_SKIX 20
 #define e_RiskGroup_IP1_o_SKIX 21
 #define e_RiskGroup_IP2_o_SKIX 22
 #define e_NumberOfInsPers_o_SKIX 23
 #define e_x_IP1_o_SKIX 24
 #define e_x_IP2_o_SKIX 25
 #define e_x_IP1_n_SKIX 26
 #define e_x_IP2_n_SKIX 27
 #define e_currentDate_n_SKIX 28
 #define e_CalcDate_SKIX 29
 #define e_BackOffice_SKIX 30
 #define e_AddContrib_n_SKIX 31
 #define e_PartSurrender_n_SKIX 32
 #define e_RateClass_n_SKIX 33
 #define e_RateClass_o_SKIX 34
 #define e_OccuClass_n_SKIX 35
 #define e_OccuSurcha_IP1_n_SKIX 36
 #define e_SportsSurcha_IP1_n_SKIX 37
 #define e_SportsSurcha_IP1_o_SKIX 38
 #define e_OccuSurcha_IP1_o_SKIX 39
 #define e_AddSurcharge_IP1_n_SKIX 40
 #define e_AddSurcharge_IP2_n_SKIX 41
 #define e_AddSurcharge_IP1_o_SKIX 42
 #define e_AddSurcharge_IP2_o_SKIX 43
 #define e_wo_examination_n_SKIX 44
 #define e_wo_examination_o_SKIX 45
 #define e_HealthClass_IP1_n_SKIX 46
 #define e_HealthSurch_IP1_n_SKIX 47
 #define e_HealthSurch_IP1_o_SKIX 48
 #define e_SpecialDiscount_n_SKIX 49
 #define e_SumDiscount_n_SKIX 50
 #define e_CommReduction_n_SKIX 51
 #define e_CommReduction_o_SKIX 52
 #define e_method_SKIX 53
 #define e_SumRelation_SKIX 54
 #define e_manual_reserve_n_SKIX 55
 #define e_state_n_SKIX 56
 #define e_StateDetail_n_SKIX 57
 #define e_DeathBenFactor_n_SKIX 58
 #define e_benefitPeriod_n_SKIX 59
 #define e_annutyPayFreq_n_SKIX 60
 #define e_state_o_SKIX 61
 #define e_StateDetail_o_SKIX 62
 #define e_benefitPeriod_o_SKIX 63
 #define e_annutyPayFreq_o_SKIX 64
 #define e_DeathBenFactor_o_SKIX 65
 #define e_guaranteePeriod_n_SKIX 66
 #define e_guaranteePeriod_o_SKIX 67
 #define e_SumOfPremiums_o_SKIX 68
 #define e_SumOfPremiums_n_SKIX 69
 #define e_manualSumsOfPrem_SKIX 70
 #define e_manual_LEBK_BWS_n_SKIX 71
 #define e_manual_LEBK_MON_n_SKIX 72
 #define e_SpecialDiscount_o_SKIX 73
 #define e_SumDiscount_o_SKIX 74
 #define e_GrossPremium_o_SKIX 75
 #define e_InterestRate_SKIX 76
 #define e_pfs_n_SKIX 77
 #define e_pst_n_SKIX 78
 #define e_pst_o_SKIX 79
 #define e_StartDateYield_n_SKIX 80
 #define e_YieldValue_o_SKIX 81
 #define e_YieldDate_o_SKIX 82
 #define e_StartDateYield_o_SKIX 83
 #define e_GrossPremium_n_SKIX 84
 #define e_YieldValue_n_SKIX 85
 #define e_YieldDate_n_SKIX 86
 #define e_AnnuityAmount_n_SKIX 87

/* Tab1 Attribute */

/* Tab2 Attribute */
 #define CostTab_T2IX 0
 #define AlphaCostMatrix_T2IX 1
 #define YieldFactorTab_T2IX 2
 #define MortalityTab_T2IX 3

/* Datum Attribute */

/* Vgl- Attribute */


/* Konstante f�r Anzahlen */
#define ANZSKALAR 88
#define ANZTAB1 0
#define ANZTAB2 4
#define ANZDATUM 0
#define ANZVERGL 0
#endif //ifndef TCD6_H
