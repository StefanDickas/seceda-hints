/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
/*
Modul      : TCD_RCTL.c
TCD-Version: 1
RBS-Name   : LifeTemplate
Generiert am 16.12.2019 15:07:19
Aufgabe    : RBS-Steuerung

Input      : <RBS-Name>->pRbsCtl->Opc     Opcode der Funktion.
Output     : <RBS_Name>->pRbsCtl->RcInfo  Return Kontroll Block Info.

Historie:    21.03.95     BEG neue Opcodes  TCD_OPC_SET_BATTR_VAL
                          TCD_OPC_SET_TATTR_VAL
        BEG neue Funktion TCDIniPS
        BEG Opcodes  TCD_OPC_SET_BATTR_VAL    -
                      TCD_OPC_SET_TATTR_VAL
                      -> TCD_OPC_SET_ATTR_VAL
27.07.95     BEG neue Opcodes .._I
19.01.96     BEG Erweiterung des ResetRbs
06.03.96     BEG Datei gefreezt
06.03.96     BEG Opcodes TCD_OPC_SET_ATTR_IN_PRC
21.05.96     MUB Optimierung vorbereitet
            PaarListenAnlegen,Zerst�ren,TraceFunktion
20.06.96     RWE Freigabe der AttrsResults
24.06.96     RWE neue Opcodes: TCD_OPC_REMOVE_RESULTS
                              TCD_OPC_GET_FIRST_RESULTS_INFO
                              TCD_OPC_GET_NEXT_RESULTS_INFO

02.07.96     MUB TCD_OPC_SET_ATTR_IN_PRC abgeklemmt
22.7.96      MUB Freigeben der lokalen ErgebnisPools auch bei ResetRBS

 -*/
#define NO_STATIC_RBS_DATA

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDPORTAB_H)
#define TCDPORTAB_H

/*-----------------
Name        : TCDPORTAB.H

Beschreibung: externes Include File, das generierumgeungsspezifische
Informationen enthaelt (Makrovorlage).
By          : BEGGI
Datum       : 20.04.94
Historie:     BEG   17.01.95  neues Makro _TCDMEMINI anstatt memset
BEG   02.03.95  bedingte Macros TCDHUGE
BEG   22.06.95  _TCDMEMINI nur im HUGE-Modell redefiniert.
BEG   20.02.96  malloc.h wird nicht mehr inkludiert (FM 451)
RWE   21.06.96  malloc.h wird wieder includiert (aber nur
              fuers HUGE-Modell, d.h. fuer DOS/WIN-Compiler)
RWE   26.06.96  WATCHMEM-Makros eingebaut (fuer TCDALLOC etc)
MUB   17.7.96   Include mit !defined versehen
KFC   02.09.96  #define TCDHUGE vorgezogen

-------------------*/

/* #define TCDHUGE */              /* bei gro�en Tabellen einschalten*/
/* Systemincludes */                  
#include <stdlib.h>                /* atoi, ...       */
#include <stdio.h>                 /* fprintf, ...    */
#include <string.h>                /* strcpy, ...     */
#include <time.h>                  /* time_t, ...     */
#include <math.h>                  /* exp, min, max, ... */

#ifdef TCDHUGE
#include <malloc.h>
#endif

/* Defines */
#define  TCDC_EXT_NAME_LNG    8  /* maximale L�nge von externen 
                                    Bezeichnern*/
/*-----------------
  Definitionen aus standard C-Includes z.B. stdio.h
-------------------*/
#ifndef NULL
#define    NULL    (void *)0
#endif

/*-----------------
  Definitionen von Basistypen
-------------------*/
typedef    short   TCD_BOOL ;
typedef    long    TCD_LONG ;
typedef    int     TCD_INT  ;
typedef    double  TCD_DOUBLE ;


/*-----------------
  modellabhaengige Definitionen von Basistypen
-------------------*/
typedef    TCD_DOUBLE  TCDTAB ;
#ifdef TCDHUGE
typedef    TCDTAB       huge * P_TCDTAB ;
typedef    TCD_DOUBLE   huge * P_TCD_DOUBLE ;
typedef    P_TCD_DOUBLE * P_P_TCD_DOUBLE ;
typedef    char huge    * TCD_LPCHAR ;
#else
typedef    TCDTAB       * P_TCDTAB ;
typedef    TCD_DOUBLE   * P_TCD_DOUBLE ;
typedef    P_TCD_DOUBLE * P_P_TCD_DOUBLE ;
typedef    char         * TCD_LPCHAR ;
#endif

/*-----------------
  weitere (Typ-)Defines 
-------------------*/  
typedef int ERRNO_TYPE;
#define TCD_FILENAME_LNG 128

/*-----------------
  Definitionen von Makros f�r Speicherallokation
-------------------*/  

/* WATCHMEM muss im TCDHUGE-Modus abgeschaltet sein */
#ifdef TCDHUGE
#undef WATCHMEM
#endif

#undef _TCDALLOC
#undef _TCDFREE
#undef _TCDREALLOC

#ifndef WATCHMEM

#define _TCDALLOC(len,size)    malloc( (size_t)(len) * (size)) ;
#define _TCDFREE(ptr)          {free(ptr), ptr = NULL;}
#define _TCDREALLOC(ptr,size)  realloc( ptr, (size_t)(size) ) ;

#else
 
void *MallocAndProt(char *sFile_,int iLine_, size_t size);
#define _TCDALLOC(len,size)\
 MallocAndProt(__FILE__,__LINE__,(len) * (size))

void FreeAndProt(char *sFile_, int iLine_, void *p_);

#define _TCDFREE(ptr)\
       {FreeAndProt(__FILE__, __LINE__, ptr) , ptr = NULL;}

void *ReallocAndProt(char *sFile_,int iLine_, void *p_, size_t size);
#define _TCDREALLOC(ptr,size)\
 ReallocAndProt(__FILE__, __LINE__, ptr,size)

void ResumeWatchmem();

#endif

/*-----------------
  modellabh�ngige Definitionen von Makros f�r Speicherallokation
-------------------*/
#undef _TCDTABALLOC
#undef _TCDTABFREE
#undef _TCDMEMINI

#ifdef TCDHUGE

#define _TCDTABALLOC(len,size)\
  _halloc( (long)(len) , (size_t)(size)) ;
#define _TCDTABFREE(ptr)\
      { _hfree ( (void huge *)ptr); ptr = NULL;}

#else

#ifndef WATCHMEM
#define _TCDTABALLOC(len,size)\
 malloc((size_t)((long)len) * ((size_t)size)) ;
#define _TCDTABFREE(ptr)       {free(ptr), ptr = NULL;}
#else
#define _TCDTABALLOC(len,size)\
 MallocAndProt(__FILE__,__LINE__,(len) * (size))
#define _TCDTABFREE(ptr)\
       FreeAndProt(__FILE__, __LINE__, ptr)
#endif

#endif


#ifdef TCDHUGE
#define _TCDMEMINI(ptr,size,nr)\
{\
   long       j;\
   TCD_LPCHAR lp;\
   for (j= 0 , lp = (TCD_LPCHAR)ptr;\
        j < ((long)(size) * (long)(nr)); j++, lp++) \
      *lp = 0;\
}  

#else
#define _TCDMEMINI(ptr,size,nr)\
 { memset (ptr, 0, (size_t) ((size) * (nr))) ; }
#endif
/*---------------------------------
  NON-Ansi-Namen mit oder ohne "_"
----------------------------------*/

/* #define NON_ANSI_WITHOUT__ */

#ifdef NON_ANSI_WITHOUT__
#define _fcvt fcvt
#endif

/*---------------------------
  ggf. Verkuerzung der Namen
-----------------------------*/
#ifdef TCD_NAMLEN8

#define TCDIMPReleaseProcData       TCD_0001
#define TCDIMPReleaseNodeData       TCD_0002
#define TCDIMPReleaseTabImpData     TCD_0003   

#define FetchFromGlobalErgebnisPool TCD_0004

#define DelEltFromSVect             TCD_0005
#define DelEltFromSVectByIndex      TCD_0006

#define DelEltFromVect              TCD_0007
#define DelEltFromVectByIndex       TCD_0008
                                
                                
#define ReleaseGlobalErgebnisPool   TCD_0009
#define ReleaseGlobalErgebnis       TCD_0010
#define ReleaseLocalErgebnisPool    TCD_0011

#define GetPrcDataSkal              TCD_0012
#define GetPrcDataTab               TCD_0013
#define GetPrcDataDat               TCD_0014
#define GetPrcDataFrm               TCD_0015

#define GetPrcAttrSkal              TCD_0016
#define GetPrcAttrTab               TCD_0017

#define GetSSAttrSkal               TCD_0018
#define GetSSAttrTab                TCD_0019

#define ErgPoolGetFirstInfo         TCD_0020
#define ErgPoolGetNextInfo          TCD_0021

#define DConstrAttrs                TCD_0022
#define DConstrAttrsResults         TCD_0023

#define GetRelAttrs                 TCD_0024

#define GetIndexToGlobalErgPool     TCD_0025
#define GetIndexToPaarListElt       TCD_0026

#define GetIndexToSS                TCD_0027
#define GetIndexToUes               TCD_0028
#define GetFromSS                   TCD_0029
#define GetFromUes                  TCD_0030

#define TCDIMPImportTreeData        TCD_0031
#define TCDIMPNFIntl                TCD_0032
#define TCDIMPGetNodeFromID         TCD_0033
#define TCDIMPGetNodeFromPath       TCD_0034
#define compBsearch                 TCD_0035
#define TCDIMPReleaseTreeData       TCD_0036 
#define TCDIMPReleaseTabData        TCD_0037  
#define DConstrTCD_C_G              TCD_0038
#define DDestrTCD_C_G               TCD_0039 
#define SConstrTCD_C_G              TCD_0040
#define DConstrTCDRbsSS             TCD_0041
#define SConstrTCDRbsSS             TCD_0042
#define SConstrTCDISSADATA          TCD_0043
#define SDestrTCD_C_G               TCD_0044
#define DDestrTCDRbsSS              TCD_0045
#define SDestrTCDRbsSS              TCD_0046
#define SDestrTCDISSADATA           TCD_0047
#define GetRbsSSFkt                 TCD_0048
#define TCDIMPGetTabIDAndTypFromPath TCD_0049
#define TCDIMPGetPathAndTypFromID    TCD_0050
#define TCDIMPReleaseTabTreeData     TCD_0051
#define TCDIMPImportTabTreeData      TCD_0052
#endif

#endif
 
/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDC_H)
#define TCDC_H

#ifdef TCDV2_5
#define TCDVERS 25
#endif
#ifdef TCDV3_0
#define TCDVERS 30
#endif
#ifndef TCDVERS
#error TCD Version muss in Makefiles angegeben werden.
#endif

/*---------
Name        : TCDC.H

Beschreibung: Zentrales Include File fuer die Anwendung
TCD weit gueltig
*----------*/

#include "p09115.h" /* direkte Vektoren */

#define  TCD_TRUE                1
#define  TCD_FALSE               0

/*---------
  Definitionen Opcodes
*----------*/
#define  TCD_OPC_INIT_RBS                    1
#define  TCD_OPC_CALC_FRM                    2
#define  TCD_OPC_CALC_PRC                    3
#define  TCD_OPC_GETNUM_FRM                  4
#define  TCD_OPC_GET_ATTR_VAL                5
#define  TCD_OPC_RESET_RBS                   6
#define  TCD_OPC_SET_PRC                     7
#define  TCD_OPC_RESET_PRC                   8
#define  TCD_OPC_SET_POOLTAB                 9
#define  TCD_OPC_RESET_POOLTAB              10
#define  TCD_OPC_SET_ATTR_VAL               11
#define  TCD_OPC_GET_PRC_INFO               12
#define  TCD_OPC_SET_POOLTAB_I              13
#define  TCD_OPC_RESET_POOLTAB_I            14
#define  TCD_OPC_SET_ATTR_IN_PRC            15
#define  TCD_OPC_SET_TRACE_ON               16
#define  TCD_OPC_SET_TRACE_OFF              17
#define  TCD_OPC_REMOVE_RESULTS             18
#define  TCD_OPC_GET_FIRST_RESULTS_INFO     19
#define  TCD_OPC_GET_NEXT_RESULTS_INFO      20

/*---------
  Definitionen Returncodes
*----------*/
#define  TCD_RC_NOT_OK              0
#define  TCD_RC_OK                  1
#define  TCD_RC_ILLOPC              2
#define  TCD_RC_VERSION_CONFLICT    3
#define  TCD_RC_UNKNOWN_FORM        4
#define  TCD_RC_ILLEGAL_FORM        5
#define  TCD_RC_ILLEGAL_PARAM       6
#define  TCD_RC_UNKNOWN_ATTR        7
#define  TCD_RC_NOT_FOUND           8
#define  TCD_RC_INPUT_MISSING       9
#define  TCD_RC_ILLEGAL_DIVISION   10
#define  TCD_RC_ILLEGAL_TAB_RANGE  11
#define  TCD_RC_STACK_OVERFLOW     12
#define  TCD_RC_CONDITION_FAIL     15
#define  TCD_RC_PAR_ERROR          20
#define  TCD_RC_TAB_IN_POOL        21
#define  TCD_RC_TAB_NOT_IN_POOL    22
#define  TCD_RC_PRC_IN_POOL        23
#define  TCD_RC_PRC_NOT_IN_POOL    24
#define  TCD_RC_UNKNOWN_PROC       25
#define  TCD_RC_PAARLISTEN_ERROR   26
#define  TCD_RC_NO_VALUE_AVAIL     30
#define  TCD_RC_USER_SET_ERROR    900
#define  TCD_RC_INTERNAL_ERR      999
#define  TCD_RC_NO_RETURN         888

/*---------
  allgemeine globale Konstanten
*----------*/
#define TCD_INIT_VARSETLEVEL    9999

/*---------
  Konfigurationsangaben
*----------*/
#define TCD_POOLADMIN_SIZE        20
#define TCD_C_MIN_USER_TYPE_ID    0
#define TCD_C_TABLISTLEN          10
#define TCD_C_MAXPRCCALLNR        2147483647

/*---------
  Definitionen Laengenangaben
*----------*/
#define TCD_DATUM_LNG              9
#define TCD_FRM_DATUM_LNG         20
#define TCD_VGLOP_LNG              3
#define TCD_NAME_LNG              26

/*---------
  Definitionen Aufrufart: (Aufzaehlungstyp)
-----------*/
#define TCD_CALLTYP_ATTR        1
#define TCD_CALLTYP_STA         2
#define TCD_CALLTYP_DYN         3
#define TCD_CALLTYP_STA_UE      4

/*---------
  Definitionen Prefix
-----------*/
#define TCD_PREFIX_TAB            '&'
#define TCD_PREFIX_PRC            '$'
#define TCD_PREFIX_FRM            'F'
#define TCD_PREFIX_ATTR           'A'

/*---------
  Definitionen Formeltypen (Aufzaehlungstyp, Wertevergabe analog Cobol)
-----------*/
#define TCD_FRMTYP_SKAL        1
#define TCD_FRMTYP_TAB1        2
#define TCD_FRMTYP_TAB2        3

/*---------
  Definitionen Belegungswerte PoolEntry
-----------*/
#define  TCD_POOLENT_INIT          0
#define  TCD_POOLENT_USED          1
#define  TCD_POOLENT_I_USED        2
#define  TCD_POOLENT_E_USED        3

/*---------
  Definitionen Assigntype
*----------*/
#define  TCD_DC_USE_NOT            0
#define  TCD_DC_USE_FRM            1
#define  TCD_DC_USE_PRC            2
#define  TCD_DC_USE_TAB            3
#define  TCD_DC_USE_VAL            4

/*----------
  Definitionen Formattypen
-----------*/
#define  TCD_ATTRFMT_SKAL          1
#define  TCD_ATTRFMT_TAB1          2
#define  TCD_ATTRFMT_TAB2          3
#define  TCD_ATTRFMT_VGLO          4
#define  TCD_ATTRFMT_DATE          5

/*----------
  Struktur Bestandsattributtabelle
 ----------*/
  typedef struct tagS_TCDATAB {
        char          Name [TCD_NAME_LNG] ;
        TCD_LONG      ID         ;
        TCD_INT       Index      ;
        TCD_INT       AttrTyp    ;
  } S_TCDATAB     ;

 typedef S_TCDATAB     * P_TCDATAB     ;

/*----------
  Struktur Tabelle aller Attribute
 ----------*/
  typedef struct tagS_ATTRTAB
  {
    TCD_LONG  ID    ;
    TCD_INT   Index ;
  } S_ATTRTAB ;

  typedef S_ATTRTAB    * P_ATTRTAB     ;

/*----------
  Typdefinition systemunabhanegiger Typen
 ----------*/
   typedef  char  TCD_VGLOP [TCD_VGLOP_LNG] ;
   typedef  char  TCD_DATUM [TCD_DATUM_LNG] ;

   typedef TCD_DOUBLE TCDTAB1 ;
   typedef P_TCDTAB   P_TCDTAB1 ;

   typedef TCD_DOUBLE TCDTAB2 ;
   typedef P_TCDTAB   P_TCDTAB2 ;

   typedef P_P_TCD_DOUBLE P_P_TCDTAB ;

/*---------
  Union Attributbelegung
 ----------*/
  typedef  union tagU_TCDVALUE {
           TCD_DOUBLE        Skalar;
           P_TCDTAB1         pTab1 ;
           P_TCDTAB2         pTab2 ;
   } U_TCDVALUE ;

  typedef  union tagU_TCDGVALUE {
           TCD_DOUBLE        Skalar;
           P_TCDTAB          pTab  ;
           TCD_VGLOP         VglOp ;
           TCD_DATUM         Datum ;
   } U_TCDGVALUE ;

/* --
 MUB 2.7.96: neu eingefuehrt, weil wir die TabellenID brauchen
--  */
  typedef  union tagU_TCDWVALUE
  {
           TCD_DOUBLE        Skalar;

           TCD_LONG          TabID ;  /*  die relevanten Attribute */
           P_TCDTAB1         pTab  ;  /*  das Ergebnis */

           TCD_VGLOP         VglOp ;
           TCD_DATUM         Datum ;
   } U_TCDWVALUE ;

  typedef struct tagS_TCDPRCVAL {
          TCD_LONG   PrcID ;
          TCD_LONG   FormelNr ;
          TCD_INT    FormelIx ;
          char       FormelName [TCD_NAME_LNG] ;
          TCD_INT    PoolIx ;
#if TCDVERS > 25
/* Version der Formel zur Pruefung 
		  Formel-Generat gegen Transport-Format */
          TCD_INT    FormelVers;
#endif

 } S_TCDPRCVAL ;

  typedef union  tagU_TCDNDVALUE {
          struct   tagTabData {
             TCD_LONG  TabID ;
             TCD_INT   PoolIx ;
          } TabData  ;
          TCD_DOUBLE Skalar ;
          char       Datum [TCD_DATUM_LNG] ;
          char       VglOp [TCD_VGLOP_LNG];
 } U_TCDNDVALUE ;


  typedef struct tagS_TCDFORMEL {
           TCD_LONG  FormelNr ;
           TCD_INT  FormelIx ;
           char     FormelName [TCD_NAME_LNG] ;
           TCD_INT  IsStaRef ;                                 
#if TCDVERS > 25
/* Version der Formel zur Pruefung 
		   Formel-Generat gegen Transport-Format */
		   TCD_INT  FormelVers;
#endif
 } S_TCDFORMEL ;

  typedef union  tagU_TCDASSIGNVAL {

       S_TCDPRCVAL  Prc    ;
       U_TCDNDVALUE Val    ;
       S_TCDFORMEL  Formel  ;

 } U_TCDASSIGNVAL ;

#define TYP3_NOT_OVERWRITTEN 2

typedef struct tagS_TCDREL_ATTR
{                                 
   TCD_LONG    iBerechnungsNummer;
   /* ID des Attributs                            */
   TCD_LONG    AttrID                  ;  
   /* Typ der Belegung SKALAR, TAB, DATUM , VGLOP */
   TCD_INT     AttrType              :4;  
   /* Flag, ob ein geerbter Wert vorhanden ist    */
   TCD_INT     bGeerbterWertVorhanden:2;  
   /* Flag, ob ein geerbter Wert vorhanden ist    */
   TCD_INT     bNotOverwritten         ;
   /* GGf. Wert hierzu                            */
   U_TCDWVALUE Belegung                ;  

}  S_TCDRELATTR;

typedef S_TCDRELATTR * P_TCDRELATTR ;

/* --
   S_TCDRELATTR_IMP    Relevantes Attribut fuer den Import
--  */
typedef struct tagS_TCDREL_ATTR_IMP
{
   TCD_LONG AttrID;
   TCD_INT  AttrType               : 4;
   TCD_INT  iIndex;

}  S_TCDRELATTR_IMP;

typedef S_TCDRELATTR_IMP * P_TCDRELATTR_IMP ;

/* --
   S_PAARLISTEN_EL    Struktur fuer ein PaarlistenElement
--  */
typedef struct tagS_PAARLISTEN_EL
{
   /* Vektor der relevanten Attribute mit der aktuellen Belegung     */
   LP_VECT          pAttrs;        
   /* lfde. Nummer der aktuellen Berechnung                          */
   TCD_LONG         iBerechnungsNummer; 
   
   TCD_LONG         lTabZeilen;         
   TCD_LONG         lTabSpalten;
   
   /* Typ des Ergebnisses (kann 'NOT_OVERWRITTEN' sein)              */
   TCD_INT          iType;              
   /* Ergebnis hierzu                                                */
   U_TCDWVALUE      Ergebnis;           

}  S_PAARLISTEN_EL;

typedef S_PAARLISTEN_EL * P_PAARLISTEN_EL ;

/* --
   S_PAARLISTE     Struktur zu einem Belegknoten einer BV
   Sie enthaelt 1 sortierten Vektor, 1 Liste und eine maximale Laenge
   fuer die Anzahl Elemente der Paarliste (Belegung,Ergebnis)
--  */
typedef struct tagS_PAARLISTE
{
   TCD_INT iWiederVerwendungsTyp;   /* KnotenTyp 1/2/3     */
   TCD_INT iWiederVerwListenLaenge; /* ListenLaenge maximal */
   TCD_INT iAct ;                   /* letztes Element     */

   /* direkter Vektor von S_ATTR_EL's   */
   LP_VECT pAttrs;                  
   /* direkter Vektor von S_PAARLISTEN_EL's */
   LP_VECT pPaarListenElts;         

}  S_PAARLISTE;

typedef S_PAARLISTE * P_PAARLISTE ; 

/* --
   S_ERGEBNIS_POOL_ELT Element eines PoolErgebnisses
--  */
typedef struct tagS_ERGEBNIS_POOL_ELT
{
   TCD_LONG    ID;
   P_PAARLISTE pPaarListe;

}  S_ERGEBNIS_POOL_ELT;

typedef S_ERGEBNIS_POOL_ELT * P_ERGEBNIS_POOL_ELT ;

/*-----------
  Struktur     Belegungsknoten
------------*/
  typedef struct tagS_TCDPRCNODE
  {
      TCD_LONG         AttrID                  ;
      TCD_INT          NodeID                  ;
      TCD_INT          AttrType                ;
      TCD_INT          AssignType              ;
      U_TCDASSIGNVAL   AssignVal               ;
      TCD_INT          SuccNodeIx              ;
      TCD_INT          AnzSuccNodes            ;
      TCD_INT          Usage                   ;

      P_PAARLISTE      pPaarListe              ;
      P_PAARLISTEN_EL  pResultForGetAttr       ;

      TCD_INT          iWiederVerwendungsTyp   ;
      TCD_INT          iWiederVerwListenLaenge ;
      TCD_INT          iAnzRelAttrs            ;
      TCD_INT          iFirstRelAttrIx         ;

  }   S_TCDPRCNODE ;

 typedef S_TCDPRCNODE  * P_TCDPRCNODE ;

/*-----------
  Struktur Auspraegungs-Belegungs-Information
------------*/
  typedef struct tagS_TCDPRCINFO {
         char  Name [TCD_NAME_LNG] ;
         TCD_LONG  ID ;
         TCD_INT   Formattyp ;
         TCD_INT   Typ ;
         TCD_INT   Klasse ;
         TCD_INT   AnzBeleg ;
         TCD_INT   TabIx ;
         TCD_LONG  RefNodeId ;
 } S_TCDPRCINFO ;

 typedef S_TCDPRCINFO  * P_TCDPRCINFO ;

/*--------
  Struktur LocalData MUB 2.7.96: wird nicht mehr verwendet!
 --------*/
  typedef struct tagS_TCDPRCLOCD {
          TCD_LONG FormelNr     ;
          TCD_INT  Usage        ;
          TCD_INT  Typ          ;
          union   {
              TCD_INT    PoolIx ;
              TCD_DOUBLE Val    ;
          } Data ;
          TCD_LONG  CalcByCallNr ;
   } S_TCDPRCLOCD ;

   typedef S_TCDPRCLOCD * P_TCDPRCLOCD ;

/*---------
  Struktur Header Auspraegungsbaum
----------*/
  typedef struct tagS_TCDPRCHDR {
    TCD_LONG       PrcID        ;
    TCD_LONG       FormelNr     ;
    TCD_INT        AnzPrcTree   ;
    TCD_INT        AnzBelegInfo ;
    TCD_INT        AnzRelAttrs  ;
    TCD_BOOL       FlSetAttrSkal;
    TCD_BOOL       FlSetAttrTab ;
    TCD_BOOL       FlSetAttrVgl ;
    TCD_BOOL       FlSetAttrDat ;
    TCD_BOOL       FlPrcCompl   ;
    TCD_LONG       PrcResIx     ;
    TCD_LONG       PrcCallNr    ;

 } S_TCDPRCHDR     ;


/*---------
  Struktur Auspraegungselement
-----------*/
  typedef union  tagU_TCDPRCELEM
  {
     S_TCDPRCHDR      TreeHdr;
     S_TCDPRCNODE     Node ;
     S_TCDPRCINFO     Info ;     
  }  U_TCDPRCELEM ;

 typedef U_TCDPRCELEM  * P_TCDPRCELEM ;

#define TCDPRCSIZE(pPrc)    (pPrc ? sizeof(S_TCDRELATTR_IMP)*\
                            (TCD_LONG)pPrc->TreeHdr.AnzRelAttrs +\
                            sizeof(U_TCDPRCELEM)*\
                            ( (TCD_LONG)pPrc->TreeHdr.AnzPrcTree +\
                             (TCD_LONG)pPrc->TreeHdr.AnzBelegInfo) : 0)


/*-------
  Datenstruktur Mehrfach-Auspraegung (MultiProc)
 --------*/
  typedef struct tagS_TCDMPRCENTRY {
        TCD_INT              PrcBelegt ;
        TCD_LONG             ID ;
        P_TCDPRCELEM         pPrcData ;
 } S_TCDMPRCENTRY ;

  typedef S_TCDMPRCENTRY * P_TCDMPRCENTRY ;

  typedef struct tagS_TCDMPRCADMIN {
        TCD_INT          Anzahl  ;
        P_TCDMPRCENTRY   Data    ;
 } S_TCDMPRCADMIN ;

 typedef S_TCDMPRCADMIN * P_TCDMPRCADMIN ;

/*--------
  Datenstruktur PoolAdmin
--------*/
  typedef struct tagS_TCDPOOLENTRY {
        TCD_LONG     ID ;
        TCD_INT      Usage ;
        TCD_INT      Typ ;
        TCD_INT      Fmttyp ;
        P_TCD_DOUBLE pData ;
  } S_TCDPOOLENTRY ;

  typedef S_TCDPOOLENTRY * P_TCDPOOLENTRY ;

  typedef struct tagS_TCDPOOLADMIN {
        TCD_INT          Anzahl  ;
        TCD_INT          AnzTabs ;
        TCD_INT          AnzProcs ;
        TCD_INT          AnzTemp  ;
        S_TCDPOOLENTRY * Data    ;
 } S_TCDPOOLADMIN ;

  typedef S_TCDPOOLADMIN * P_TCDPOOLADMIN ;

/*------
  Datenstruktur Kontrollstruktur
--------*/
  typedef struct tagS_TCDRBSINFO {
       char TcdVersion [TCD_DATUM_LNG]   ;
       char TcdRelease [TCD_DATUM_LNG]   ;
       char RbsInterf  [TCD_DATUM_LNG]   ;
       TCD_LONG RbsId ;
   } S_TCDRBSINFO ;

   typedef struct tagS_TCDRCINFO {
       TCD_INT   Rc ;
       TCD_INT   Errc ;
       char FormelName [TCD_NAME_LNG] ;
       TCD_INT   FormelNr ;
       char AttrName   [TCD_NAME_LNG] ;
   } S_TCDRCINFO          ;

   typedef S_TCDRCINFO * P_TCDRCINFO ;


   typedef struct tagS_TCDCTLPAR {

/*-
  Opcode:   TCD_OPC_GET_ATTR_VAL, TCD_OPC_SET_ATTR_VAL
--*/
        struct tagS_TCDPARGA {
           TCD_LONG    ProcID;
           TCD_LONG    ID;
           TCD_LONG    TabID;
           TCD_INT     TabIx ;
           U_TCDGVALUE Val ;
           TCD_INT     Typ ;
           TCD_INT     ProcIx;
        }            GA ;

/*-
  Opcode:   TCD_OPC_SET_POOLTAB
--*/
        struct tagS_TCDPARST {
            TCD_LONG  ID;
            TCD_INT   Dim ;
            P_TCDTAB  pTab ;
            TCD_INT    TabIx ;
        }            ST ;

/*-
  Opcode:   TCD_OPC_RESET_POOLTAB
--*/
        struct tagS_TCDPARRT{
            TCD_LONG  ID;
            P_TCDTAB  pTab ;
        }            RT ;

/*-
  Opcode:   TCD_OPC_SET_PRC
--*/
        struct tagS_TCDPARSP {
            TCD_LONG      ProcID;
            P_TCDPRCELEM  pProc;
            TCD_INT       ProcIx;
        }            SP;

/*-
  Opcode:   TCD_OPC_RESET_PRC
--*/
        struct tagS_TCDPARRP {
            TCD_LONG  ProcID;
            P_TCDPRCELEM  pProc;
        }            RP;

/*-
  Opcode:   TCD_OPC_CALC_FRM , TCD_OPC_CALC_PRC
--*/
        struct tagS_TCDPARCFP {
            TCD_LONG       FormelNr ;
            TCD_LONG       ProcID;
            TCD_INT        Typ ;
            U_TCDVALUE     Value ;
            TCD_INT        ProcIx;
        }            CFP ;

/*-
  Opcode:   TCD_OPC_GETNUM_FRM
--*/
        struct tagS_TCDPARGF {
            char  Name [TCD_NAME_LNG] ;
            TCD_LONG  FormelNr ;
        }            GF ;

/*-
  Opcode:   TCD_OPC_GET_PRC_INFO
--*/
        struct tagS_TCDPRCBINFO {
            TCD_LONG        ProcID;
            TCD_INT         ProcIx;
            P_TCDPRCELEM    pProcInfo;
            TCD_INT         AnzProcInfo ;
        }            PI ;

/*-
  Opcode:   TCD_OPC_REMOVE_RESULTS,
            TCD_OPC_GET_FIRST_RESULTS_INFO,
            TCD_OPC_GET_NEXT_RESULTS_INFO
--*/
        struct tagS_TCDPAR_RESULTPOOL {
            TCD_LONG        ProcID;
            TCD_LONG        lNumOfResults;
            TCD_INT         bFinished;
        }            RESP ;

   } S_TCDCTLPAR ;

   typedef S_TCDCTLPAR * P_TCDCTLPAR ;

   typedef struct tagS_TCDRBSCTL {
          TCD_INT       Opc     ;
          S_TCDRBSINFO  RbsInfo ;
          S_TCDRCINFO   RCInfo  ;
          S_TCDCTLPAR   Par     ;
  } S_TCDRBSCTL ;

   typedef S_TCDRBSCTL * P_TCDRBSCTL ;

/*------
  Datenstruktur Rechenbausteinschnittstelle
 --------*/
   typedef struct tagS_TCDV_F_FLAGS {
         TCD_BOOL       V_In   ;
         TCD_BOOL       F_In   ;
         TCD_BOOL       V_Comp ;
         TCD_BOOL       V_Use  ;
         TCD_BOOL       F_Use  ;
         TCD_BOOL       V_Miss ;
         TCD_BOOL       F_Miss ;
   } S_TCDV_F_FLAGS ;

   typedef S_TCDV_F_FLAGS * P_TCDV_F_FLAGS ;

   typedef struct tagS_TCDV_FLAGS {
         TCD_BOOL       V_In   ;
         TCD_BOOL       V_Use  ;
         TCD_BOOL       V_Miss ;
   } S_TCDV_FLAGS ;

   typedef S_TCDV_FLAGS   * P_TCDV_FLAGS   ;

   typedef struct tagS_TCDSKAL_DATA
   {
        TCD_DOUBLE      Val    ;
        TCD_LONG        Formel ;
        S_TCDV_F_FLAGS  Flags  ;
   } S_TCDSKAL_DATA ;

   typedef S_TCDSKAL_DATA * P_TCDSKAL_DATA ;

   typedef struct tagS_TCDTAB1_DATA
   {
     TCD_LONG        TabID;
     P_TCDTAB1       pVal ;
     TCD_LONG        Formel ;
     S_TCDV_F_FLAGS  Flags ;

   } S_TCDTAB1_DATA ;
   typedef S_TCDTAB1_DATA  * P_TCDTAB1_DATA  ;

   typedef struct tagS_TCDTAB2_DATA
   {
     TCD_LONG        TabID;
     P_TCDTAB2       pVal ;
     TCD_LONG        Formel ;
     S_TCDV_F_FLAGS  Flags ;

   } S_TCDTAB2_DATA ;
   typedef S_TCDTAB2_DATA * P_TCDTAB2_DATA ;

   typedef struct tagS_TCDDAT_DATA {
        char             Val [TCD_DATUM_LNG] ;
        S_TCDV_FLAGS     Flags ;
   } S_TCDDAT_DATA ;

   typedef S_TCDDAT_DATA * P_TCDDAT_DATA ;

   typedef struct tagS_TCDVGL_DATA {
        char            Val [TCD_VGLOP_LNG] ;
        S_TCDV_FLAGS    Flags ;
   } S_TCDVGL_DATA ;

   typedef S_TCDVGL_DATA * P_TCDVGL_DATA ;

   typedef struct tagS_TCD_RBS_SSA
   {
        P_TCDSKAL_DATA    pSkal ;
        P_TCDTAB1_DATA    pTab1 ;
        P_TCDTAB2_DATA    pTab2 ;
        P_TCDDAT_DATA     pDat  ;
        P_TCDVGL_DATA     pVgl  ;
   } S_TCD_RBS_SSA ;

   typedef S_TCD_RBS_SSA  * P_TCD_RBS_SSA ;


   typedef struct tagS_TCDRBS_SS {
       S_TCDRBSCTL       RCTL ;
       S_TCD_RBS_SSA     SSAData   ;
       S_TCDPOOLADMIN    PoolAdmin ;
       S_TCDMPRCADMIN    MPrcAdmin ;
 } S_TCDRBS_SS ;

 typedef S_TCDRBS_SS  * P_TCDRBS_SS ;

  typedef struct tagS_TCDPARATTR_SK {
        TCD_INT      Level ;
        TCD_DOUBLE   Val ;
 } S_TCDPARATTR_SK   ;

 typedef S_TCDPARATTR_SK  * P_TCDPARATTR_SK ;

  typedef struct tagS_TCDPARATTR_VGL {
        TCD_INT      Level;
        char         Val  [TCD_VGLOP_LNG] ;
 } S_TCDPARATTR_VGL  ;

 typedef S_TCDPARATTR_VGL * P_TCDPARATTR_VGL ;

  typedef struct tagS_TCDPARATTR_DAT
  {
        TCD_INT      Level;
        char         Val  [TCD_DATUM_LNG] ;
 } S_TCDPARATTR_DAT  ;

 typedef S_TCDPARATTR_DAT * P_TCDPARATTR_DAT ;

/*-----------
  Struktur Schnittstellendaten (interne Sicht)
-----------*/
  typedef struct tagS_TCDISSADATA
  {
     TCD_INT      AnzSSASkal ;
     TCD_INT      AnzSSATab1 ;
     TCD_INT      AnzSSATab2 ;
     TCD_INT      AnzSSADat ;
     TCD_INT      AnzSSAVgl ;
     TCD_INT      AnzParSkal;
     TCD_INT      AnzParVgl ;
     TCD_INT      AnzParDat ;
     TCD_INT      AnzZeilen ;
     TCD_INT      AnzSpalten ;
     P_TCDSKAL_DATA    pSkal ;
     P_TCDTAB1_DATA    pTab1 ;
     P_TCDTAB2_DATA    pTab2 ;
     P_TCDDAT_DATA     pDat ;
     P_TCDVGL_DATA     pVgl ;
     P_TCDPARATTR_SK   pParSkal ;
     P_TCDPARATTR_VGL  pParVgl;
     P_TCDPARATTR_DAT  pParDat;

 }   S_TCDISSADATA ;
 typedef S_TCDISSADATA * P_TCDISSADATA ;



/*------
Datenstruktur globale Daten des Rechenbausteins;
diese Datenstruktur enthaelt Informationen und Teilstrukturen, die
in den programmierten Funktionen benoetigt werden.
Initialisierung dieser Daten erfolgt mehrstufig.
- beim Init: globaler Pointer pTCDTCD initialisiert (zeigt auf die Str)
pRbsSS zeigt auf die RBS-Schnittstelle
- bei auspraegungsspez. Opcodes werden die Teilstrukturen fuer die
Auspraegung initialisiert, ...
- bei einer neuen Berechnung werden die internen Aufrufschnittstellen
initialisiert
--------*/
  typedef struct tagS_TCD_C_G
  {
      P_TCDRBS_SS      pRbsSS      ;
      P_TCDPRCELEM     pPrcData    ;
      S_TCDPRCHDR *    pPrcHdr     ;
      P_TCDPRCELEM     pPrcTreeNode;
      P_TCDPRCELEM     pInfo       ;
      P_TCDRELATTR_IMP pRelAttrs   ;
      P_TCDMPRCADMIN   pMPrcAdmin  ;
      P_TCDRBSCTL      pRbsCtl     ;
      S_TCDISSADATA    SSAData     ;
      P_TCDPOOLADMIN   pPoolAdmin  ;
      TCD_INT          GlbVarSet   ;
      TCD_LONG         RBS_ID      ;
      TCD_BOOL         ValFound    ;
      TCD_BOOL         FrmFound    ;
      TCD_BOOL         V_Comp      ;
      TCD_BOOL         PrcChg      ;
      void *           pApplIf     ;
      P_TCDTAB         ResTab      ;
      TCD_DOUBLE       ResSkal     ;
      
      TCD_LONG         LastCalcPrcID;
      LP_VECT          pErgebnisPool;
      TCD_LONG         iBerechnungsNummer;
      TCD_INT          iErgPoolIteratorGl;                       
      P_PAARLISTE      pPaarListeNotToSave;
      
      TCD_BOOL         btrace_open;
      TCD_BOOL         btrace_enabled;
      
/* RWE, 10.06.1997: Neues Datenelement fuer Beobachtung
   der Wiederverwendung (ehemals WatchPol-Funktionalitaet) */
      TCD_BOOL         bProtWV;
      
  }   S_TCD_C_G ;
  typedef S_TCD_C_G   * P_TCD_C_G ;
#endif
 
/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDI_H)
#define TCDI_H
/*--------------
    Name        : TCDI.H

    Beschreibung: Include File intern nur f�r C- Generator
                  wird von den fest programmierten Moduln und
                  generierten Moduln benoetigt
    By          : BEGGI
    Datum       : 22.02.94
    Historie    : BEG   28.11.95   Definition Attributklassen
*--------------*/

/*-------------
  Returncodes FrmRet und ValRet (Definitionen analog Cobol) fuer
  Attributmanager
---------------*/
#define TCD_AIRC_CALLVIAFRM    4

/*-------------
  Definitionen Attributtypen (Aufzaehlungstyp)
---------------*/
#define TCD_ATTYP_TAR_SKAL      1
#define TCD_ATTYP_TAR_TAB1      2
#define TCD_ATTYP_TAR_TAB2      3
#define TCD_ATTYP_TAR_DATE      4
#define TCD_ATTYP_TAR_VGLO      5
#define TCD_ATTYP_BST_SKAL      6
#define TCD_ATTYP_BST_TAB1      7
#define TCD_ATTYP_BST_TAB2      8
#define TCD_ATTYP_BST_DATE      9
#define TCD_ATTYP_BST_VGLO     10

#define TCD_ATTRTYP_SKAL        0
#define TCD_ATTRTYP_TAB1        1
#define TCD_ATTRTYP_TAB2        2
#define TCD_ATTRTYP_DATE        3
#define TCD_ATTRTYP_VGLO        4

/*--------------
  Definitionen Attributklasse
---------------*/
#define TCD_ATTRCLASS_TAR       1
#define TCD_ATTRCLASS_BST       6

/*-------------
  Definitionen Errorcodes
---------------*/
#define TCD_UNKNOWN_OPCODE       1
#define TCD_NO_SPACE_IN_TLIST    2
#define TCD_ERR_GETMEM           3
#define TCD_GETEMPTYENTRY        4
#define TCD_NOPOOLADMIN          5
#define TCD_ILLTABFMT            6
#define TCD_UNK_ASSIGNTYP        7
#define TCD_NO_MPRCADMIN         8
#define TCD_EXPPOOLADMIN         9
#define TCD_NO_MEMORY           10
#define TCD_NO_PRCREF           11
#define TCD_ILLFRM_ID           12
#define TCD_ILLFRM_CMP          13
#define TCD_ERR_INIT_FORMEL     14
#define TCD_FRMGEN_OUT_OF_DATE	15
#define TCD_TRPFMT_OUT_OF_DATE	16

/*----------
  Datenstruktur Freigabeliste  Hilfsvariablentabellen
 ------------*/
  typedef struct tagS_TCDTABLIST    {
         TCD_INT        CallOvw ;
         TCD_LONG       CallerID ;
         TCD_LONG       CallFrmNr ;
         TCD_INT        CallType  ;
         P_TCD_DOUBLE   Adr ;
 } S_TCDTABLIST   ;

 typedef  S_TCDTABLIST  * P_TCDTABLIST  ;

/*----------
  Datenstruktur Formelparameter
 ------------*/
  typedef struct tagS_TCD_C_F1 
  {
     char         * FormelName     ;
     TCD_INT        FrmTyp         ;
     TCD_LONG       FrmNr          ;
     TCD_INT        FrmIx          ;
     char         * AttrName       ;
     TCD_INT        CallType       ;
     TCD_LONG       AttrID         ;
     TCD_INT        AttrTyp        ;
     TCD_INT        AttrIx         ;
     TCD_INT        ParIx          ;
     TCD_INT        Ret            ;
     TCD_INT        ExecCond       ;
     P_TCDPRCNODE   PrcFNode       ;
     P_TCDPRCNODE   pNode          ;
     TCD_INT        MinVarSet      ;
     TCD_INT        BegVarSet      ;
     char         * CmpTime        ;
     TCD_INT        Level          ;
     P_TCD_DOUBLE   pVarSkal       ;
     P_P_TCDTAB     pVarTab        ;
     char         * VarDatVgl      ;
     TCD_INT      * VarIndex       ;
     P_TCDTABLIST   FreeList       ;
     TCD_INT        AnzTabList     ;
     TCD_INT        AnzTabListEnt  ;
     P_TCDPRCNODE   NextFNode      ;
     TCD_INT        NextExecCond   ;
     TCD_INT        NextCallType   ;
     struct tagS_TCD_C_F1 * pPrevLevelInfo ;
     P_TCD_C_G      pTCDTCD ;
  } S_TCD_C_F1 ;

  typedef  S_TCD_C_F1 *   P_TCD_C_F1 ;

  typedef struct tagS_TCDFTAB {
        char          FrmName [TCD_NAME_LNG] ;
        void          (* pFormelFunc ) ( P_TCD_C_F1);
        TCD_LONG      FrmNr      ;
        TCD_INT       FrmTyp     ;
        char          Datum [TCD_FRM_DATUM_LNG] ;
  } S_TCDFTAB     ;

 typedef S_TCDFTAB     * P_TCDFTAB     ;

/* extern P_TCD_C_G pTCDTCD ; */

#endif

 
/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_POOL_H)
#define TCD_POOL_H
/*---------------------------------------------------------------------
  Datei      : TCD_POOL.h
  Generiert am 16.12.2019 15:07:18
  Historie      : 27.7.95    BEG neuer Prefix fuer Tabellenentry
---------------------------------------------------------------------*/
void    TCDPIT   (P_TCD_C_G);
void    TCDPRP   (P_TCD_C_G) ;
void    TCDPST   (P_TCD_C_G) ;
void    TCDPRT   (P_TCD_C_G) ;
void    TCDPSAT  (P_TCD_C_G) ;
void    TCDPRTA  (P_TCD_C_G) ;
TCD_INT TCDPGF   (P_TCD_C_G,P_TCD_DOUBLE Var, TCD_INT *PIndex) ;

#endif
 
/*---------------------------------------------------------------------------

(C) Copyright 1993-2002, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------------*/
#if !defined (TCD_ATTR_H)
#define TCD_ATTR_H
/*---------------------------------------------------------------------
  Datei:        TCD_ATTR.H
  Beschreibung: Attributmanager
---------------------------------------------------------------------*/
TCD_INT   TCDAATS (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAATT (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAABS (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAABT (P_TCD_C_F1 pF1) ;
void      TCDAATD (P_TCD_C_F1 pF1) ;
void      TCDAABD (P_TCD_C_F1 pF1) ;
void      TCDAATV (P_TCD_C_F1 pF1) ;
void      TCDAABV (P_TCD_C_F1 pF1) ;
void      TCDAFT  (P_TCD_C_F1 pF1) ;
void      TCDAFBS (P_TCD_C_F1 pF1) ;
void      TCDAFBT (P_TCD_C_F1 pF1) ;

#endif
 
/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_DAT_H)
#define TCD_DAT_H
/*---------------------------------------------------------------------
  Datei:   TCD_DAT.h
  Beschreibung: Schnittstelle zum Datenmanager.
  Historie:       06.03.96  BEG   Datei gefreezt
              06.03.96  BEG   Erweiterungen, neue ext. Funktion TCDDSV
              20.06.96  RWE   neue Prototypen        
              13.10.96  MUB   Schnittstellen um pTCDTCD erweitert
---------------------------------------------------------------------*/
void  TCDDIP (P_TCD_C_G pTCDTCD) ;
void  TCDDGPI(P_TCD_C_G pTCDTCD) ;
void  TCDDGA (P_TCD_C_G pTCDTCD) ;
void  TCDDSA (P_TCD_C_G pTCDTCD) ;
void  TCDDSP (P_TCD_C_G pTCDTCD) ;
void  TCDDRP (P_TCD_C_G pTCDTCD) ;
void  TCDDSV (P_TCD_C_G pTCDTCD) ;

void          ReleasePrcAttrResults   (P_TCDPRCELEM);
void          ReleaseMPrcAttrResults  (P_TCDMPRCADMIN);
P_TCDPRCELEM  MPrcAdminGetPrc         (P_TCDMPRCADMIN,TCD_LONG);

#endif
 
/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_FRT_H)
#define TCD_FRT_H
/*---------------------------------------------------------------------
    Datei:        TCD_FRT.H

Beschreibung: Modul zur allgemeinen Endebehandlung einer Formelfunktion
By:           BEGGI
Datum:        30.03.94
Historie:     BEG    28.11.95  neue Funktion: TCDSetPD
---------------------------------------------------------------------*/
TCD_INT TCDInit (P_TCD_C_F1 pMyPar, TCD_INT FrmNr, char *fctl_cmptime,
				 TCD_LONG VerNr);
void    TCDFtID (P_TCD_C_F1 pMyPar, char * AttrName,
                 TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                 TCD_INT *Var) ;

void    TCDSetPS (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                 TCD_DOUBLE *Var1, TCD_INT *Var2, TCD_DOUBLE Var3) ;
void    TCDSetPV (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                  char *Var1, TCD_INT *Var2, char *Var3) ;
void    TCDSetPD (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                  char *Var1, TCD_INT *Var2, char *Var3) ;

TCD_INT TCDGetTb (P_TCD_C_F1 pMyPar, P_P_TCDTAB Var) ;
void    TCDIniPS (P_TCD_C_G) ;

void    TCDIniFC (P_TCD_C_G) ;
void    TCDIniFU (P_TCD_C_G) ;
void    TCDIniFM (P_TCD_C_G) ;

void    TCDRetSk (P_TCD_C_F1 pMyPar, P_TCD_DOUBLE  VarSkal) ;
void    TCDRetTb (P_TCD_C_F1 pF1, P_P_TCDTAB  VarTab) ;

/*-----------------
  TraceFunktionsprototypen und Trace Makros
-------------------*/
#ifdef TRACEFKT
void _TCD_TRACE( const char * ,const char * ,const char *,P_TCD_C_G );
void _TCD_TRVAL( const char * , int , double *, double,P_TCD_C_G  ) ;

#define TCD_TRACE(pack,func,text, pTCDTCD)  \
            _TCD_TRACE(pack,func,text, pTCDTCD);
#define TCD_TRVAL(text,type,val1,val2, pTCDTCD) \
            _TCD_TRVAL(text,type,val1,val2, pTCDTCD);
#endif

#define C_TRACEFILE        "CTRACE.TCD"

#endif
  
/* RWE, 10.06.1997   */
/*-----------------
  Funktionsprototypen fuer Wiederverwendungsprotokoll
-------------------*/ 
#ifdef PROTWV
void     SetProtWV             (P_TCD_C_G pIf, TCD_BOOL bProtWV);   
  /* ^Dieser Prototyp ist auch in commands.c enthalten! */
TCD_BOOL ProtWVEnabled         (P_TCD_C_G pIf);
void     ProtWV1               (P_TCD_C_F1 pMyPar); 
void     ProtWV2               (P_TCD_C_F1   pMyPar, 
                                P_TCDPRCNODE pNode,
                                P_PAARLISTE  pPaarListe, 
                                TCD_INT      iFlag);
void     ProtWVString          (char *s);
                                
#define C_PROTWVFILE       "CPROTWV.TCD"
#endif
 
/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_FCTL_H)
#define TCD_FCTL_H
/*---------------------------------------------------------------------
  Modul:   TCD_FCTL.H
  f�r RBS: LifeTemplate
---------------------------------------------------------------------*/

void  LifeTemF(P_TCD_C_G pTCDTCD) ;
void  LifeTem1(P_TCD_C_F1  pF1 ) ;
void    TCD3FES (P_TCD_C_F1 pMyPar, char * AttrName, TCD_INT Ix,
                       TCD_LONG ID, TCD_INT AttrTyp, TCD_INT ParIx,
                       P_TCD_DOUBLE Var) ;
void    TCD3FET (P_TCD_C_F1 pMyPar, char * AttrName, TCD_INT Ix,
                      TCD_LONG ID, TCD_INT AttrTyp, P_P_TCDTAB Var);
void    TCD3FED (P_TCD_C_F1 pMyPar, char * AttrName,
                      TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                      TCD_INT ParIx, char *Var) ;
void    TCD3FEV (P_TCD_C_F1 pMyPar, char * AttrName,
                      TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                      TCD_INT ParIx, char *Var) ;
TCD_INT TCD3FE1 (P_TCD_C_F1 pMyPar, TCD_BOOL option, char * Name,
                      TCD_LONG ID, TCD_INT FrmNr, P_TCD_DOUBLE Var) ;
TCD_INT TCD3FE2 (P_TCD_C_F1 pMyPar, TCD_BOOL option, char * Name,
                      TCD_LONG ID, TCD_INT FrmNr, P_P_TCDTAB  Var) ;

TCD_INT TCDChkFrm     (P_TCD_C_F1,void *);
void    ClearOverwriteStack(P_TCD_C_G pTCDTCD );

void       TCD3FESaveResult(P_TCD_C_F1);

#endif
 
/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_RCTL_H)
#define TCD_RCTL_H
/*---------------------------------------------------------------------
  Datei :  TCD_RCTL.h
  Beschreibung:      TCD Schnittstelle fur RBS LifeTemplate
---------------------------------------------------------------------*/
#define I_PAR_SKAL_SIZE (89 + 85)
#define I_PAR_VGL_SIZE  (1 + 0)
#define I_PAR_DAT_SIZE  (1 + 0)
#define I_SKAL_DATA_SIZE 89
#define I_TAB1_DATA_SIZE 1
#define I_TAB2_DATA_SIZE 5
#define I_DAT_DATA_SIZE  1
#define I_VGL_DATA_SIZE  1

#define I_ANZ_BSTATTRSK   88
#define I_ANZ_BSTATTRT1   0
#define I_ANZ_BSTATTRT2   4
#define I_ANZ_BSTATTRDT   0
#define I_ANZ_BSTATTRVG   0
#define I_ANZ_ATTRSK      173
#define I_ANZ_ATTRVG      0
#define I_ANZ_ATTRDT      0
#define I_MAXROWS         200
#define I_MAXCOLS         110

#define I_RBS_ID          0X3FE

/*-------------------------------------------------------------------
  Funktionsprototyp Aufruf Rechenbaustein
-------------------------------------------------------------------*/
typedef  void  (*TCDRbsSSFktType) (S_TCD_C_G *);
void            LifeTem0(S_TCD_C_G * pRbsIf) ; 
TCDRbsSSFktType GetRbsSSFkt(); 
               /* Gibt Zeiger auf LifeTem0 zurueck */


/*---------------------------------------------------------------------
 Definition dynamischer Aufbau der RBS-Strukturen
---------------------------------------------------------------------*/
S_TCD_C_G       *DConstrTCD_C_G ();
void             DDestrTCD_C_G  (S_TCD_C_G **ppTCD_C_G);

/*---------------------------------------------------------------------
 Definition statischer RBS-Strukturen
---------------------------------------------------------------------*/

#ifndef NO_STATIC_RBS_DATA
#define STATIC_RBS_DATA
#endif
      
#ifdef STATIC_RBS_DATA

TCDRbsSSFktType TCDRbsSSFkt0 = LifeTem0;

 S_TCDPARATTR_SK  ParSkal [ I_PAR_SKAL_SIZE ] ;
 S_TCDPARATTR_VGL ParVgl  [ I_PAR_VGL_SIZE ] ;
 S_TCDPARATTR_DAT ParDat  [ I_PAR_DAT_SIZE ] ;
 S_TCDSKAL_DATA   Skal    [ I_SKAL_DATA_SIZE ] ;
 S_TCDTAB1_DATA   Tab1    [ I_TAB1_DATA_SIZE ] ;
 S_TCDTAB2_DATA   Tab2    [ I_TAB2_DATA_SIZE ] ;
 S_TCDDAT_DATA    Dat     [ I_DAT_DATA_SIZE ] ;
 S_TCDVGL_DATA    Vgl     [ I_VGL_DATA_SIZE ] ;

/*---------------------------------------------------------------------
 Definition der externen RBS-Schnittstelle
---------------------------------------------------------------------*/
 S_TCDRBS_SS  LifeTeSS  =
{
    /* RCTL      */  { 0 },
    /* SSAData   */  { Skal, Tab1, Tab2, Dat, Vgl },
    /* PoolAdmin */  { 0 },
    /* MPrcAdmin */  { 0 }
} ;

S_TCDRBS_SS *pTCDRbsSS = &LifeTeSS;



/*---------------------------------------------------------------------
 Definition der internen RBS-Schnittstelle
---------------------------------------------------------------------*/
 S_TCD_C_G  LifeTeCP =
{
/* pRbsSS -> RBS-Schnittstelle    */ & LifeTeSS,
/* pPrcData                       */ 0,
/* pPrcHdr                        */ 0,
/* pPrcTreeNode                   */ 0,
/* pInfo                          */ 0,
/* pRelAttrs                      */ 0,
/* pMPrcAdmin Zeiger auf MProcSS  */ & LifeTeSS.MPrcAdmin,
/* pRbsCtl Zeiger auf RBS-Controll*/ & LifeTeSS.RCTL,

/* SSAData -> interne Struktur    */ {
/* der Schnittstellendaten        */
/* AnzSSASkal  Anz.Skal. Attribute*/   I_ANZ_BSTATTRSK,
/* AnzSSATab1  Anz.Tab1  Attribute*/   I_ANZ_BSTATTRT1,
/* AnzSSATab2  Anz.Tab2  Attribute*/   I_ANZ_BSTATTRT2,
/* AnzSSADat   Anz.Dat   Attribute*/   I_ANZ_BSTATTRDT,
/* AnzSSAVgl   Anz.Vgl   Attribute*/   I_ANZ_BSTATTRVG,
/* AnzParSkal  Anz.Parameterattr. */   I_ANZ_ATTRSK,
/* AnzParVgl   Anz.Parameterattr. */   I_ANZ_ATTRVG,
/* AnzParDat   (AnzSkal + AnzVgl) */   I_ANZ_ATTRDT,
/* AnzZeilen einer Tabelle        */   I_MAXROWS,
/* AnzSpalten einer Tabelle       */   I_MAXCOLS,

/* pSkal    -> Anfang skal. SSA   */   Skal,
/* pTab1    -> Anfang Tab1 SSA    */   Tab1,
/* pTab2    -> Anfang Tab2 SSA    */   Tab2,
/* pDat     -> Anfang Dat SSA     */   Dat,
/* pVgl     -> Anfang Vgl SSA     */   Vgl,
/* pParSkal -> skalare Daten (Par)*/   ParSkal,
/* pParVgl  -> Parameter (VglOp)  */   ParVgl,
/* pParDat  -> Parameter (Datum)  */   ParDat
                                     },

/* PoolAdmin                      */ & LifeTeSS.PoolAdmin,
/* GlbVarSet                      */ 0 ,
/* ID des aktuellen RBS           */ I_RBS_ID,
/* ValFound                       */ 0 ,
/* Frm Found                      */ 0 ,
/* Attributkennzeichen            */ 0 ,
/* PrcChg: fur InitChk            */ 0 ,
/* pApplIf                        */ NULL ,
/* ResTab                         */ 0 ,
/* ResSkal                        */ 0 ,



/* Id der letzt berechneten BV    */ 0 ,
/* ErgebnisPool                   */ 0 ,
/* laufende BerechnungsNummer     */ 0 ,
/* ErgPoolIteratorGlobal          */ 0 ,
/* Flag nicht zu merkendes Erg.   */ 0 ,




/* btrace_open                    */ 0,
/* btrace_enabled                 */ 0,


/* bProtWV                        */ 0
} ;

S_TCD_C_G  *pTCDRbsCP = &LifeTeCP ;

#endif /* Definition statischer Rbs-Daten */

#endif
 

#include "p09201.h"

/* Prototypen der internen Funktionen */
void    ResetLocalErgebnisPool(P_TCD_C_G pTCDTCD,TCD_LONG);

TCD_INT ErgPoolGetFirstInfo   (P_TCD_C_G,TCD_LONG *,TCD_LONG *);
TCD_INT ErgPoolGetNextInfo    (P_TCD_C_G,TCD_LONG *,TCD_LONG *);




/*
  Externe Funktion:        LifeTem0  [extern]
  Beschreibung             Rechenbausteinsteuerung LifeTemplate
  Author:                  BEG (Musterdatei)
*/
void LifeTem0 (S_TCD_C_G * pRbsIf)
{
   int             rc ;        
   P_TCD_C_G       pTCDTCD = pRbsIf ;
   P_TCDRCINFO     pTcdRcInfo ;
   P_TCDCTLPAR     pTcdPar ;
/*
   Initialisierung RC-Struktur
-*/
   pTcdRcInfo       = &(pTCDTCD->pRbsSS->RCTL.RCInfo) ;
   pTcdPar          = &(pTCDTCD->pRbsSS->RCTL.Par) ;

   pTcdRcInfo->Rc   = TCD_RC_OK ;
   pTcdRcInfo->Errc = 0 ;

   switch ( pTCDTCD->pRbsSS->RCTL.Opc) 
   {
      case TCD_OPC_INIT_RBS :
    /*
      Initialisierung des Rechenbausteins
    */
           rc = TCD_RC_OK ;
           pTCDTCD->GlbVarSet = 0;
           pTCDTCD->pPoolAdmin->Anzahl = 0 ;
           pTCDTCD->pPoolAdmin->Data   = 0 ;
           pTCDTCD->pMPrcAdmin->Anzahl = 0 ;
           pTCDTCD->pMPrcAdmin->Data   = 0 ;
           pTCDTCD->iBerechnungsNummer = 1;   
           /* RWE, 10.06.1997  */
#ifdef PROTWV           
           SetProtWV(pTCDTCD,0);
#endif           
           return ;

      case TCD_OPC_CALC_FRM :
    /*
      Calc-Formel:
      1. InitPool, falls erforderlich
    */
           if (pTCDTCD->pPoolAdmin->AnzTemp > 0) 
           {
               TCDPIT (pTCDTCD) ;
               if ( pTcdRcInfo->Rc != TCD_RC_OK )   return ;
           }
    /*
      2. Init der internen Schnittstelle, falls erforderlich
    */
           if (pTCDTCD->GlbVarSet) 
           {
              TCDIniPS (pTCDTCD) ;
           }

    /*
      3. InitAttrFlags, falls gewuenscht
    */
#ifdef TCD_D_MISS
           TCDIniFM (pTCDTCD) ;
           if ( pTcdRcInfo->Rc != TCD_RC_OK )    
              return ;
#endif
#ifdef TCD_D_USE
           TCDIniFU (pTCDTCD) ;
           if ( pTcdRcInfo->Rc != TCD_RC_OK )     
              return ;
#endif
    /*
      4. InitAttrFlags Computed, falls erforderlich
    */
           if ( pTCDTCD->V_Comp) 
           {
              TCDIniFC (pTCDTCD) ;
              if ( pTcdRcInfo->Rc != TCD_RC_OK )      
                 return ;
           }

    /*
      4. Berechnen der Formel
    */
           LifeTemF (pTCDTCD) ;
           return ;

      case TCD_OPC_CALC_PRC :
      {
    /*
      Calc-Proc:                              RWE, 20.06.96
      0. zuletzt berechnete Prc merken 
      (um die AttrResults ggf. zu l�schen):
    */
        pTCDTCD->iBerechnungsNummer++;
        if (pTCDTCD->LastCalcPrcID!=0) 
            ResetLocalErgebnisPool(pTCDTCD,pTCDTCD->LastCalcPrcID);

    /*
      Calc-Proc:
      1. InitPool, falls erforderlich
    */
           if (pTCDTCD->pPoolAdmin->AnzTemp > 0) 
           {
               TCDPIT (pTCDTCD) ;
               if ( pTcdRcInfo->Rc != TCD_RC_OK )     
                  return ;
           }

    /*
      2. Init der internen Schnittstelle, falls erforderlich
    */
           if (pTCDTCD->GlbVarSet) 
           {
              TCDIniPS (pTCDTCD) ;
           }

    /*
      3. InitAttrFlags, falls gewuenscht
    */
#ifdef TCD_D_MISS
           TCDIniFM (pTCDTCD) ;
           if ( pTcdRcInfo->Rc != TCD_RC_OK )         
              return ;
#endif
#ifdef TCD_D_USE
           TCDIniFU (pTCDTCD) ;
           if ( pTcdRcInfo->Rc != TCD_RC_OK )         
              return ;
#endif
    /*
      4. InitAttrFlags Computed, falls erforderlich
    */
           if ( pTCDTCD->V_Comp) 
           {
              TCDIniFC (pTCDTCD) ;
              if ( pTcdRcInfo->Rc != TCD_RC_OK )      
                 return ;
           }

    /*
      5. InitAuspraegung, falls erforderlich
    */
           TCDDIP (pTCDTCD) ;
           if ( pTcdRcInfo->Rc != TCD_RC_OK )         
              return ;

    /*
      6. Berchnung der Auspraegung
    */
           pTcdPar->CFP.FormelNr = pTCDTCD->pPrcHdr->FormelNr;

           LifeTemF (pTCDTCD) ;
           
           /* ID fuers spaetere Aufraeumen der AttrResults merken 
              (RWE, 20.06.96) */
           pTCDTCD->LastCalcPrcID = pTCDTCD->pPrcHdr->PrcID; 

           return ;
      }

      case TCD_OPC_GETNUM_FRM:
    /*
      Ermitteln der Formelnummer zu einem gegebenen Formelnamen
    */
           LifeTemF (pTCDTCD) ;
           return ;

      case TCD_OPC_GET_ATTR_VAL:
    /*
      Besorgen einer Attributbelegung zu einer Auspr�gung
    */
           TCDDGA (pTCDTCD) ;
           return ;

    /*
      Belegen eines Attributs in einer Auspr�gung mit Auswertung 
      d. Belegliste
    */
      case TCD_OPC_SET_ATTR_VAL:
           TCDDSA (pTCDTCD) ;
           return ;

    /*
      Belegen eines Attributs in einer Proc ohne Auswertung 
      d. Belegliste
      MUB 25.6.96: nix mehr ...
    */
      case TCD_OPC_SET_ATTR_IN_PRC :
      /*  TCDDSV () ; */

           pTcdRcInfo->Rc = TCD_RC_ILLOPC ;
           return ;


      case TCD_OPC_GET_PRC_INFO:
    /*
      Besorgen der Belegungsinformation zu einer Auspr�gung
    */
           TCDDGPI (pTCDTCD) ;
           return ;

      case TCD_OPC_RESET_RBS :

           ReleaseMPrcAttrResults (pTCDTCD->pMPrcAdmin);  
           /*  RWE 20.06.96 */
    /*
      Freigeben der Daten der letzten Proc R�cksetzen des PoolAdmin 
      und MultiProc
    */
           if (pTCDTCD->pPoolAdmin->AnzTemp > 0)
           {
               TCDPIT (pTCDTCD) ;
           }
           TCDPRP  (pTCDTCD) ;
           if ( pTcdRcInfo->Rc != TCD_RC_OK )
              return ;

           if (pTCDTCD->LastCalcPrcID !=0) 
              ResetLocalErgebnisPool(pTCDTCD,pTCDTCD->LastCalcPrcID);

           if (pTCDTCD->pMPrcAdmin)
           {
              if (pTCDTCD->pMPrcAdmin->Data)
              {
                 _TCDFREE ( pTCDTCD->pMPrcAdmin->Data ) ;
              }
              pTCDTCD->pMPrcAdmin->Anzahl = 0 ;
           }
           pTcdRcInfo->Rc = TCD_RC_OK ;

           ReleaseGlobalErgebnisPool(pTCDTCD);
           return ;

      case TCD_OPC_SET_PRC  :
    /*
      �bernehmen einer Auspr�gung in die MultiProc
    */
           TCDDSP (pTCDTCD) ;
           return ;

      case TCD_OPC_RESET_PRC :
    /*
      Auspr�gung aus MultiProc l�schen
    */
           TCDDRP (pTCDTCD) ;

           /* Ggf. lokale Ergebnisse loeschen */
           if (pTCDTCD->LastCalcPrcID !=0) 
              ResetLocalErgebnisPool(pTCDTCD,pTCDTCD->LastCalcPrcID);

           return ;

      case TCD_OPC_SET_POOLTAB :
    /*
      �bernehmen einer Tabelle in die Poolverwaltung
    */
           if (pTcdPar->ST.ID  == 0) 
           {
               pTcdRcInfo->Rc  = TCD_RC_PAR_ERROR ;
               return ;
           }
           TCDPST (pTCDTCD) ;
           return ;

      case TCD_OPC_SET_POOLTAB_I :
    /*
      �bernehmen einer Tabelle in die Poolverwaltung
    */
           if (pTcdPar->ST.ID  == 0) 
           {
               pTcdRcInfo->Rc  = TCD_RC_PAR_ERROR ;
               return ;
           }
           TCDPSAT (pTCDTCD) ;
           return ;


      case TCD_OPC_RESET_POOLTAB :
    /*
      Tabelle    aus Poolverwaltung l�schen
    */
           if (pTcdPar->RT.ID == 0) 
           {
               pTcdRcInfo->Rc  = TCD_RC_PAR_ERROR ;
               return ;
           }
           TCDPRT(pTCDTCD) ;
           return ;

      case TCD_OPC_RESET_POOLTAB_I :
    /*
      Tabelle    aus Poolverwaltung l�schen
    */
           if (pTcdPar->RT.ID == 0) 
           {
               pTcdRcInfo->Rc  = TCD_RC_PAR_ERROR ;
               return ;
           }
           TCDPRTA (pTCDTCD) ;
           return ;

      case TCD_OPC_SET_TRACE_ON:
    /*
        Formel-Trace einschalten
    */
           /*TraceOn(); */
           pTCDTCD->btrace_enabled = 1;
           return;

      case TCD_OPC_SET_TRACE_OFF:
    /*
        Formel-Trace ausschalten
    */
           /*TraceOff(); */
           pTCDTCD->btrace_enabled = 0;
           return;

      case TCD_OPC_REMOVE_RESULTS:
    /*
        Ergebnisse aus dem Ergebnispool entfernen
    */
           if (pTcdPar->RESP.ProcID < 0) 
           {
               pTcdRcInfo->Rc  = TCD_RC_PAR_ERROR ;
               return ;
           }

           ReleaseGlobalErgebnis( pTCDTCD,pTcdPar->RESP.ProcID );
           return;

      case TCD_OPC_GET_FIRST_RESULTS_INFO:
      case TCD_OPC_GET_NEXT_RESULTS_INFO:
    /*
        Informationen �ber den Ergebnispool abfragen:
    */
   {
    TCD_INT bSuccess = 
             
    pTCDTCD->pRbsSS->RCTL.Opc == TCD_OPC_GET_FIRST_RESULTS_INFO ?
                     
    ErgPoolGetFirstInfo( 
    pTCDTCD,&(pTcdPar->RESP.ProcID),&(pTcdPar->RESP.lNumOfResults )) :
        
    ErgPoolGetNextInfo (                                              
    pTCDTCD,&(pTcdPar->RESP.ProcID),&(pTcdPar->RESP.lNumOfResults )) ;
                                            
    pTcdPar->RESP.bFinished = !bSuccess;
        
    return;
      }
      
      default:
    /*
      alles andere macht der RBS nicht
    */
           pTcdRcInfo->Rc = TCD_RC_ILLOPC ;
           return ;
   }
}
              
              
/* TCDRbsSSFktType GetRbsSSFkt(); 
   gibt Zeiger auf die Rbs-SS-Funktion zurueck (damit kann die 
   Rbs-SS-Funktion immer unter dem gleichen Namen angesprochen werden)
*/   
TCDRbsSSFktType GetRbsSSFkt()
{ return &LifeTem0; }

              
/* 
   void ResetLocalErgebnisPool:
   Gibt vor Beginn einer neuen Berechnung (ExecProc) oder bei
   RBS-Reset die gespeicherten lokalen ErgebnisPools frei ...
  */
void ResetLocalErgebnisPool(P_TCD_C_G pTCDTCD, TCD_LONG LastCalcPrcID)
{
   P_TCDPRCELEM pLastCalcPrc = MPrcAdminGetPrc(pTCDTCD->pMPrcAdmin, 
                                               LastCalcPrcID);

   if (pLastCalcPrc)
      ReleasePrcAttrResults ( pLastCalcPrc );
}


/*RWE, 23.06.96: */
/* 
   long ErgPoolGetFirstInfo
   liefert naechste ProcID und die Anz. der dazu gespeicherten Erg'e
  */
TCD_INT /*bSuccess*/
        ErgPoolGetFirstInfo ( P_TCD_C_G pTCDTCD,TCD_LONG *pProcID, 
                              TCD_LONG *plAnzErgebnisse )
{
   TCD_INT bSuccess;
   bSuccess = ErgPoolGetNextInfo ( pTCDTCD,pProcID, plAnzErgebnisse);
   return bSuccess;
}


/*RWE, 23.06.96: */
/* 
   long ErgPoolGetNextInfo       
   liefert naechste ProcID und die Anz. der dazu gespeicherten Erg'e
  */
TCD_INT /*bSuccess*/
       ErgPoolGetNextInfo ( P_TCD_C_G pTCDTCD, TCD_LONG *pProcID, 
                            TCD_LONG *plAnzErgebnisse )
{
   if (!pTCDTCD->pErgebnisPool) return 0;
   while (pTCDTCD->iErgPoolIteratorGl<VectLen(pTCDTCD->pErgebnisPool))
     {
        P_ERGEBNIS_POOL_ELT pPoolElt =
          (P_ERGEBNIS_POOL_ELT)GetVectElt(pTCDTCD->pErgebnisPool,
                                          pTCDTCD->iErgPoolIteratorGl);
        if (!pPoolElt) return 0;
        if (pPoolElt->ID)
       {
          *pProcID = pPoolElt->ID;
          *plAnzErgebnisse = 0;
          if (pPoolElt->pPaarListe && 
              pPoolElt->pPaarListe->pPaarListenElts)
             *plAnzErgebnisse = 
                  VectLen(pPoolElt->pPaarListe->pPaarListenElts);
          pTCDTCD->iErgPoolIteratorGl++;
          return 1;
       }
     pTCDTCD->iErgPoolIteratorGl++;
     }
   return 0;
}


/* RWE, 15.1.98: */
/**************
  Dynamische Erzeugung der Rbs-Schnittstelle
**************/


/**************
  Prototypen
**************/
static TCD_INT      SConstrTCD_C_G     (S_TCD_C_G *pTCD_C_G) ;
static S_TCDRBS_SS *DConstrTCDRbsSS    () ;
static TCD_INT      SConstrTCDRbsSS    (S_TCDRBS_SS *pTCDRbsSS) ;
static TCD_INT      SConstrTCDISSADATA (S_TCDISSADATA *pTCDISSADATA,
					S_TCDSKAL_DATA *pSkalData,
					S_TCDTAB1_DATA *pTab1Data,
					S_TCDTAB2_DATA *pTab2Data,
					S_TCDDAT_DATA  *pDatData,
					S_TCDVGL_DATA  *pVglData) ;

static void SDestrTCD_C_G              (S_TCD_C_G     *pTCD_C_G) ;
static void DDestrTCDRbsSS             (S_TCDRBS_SS  **ppTCDRbsSS) ;
static void SDestrTCDRbsSS             (S_TCDRBS_SS   *pTCDRbsSS) ;
static void SDestrTCDISSADATA          (S_TCDISSADATA *pTCDISSADATA);

/**************
  Konstruktoren
**************/

/**************
  Main-Constructor - to be called from the user of the TCD subystem
**************/
S_TCD_C_G *DConstrTCD_C_G()
{
	S_TCD_C_G *p = _TCDALLOC(1,sizeof(S_TCD_C_G));
	if (!p) return NULL;
	if (!SConstrTCD_C_G(p))
	{
		_TCDFREE(p);
		return NULL;
	}
   return p;
}

static TCD_INT /*success*/ SConstrTCD_C_G (S_TCD_C_G *pTCD_C_G)
{
	if (!pTCD_C_G) return 0;
	_TCDMEMINI(pTCD_C_G,sizeof(S_TCD_C_G),1);
   if ((pTCD_C_G->pRbsSS=DConstrTCDRbsSS())==NULL)
	   return 0;
   pTCD_C_G->pMPrcAdmin = &(pTCD_C_G->pRbsSS->MPrcAdmin);
	pTCD_C_G->pRbsCtl    = &(pTCD_C_G->pRbsSS->RCTL);
   if (!SConstrTCDISSADATA(&(pTCD_C_G->SSAData),
		             pTCD_C_G->pRbsSS->SSAData.pSkal,
			     pTCD_C_G->pRbsSS->SSAData.pTab1,
			     pTCD_C_G->pRbsSS->SSAData.pTab2,
			     pTCD_C_G->pRbsSS->SSAData.pDat,
			     pTCD_C_G->pRbsSS->SSAData.pVgl))
      return 0;
   pTCD_C_G->pPoolAdmin = &(pTCD_C_G->pRbsSS->PoolAdmin);
   pTCD_C_G->RBS_ID     = I_RBS_ID;
   return 1;
}

static S_TCDRBS_SS *DConstrTCDRbsSS()
{
  S_TCDRBS_SS *p = _TCDALLOC(1,sizeof(S_TCDRBS_SS)); 
  if (!p) return NULL;
  if (!SConstrTCDRbsSS(p))
  {
	  _TCDFREE(p);
	  return NULL;
  }
  return p;
}

static TCD_INT /* success */  SConstrTCDRbsSS(S_TCDRBS_SS *pTCDRbsSS)
{
char *p;
TCD_LONG l;
if (!pTCDRbsSS) return 0;
_TCDMEMINI(pTCDRbsSS,sizeof(S_TCDRBS_SS),1);
l =  I_SKAL_DATA_SIZE*sizeof(S_TCDSKAL_DATA)+
	  I_TAB1_DATA_SIZE*sizeof(S_TCDTAB1_DATA)+
	  I_TAB2_DATA_SIZE*sizeof(S_TCDTAB2_DATA)+
	  I_DAT_DATA_SIZE*sizeof(S_TCDDAT_DATA)+
	  I_VGL_DATA_SIZE*sizeof(S_TCDVGL_DATA);
p = _TCDALLOC(l,1);
if (!p && (l>0)) return 0;
_TCDMEMINI(p,l,1);

pTCDRbsSS->SSAData.pSkal = (S_TCDSKAL_DATA*)p;
p += I_SKAL_DATA_SIZE*sizeof(S_TCDSKAL_DATA);
pTCDRbsSS->SSAData.pTab1 = (S_TCDTAB1_DATA*)p;
p += I_TAB1_DATA_SIZE*sizeof(S_TCDTAB1_DATA);
pTCDRbsSS->SSAData.pTab2 = (S_TCDTAB2_DATA*)p;
p += I_TAB2_DATA_SIZE*sizeof(S_TCDTAB2_DATA);
pTCDRbsSS->SSAData.pDat = (S_TCDDAT_DATA*)p;
p += I_DAT_DATA_SIZE*sizeof(S_TCDDAT_DATA);
pTCDRbsSS->SSAData.pVgl = (S_TCDVGL_DATA*)p;

return 1;
}

static TCD_INT /*success*/ SConstrTCDISSADATA(
                                S_TCDISSADATA *pTCDISSADATA,
				S_TCDSKAL_DATA *pSkalData,
				S_TCDTAB1_DATA *pTab1Data,
				S_TCDTAB2_DATA *pTab2Data,
				S_TCDDAT_DATA  *pDatData,
				S_TCDVGL_DATA  *pVglData)
{
   int iAnzAttrSk = I_ANZ_ATTRSK;
   int iAnzAttrVg = I_ANZ_ATTRVG;
   int iAnzAttrDt = I_ANZ_ATTRDT;

   if (!pTCDISSADATA) return 0;
   pTCDISSADATA->AnzSSASkal=I_ANZ_BSTATTRSK;
   pTCDISSADATA->AnzSSATab1 = I_ANZ_BSTATTRT1;
   pTCDISSADATA->AnzSSATab2 = I_ANZ_BSTATTRT2;
   pTCDISSADATA->AnzSSADat = I_ANZ_BSTATTRDT;
   pTCDISSADATA->AnzSSAVgl = I_ANZ_BSTATTRVG;
   pTCDISSADATA->AnzParSkal = I_ANZ_ATTRSK;
   pTCDISSADATA->AnzParVgl = I_ANZ_ATTRVG;
   pTCDISSADATA->AnzParDat = I_ANZ_ATTRDT;
   pTCDISSADATA->AnzZeilen = I_MAXROWS;
   pTCDISSADATA->AnzSpalten = I_MAXCOLS;
   pTCDISSADATA->pSkal = pSkalData;
   pTCDISSADATA->pTab1 = pTab1Data;
   pTCDISSADATA->pTab2 = pTab2Data;
   pTCDISSADATA->pDat = pDatData;
   pTCDISSADATA->pVgl = pVglData;

   /* pParSkal, pParVgl, pParDat allozieren */
   pTCDISSADATA->pParSkal = !I_ANZ_ATTRSK ? NULL :
	   _TCDALLOC(I_ANZ_ATTRSK,sizeof(S_TCDPARATTR_SK));
   pTCDISSADATA->pParVgl = !I_ANZ_ATTRVG ? NULL :
	   _TCDALLOC(I_ANZ_ATTRVG,sizeof(S_TCDPARATTR_VGL));
   pTCDISSADATA->pParDat = !I_ANZ_ATTRDT ? NULL :
	   _TCDALLOC(I_ANZ_ATTRDT,sizeof(S_TCDPARATTR_DAT));
   if (   (pTCDISSADATA->pParSkal==NULL && iAnzAttrSk>0) 
	   || (pTCDISSADATA->pParVgl==NULL  && iAnzAttrVg>0)
	   || (pTCDISSADATA->pParDat==NULL  && iAnzAttrDt>0))
      return 0;
   if (pTCDISSADATA->pParSkal)
	   _TCDMEMINI(pTCDISSADATA->pParSkal,
				  sizeof(S_TCDPARATTR_SK),I_ANZ_ATTRSK);
   if (pTCDISSADATA->pParVgl)
	   _TCDMEMINI(pTCDISSADATA->pParVgl,
				  sizeof(S_TCDPARATTR_VGL),I_ANZ_ATTRVG);
   if (pTCDISSADATA->pParDat)
	   _TCDMEMINI(pTCDISSADATA->pParDat,
				  sizeof(S_TCDPARATTR_DAT),I_ANZ_ATTRDT);

   return 1;
}

/**************
   Destruktoren
**************/

/**************
  Main-Destructor - to be called from the user of the TCD subystem
**************/
void DDestrTCD_C_G (S_TCD_C_G **ppTCD_C_G)
{
  if (!ppTCD_C_G || !*ppTCD_C_G) 
    return;
  SDestrTCD_C_G(*ppTCD_C_G) ;
  _TCDFREE(*ppTCD_C_G);
  *ppTCD_C_G = NULL;
}

static void SDestrTCD_C_G ( S_TCD_C_G *pTCD_C_G)
{
  if (!pTCD_C_G) return;
  SDestrTCDISSADATA(&(pTCD_C_G->SSAData)) ;
  DDestrTCDRbsSS(&(pTCD_C_G->pRbsSS)) ;
  return ;
}

static void   DDestrTCDRbsSS(S_TCDRBS_SS **ppTCDRbsSS)
{
  if (!ppTCDRbsSS || !*ppTCDRbsSS)
    return;
  SDestrTCDRbsSS(*ppTCDRbsSS) ;
  _TCDFREE(*ppTCDRbsSS) ;
  *ppTCDRbsSS = NULL;
}

static void   SDestrTCDRbsSS(S_TCDRBS_SS *pTCDRbsSS)
{
  if (!pTCDRbsSS)
    return;
  _TCDFREE(pTCDRbsSS->SSAData.pSkal) ;
}

static void SDestrTCDISSADATA(S_TCDISSADATA *pTCDISSADATA)
{
   if (!pTCDISSADATA)
     return;
   _TCDFREE(pTCDISSADATA->pParSkal) ;
   _TCDFREE(pTCDISSADATA->pParVgl) ;
   _TCDFREE(pTCDISSADATA->pParDat) ;
}
