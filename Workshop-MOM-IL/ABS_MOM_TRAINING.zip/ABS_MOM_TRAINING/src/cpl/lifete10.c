/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
 /*--------------------------------------------------------------------
    Modul:        TCD_PKF.c

    Beschreibung: Funktionen C-Generator, die vom Makrogenerator
                  aufgerufen werden
    By:           BEGGI
    Datum:        16.12.2019 15:07:19
    Historie :    BEG  22.11.95      FM: 384
  MUB  21.5.96 Optimierung begonnen, Beschaffungsflags etc.
  MUB          Pr�fung, ob Ergebnis schon berechnet wurde.
  MUB 17.7.96  Abweisungen zwischen #ifdef TRACEFKT #endif korrigiert
  MUB 26.7.96  Erfolgreiche Wiederverwendung eines Ergebnisses
               ins Tracefile schreiben
---------------------------------------------------------------------*/

/* Includes */
/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDPORTAB_H)
#define TCDPORTAB_H

/*-----------------
Name        : TCDPORTAB.H

Beschreibung: externes Include File, das generierumgeungsspezifische
Informationen enthaelt (Makrovorlage).
By          : BEGGI
Datum       : 20.04.94
Historie:     BEG   17.01.95  neues Makro _TCDMEMINI anstatt memset
BEG   02.03.95  bedingte Macros TCDHUGE
BEG   22.06.95  _TCDMEMINI nur im HUGE-Modell redefiniert.
BEG   20.02.96  malloc.h wird nicht mehr inkludiert (FM 451)
RWE   21.06.96  malloc.h wird wieder includiert (aber nur
              fuers HUGE-Modell, d.h. fuer DOS/WIN-Compiler)
RWE   26.06.96  WATCHMEM-Makros eingebaut (fuer TCDALLOC etc)
MUB   17.7.96   Include mit !defined versehen
KFC   02.09.96  #define TCDHUGE vorgezogen

-------------------*/

/* #define TCDHUGE */              /* bei gro�en Tabellen einschalten*/
/* Systemincludes */                  
#include <stdlib.h>                /* atoi, ...       */
#include <stdio.h>                 /* fprintf, ...    */
#include <string.h>                /* strcpy, ...     */
#include <time.h>                  /* time_t, ...     */
#include <math.h>                  /* exp, min, max, ... */

#ifdef TCDHUGE
#include <malloc.h>
#endif

/* Defines */
#define  TCDC_EXT_NAME_LNG    8  /* maximale L�nge von externen 
                                    Bezeichnern*/
/*-----------------
  Definitionen aus standard C-Includes z.B. stdio.h
-------------------*/
#ifndef NULL
#define    NULL    (void *)0
#endif

/*-----------------
  Definitionen von Basistypen
-------------------*/
typedef    short   TCD_BOOL ;
typedef    long    TCD_LONG ;
typedef    int     TCD_INT  ;
typedef    double  TCD_DOUBLE ;


/*-----------------
  modellabhaengige Definitionen von Basistypen
-------------------*/
typedef    TCD_DOUBLE  TCDTAB ;
#ifdef TCDHUGE
typedef    TCDTAB       huge * P_TCDTAB ;
typedef    TCD_DOUBLE   huge * P_TCD_DOUBLE ;
typedef    P_TCD_DOUBLE * P_P_TCD_DOUBLE ;
typedef    char huge    * TCD_LPCHAR ;
#else
typedef    TCDTAB       * P_TCDTAB ;
typedef    TCD_DOUBLE   * P_TCD_DOUBLE ;
typedef    P_TCD_DOUBLE * P_P_TCD_DOUBLE ;
typedef    char         * TCD_LPCHAR ;
#endif

/*-----------------
  weitere (Typ-)Defines 
-------------------*/  
typedef int ERRNO_TYPE;
#define TCD_FILENAME_LNG 128

/*-----------------
  Definitionen von Makros f�r Speicherallokation
-------------------*/  

/* WATCHMEM muss im TCDHUGE-Modus abgeschaltet sein */
#ifdef TCDHUGE
#undef WATCHMEM
#endif

#undef _TCDALLOC
#undef _TCDFREE
#undef _TCDREALLOC

#ifndef WATCHMEM

#define _TCDALLOC(len,size)    malloc( (size_t)(len) * (size)) ;
#define _TCDFREE(ptr)          {free(ptr), ptr = NULL;}
#define _TCDREALLOC(ptr,size)  realloc( ptr, (size_t)(size) ) ;

#else
 
void *MallocAndProt(char *sFile_,int iLine_, size_t size);
#define _TCDALLOC(len,size)\
 MallocAndProt(__FILE__,__LINE__,(len) * (size))

void FreeAndProt(char *sFile_, int iLine_, void *p_);

#define _TCDFREE(ptr)\
       {FreeAndProt(__FILE__, __LINE__, ptr) , ptr = NULL;}

void *ReallocAndProt(char *sFile_,int iLine_, void *p_, size_t size);
#define _TCDREALLOC(ptr,size)\
 ReallocAndProt(__FILE__, __LINE__, ptr,size)

void ResumeWatchmem();

#endif

/*-----------------
  modellabh�ngige Definitionen von Makros f�r Speicherallokation
-------------------*/
#undef _TCDTABALLOC
#undef _TCDTABFREE
#undef _TCDMEMINI

#ifdef TCDHUGE

#define _TCDTABALLOC(len,size)\
  _halloc( (long)(len) , (size_t)(size)) ;
#define _TCDTABFREE(ptr)\
      { _hfree ( (void huge *)ptr); ptr = NULL;}

#else

#ifndef WATCHMEM
#define _TCDTABALLOC(len,size)\
 malloc((size_t)((long)len) * ((size_t)size)) ;
#define _TCDTABFREE(ptr)       {free(ptr), ptr = NULL;}
#else
#define _TCDTABALLOC(len,size)\
 MallocAndProt(__FILE__,__LINE__,(len) * (size))
#define _TCDTABFREE(ptr)\
       FreeAndProt(__FILE__, __LINE__, ptr)
#endif

#endif


#ifdef TCDHUGE
#define _TCDMEMINI(ptr,size,nr)\
{\
   long       j;\
   TCD_LPCHAR lp;\
   for (j= 0 , lp = (TCD_LPCHAR)ptr;\
        j < ((long)(size) * (long)(nr)); j++, lp++) \
      *lp = 0;\
}  

#else
#define _TCDMEMINI(ptr,size,nr)\
 { memset (ptr, 0, (size_t) ((size) * (nr))) ; }
#endif
/*---------------------------------
  NON-Ansi-Namen mit oder ohne "_"
----------------------------------*/

/* #define NON_ANSI_WITHOUT__ */

#ifdef NON_ANSI_WITHOUT__
#define _fcvt fcvt
#endif

/*---------------------------
  ggf. Verkuerzung der Namen
-----------------------------*/
#ifdef TCD_NAMLEN8

#define TCDIMPReleaseProcData       TCD_0001
#define TCDIMPReleaseNodeData       TCD_0002
#define TCDIMPReleaseTabImpData     TCD_0003   

#define FetchFromGlobalErgebnisPool TCD_0004

#define DelEltFromSVect             TCD_0005
#define DelEltFromSVectByIndex      TCD_0006

#define DelEltFromVect              TCD_0007
#define DelEltFromVectByIndex       TCD_0008
                                
                                
#define ReleaseGlobalErgebnisPool   TCD_0009
#define ReleaseGlobalErgebnis       TCD_0010
#define ReleaseLocalErgebnisPool    TCD_0011

#define GetPrcDataSkal              TCD_0012
#define GetPrcDataTab               TCD_0013
#define GetPrcDataDat               TCD_0014
#define GetPrcDataFrm               TCD_0015

#define GetPrcAttrSkal              TCD_0016
#define GetPrcAttrTab               TCD_0017

#define GetSSAttrSkal               TCD_0018
#define GetSSAttrTab                TCD_0019

#define ErgPoolGetFirstInfo         TCD_0020
#define ErgPoolGetNextInfo          TCD_0021

#define DConstrAttrs                TCD_0022
#define DConstrAttrsResults         TCD_0023

#define GetRelAttrs                 TCD_0024

#define GetIndexToGlobalErgPool     TCD_0025
#define GetIndexToPaarListElt       TCD_0026

#define GetIndexToSS                TCD_0027
#define GetIndexToUes               TCD_0028
#define GetFromSS                   TCD_0029
#define GetFromUes                  TCD_0030

#define TCDIMPImportTreeData        TCD_0031
#define TCDIMPNFIntl                TCD_0032
#define TCDIMPGetNodeFromID         TCD_0033
#define TCDIMPGetNodeFromPath       TCD_0034
#define compBsearch                 TCD_0035
#define TCDIMPReleaseTreeData       TCD_0036 
#define TCDIMPReleaseTabData        TCD_0037  
#define DConstrTCD_C_G              TCD_0038
#define DDestrTCD_C_G               TCD_0039 
#define SConstrTCD_C_G              TCD_0040
#define DConstrTCDRbsSS             TCD_0041
#define SConstrTCDRbsSS             TCD_0042
#define SConstrTCDISSADATA          TCD_0043
#define SDestrTCD_C_G               TCD_0044
#define DDestrTCDRbsSS              TCD_0045
#define SDestrTCDRbsSS              TCD_0046
#define SDestrTCDISSADATA           TCD_0047
#define GetRbsSSFkt                 TCD_0048
#define TCDIMPGetTabIDAndTypFromPath TCD_0049
#define TCDIMPGetPathAndTypFromID    TCD_0050
#define TCDIMPReleaseTabTreeData     TCD_0051
#define TCDIMPImportTabTreeData      TCD_0052
#endif

#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDC_H)
#define TCDC_H

#ifdef TCDV2_5
#define TCDVERS 25
#endif
#ifdef TCDV3_0
#define TCDVERS 30
#endif
#ifndef TCDVERS
#error TCD Version muss in Makefiles angegeben werden.
#endif

/*---------
Name        : TCDC.H

Beschreibung: Zentrales Include File fuer die Anwendung
TCD weit gueltig
*----------*/

#include "p09115.h" /* direkte Vektoren */

#define  TCD_TRUE                1
#define  TCD_FALSE               0

/*---------
  Definitionen Opcodes
*----------*/
#define  TCD_OPC_INIT_RBS                    1
#define  TCD_OPC_CALC_FRM                    2
#define  TCD_OPC_CALC_PRC                    3
#define  TCD_OPC_GETNUM_FRM                  4
#define  TCD_OPC_GET_ATTR_VAL                5
#define  TCD_OPC_RESET_RBS                   6
#define  TCD_OPC_SET_PRC                     7
#define  TCD_OPC_RESET_PRC                   8
#define  TCD_OPC_SET_POOLTAB                 9
#define  TCD_OPC_RESET_POOLTAB              10
#define  TCD_OPC_SET_ATTR_VAL               11
#define  TCD_OPC_GET_PRC_INFO               12
#define  TCD_OPC_SET_POOLTAB_I              13
#define  TCD_OPC_RESET_POOLTAB_I            14
#define  TCD_OPC_SET_ATTR_IN_PRC            15
#define  TCD_OPC_SET_TRACE_ON               16
#define  TCD_OPC_SET_TRACE_OFF              17
#define  TCD_OPC_REMOVE_RESULTS             18
#define  TCD_OPC_GET_FIRST_RESULTS_INFO     19
#define  TCD_OPC_GET_NEXT_RESULTS_INFO      20

/*---------
  Definitionen Returncodes
*----------*/
#define  TCD_RC_NOT_OK              0
#define  TCD_RC_OK                  1
#define  TCD_RC_ILLOPC              2
#define  TCD_RC_VERSION_CONFLICT    3
#define  TCD_RC_UNKNOWN_FORM        4
#define  TCD_RC_ILLEGAL_FORM        5
#define  TCD_RC_ILLEGAL_PARAM       6
#define  TCD_RC_UNKNOWN_ATTR        7
#define  TCD_RC_NOT_FOUND           8
#define  TCD_RC_INPUT_MISSING       9
#define  TCD_RC_ILLEGAL_DIVISION   10
#define  TCD_RC_ILLEGAL_TAB_RANGE  11
#define  TCD_RC_STACK_OVERFLOW     12
#define  TCD_RC_CONDITION_FAIL     15
#define  TCD_RC_PAR_ERROR          20
#define  TCD_RC_TAB_IN_POOL        21
#define  TCD_RC_TAB_NOT_IN_POOL    22
#define  TCD_RC_PRC_IN_POOL        23
#define  TCD_RC_PRC_NOT_IN_POOL    24
#define  TCD_RC_UNKNOWN_PROC       25
#define  TCD_RC_PAARLISTEN_ERROR   26
#define  TCD_RC_NO_VALUE_AVAIL     30
#define  TCD_RC_USER_SET_ERROR    900
#define  TCD_RC_INTERNAL_ERR      999
#define  TCD_RC_NO_RETURN         888

/*---------
  allgemeine globale Konstanten
*----------*/
#define TCD_INIT_VARSETLEVEL    9999

/*---------
  Konfigurationsangaben
*----------*/
#define TCD_POOLADMIN_SIZE        20
#define TCD_C_MIN_USER_TYPE_ID    0
#define TCD_C_TABLISTLEN          10
#define TCD_C_MAXPRCCALLNR        2147483647

/*---------
  Definitionen Laengenangaben
*----------*/
#define TCD_DATUM_LNG              9
#define TCD_FRM_DATUM_LNG         20
#define TCD_VGLOP_LNG              3
#define TCD_NAME_LNG              26

/*---------
  Definitionen Aufrufart: (Aufzaehlungstyp)
-----------*/
#define TCD_CALLTYP_ATTR        1
#define TCD_CALLTYP_STA         2
#define TCD_CALLTYP_DYN         3
#define TCD_CALLTYP_STA_UE      4

/*---------
  Definitionen Prefix
-----------*/
#define TCD_PREFIX_TAB            '&'
#define TCD_PREFIX_PRC            '$'
#define TCD_PREFIX_FRM            'F'
#define TCD_PREFIX_ATTR           'A'

/*---------
  Definitionen Formeltypen (Aufzaehlungstyp, Wertevergabe analog Cobol)
-----------*/
#define TCD_FRMTYP_SKAL        1
#define TCD_FRMTYP_TAB1        2
#define TCD_FRMTYP_TAB2        3

/*---------
  Definitionen Belegungswerte PoolEntry
-----------*/
#define  TCD_POOLENT_INIT          0
#define  TCD_POOLENT_USED          1
#define  TCD_POOLENT_I_USED        2
#define  TCD_POOLENT_E_USED        3

/*---------
  Definitionen Assigntype
*----------*/
#define  TCD_DC_USE_NOT            0
#define  TCD_DC_USE_FRM            1
#define  TCD_DC_USE_PRC            2
#define  TCD_DC_USE_TAB            3
#define  TCD_DC_USE_VAL            4

/*----------
  Definitionen Formattypen
-----------*/
#define  TCD_ATTRFMT_SKAL          1
#define  TCD_ATTRFMT_TAB1          2
#define  TCD_ATTRFMT_TAB2          3
#define  TCD_ATTRFMT_VGLO          4
#define  TCD_ATTRFMT_DATE          5

/*----------
  Struktur Bestandsattributtabelle
 ----------*/
  typedef struct tagS_TCDATAB {
        char          Name [TCD_NAME_LNG] ;
        TCD_LONG      ID         ;
        TCD_INT       Index      ;
        TCD_INT       AttrTyp    ;
  } S_TCDATAB     ;

 typedef S_TCDATAB     * P_TCDATAB     ;

/*----------
  Struktur Tabelle aller Attribute
 ----------*/
  typedef struct tagS_ATTRTAB
  {
    TCD_LONG  ID    ;
    TCD_INT   Index ;
  } S_ATTRTAB ;

  typedef S_ATTRTAB    * P_ATTRTAB     ;

/*----------
  Typdefinition systemunabhanegiger Typen
 ----------*/
   typedef  char  TCD_VGLOP [TCD_VGLOP_LNG] ;
   typedef  char  TCD_DATUM [TCD_DATUM_LNG] ;

   typedef TCD_DOUBLE TCDTAB1 ;
   typedef P_TCDTAB   P_TCDTAB1 ;

   typedef TCD_DOUBLE TCDTAB2 ;
   typedef P_TCDTAB   P_TCDTAB2 ;

   typedef P_P_TCD_DOUBLE P_P_TCDTAB ;

/*---------
  Union Attributbelegung
 ----------*/
  typedef  union tagU_TCDVALUE {
           TCD_DOUBLE        Skalar;
           P_TCDTAB1         pTab1 ;
           P_TCDTAB2         pTab2 ;
   } U_TCDVALUE ;

  typedef  union tagU_TCDGVALUE {
           TCD_DOUBLE        Skalar;
           P_TCDTAB          pTab  ;
           TCD_VGLOP         VglOp ;
           TCD_DATUM         Datum ;
   } U_TCDGVALUE ;

/* --
 MUB 2.7.96: neu eingefuehrt, weil wir die TabellenID brauchen
--  */
  typedef  union tagU_TCDWVALUE
  {
           TCD_DOUBLE        Skalar;

           TCD_LONG          TabID ;  /*  die relevanten Attribute */
           P_TCDTAB1         pTab  ;  /*  das Ergebnis */

           TCD_VGLOP         VglOp ;
           TCD_DATUM         Datum ;
   } U_TCDWVALUE ;

  typedef struct tagS_TCDPRCVAL {
          TCD_LONG   PrcID ;
          TCD_LONG   FormelNr ;
          TCD_INT    FormelIx ;
          char       FormelName [TCD_NAME_LNG] ;
          TCD_INT    PoolIx ;
#if TCDVERS > 25
/* Version der Formel zur Pruefung 
		  Formel-Generat gegen Transport-Format */
          TCD_INT    FormelVers;
#endif

 } S_TCDPRCVAL ;

  typedef union  tagU_TCDNDVALUE {
          struct   tagTabData {
             TCD_LONG  TabID ;
             TCD_INT   PoolIx ;
          } TabData  ;
          TCD_DOUBLE Skalar ;
          char       Datum [TCD_DATUM_LNG] ;
          char       VglOp [TCD_VGLOP_LNG];
 } U_TCDNDVALUE ;


  typedef struct tagS_TCDFORMEL {
           TCD_LONG  FormelNr ;
           TCD_INT  FormelIx ;
           char     FormelName [TCD_NAME_LNG] ;
           TCD_INT  IsStaRef ;                                 
#if TCDVERS > 25
/* Version der Formel zur Pruefung 
		   Formel-Generat gegen Transport-Format */
		   TCD_INT  FormelVers;
#endif
 } S_TCDFORMEL ;

  typedef union  tagU_TCDASSIGNVAL {

       S_TCDPRCVAL  Prc    ;
       U_TCDNDVALUE Val    ;
       S_TCDFORMEL  Formel  ;

 } U_TCDASSIGNVAL ;

#define TYP3_NOT_OVERWRITTEN 2

typedef struct tagS_TCDREL_ATTR
{                                 
   TCD_LONG    iBerechnungsNummer;
   /* ID des Attributs                            */
   TCD_LONG    AttrID                  ;  
   /* Typ der Belegung SKALAR, TAB, DATUM , VGLOP */
   TCD_INT     AttrType              :4;  
   /* Flag, ob ein geerbter Wert vorhanden ist    */
   TCD_INT     bGeerbterWertVorhanden:2;  
   /* Flag, ob ein geerbter Wert vorhanden ist    */
   TCD_INT     bNotOverwritten         ;
   /* GGf. Wert hierzu                            */
   U_TCDWVALUE Belegung                ;  

}  S_TCDRELATTR;

typedef S_TCDRELATTR * P_TCDRELATTR ;

/* --
   S_TCDRELATTR_IMP    Relevantes Attribut fuer den Import
--  */
typedef struct tagS_TCDREL_ATTR_IMP
{
   TCD_LONG AttrID;
   TCD_INT  AttrType               : 4;
   TCD_INT  iIndex;

}  S_TCDRELATTR_IMP;

typedef S_TCDRELATTR_IMP * P_TCDRELATTR_IMP ;

/* --
   S_PAARLISTEN_EL    Struktur fuer ein PaarlistenElement
--  */
typedef struct tagS_PAARLISTEN_EL
{
   /* Vektor der relevanten Attribute mit der aktuellen Belegung     */
   LP_VECT          pAttrs;        
   /* lfde. Nummer der aktuellen Berechnung                          */
   TCD_LONG         iBerechnungsNummer; 
   
   TCD_LONG         lTabZeilen;         
   TCD_LONG         lTabSpalten;
   
   /* Typ des Ergebnisses (kann 'NOT_OVERWRITTEN' sein)              */
   TCD_INT          iType;              
   /* Ergebnis hierzu                                                */
   U_TCDWVALUE      Ergebnis;           

}  S_PAARLISTEN_EL;

typedef S_PAARLISTEN_EL * P_PAARLISTEN_EL ;

/* --
   S_PAARLISTE     Struktur zu einem Belegknoten einer BV
   Sie enthaelt 1 sortierten Vektor, 1 Liste und eine maximale Laenge
   fuer die Anzahl Elemente der Paarliste (Belegung,Ergebnis)
--  */
typedef struct tagS_PAARLISTE
{
   TCD_INT iWiederVerwendungsTyp;   /* KnotenTyp 1/2/3     */
   TCD_INT iWiederVerwListenLaenge; /* ListenLaenge maximal */
   TCD_INT iAct ;                   /* letztes Element     */

   /* direkter Vektor von S_ATTR_EL's   */
   LP_VECT pAttrs;                  
   /* direkter Vektor von S_PAARLISTEN_EL's */
   LP_VECT pPaarListenElts;         

}  S_PAARLISTE;

typedef S_PAARLISTE * P_PAARLISTE ; 

/* --
   S_ERGEBNIS_POOL_ELT Element eines PoolErgebnisses
--  */
typedef struct tagS_ERGEBNIS_POOL_ELT
{
   TCD_LONG    ID;
   P_PAARLISTE pPaarListe;

}  S_ERGEBNIS_POOL_ELT;

typedef S_ERGEBNIS_POOL_ELT * P_ERGEBNIS_POOL_ELT ;

/*-----------
  Struktur     Belegungsknoten
------------*/
  typedef struct tagS_TCDPRCNODE
  {
      TCD_LONG         AttrID                  ;
      TCD_INT          NodeID                  ;
      TCD_INT          AttrType                ;
      TCD_INT          AssignType              ;
      U_TCDASSIGNVAL   AssignVal               ;
      TCD_INT          SuccNodeIx              ;
      TCD_INT          AnzSuccNodes            ;
      TCD_INT          Usage                   ;

      P_PAARLISTE      pPaarListe              ;
      P_PAARLISTEN_EL  pResultForGetAttr       ;

      TCD_INT          iWiederVerwendungsTyp   ;
      TCD_INT          iWiederVerwListenLaenge ;
      TCD_INT          iAnzRelAttrs            ;
      TCD_INT          iFirstRelAttrIx         ;

  }   S_TCDPRCNODE ;

 typedef S_TCDPRCNODE  * P_TCDPRCNODE ;

/*-----------
  Struktur Auspraegungs-Belegungs-Information
------------*/
  typedef struct tagS_TCDPRCINFO {
         char  Name [TCD_NAME_LNG] ;
         TCD_LONG  ID ;
         TCD_INT   Formattyp ;
         TCD_INT   Typ ;
         TCD_INT   Klasse ;
         TCD_INT   AnzBeleg ;
         TCD_INT   TabIx ;
         TCD_LONG  RefNodeId ;
 } S_TCDPRCINFO ;

 typedef S_TCDPRCINFO  * P_TCDPRCINFO ;

/*--------
  Struktur LocalData MUB 2.7.96: wird nicht mehr verwendet!
 --------*/
  typedef struct tagS_TCDPRCLOCD {
          TCD_LONG FormelNr     ;
          TCD_INT  Usage        ;
          TCD_INT  Typ          ;
          union   {
              TCD_INT    PoolIx ;
              TCD_DOUBLE Val    ;
          } Data ;
          TCD_LONG  CalcByCallNr ;
   } S_TCDPRCLOCD ;

   typedef S_TCDPRCLOCD * P_TCDPRCLOCD ;

/*---------
  Struktur Header Auspraegungsbaum
----------*/
  typedef struct tagS_TCDPRCHDR {
    TCD_LONG       PrcID        ;
    TCD_LONG       FormelNr     ;
    TCD_INT        AnzPrcTree   ;
    TCD_INT        AnzBelegInfo ;
    TCD_INT        AnzRelAttrs  ;
    TCD_BOOL       FlSetAttrSkal;
    TCD_BOOL       FlSetAttrTab ;
    TCD_BOOL       FlSetAttrVgl ;
    TCD_BOOL       FlSetAttrDat ;
    TCD_BOOL       FlPrcCompl   ;
    TCD_LONG       PrcResIx     ;
    TCD_LONG       PrcCallNr    ;

 } S_TCDPRCHDR     ;


/*---------
  Struktur Auspraegungselement
-----------*/
  typedef union  tagU_TCDPRCELEM
  {
     S_TCDPRCHDR      TreeHdr;
     S_TCDPRCNODE     Node ;
     S_TCDPRCINFO     Info ;     
  }  U_TCDPRCELEM ;

 typedef U_TCDPRCELEM  * P_TCDPRCELEM ;

#define TCDPRCSIZE(pPrc)    (pPrc ? sizeof(S_TCDRELATTR_IMP)*\
                            (TCD_LONG)pPrc->TreeHdr.AnzRelAttrs +\
                            sizeof(U_TCDPRCELEM)*\
                            ( (TCD_LONG)pPrc->TreeHdr.AnzPrcTree +\
                             (TCD_LONG)pPrc->TreeHdr.AnzBelegInfo) : 0)


/*-------
  Datenstruktur Mehrfach-Auspraegung (MultiProc)
 --------*/
  typedef struct tagS_TCDMPRCENTRY {
        TCD_INT              PrcBelegt ;
        TCD_LONG             ID ;
        P_TCDPRCELEM         pPrcData ;
 } S_TCDMPRCENTRY ;

  typedef S_TCDMPRCENTRY * P_TCDMPRCENTRY ;

  typedef struct tagS_TCDMPRCADMIN {
        TCD_INT          Anzahl  ;
        P_TCDMPRCENTRY   Data    ;
 } S_TCDMPRCADMIN ;

 typedef S_TCDMPRCADMIN * P_TCDMPRCADMIN ;

/*--------
  Datenstruktur PoolAdmin
--------*/
  typedef struct tagS_TCDPOOLENTRY {
        TCD_LONG     ID ;
        TCD_INT      Usage ;
        TCD_INT      Typ ;
        TCD_INT      Fmttyp ;
        P_TCD_DOUBLE pData ;
  } S_TCDPOOLENTRY ;

  typedef S_TCDPOOLENTRY * P_TCDPOOLENTRY ;

  typedef struct tagS_TCDPOOLADMIN {
        TCD_INT          Anzahl  ;
        TCD_INT          AnzTabs ;
        TCD_INT          AnzProcs ;
        TCD_INT          AnzTemp  ;
        S_TCDPOOLENTRY * Data    ;
 } S_TCDPOOLADMIN ;

  typedef S_TCDPOOLADMIN * P_TCDPOOLADMIN ;

/*------
  Datenstruktur Kontrollstruktur
--------*/
  typedef struct tagS_TCDRBSINFO {
       char TcdVersion [TCD_DATUM_LNG]   ;
       char TcdRelease [TCD_DATUM_LNG]   ;
       char RbsInterf  [TCD_DATUM_LNG]   ;
       TCD_LONG RbsId ;
   } S_TCDRBSINFO ;

   typedef struct tagS_TCDRCINFO {
       TCD_INT   Rc ;
       TCD_INT   Errc ;
       char FormelName [TCD_NAME_LNG] ;
       TCD_INT   FormelNr ;
       char AttrName   [TCD_NAME_LNG] ;
   } S_TCDRCINFO          ;

   typedef S_TCDRCINFO * P_TCDRCINFO ;


   typedef struct tagS_TCDCTLPAR {

/*-
  Opcode:   TCD_OPC_GET_ATTR_VAL, TCD_OPC_SET_ATTR_VAL
--*/
        struct tagS_TCDPARGA {
           TCD_LONG    ProcID;
           TCD_LONG    ID;
           TCD_LONG    TabID;
           TCD_INT     TabIx ;
           U_TCDGVALUE Val ;
           TCD_INT     Typ ;
           TCD_INT     ProcIx;
        }            GA ;

/*-
  Opcode:   TCD_OPC_SET_POOLTAB
--*/
        struct tagS_TCDPARST {
            TCD_LONG  ID;
            TCD_INT   Dim ;
            P_TCDTAB  pTab ;
            TCD_INT    TabIx ;
        }            ST ;

/*-
  Opcode:   TCD_OPC_RESET_POOLTAB
--*/
        struct tagS_TCDPARRT{
            TCD_LONG  ID;
            P_TCDTAB  pTab ;
        }            RT ;

/*-
  Opcode:   TCD_OPC_SET_PRC
--*/
        struct tagS_TCDPARSP {
            TCD_LONG      ProcID;
            P_TCDPRCELEM  pProc;
            TCD_INT       ProcIx;
        }            SP;

/*-
  Opcode:   TCD_OPC_RESET_PRC
--*/
        struct tagS_TCDPARRP {
            TCD_LONG  ProcID;
            P_TCDPRCELEM  pProc;
        }            RP;

/*-
  Opcode:   TCD_OPC_CALC_FRM , TCD_OPC_CALC_PRC
--*/
        struct tagS_TCDPARCFP {
            TCD_LONG       FormelNr ;
            TCD_LONG       ProcID;
            TCD_INT        Typ ;
            U_TCDVALUE     Value ;
            TCD_INT        ProcIx;
        }            CFP ;

/*-
  Opcode:   TCD_OPC_GETNUM_FRM
--*/
        struct tagS_TCDPARGF {
            char  Name [TCD_NAME_LNG] ;
            TCD_LONG  FormelNr ;
        }            GF ;

/*-
  Opcode:   TCD_OPC_GET_PRC_INFO
--*/
        struct tagS_TCDPRCBINFO {
            TCD_LONG        ProcID;
            TCD_INT         ProcIx;
            P_TCDPRCELEM    pProcInfo;
            TCD_INT         AnzProcInfo ;
        }            PI ;

/*-
  Opcode:   TCD_OPC_REMOVE_RESULTS,
            TCD_OPC_GET_FIRST_RESULTS_INFO,
            TCD_OPC_GET_NEXT_RESULTS_INFO
--*/
        struct tagS_TCDPAR_RESULTPOOL {
            TCD_LONG        ProcID;
            TCD_LONG        lNumOfResults;
            TCD_INT         bFinished;
        }            RESP ;

   } S_TCDCTLPAR ;

   typedef S_TCDCTLPAR * P_TCDCTLPAR ;

   typedef struct tagS_TCDRBSCTL {
          TCD_INT       Opc     ;
          S_TCDRBSINFO  RbsInfo ;
          S_TCDRCINFO   RCInfo  ;
          S_TCDCTLPAR   Par     ;
  } S_TCDRBSCTL ;

   typedef S_TCDRBSCTL * P_TCDRBSCTL ;

/*------
  Datenstruktur Rechenbausteinschnittstelle
 --------*/
   typedef struct tagS_TCDV_F_FLAGS {
         TCD_BOOL       V_In   ;
         TCD_BOOL       F_In   ;
         TCD_BOOL       V_Comp ;
         TCD_BOOL       V_Use  ;
         TCD_BOOL       F_Use  ;
         TCD_BOOL       V_Miss ;
         TCD_BOOL       F_Miss ;
   } S_TCDV_F_FLAGS ;

   typedef S_TCDV_F_FLAGS * P_TCDV_F_FLAGS ;

   typedef struct tagS_TCDV_FLAGS {
         TCD_BOOL       V_In   ;
         TCD_BOOL       V_Use  ;
         TCD_BOOL       V_Miss ;
   } S_TCDV_FLAGS ;

   typedef S_TCDV_FLAGS   * P_TCDV_FLAGS   ;

   typedef struct tagS_TCDSKAL_DATA
   {
        TCD_DOUBLE      Val    ;
        TCD_LONG        Formel ;
        S_TCDV_F_FLAGS  Flags  ;
   } S_TCDSKAL_DATA ;

   typedef S_TCDSKAL_DATA * P_TCDSKAL_DATA ;

   typedef struct tagS_TCDTAB1_DATA
   {
     TCD_LONG        TabID;
     P_TCDTAB1       pVal ;
     TCD_LONG        Formel ;
     S_TCDV_F_FLAGS  Flags ;

   } S_TCDTAB1_DATA ;
   typedef S_TCDTAB1_DATA  * P_TCDTAB1_DATA  ;

   typedef struct tagS_TCDTAB2_DATA
   {
     TCD_LONG        TabID;
     P_TCDTAB2       pVal ;
     TCD_LONG        Formel ;
     S_TCDV_F_FLAGS  Flags ;

   } S_TCDTAB2_DATA ;
   typedef S_TCDTAB2_DATA * P_TCDTAB2_DATA ;

   typedef struct tagS_TCDDAT_DATA {
        char             Val [TCD_DATUM_LNG] ;
        S_TCDV_FLAGS     Flags ;
   } S_TCDDAT_DATA ;

   typedef S_TCDDAT_DATA * P_TCDDAT_DATA ;

   typedef struct tagS_TCDVGL_DATA {
        char            Val [TCD_VGLOP_LNG] ;
        S_TCDV_FLAGS    Flags ;
   } S_TCDVGL_DATA ;

   typedef S_TCDVGL_DATA * P_TCDVGL_DATA ;

   typedef struct tagS_TCD_RBS_SSA
   {
        P_TCDSKAL_DATA    pSkal ;
        P_TCDTAB1_DATA    pTab1 ;
        P_TCDTAB2_DATA    pTab2 ;
        P_TCDDAT_DATA     pDat  ;
        P_TCDVGL_DATA     pVgl  ;
   } S_TCD_RBS_SSA ;

   typedef S_TCD_RBS_SSA  * P_TCD_RBS_SSA ;


   typedef struct tagS_TCDRBS_SS {
       S_TCDRBSCTL       RCTL ;
       S_TCD_RBS_SSA     SSAData   ;
       S_TCDPOOLADMIN    PoolAdmin ;
       S_TCDMPRCADMIN    MPrcAdmin ;
 } S_TCDRBS_SS ;

 typedef S_TCDRBS_SS  * P_TCDRBS_SS ;

  typedef struct tagS_TCDPARATTR_SK {
        TCD_INT      Level ;
        TCD_DOUBLE   Val ;
 } S_TCDPARATTR_SK   ;

 typedef S_TCDPARATTR_SK  * P_TCDPARATTR_SK ;

  typedef struct tagS_TCDPARATTR_VGL {
        TCD_INT      Level;
        char         Val  [TCD_VGLOP_LNG] ;
 } S_TCDPARATTR_VGL  ;

 typedef S_TCDPARATTR_VGL * P_TCDPARATTR_VGL ;

  typedef struct tagS_TCDPARATTR_DAT
  {
        TCD_INT      Level;
        char         Val  [TCD_DATUM_LNG] ;
 } S_TCDPARATTR_DAT  ;

 typedef S_TCDPARATTR_DAT * P_TCDPARATTR_DAT ;

/*-----------
  Struktur Schnittstellendaten (interne Sicht)
-----------*/
  typedef struct tagS_TCDISSADATA
  {
     TCD_INT      AnzSSASkal ;
     TCD_INT      AnzSSATab1 ;
     TCD_INT      AnzSSATab2 ;
     TCD_INT      AnzSSADat ;
     TCD_INT      AnzSSAVgl ;
     TCD_INT      AnzParSkal;
     TCD_INT      AnzParVgl ;
     TCD_INT      AnzParDat ;
     TCD_INT      AnzZeilen ;
     TCD_INT      AnzSpalten ;
     P_TCDSKAL_DATA    pSkal ;
     P_TCDTAB1_DATA    pTab1 ;
     P_TCDTAB2_DATA    pTab2 ;
     P_TCDDAT_DATA     pDat ;
     P_TCDVGL_DATA     pVgl ;
     P_TCDPARATTR_SK   pParSkal ;
     P_TCDPARATTR_VGL  pParVgl;
     P_TCDPARATTR_DAT  pParDat;

 }   S_TCDISSADATA ;
 typedef S_TCDISSADATA * P_TCDISSADATA ;



/*------
Datenstruktur globale Daten des Rechenbausteins;
diese Datenstruktur enthaelt Informationen und Teilstrukturen, die
in den programmierten Funktionen benoetigt werden.
Initialisierung dieser Daten erfolgt mehrstufig.
- beim Init: globaler Pointer pTCDTCD initialisiert (zeigt auf die Str)
pRbsSS zeigt auf die RBS-Schnittstelle
- bei auspraegungsspez. Opcodes werden die Teilstrukturen fuer die
Auspraegung initialisiert, ...
- bei einer neuen Berechnung werden die internen Aufrufschnittstellen
initialisiert
--------*/
  typedef struct tagS_TCD_C_G
  {
      P_TCDRBS_SS      pRbsSS      ;
      P_TCDPRCELEM     pPrcData    ;
      S_TCDPRCHDR *    pPrcHdr     ;
      P_TCDPRCELEM     pPrcTreeNode;
      P_TCDPRCELEM     pInfo       ;
      P_TCDRELATTR_IMP pRelAttrs   ;
      P_TCDMPRCADMIN   pMPrcAdmin  ;
      P_TCDRBSCTL      pRbsCtl     ;
      S_TCDISSADATA    SSAData     ;
      P_TCDPOOLADMIN   pPoolAdmin  ;
      TCD_INT          GlbVarSet   ;
      TCD_LONG         RBS_ID      ;
      TCD_BOOL         ValFound    ;
      TCD_BOOL         FrmFound    ;
      TCD_BOOL         V_Comp      ;
      TCD_BOOL         PrcChg      ;
      void *           pApplIf     ;
      P_TCDTAB         ResTab      ;
      TCD_DOUBLE       ResSkal     ;
      
      TCD_LONG         LastCalcPrcID;
      LP_VECT          pErgebnisPool;
      TCD_LONG         iBerechnungsNummer;
      TCD_INT          iErgPoolIteratorGl;                       
      P_PAARLISTE      pPaarListeNotToSave;
      
      TCD_BOOL         btrace_open;
      TCD_BOOL         btrace_enabled;
      
/* RWE, 10.06.1997: Neues Datenelement fuer Beobachtung
   der Wiederverwendung (ehemals WatchPol-Funktionalitaet) */
      TCD_BOOL         bProtWV;
      
  }   S_TCD_C_G ;
  typedef S_TCD_C_G   * P_TCD_C_G ;
#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDI_H)
#define TCDI_H
/*--------------
    Name        : TCDI.H

    Beschreibung: Include File intern nur f�r C- Generator
                  wird von den fest programmierten Moduln und
                  generierten Moduln benoetigt
    By          : BEGGI
    Datum       : 22.02.94
    Historie    : BEG   28.11.95   Definition Attributklassen
*--------------*/

/*-------------
  Returncodes FrmRet und ValRet (Definitionen analog Cobol) fuer
  Attributmanager
---------------*/
#define TCD_AIRC_CALLVIAFRM    4

/*-------------
  Definitionen Attributtypen (Aufzaehlungstyp)
---------------*/
#define TCD_ATTYP_TAR_SKAL      1
#define TCD_ATTYP_TAR_TAB1      2
#define TCD_ATTYP_TAR_TAB2      3
#define TCD_ATTYP_TAR_DATE      4
#define TCD_ATTYP_TAR_VGLO      5
#define TCD_ATTYP_BST_SKAL      6
#define TCD_ATTYP_BST_TAB1      7
#define TCD_ATTYP_BST_TAB2      8
#define TCD_ATTYP_BST_DATE      9
#define TCD_ATTYP_BST_VGLO     10

#define TCD_ATTRTYP_SKAL        0
#define TCD_ATTRTYP_TAB1        1
#define TCD_ATTRTYP_TAB2        2
#define TCD_ATTRTYP_DATE        3
#define TCD_ATTRTYP_VGLO        4

/*--------------
  Definitionen Attributklasse
---------------*/
#define TCD_ATTRCLASS_TAR       1
#define TCD_ATTRCLASS_BST       6

/*-------------
  Definitionen Errorcodes
---------------*/
#define TCD_UNKNOWN_OPCODE       1
#define TCD_NO_SPACE_IN_TLIST    2
#define TCD_ERR_GETMEM           3
#define TCD_GETEMPTYENTRY        4
#define TCD_NOPOOLADMIN          5
#define TCD_ILLTABFMT            6
#define TCD_UNK_ASSIGNTYP        7
#define TCD_NO_MPRCADMIN         8
#define TCD_EXPPOOLADMIN         9
#define TCD_NO_MEMORY           10
#define TCD_NO_PRCREF           11
#define TCD_ILLFRM_ID           12
#define TCD_ILLFRM_CMP          13
#define TCD_ERR_INIT_FORMEL     14
#define TCD_FRMGEN_OUT_OF_DATE	15
#define TCD_TRPFMT_OUT_OF_DATE	16

/*----------
  Datenstruktur Freigabeliste  Hilfsvariablentabellen
 ------------*/
  typedef struct tagS_TCDTABLIST    {
         TCD_INT        CallOvw ;
         TCD_LONG       CallerID ;
         TCD_LONG       CallFrmNr ;
         TCD_INT        CallType  ;
         P_TCD_DOUBLE   Adr ;
 } S_TCDTABLIST   ;

 typedef  S_TCDTABLIST  * P_TCDTABLIST  ;

/*----------
  Datenstruktur Formelparameter
 ------------*/
  typedef struct tagS_TCD_C_F1 
  {
     char         * FormelName     ;
     TCD_INT        FrmTyp         ;
     TCD_LONG       FrmNr          ;
     TCD_INT        FrmIx          ;
     char         * AttrName       ;
     TCD_INT        CallType       ;
     TCD_LONG       AttrID         ;
     TCD_INT        AttrTyp        ;
     TCD_INT        AttrIx         ;
     TCD_INT        ParIx          ;
     TCD_INT        Ret            ;
     TCD_INT        ExecCond       ;
     P_TCDPRCNODE   PrcFNode       ;
     P_TCDPRCNODE   pNode          ;
     TCD_INT        MinVarSet      ;
     TCD_INT        BegVarSet      ;
     char         * CmpTime        ;
     TCD_INT        Level          ;
     P_TCD_DOUBLE   pVarSkal       ;
     P_P_TCDTAB     pVarTab        ;
     char         * VarDatVgl      ;
     TCD_INT      * VarIndex       ;
     P_TCDTABLIST   FreeList       ;
     TCD_INT        AnzTabList     ;
     TCD_INT        AnzTabListEnt  ;
     P_TCDPRCNODE   NextFNode      ;
     TCD_INT        NextExecCond   ;
     TCD_INT        NextCallType   ;
     struct tagS_TCD_C_F1 * pPrevLevelInfo ;
     P_TCD_C_G      pTCDTCD ;
  } S_TCD_C_F1 ;

  typedef  S_TCD_C_F1 *   P_TCD_C_F1 ;

  typedef struct tagS_TCDFTAB {
        char          FrmName [TCD_NAME_LNG] ;
        void          (* pFormelFunc ) ( P_TCD_C_F1);
        TCD_LONG      FrmNr      ;
        TCD_INT       FrmTyp     ;
        char          Datum [TCD_FRM_DATUM_LNG] ;
  } S_TCDFTAB     ;

 typedef S_TCDFTAB     * P_TCDFTAB     ;

/* extern P_TCD_C_G pTCDTCD ; */

#endif


/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_POOL_H)
#define TCD_POOL_H
/*---------------------------------------------------------------------
  Datei      : TCD_POOL.h
  Generiert am 16.12.2019 15:07:18
  Historie      : 27.7.95    BEG neuer Prefix fuer Tabellenentry
---------------------------------------------------------------------*/
void    TCDPIT   (P_TCD_C_G);
void    TCDPRP   (P_TCD_C_G) ;
void    TCDPST   (P_TCD_C_G) ;
void    TCDPRT   (P_TCD_C_G) ;
void    TCDPSAT  (P_TCD_C_G) ;
void    TCDPRTA  (P_TCD_C_G) ;
TCD_INT TCDPGF   (P_TCD_C_G,P_TCD_DOUBLE Var, TCD_INT *PIndex) ;

#endif

/*---------------------------------------------------------------------------

(C) Copyright 1993-2002, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------------*/
#if !defined (TCD_ATTR_H)
#define TCD_ATTR_H
/*---------------------------------------------------------------------
  Datei:        TCD_ATTR.H
  Beschreibung: Attributmanager
---------------------------------------------------------------------*/
TCD_INT   TCDAATS (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAATT (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAABS (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAABT (P_TCD_C_F1 pF1) ;
void      TCDAATD (P_TCD_C_F1 pF1) ;
void      TCDAABD (P_TCD_C_F1 pF1) ;
void      TCDAATV (P_TCD_C_F1 pF1) ;
void      TCDAABV (P_TCD_C_F1 pF1) ;
void      TCDAFT  (P_TCD_C_F1 pF1) ;
void      TCDAFBS (P_TCD_C_F1 pF1) ;
void      TCDAFBT (P_TCD_C_F1 pF1) ;

#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_FRT_H)
#define TCD_FRT_H
/*---------------------------------------------------------------------
    Datei:        TCD_FRT.H

Beschreibung: Modul zur allgemeinen Endebehandlung einer Formelfunktion
By:           BEGGI
Datum:        30.03.94
Historie:     BEG    28.11.95  neue Funktion: TCDSetPD
---------------------------------------------------------------------*/
TCD_INT TCDInit (P_TCD_C_F1 pMyPar, TCD_INT FrmNr, char *fctl_cmptime,
				 TCD_LONG VerNr);
void    TCDFtID (P_TCD_C_F1 pMyPar, char * AttrName,
                 TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                 TCD_INT *Var) ;

void    TCDSetPS (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                 TCD_DOUBLE *Var1, TCD_INT *Var2, TCD_DOUBLE Var3) ;
void    TCDSetPV (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                  char *Var1, TCD_INT *Var2, char *Var3) ;
void    TCDSetPD (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                  char *Var1, TCD_INT *Var2, char *Var3) ;

TCD_INT TCDGetTb (P_TCD_C_F1 pMyPar, P_P_TCDTAB Var) ;
void    TCDIniPS (P_TCD_C_G) ;

void    TCDIniFC (P_TCD_C_G) ;
void    TCDIniFU (P_TCD_C_G) ;
void    TCDIniFM (P_TCD_C_G) ;

void    TCDRetSk (P_TCD_C_F1 pMyPar, P_TCD_DOUBLE  VarSkal) ;
void    TCDRetTb (P_TCD_C_F1 pF1, P_P_TCDTAB  VarTab) ;

/*-----------------
  TraceFunktionsprototypen und Trace Makros
-------------------*/
#ifdef TRACEFKT
void _TCD_TRACE( const char * ,const char * ,const char *,P_TCD_C_G );
void _TCD_TRVAL( const char * , int , double *, double,P_TCD_C_G  ) ;

#define TCD_TRACE(pack,func,text, pTCDTCD)  \
            _TCD_TRACE(pack,func,text, pTCDTCD);
#define TCD_TRVAL(text,type,val1,val2, pTCDTCD) \
            _TCD_TRVAL(text,type,val1,val2, pTCDTCD);
#endif

#define C_TRACEFILE        "CTRACE.TCD"

#endif
  
/* RWE, 10.06.1997   */
/*-----------------
  Funktionsprototypen fuer Wiederverwendungsprotokoll
-------------------*/ 
#ifdef PROTWV
void     SetProtWV             (P_TCD_C_G pIf, TCD_BOOL bProtWV);   
  /* ^Dieser Prototyp ist auch in commands.c enthalten! */
TCD_BOOL ProtWVEnabled         (P_TCD_C_G pIf);
void     ProtWV1               (P_TCD_C_F1 pMyPar); 
void     ProtWV2               (P_TCD_C_F1   pMyPar, 
                                P_TCDPRCNODE pNode,
                                P_PAARLISTE  pPaarListe, 
                                TCD_INT      iFlag);
void     ProtWVString          (char *s);
                                
#define C_PROTWVFILE       "CPROTWV.TCD"
#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_IOP_H)
#define TCD_IOP_H

#ifndef SUBSYSTEM
  #define IOP_EXPORT 
#else
  #define IOP_EXPORT
#endif
TCD_DOUBLE IOP_EXPORT   TCDABS     (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDFAK     (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDINT     (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDSIGN    (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDDIV     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDEXP     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDMIN     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDMAX     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDZDAYS   (TCD_INT    datefmt, char *val1, 
                                    char *val2);
TCD_DOUBLE IOP_EXPORT   TCDKDAYS   (TCD_INT    datefmt, char *val1, 
                                    char *val2);
TCD_DOUBLE IOP_EXPORT   TCDRND     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDCUT     (TCD_DOUBLE val1, TCD_DOUBLE val2);


#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_FCTL_H)
#define TCD_FCTL_H
/*---------------------------------------------------------------------
  Modul:   TCD_FCTL.H
  f�r RBS: LifeTemplate
---------------------------------------------------------------------*/

void  LifeTemF(P_TCD_C_G pTCDTCD) ;
void  LifeTem1(P_TCD_C_F1  pF1 ) ;
void    TCD3FES (P_TCD_C_F1 pMyPar, char * AttrName, TCD_INT Ix,
                       TCD_LONG ID, TCD_INT AttrTyp, TCD_INT ParIx,
                       P_TCD_DOUBLE Var) ;
void    TCD3FET (P_TCD_C_F1 pMyPar, char * AttrName, TCD_INT Ix,
                      TCD_LONG ID, TCD_INT AttrTyp, P_P_TCDTAB Var);
void    TCD3FED (P_TCD_C_F1 pMyPar, char * AttrName,
                      TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                      TCD_INT ParIx, char *Var) ;
void    TCD3FEV (P_TCD_C_F1 pMyPar, char * AttrName,
                      TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                      TCD_INT ParIx, char *Var) ;
TCD_INT TCD3FE1 (P_TCD_C_F1 pMyPar, TCD_BOOL option, char * Name,
                      TCD_LONG ID, TCD_INT FrmNr, P_TCD_DOUBLE Var) ;
TCD_INT TCD3FE2 (P_TCD_C_F1 pMyPar, TCD_BOOL option, char * Name,
                      TCD_LONG ID, TCD_INT FrmNr, P_P_TCDTAB  Var) ;

TCD_INT TCDChkFrm     (P_TCD_C_F1,void *);
void    ClearOverwriteStack(P_TCD_C_G pTCDTCD );

void       TCD3FESaveResult(P_TCD_C_F1);

#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_PKF_H)
#define TCD_PKF_H
/*---------------------------------------------------------------------
    Modul:        C:\dev\TCD_DB\template\db\R3FE\C\C3E9\lifete10.h

    Beschreibung: Funktionsprototypen der externen Funktionen der
                  Formelsammlungsdatei
    By:           BEGGI
    Generiert am: 16.12.2019 15:07:19
---------------------------------------------------------------------*/
   
      void LifeTem1 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTem2 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTem3 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTem4 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTem5 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTem6 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTem7 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTem8 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTem9 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe10 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe11 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe12 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe13 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe14 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe15 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe16 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe17 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe18 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe19 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe20 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe21 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe22 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe23 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe24 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe25 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe26 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe27 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe28 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe29 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe30 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe31 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe32 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe33 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe34 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe35 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe36 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe37 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe38 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe39 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe40 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe41 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe42 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe43 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe44 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe45 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe46 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe47 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe48 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe49 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe50 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe51 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe52 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe53 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe54 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe55 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe56 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe57 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe58 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe59 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe60 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe61 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe62 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe63 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe64 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe65 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe66 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe67 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe68 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe69 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe70 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe71 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe72 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe73 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe74 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe75 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe76 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe77 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe78 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe79 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe80 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe81 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe82 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe83 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe84 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe85 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe86 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe87 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe88 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe89 (P_TCD_C_F1 pMyPar) ;
   

#endif



/*---------------------------------------------------------
   Externe Funktion : LifeTem1
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_n_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeTem1 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeTem1","Begin asgn_e_n_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,1,"12.12.2019 17:29:55",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeTem1",
              "Ende asgn_e_n_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_n_n", 0, 4, 6, 0, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeTem1","End asgn_e_n_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_n_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_n_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_n_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeTem5
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_m_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeTem5 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeTem5","Begin asgn_e_m_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,5,"12.12.2019 17:29:55",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeTem5",
              "Ende asgn_e_m_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_m_n", 1, 8, 6, 1, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeTem5","End asgn_e_m_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_m_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_m_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_m_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeTe15
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_TBeg_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeTe15 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeTe15","Begin asgn_e_TBeg_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,15,"12.12.2019 17:29:55",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeTe15",
              "Ende asgn_e_TBeg_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_TBeg_n", 2, 19, 6, 2, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeTe15","End asgn_e_TBeg_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_TBeg_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_TBeg_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_TBeg_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeTe16
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_tarif_nr_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeTe16 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeTe16","Begin asgn_e_tarif_nr_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,16,"12.12.2019 17:29:55",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeTe16",
              "Ende asgn_e_tarif_nr_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_tarif_nr_n", 3, 20, 6, 3, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeTe16","End asgn_e_tarif_nr_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_tarif_nr_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_tarif_nr_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_tarif_nr_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeTe23
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_tarsumme_ges_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeTe23 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeTe23","Begin asgn_e_tarsumme_ges_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,23,"12.12.2019 17:29:55",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeTe23",
              "Ende asgn_e_tarsumme_ges_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_tarsumme_ges_n", 4, 27, 6, 4, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeTe23","End asgn_e_tarsumme_ges_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_tarsumme_ges_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_tarsumme_ges_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_tarsumme_ges_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeTe29
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_tarsumme_pfr_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeTe29 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeTe29","Begin asgn_e_tarsumme_pfr_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,29,"12.12.2019 17:29:56",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeTe29",
              "Ende asgn_e_tarsumme_pfr_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_tarsumme_pfr_n", 5, 33, 6, 5, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeTe29","End asgn_e_tarsumme_pfr_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_tarsumme_pfr_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_tarsumme_pfr_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_tarsumme_pfr_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeTe83
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_m_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeTe83 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeTe83","Begin asgn_e_m_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,83,"12.12.2019 17:29:56",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeTe83",
              "Ende asgn_e_m_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_m_o", 6, 103, 6, 6, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeTe83","End asgn_e_m_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_m_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_m_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_m_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeTe84
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_n_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeTe84 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeTe84","Begin asgn_e_n_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,84,"12.12.2019 17:29:56",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeTe84",
              "Ende asgn_e_n_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_n_o", 7, 104, 6, 7, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeTe84","End asgn_e_n_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_n_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_n_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_n_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeTe99
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_tarif_nr_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeTe99 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeTe99","Begin asgn_e_tarif_nr_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,99,"12.12.2019 17:29:56",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeTe99",
              "Ende asgn_e_tarif_nr_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_tarif_nr_o", 8, 121, 6, 8, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeTe99","End asgn_e_tarif_nr_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_tarif_nr_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_tarif_nr_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_tarif_nr_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT100
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_TBeg_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT100 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT100","Begin asgn_e_TBeg_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,100,"12.12.2019 17:29:56",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT100",
              "Ende asgn_e_TBeg_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_TBeg_o", 9, 122, 6, 9, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT100","End asgn_e_TBeg_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_TBeg_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_TBeg_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_TBeg_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT103
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_reserve_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT103 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT103","Begin asgn_e_reserve_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,103,"12.12.2019 17:29:56",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT103",
              "Ende asgn_e_reserve_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_reserve_o", 10, 125, 6, 10, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT103","End asgn_e_reserve_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_reserve_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_reserve_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_reserve_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT112
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_tarsumme_ges_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT112 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT112","Begin asgn_e_tarsumme_ges_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,112,"12.12.2019 17:29:56",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT112",
              "Ende asgn_e_tarsumme_ges_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_tarsumme_ges_o", 11, 134, 6, 11, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT112","End asgn_e_tarsumme_ges_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_tarsumme_ges_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_tarsumme_ges_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_tarsumme_ges_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT131
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_i_Wert
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT131 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT131","Begin asgn_i_Wert",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,131,"12.12.2019 17:29:56",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT131",
              "Ende asgn_i_Wert",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "i_Wert", 21, 315, 1, 109, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT131","End asgn_i_Wert",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_i_Wert", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_i_Wert", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_i_Wert");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT552
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_NumberOfInsPers_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT552 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT552","Begin asgn_e_NumberOfInsPers_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,552,"12.12.2019 17:29:56",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT552",
              "Ende asgn_e_NumberOfInsPers_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_NumberOfInsPers_n", 12, 323, 6, 12, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT552","End asgn_e_NumberOfInsPers_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_NumberOfInsPers_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_NumberOfInsPers_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_NumberOfInsPers_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT555
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_BirthDate_IP1_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT555 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT555","Begin asgn_e_BirthDate_IP1_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,555,"12.12.2019 17:29:56",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT555",
              "Ende asgn_e_BirthDate_IP1_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_BirthDate_IP1_n", 13, 330, 6, 13, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT555","End asgn_e_BirthDate_IP1_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_BirthDate_IP1_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_BirthDate_IP1_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_BirthDate_IP1_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT557
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_ea_IP1_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT557 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT557","Begin asgn_e_ea_IP1_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,557,"12.12.2019 17:29:57",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT557",
              "Ende asgn_e_ea_IP1_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_ea_IP1_n", 14, 332, 6, 14, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT557","End asgn_e_ea_IP1_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_ea_IP1_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_ea_IP1_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_ea_IP1_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT558
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_ea_IP2_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT558 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT558","Begin asgn_e_ea_IP2_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,558,"12.12.2019 17:29:57",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT558",
              "Ende asgn_e_ea_IP2_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_ea_IP2_n", 15, 333, 6, 15, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT558","End asgn_e_ea_IP2_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_ea_IP2_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_ea_IP2_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_ea_IP2_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT559
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_gender_IP1_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT559 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT559","Begin asgn_e_gender_IP1_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,559,"12.12.2019 17:29:57",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT559",
              "Ende asgn_e_gender_IP1_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_gender_IP1_n", 16, 334, 6, 16, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT559","End asgn_e_gender_IP1_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_gender_IP1_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_gender_IP1_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_gender_IP1_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT560
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_gender_IP2_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT560 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT560","Begin asgn_e_gender_IP2_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,560,"12.12.2019 17:29:57",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT560",
              "Ende asgn_e_gender_IP2_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_gender_IP2_n", 17, 335, 6, 17, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT560","End asgn_e_gender_IP2_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_gender_IP2_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_gender_IP2_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_gender_IP2_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT561
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_BirthDate_IP1_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT561 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT561","Begin asgn_e_BirthDate_IP1_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,561,"12.12.2019 17:29:57",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT561",
              "Ende asgn_e_BirthDate_IP1_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_BirthDate_IP1_o", 18, 336, 6, 18, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT561","End asgn_e_BirthDate_IP1_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_BirthDate_IP1_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_BirthDate_IP1_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_BirthDate_IP1_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT563
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_RiskGroup_IP1_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT563 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT563","Begin asgn_e_RiskGroup_IP1_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,563,"12.12.2019 17:29:57",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT563",
              "Ende asgn_e_RiskGroup_IP1_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_RiskGroup_IP1_n", 19, 338, 6, 19, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT563","End asgn_e_RiskGroup_IP1_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_RiskGroup_IP1_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_RiskGroup_IP1_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_RiskGroup_IP1_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT564
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_RiskGroup_IP2_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT564 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT564","Begin asgn_e_RiskGroup_IP2_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,564,"12.12.2019 17:29:57",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT564",
              "Ende asgn_e_RiskGroup_IP2_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_RiskGroup_IP2_n", 20, 339, 6, 20, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT564","End asgn_e_RiskGroup_IP2_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_RiskGroup_IP2_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_RiskGroup_IP2_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_RiskGroup_IP2_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT565
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_RiskGroup_IP1_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT565 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT565","Begin asgn_e_RiskGroup_IP1_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,565,"12.12.2019 17:29:57",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT565",
              "Ende asgn_e_RiskGroup_IP1_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_RiskGroup_IP1_o", 21, 340, 6, 21, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT565","End asgn_e_RiskGroup_IP1_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_RiskGroup_IP1_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_RiskGroup_IP1_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_RiskGroup_IP1_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT566
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_RiskGroup_IP2_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT566 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT566","Begin asgn_e_RiskGroup_IP2_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,566,"12.12.2019 17:29:57",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT566",
              "Ende asgn_e_RiskGroup_IP2_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_RiskGroup_IP2_o", 22, 341, 6, 22, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT566","End asgn_e_RiskGroup_IP2_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_RiskGroup_IP2_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_RiskGroup_IP2_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_RiskGroup_IP2_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT567
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_NumberOfInsPers_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT567 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT567","Begin asgn_e_NumberOfInsPers_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,567,"12.12.2019 17:29:57",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT567",
              "Ende asgn_e_NumberOfInsPers_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_NumberOfInsPers_o", 23, 342, 6, 23, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT567","End asgn_e_NumberOfInsPers_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_NumberOfInsPers_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_NumberOfInsPers_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_NumberOfInsPers_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT568
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_x_IP1_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT568 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT568","Begin asgn_e_x_IP1_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,568,"12.12.2019 17:29:57",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT568",
              "Ende asgn_e_x_IP1_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_x_IP1_o", 24, 343, 6, 24, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT568","End asgn_e_x_IP1_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_x_IP1_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_x_IP1_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_x_IP1_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT569
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_x_IP2_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT569 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT569","Begin asgn_e_x_IP2_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,569,"12.12.2019 17:29:58",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT569",
              "Ende asgn_e_x_IP2_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_x_IP2_o", 25, 344, 6, 25, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT569","End asgn_e_x_IP2_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_x_IP2_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_x_IP2_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_x_IP2_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT570
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_x_IP1_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT570 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT570","Begin asgn_e_x_IP1_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,570,"12.12.2019 17:29:58",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT570",
              "Ende asgn_e_x_IP1_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_x_IP1_n", 26, 345, 6, 26, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT570","End asgn_e_x_IP1_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_x_IP1_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_x_IP1_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_x_IP1_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT571
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_x_IP2_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT571 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT571","Begin asgn_e_x_IP2_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,571,"12.12.2019 17:29:58",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT571",
              "Ende asgn_e_x_IP2_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_x_IP2_n", 27, 346, 6, 27, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT571","End asgn_e_x_IP2_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_x_IP2_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_x_IP2_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_x_IP2_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT574
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_currentDate_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT574 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT574","Begin asgn_e_currentDate_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,574,"12.12.2019 17:29:58",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT574",
              "Ende asgn_e_currentDate_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_currentDate_n", 28, 348, 6, 28, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT574","End asgn_e_currentDate_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_currentDate_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_currentDate_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_currentDate_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT584
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_CalcDate
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT584 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT584","Begin asgn_e_CalcDate",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,584,"12.12.2019 17:29:58",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT584",
              "Ende asgn_e_CalcDate",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_CalcDate", 29, 351, 6, 29, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT584","End asgn_e_CalcDate",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_CalcDate", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_CalcDate", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_CalcDate");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT585
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_BackOffice
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT585 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT585","Begin asgn_e_BackOffice",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,585,"12.12.2019 17:29:58",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT585",
              "Ende asgn_e_BackOffice",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_BackOffice", 30, 352, 6, 30, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT585","End asgn_e_BackOffice",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_BackOffice", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_BackOffice", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_BackOffice");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT589
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_CostTab
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT589 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_INT     HV_0 = 0;
   TCD_INT     HV_1 = 0;
   TCD_INT     HV_3 = 0;
   P_TCDTAB2   HV_2;
   P_TCDTAB2   HV_4;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT589","Begin asgn_CostTab",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,589,"12.12.2019 17:29:58",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Besorgen einer freien Tabelle, falls Formel vom Typ TAB1/TAB2 */
   rc = TCDGetTb (pMyPar, &HV_2);


   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT589",
              "Ende asgn_CostTab",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_3 = 0;
   for ( HV_0 = (TCD_INT) (0) ; HV_0 <= 199; HV_0 = HV_0 + 1 ) {
      for ( HV_1 = (TCD_INT) (0) ; HV_1 <= 109; HV_1 = HV_1 + 1 ) {
         if ( HV_3 != 0 ) goto l_5 ;
         TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_5: 
         HV_2 [ HV_0 * 110 + HV_1 ]  = HV_4 [ HV_0 * 110 + HV_1 ] ;
      }
   }


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetTb (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT589","End asgn_CostTab",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_CostTab", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_CostTab", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_CostTab");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT592
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_AddContrib_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT592 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT592","Begin asgn_e_AddContrib_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,592,"12.12.2019 17:29:58",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT592",
              "Ende asgn_e_AddContrib_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_AddContrib_n", 31, 359, 6, 31, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT592","End asgn_e_AddContrib_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_AddContrib_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_AddContrib_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_AddContrib_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT593
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_PartSurrender_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT593 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT593","Begin asgn_e_PartSurrender_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,593,"12.12.2019 17:29:59",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT593",
              "Ende asgn_e_PartSurrender_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_PartSurrender_n", 32, 360, 6, 32, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT593","End asgn_e_PartSurrender_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_PartSurrender_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_PartSurrender_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_PartSurrender_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT594
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_RateClass_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT594 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT594","Begin asgn_e_RateClass_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,594,"12.12.2019 17:29:59",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT594",
              "Ende asgn_e_RateClass_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_RateClass_n", 33, 361, 6, 33, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT594","End asgn_e_RateClass_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_RateClass_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_RateClass_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_RateClass_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT595
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_RateClass_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT595 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT595","Begin asgn_e_RateClass_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,595,"12.12.2019 17:29:59",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT595",
              "Ende asgn_e_RateClass_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_RateClass_o", 34, 362, 6, 34, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT595","End asgn_e_RateClass_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_RateClass_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_RateClass_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_RateClass_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT605
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_OccuClass_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT605 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT605","Begin asgn_e_OccuClass_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,605,"12.12.2019 17:29:59",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT605",
              "Ende asgn_e_OccuClass_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_OccuClass_n", 35, 364, 6, 35, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT605","End asgn_e_OccuClass_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_OccuClass_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_OccuClass_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_OccuClass_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT606
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_OccuSurcha_IP1_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT606 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT606","Begin asgn_e_OccuSurcha_IP1_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,606,"12.12.2019 17:29:59",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT606",
              "Ende asgn_e_OccuSurcha_IP1_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_OccuSurcha_IP1_n", 36, 367, 6, 36, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT606","End asgn_e_OccuSurcha_IP1_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_OccuSurcha_IP1_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_OccuSurcha_IP1_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_OccuSurcha_IP1_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT607
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_SportsSurcha_IP1_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT607 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT607","Begin asgn_e_SportsSurcha_IP1_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,607,"12.12.2019 17:29:59",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT607",
              "Ende asgn_e_SportsSurcha_IP1_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_SportsSurcha_IP1_n", 37, 368, 6, 37, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT607","End asgn_e_SportsSurcha_IP1_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_SportsSurcha_IP1_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_SportsSurcha_IP1_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_SportsSurcha_IP1_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT608
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_SportsSurcha_IP1_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT608 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT608","Begin asgn_e_SportsSurcha_IP1_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,608,"12.12.2019 17:29:59",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT608",
              "Ende asgn_e_SportsSurcha_IP1_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_SportsSurcha_IP1_o", 38, 369, 6, 38, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT608","End asgn_e_SportsSurcha_IP1_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_SportsSurcha_IP1_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_SportsSurcha_IP1_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_SportsSurcha_IP1_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT609
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_OccuSurcha_IP1_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT609 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT609","Begin asgn_e_OccuSurcha_IP1_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,609,"12.12.2019 17:29:59",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT609",
              "Ende asgn_e_OccuSurcha_IP1_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_OccuSurcha_IP1_o", 39, 370, 6, 39, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT609","End asgn_e_OccuSurcha_IP1_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_OccuSurcha_IP1_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_OccuSurcha_IP1_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_OccuSurcha_IP1_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT610
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_AddSurcharge_IP1_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT610 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT610","Begin asgn_e_AddSurcharge_IP1_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,610,"12.12.2019 17:29:59",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT610",
              "Ende asgn_e_AddSurcharge_IP1_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_AddSurcharge_IP1_n", 40, 371, 6, 40, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT610","End asgn_e_AddSurcharge_IP1_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_AddSurcharge_IP1_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_AddSurcharge_IP1_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_AddSurcharge_IP1_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT611
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_AddSurcharge_IP2_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT611 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT611","Begin asgn_e_AddSurcharge_IP2_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,611,"12.12.2019 17:29:59",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT611",
              "Ende asgn_e_AddSurcharge_IP2_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_AddSurcharge_IP2_n", 41, 372, 6, 41, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT611","End asgn_e_AddSurcharge_IP2_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_AddSurcharge_IP2_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_AddSurcharge_IP2_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_AddSurcharge_IP2_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT612
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_wo_examination_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT612 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT612","Begin asgn_e_wo_examination_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,612,"12.12.2019 17:30:00",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT612",
              "Ende asgn_e_wo_examination_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_wo_examination_n", 44, 379, 6, 44, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT612","End asgn_e_wo_examination_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_wo_examination_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_wo_examination_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_wo_examination_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT613
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_wo_examination_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT613 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT613","Begin asgn_e_wo_examination_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,613,"12.12.2019 17:30:00",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT613",
              "Ende asgn_e_wo_examination_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_wo_examination_o", 45, 380, 6, 45, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT613","End asgn_e_wo_examination_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_wo_examination_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_wo_examination_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_wo_examination_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT616
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_HealthClass_IP1_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT616 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT616","Begin asgn_e_HealthClass_IP1_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,616,"12.12.2019 17:30:00",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT616",
              "Ende asgn_e_HealthClass_IP1_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_HealthClass_IP1_n", 46, 381, 6, 46, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT616","End asgn_e_HealthClass_IP1_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_HealthClass_IP1_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_HealthClass_IP1_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_HealthClass_IP1_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT619
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_HealthSurch_IP1_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT619 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT619","Begin asgn_e_HealthSurch_IP1_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,619,"12.12.2019 17:30:00",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT619",
              "Ende asgn_e_HealthSurch_IP1_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_HealthSurch_IP1_o", 48, 389, 6, 48, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT619","End asgn_e_HealthSurch_IP1_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_HealthSurch_IP1_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_HealthSurch_IP1_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_HealthSurch_IP1_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT620
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_SpecialDiscount_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT620 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT620","Begin asgn_e_SpecialDiscount_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,620,"12.12.2019 17:29:58",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT620",
              "Ende asgn_e_SpecialDiscount_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_SpecialDiscount_n", 49, 390, 6, 49, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT620","End asgn_e_SpecialDiscount_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_SpecialDiscount_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_SpecialDiscount_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_SpecialDiscount_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT621
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_SumDiscount_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT621 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT621","Begin asgn_e_SumDiscount_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,621,"12.12.2019 17:29:58",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT621",
              "Ende asgn_e_SumDiscount_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_SumDiscount_n", 50, 391, 6, 50, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT621","End asgn_e_SumDiscount_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_SumDiscount_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_SumDiscount_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_SumDiscount_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT622
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_HealthSurch_IP1_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT622 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT622","Begin asgn_e_HealthSurch_IP1_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,622,"12.12.2019 17:29:58",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT622",
              "Ende asgn_e_HealthSurch_IP1_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_HealthSurch_IP1_n", 47, 388, 6, 47, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT622","End asgn_e_HealthSurch_IP1_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_HealthSurch_IP1_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_HealthSurch_IP1_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_HealthSurch_IP1_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT623
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_AlphaCostMatrix
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT623 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_INT     HV_0 = 0;
   TCD_INT     HV_1 = 0;
   TCD_INT     HV_3 = 0;
   P_TCDTAB2   HV_2;
   P_TCDTAB2   HV_4;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT623","Begin asgn_AlphaCostMatrix",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,623,"12.12.2019 17:30:00",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Besorgen einer freien Tabelle, falls Formel vom Typ TAB1/TAB2 */
   rc = TCDGetTb (pMyPar, &HV_2);


   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT623",
              "Ende asgn_AlphaCostMatrix",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_3 = 0;
   for ( HV_0 = (TCD_INT) (0) ; HV_0 <= 199; HV_0 = HV_0 + 1 ) {
      for ( HV_1 = (TCD_INT) (0) ; HV_1 <= 109; HV_1 = HV_1 + 1 ) {
         if ( HV_3 != 0 ) goto l_5 ;
         TCD3FET (pMyPar, "AlphaCostMatrix", 1, 393, 8,  (P_TCDTAB *)
            &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_5: 
         HV_2 [ HV_0 * 110 + HV_1 ]  = HV_4 [ HV_0 * 110 + HV_1 ] ;
      }
   }


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetTb (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT623","End asgn_AlphaCostMatrix",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_AlphaCostMatrix", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_AlphaCostMatrix", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_AlphaCostMatrix");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT624
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_YieldFactorTab
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT624 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_INT     HV_0 = 0;
   TCD_INT     HV_1 = 0;
   TCD_INT     HV_3 = 0;
   P_TCDTAB2   HV_2;
   P_TCDTAB2   HV_4;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT624","Begin asgn_YieldFactorTab",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,624,"12.12.2019 17:30:00",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Besorgen einer freien Tabelle, falls Formel vom Typ TAB1/TAB2 */
   rc = TCDGetTb (pMyPar, &HV_2);


   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT624",
              "Ende asgn_YieldFactorTab",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_3 = 0;
   for ( HV_0 = (TCD_INT) (0) ; HV_0 <= 199; HV_0 = HV_0 + 1 ) {
      for ( HV_1 = (TCD_INT) (0) ; HV_1 <= 109; HV_1 = HV_1 + 1 ) {
         if ( HV_3 != 0 ) goto l_5 ;
         TCD3FET (pMyPar, "YieldFactorTab", 2, 394, 8,  (P_TCDTAB *)
            &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_5: 
         HV_2 [ HV_0 * 110 + HV_1 ]  = HV_4 [ HV_0 * 110 + HV_1 ] ;
      }
   }


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetTb (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT624","End asgn_YieldFactorTab",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_YieldFactorTab", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_YieldFactorTab", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_YieldFactorTab");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT625
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_MortalityTab
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT625 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_INT     HV_0 = 0;
   TCD_INT     HV_1 = 0;
   TCD_INT     HV_3 = 0;
   P_TCDTAB2   HV_2;
   P_TCDTAB2   HV_4;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT625","Begin asgn_MortalityTab",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,625,"12.12.2019 17:30:00",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Besorgen einer freien Tabelle, falls Formel vom Typ TAB1/TAB2 */
   rc = TCDGetTb (pMyPar, &HV_2);


   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_2);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT625",
              "Ende asgn_MortalityTab",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_3 = 0;
   for ( HV_0 = (TCD_INT) (0) ; HV_0 <= 199; HV_0 = HV_0 + 1 ) {
      for ( HV_1 = (TCD_INT) (0) ; HV_1 <= 109; HV_1 = HV_1 + 1 ) {
         if ( HV_3 != 0 ) goto l_5 ;
         TCD3FET (pMyPar, "MortalityTab", 3, 395, 8,  (P_TCDTAB *)
            &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_5: 
         HV_2 [ HV_0 * 110 + HV_1 ]  = HV_4 [ HV_0 * 110 + HV_1 ] ;
      }
   }


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetTb (pMyPar, &HV_2);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT625","End asgn_MortalityTab",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_MortalityTab", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_MortalityTab", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_MortalityTab");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT634
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_CommReduction_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT634 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT634","Begin asgn_e_CommReduction_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,634,"12.12.2019 17:30:00",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT634",
              "Ende asgn_e_CommReduction_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_CommReduction_o", 52, 408, 6, 52, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT634","End asgn_e_CommReduction_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_CommReduction_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_CommReduction_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_CommReduction_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT635
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_CommReduction_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT635 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT635","Begin asgn_e_CommReduction_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,635,"12.12.2019 17:30:00",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT635",
              "Ende asgn_e_CommReduction_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_CommReduction_n", 51, 407, 6, 51, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT635","End asgn_e_CommReduction_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_CommReduction_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_CommReduction_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_CommReduction_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT661
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_method
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT661 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT661","Begin asgn_e_method",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,661,"12.12.2019 17:30:01",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT661",
              "Ende asgn_e_method",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_method", 53, 409, 6, 53, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT661","End asgn_e_method",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_method", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_method", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_method");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT667
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_SumRelation
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT667 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT667","Begin asgn_e_SumRelation",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,667,"12.12.2019 17:30:01",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT667",
              "Ende asgn_e_SumRelation",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_SumRelation", 54, 410, 6, 54, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT667","End asgn_e_SumRelation",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_SumRelation", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_SumRelation", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_SumRelation");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT680
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_i_MaturityAmount
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT680 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT680","Begin asgn_i_MaturityAmount",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,680,"12.12.2019 17:30:01",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT680",
              "Ende asgn_i_MaturityAmount",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "i_MaturityAmount", 65, 419, 1, 153, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT680","End asgn_i_MaturityAmount",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_i_MaturityAmount", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_i_MaturityAmount", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_i_MaturityAmount");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT689
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_state_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT689 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT689","Begin asgn_e_state_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,689,"12.12.2019 17:30:01",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT689",
              "Ende asgn_e_state_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_state_n", 56, 423, 6, 56, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT689","End asgn_e_state_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_state_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_state_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_state_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT690
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_StateDetail_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT690 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT690","Begin asgn_e_StateDetail_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,690,"12.12.2019 17:30:01",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT690",
              "Ende asgn_e_StateDetail_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_StateDetail_n", 57, 424, 6, 57, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT690","End asgn_e_StateDetail_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_StateDetail_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_StateDetail_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_StateDetail_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT691
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_DeathBenFactor_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT691 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT691","Begin asgn_e_DeathBenFactor_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,691,"12.12.2019 17:30:01",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT691",
              "Ende asgn_e_DeathBenFactor_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_DeathBenFactor_n", 58, 425, 6, 58, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT691","End asgn_e_DeathBenFactor_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_DeathBenFactor_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_DeathBenFactor_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_DeathBenFactor_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT719
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_benefitPeriod_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT719 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT719","Begin asgn_e_benefitPeriod_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,719,"12.12.2019 17:30:01",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT719",
              "Ende asgn_e_benefitPeriod_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_benefitPeriod_n", 59, 432, 6, 59, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT719","End asgn_e_benefitPeriod_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_benefitPeriod_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_benefitPeriod_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_benefitPeriod_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT720
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_annutyPayFreq_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT720 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT720","Begin asgn_e_annutyPayFreq_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,720,"12.12.2019 17:30:01",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT720",
              "Ende asgn_e_annutyPayFreq_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_annutyPayFreq_n", 60, 433, 6, 60, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT720","End asgn_e_annutyPayFreq_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_annutyPayFreq_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_annutyPayFreq_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_annutyPayFreq_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT722
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_state_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT722 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT722","Begin asgn_e_state_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,722,"12.12.2019 17:30:01",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT722",
              "Ende asgn_e_state_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_state_o", 61, 434, 6, 61, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT722","End asgn_e_state_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_state_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_state_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_state_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT723
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_StateDetail_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT723 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT723","Begin asgn_e_StateDetail_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,723,"12.12.2019 17:30:01",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT723",
              "Ende asgn_e_StateDetail_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_StateDetail_o", 62, 435, 6, 62, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT723","End asgn_e_StateDetail_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_StateDetail_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_StateDetail_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_StateDetail_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT725
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_benefitPeriod_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT725 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT725","Begin asgn_e_benefitPeriod_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,725,"12.12.2019 17:30:02",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT725",
              "Ende asgn_e_benefitPeriod_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_benefitPeriod_o", 63, 436, 6, 63, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT725","End asgn_e_benefitPeriod_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_benefitPeriod_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_benefitPeriod_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_benefitPeriod_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT726
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_annutyPayFreq_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT726 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT726","Begin asgn_e_annutyPayFreq_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,726,"12.12.2019 17:30:02",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT726",
              "Ende asgn_e_annutyPayFreq_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_annutyPayFreq_o", 64, 437, 6, 64, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT726","End asgn_e_annutyPayFreq_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_annutyPayFreq_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_annutyPayFreq_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_annutyPayFreq_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT727
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_DeathBenFactor_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT727 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT727","Begin asgn_e_DeathBenFactor_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,727,"12.12.2019 17:30:02",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT727",
              "Ende asgn_e_DeathBenFactor_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_DeathBenFactor_o", 65, 438, 6, 65, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT727","End asgn_e_DeathBenFactor_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_DeathBenFactor_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_DeathBenFactor_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_DeathBenFactor_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT729
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_guaranteePeriod_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT729 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT729","Begin asgn_e_guaranteePeriod_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,729,"12.12.2019 17:30:02",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT729",
              "Ende asgn_e_guaranteePeriod_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_guaranteePeriod_o", 67, 440, 6, 67, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT729","End asgn_e_guaranteePeriod_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_guaranteePeriod_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_guaranteePeriod_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_guaranteePeriod_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT730
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_guaranteePeriod_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT730 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT730","Begin asgn_e_guaranteePeriod_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,730,"12.12.2019 17:30:02",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT730",
              "Ende asgn_e_guaranteePeriod_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_guaranteePeriod_n", 66, 439, 6, 66, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT730","End asgn_e_guaranteePeriod_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_guaranteePeriod_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_guaranteePeriod_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_guaranteePeriod_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT731
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_SumOfPremiums_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT731 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT731","Begin asgn_e_SumOfPremiums_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,731,"12.12.2019 17:30:02",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT731",
              "Ende asgn_e_SumOfPremiums_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_SumOfPremiums_o", 68, 442, 6, 68, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT731","End asgn_e_SumOfPremiums_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_SumOfPremiums_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_SumOfPremiums_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_SumOfPremiums_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT732
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_SumOfPremiums_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT732 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT732","Begin asgn_e_SumOfPremiums_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,732,"12.12.2019 17:30:01",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT732",
              "Ende asgn_e_SumOfPremiums_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_SumOfPremiums_n", 69, 443, 6, 69, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT732","End asgn_e_SumOfPremiums_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_SumOfPremiums_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_SumOfPremiums_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_SumOfPremiums_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT738
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_manual_LEBK_BWS_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT738 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT738","Begin asgn_e_manual_LEBK_BWS_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,738,"12.12.2019 17:30:02",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT738",
              "Ende asgn_e_manual_LEBK_BWS_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_manual_LEBK_BWS_n", 71, 445, 6, 71, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT738","End asgn_e_manual_LEBK_BWS_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_manual_LEBK_BWS_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_manual_LEBK_BWS_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_manual_LEBK_BWS_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT739
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_manual_LEBK_MON_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT739 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT739","Begin asgn_e_manual_LEBK_MON_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,739,"12.12.2019 17:30:02",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT739",
              "Ende asgn_e_manual_LEBK_MON_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_manual_LEBK_MON_n", 72, 446, 6, 72, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT739","End asgn_e_manual_LEBK_MON_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_manual_LEBK_MON_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_manual_LEBK_MON_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_manual_LEBK_MON_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT740
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_SpecialDiscount_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT740 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT740","Begin asgn_e_SpecialDiscount_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,740,"12.12.2019 17:30:02",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT740",
              "Ende asgn_e_SpecialDiscount_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_SpecialDiscount_o", 73, 447, 6, 73, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT740","End asgn_e_SpecialDiscount_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_SpecialDiscount_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_SpecialDiscount_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_SpecialDiscount_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT741
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_SumDiscount_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT741 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT741","Begin asgn_e_SumDiscount_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,741,"12.12.2019 17:30:02",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT741",
              "Ende asgn_e_SumDiscount_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_SumDiscount_o", 74, 448, 6, 74, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT741","End asgn_e_SumDiscount_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_SumDiscount_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_SumDiscount_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_SumDiscount_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT742
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_GrossPremium_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT742 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT742","Begin asgn_e_GrossPremium_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,742,"12.12.2019 17:30:02",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT742",
              "Ende asgn_e_GrossPremium_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_GrossPremium_o", 75, 449, 6, 75, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT742","End asgn_e_GrossPremium_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_GrossPremium_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_GrossPremium_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_GrossPremium_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT743
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_pfs_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT743 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT743","Begin asgn_e_pfs_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,743,"12.12.2019 17:30:03",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT743",
              "Ende asgn_e_pfs_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_pfs_n", 77, 452, 6, 77, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT743","End asgn_e_pfs_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_pfs_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_pfs_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_pfs_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT744
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_pst_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT744 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT744","Begin asgn_e_pst_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,744,"12.12.2019 17:30:03",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT744",
              "Ende asgn_e_pst_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_pst_n", 78, 453, 6, 78, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT744","End asgn_e_pst_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_pst_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_pst_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_pst_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT745
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_pst_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT745 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT745","Begin asgn_e_pst_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,745,"12.12.2019 17:30:03",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT745",
              "Ende asgn_e_pst_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_pst_o", 79, 454, 6, 79, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT745","End asgn_e_pst_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_pst_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_pst_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_pst_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT746
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_StartDateYield_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT746 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT746","Begin asgn_e_StartDateYield_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,746,"12.12.2019 17:30:03",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT746",
              "Ende asgn_e_StartDateYield_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_StartDateYield_n", 80, 455, 6, 80, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT746","End asgn_e_StartDateYield_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_StartDateYield_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_StartDateYield_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_StartDateYield_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT747
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_YieldDate_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT747 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT747","Begin asgn_e_YieldDate_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,747,"12.12.2019 17:30:03",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT747",
              "Ende asgn_e_YieldDate_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_YieldDate_o", 82, 459, 6, 82, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT747","End asgn_e_YieldDate_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_YieldDate_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_YieldDate_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_YieldDate_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT748
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_YieldValue_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT748 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT748","Begin asgn_e_YieldValue_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,748,"12.12.2019 17:30:03",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT748",
              "Ende asgn_e_YieldValue_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_YieldValue_o", 81, 458, 6, 81, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT748","End asgn_e_YieldValue_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_YieldValue_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_YieldValue_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_YieldValue_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT749
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_StartDateYield_o
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT749 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT749","Begin asgn_e_StartDateYield_o",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,749,"12.12.2019 17:30:03",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT749",
              "Ende asgn_e_StartDateYield_o",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_StartDateYield_o", 83, 460, 6, 83, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT749","End asgn_e_StartDateYield_o",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_StartDateYield_o", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_StartDateYield_o", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_StartDateYield_o");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT750
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_GrossPremium_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT750 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT750","Begin asgn_e_GrossPremium_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,750,"12.12.2019 17:30:03",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT750",
              "Ende asgn_e_GrossPremium_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_GrossPremium_n", 84, 461, 6, 84, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT750","End asgn_e_GrossPremium_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_GrossPremium_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_GrossPremium_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_GrossPremium_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT751
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_YieldDate_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT751 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT751","Begin asgn_e_YieldDate_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,751,"12.12.2019 17:30:03",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT751",
              "Ende asgn_e_YieldDate_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_YieldDate_n", 86, 463, 6, 86, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT751","End asgn_e_YieldDate_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_YieldDate_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_YieldDate_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_YieldDate_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT752
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_YieldValue_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT752 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT752","Begin asgn_e_YieldValue_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,752,"12.12.2019 17:30:03",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT752",
              "Ende asgn_e_YieldValue_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_YieldValue_n", 85, 462, 6, 85, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT752","End asgn_e_YieldValue_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_YieldValue_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_YieldValue_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_YieldValue_n");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT782
   Beschreibung: Die Funktion berechnet die Formel 
                 asgn_e_AnnuityAmount_n
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT782 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_0 = 0;
   TCD_DOUBLE  HV_2 = 0;
   TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT782","Begin asgn_e_AnnuityAmount_n",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,782,"16.12.2019 15:07:02",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound = TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT782",
              "Ende asgn_e_AnnuityAmount_n",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
   HV_1 = 0;
   if ( HV_1 != 0 ) goto l_5 ;
   TCD3FES (pMyPar, "e_AnnuityAmount_n", 87, 475, 6, 87, &HV_2);
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto l_ende;
   HV_1 = 1;
l_5: 
   HV_0 = HV_2;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
      TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT782","End asgn_e_AnnuityAmount_n",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("asgn_e_AnnuityAmount_n", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("asgn_e_AnnuityAmount_n", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "asgn_e_AnnuityAmount_n");
   }                                         
   return ;

   }
}

