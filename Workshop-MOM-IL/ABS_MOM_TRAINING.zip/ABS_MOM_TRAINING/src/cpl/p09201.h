/*---------------------------------------------------------------------------

(C) Copyright 1993-2002, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------------*/
#if !defined (P09201_H)
#define P09201_H

#define  VectLen(pVect)        ( (pVect) ? (pVect)->iLenOccupied : 0 )

#define  GetVectElt(pVect, iIndex) \
        ( (iIndex >= (pVect)->iLen) ?  \
        GetVectEltInt ((pVect), iIndex)  : \
        (char *)(pVect)->pArray+(TCD_LONG)iIndex*(pVect)->iSizeOfData)


/* Exporte */

P_PAARLISTE      NewAttrsResults (P_TCD_C_G,P_TCDPRCNODE,TCD_LONG);
P_PAARLISTEN_EL  FindPaarListElt            (P_PAARLISTE,TCD_INT);

void *  GetRelAttr                 (LP_VECT,TCD_INT);
void    ReleaseGlobalErgebnisPool  (P_TCD_C_G);
void    ReleaseLocalErgebnisPool   (P_PAARLISTE);
void *  FetchFromGlobalErgebnisPool(P_TCD_C_G,TCD_LONG,TCD_INT);
void *  GetErgPoolElt              (P_TCD_C_G,TCD_LONG);

TCD_INT ReleaseGlobalErgebnis      (P_TCD_C_G,TCD_LONG PrcID );
TCD_INT InsertPaarListElt(P_TCD_C_G,P_PAARLISTE,P_PAARLISTEN_EL);
TCD_INT PaarListEltToProtect       (LP_VECT);
TCD_INT GetValueFromNode           (P_TCD_C_G, P_TCDRELATTR,TCD_INT);

#endif
