/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
/*------------------------------------------
    Program:      TCD_IOP.C

    Beschreibung: Makrovorlage fuer die Rechenoperationen
    By:           BEG
    Datum:        22.04.94
    Historie:     21.04.95  Aenderungen an Datumsfunktionen
              05.05.95  weitere Aenderungen
        BEG   13.07.95  TCDCUT geaendert im Fall dass 2.Parameter < 0
        BEG   01.09.95  TCDFAK geaendert: fak(0) = 1
        BEG   04.09.95  TCDZDAYS geaendert
        BEG   07.09.95  neu DoubToInt : hasenreine integer funktion
                        (beruecksichtigt Ungenauigkeit ab 15. Stelle)
        RON   05.10.95  Monatsermittlung in Datumsformat jjjjmmtt
                        korrigiert
        BEG   06.12.95  TCDZDAYS korrigiert
        THK   22.07.97  Kommentare �berarbeitet
-------------------------------------------*/

/*------------------------------------------
   Includes
-------------------------------------------*/
/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDPORTAB_H)
#define TCDPORTAB_H

/*-----------------
Name        : TCDPORTAB.H

Beschreibung: externes Include File, das generierumgeungsspezifische
Informationen enthaelt (Makrovorlage).
By          : BEGGI
Datum       : 20.04.94
Historie:     BEG   17.01.95  neues Makro _TCDMEMINI anstatt memset
BEG   02.03.95  bedingte Macros TCDHUGE
BEG   22.06.95  _TCDMEMINI nur im HUGE-Modell redefiniert.
BEG   20.02.96  malloc.h wird nicht mehr inkludiert (FM 451)
RWE   21.06.96  malloc.h wird wieder includiert (aber nur
              fuers HUGE-Modell, d.h. fuer DOS/WIN-Compiler)
RWE   26.06.96  WATCHMEM-Makros eingebaut (fuer TCDALLOC etc)
MUB   17.7.96   Include mit !defined versehen
KFC   02.09.96  #define TCDHUGE vorgezogen

-------------------*/

/* #define TCDHUGE */              /* bei gro�en Tabellen einschalten*/
/* Systemincludes */                  
#include <stdlib.h>                /* atoi, ...       */
#include <stdio.h>                 /* fprintf, ...    */
#include <string.h>                /* strcpy, ...     */
#include <time.h>                  /* time_t, ...     */
#include <math.h>                  /* exp, min, max, ... */

#ifdef TCDHUGE
#include <malloc.h>
#endif

/* Defines */
#define  TCDC_EXT_NAME_LNG    8  /* maximale L�nge von externen 
                                    Bezeichnern*/
/*-----------------
  Definitionen aus standard C-Includes z.B. stdio.h
-------------------*/
#ifndef NULL
#define    NULL    (void *)0
#endif

/*-----------------
  Definitionen von Basistypen
-------------------*/
typedef    short   TCD_BOOL ;
typedef    long    TCD_LONG ;
typedef    int     TCD_INT  ;
typedef    double  TCD_DOUBLE ;


/*-----------------
  modellabhaengige Definitionen von Basistypen
-------------------*/
typedef    TCD_DOUBLE  TCDTAB ;
#ifdef TCDHUGE
typedef    TCDTAB       huge * P_TCDTAB ;
typedef    TCD_DOUBLE   huge * P_TCD_DOUBLE ;
typedef    P_TCD_DOUBLE * P_P_TCD_DOUBLE ;
typedef    char huge    * TCD_LPCHAR ;
#else
typedef    TCDTAB       * P_TCDTAB ;
typedef    TCD_DOUBLE   * P_TCD_DOUBLE ;
typedef    P_TCD_DOUBLE * P_P_TCD_DOUBLE ;
typedef    char         * TCD_LPCHAR ;
#endif

/*-----------------
  weitere (Typ-)Defines 
-------------------*/  
typedef int ERRNO_TYPE;
#define TCD_FILENAME_LNG 128

/*-----------------
  Definitionen von Makros f�r Speicherallokation
-------------------*/  

/* WATCHMEM muss im TCDHUGE-Modus abgeschaltet sein */
#ifdef TCDHUGE
#undef WATCHMEM
#endif

#undef _TCDALLOC
#undef _TCDFREE
#undef _TCDREALLOC

#ifndef WATCHMEM

#define _TCDALLOC(len,size)    malloc( (size_t)(len) * (size)) ;
#define _TCDFREE(ptr)          {free(ptr), ptr = NULL;}
#define _TCDREALLOC(ptr,size)  realloc( ptr, (size_t)(size) ) ;

#else
 
void *MallocAndProt(char *sFile_,int iLine_, size_t size);
#define _TCDALLOC(len,size)\
 MallocAndProt(__FILE__,__LINE__,(len) * (size))

void FreeAndProt(char *sFile_, int iLine_, void *p_);

#define _TCDFREE(ptr)\
       {FreeAndProt(__FILE__, __LINE__, ptr) , ptr = NULL;}

void *ReallocAndProt(char *sFile_,int iLine_, void *p_, size_t size);
#define _TCDREALLOC(ptr,size)\
 ReallocAndProt(__FILE__, __LINE__, ptr,size)

void ResumeWatchmem();

#endif

/*-----------------
  modellabh�ngige Definitionen von Makros f�r Speicherallokation
-------------------*/
#undef _TCDTABALLOC
#undef _TCDTABFREE
#undef _TCDMEMINI

#ifdef TCDHUGE

#define _TCDTABALLOC(len,size)\
  _halloc( (long)(len) , (size_t)(size)) ;
#define _TCDTABFREE(ptr)\
      { _hfree ( (void huge *)ptr); ptr = NULL;}

#else

#ifndef WATCHMEM
#define _TCDTABALLOC(len,size)\
 malloc((size_t)((long)len) * ((size_t)size)) ;
#define _TCDTABFREE(ptr)       {free(ptr), ptr = NULL;}
#else
#define _TCDTABALLOC(len,size)\
 MallocAndProt(__FILE__,__LINE__,(len) * (size))
#define _TCDTABFREE(ptr)\
       FreeAndProt(__FILE__, __LINE__, ptr)
#endif

#endif


#ifdef TCDHUGE
#define _TCDMEMINI(ptr,size,nr)\
{\
   long       j;\
   TCD_LPCHAR lp;\
   for (j= 0 , lp = (TCD_LPCHAR)ptr;\
        j < ((long)(size) * (long)(nr)); j++, lp++) \
      *lp = 0;\
}  

#else
#define _TCDMEMINI(ptr,size,nr)\
 { memset (ptr, 0, (size_t) ((size) * (nr))) ; }
#endif
/*---------------------------------
  NON-Ansi-Namen mit oder ohne "_"
----------------------------------*/

/* #define NON_ANSI_WITHOUT__ */

#ifdef NON_ANSI_WITHOUT__
#define _fcvt fcvt
#endif

/*---------------------------
  ggf. Verkuerzung der Namen
-----------------------------*/
#ifdef TCD_NAMLEN8

#define TCDIMPReleaseProcData       TCD_0001
#define TCDIMPReleaseNodeData       TCD_0002
#define TCDIMPReleaseTabImpData     TCD_0003   

#define FetchFromGlobalErgebnisPool TCD_0004

#define DelEltFromSVect             TCD_0005
#define DelEltFromSVectByIndex      TCD_0006

#define DelEltFromVect              TCD_0007
#define DelEltFromVectByIndex       TCD_0008
                                
                                
#define ReleaseGlobalErgebnisPool   TCD_0009
#define ReleaseGlobalErgebnis       TCD_0010
#define ReleaseLocalErgebnisPool    TCD_0011

#define GetPrcDataSkal              TCD_0012
#define GetPrcDataTab               TCD_0013
#define GetPrcDataDat               TCD_0014
#define GetPrcDataFrm               TCD_0015

#define GetPrcAttrSkal              TCD_0016
#define GetPrcAttrTab               TCD_0017

#define GetSSAttrSkal               TCD_0018
#define GetSSAttrTab                TCD_0019

#define ErgPoolGetFirstInfo         TCD_0020
#define ErgPoolGetNextInfo          TCD_0021

#define DConstrAttrs                TCD_0022
#define DConstrAttrsResults         TCD_0023

#define GetRelAttrs                 TCD_0024

#define GetIndexToGlobalErgPool     TCD_0025
#define GetIndexToPaarListElt       TCD_0026

#define GetIndexToSS                TCD_0027
#define GetIndexToUes               TCD_0028
#define GetFromSS                   TCD_0029
#define GetFromUes                  TCD_0030

#define TCDIMPImportTreeData        TCD_0031
#define TCDIMPNFIntl                TCD_0032
#define TCDIMPGetNodeFromID         TCD_0033
#define TCDIMPGetNodeFromPath       TCD_0034
#define compBsearch                 TCD_0035
#define TCDIMPReleaseTreeData       TCD_0036 
#define TCDIMPReleaseTabData        TCD_0037  
#define DConstrTCD_C_G              TCD_0038
#define DDestrTCD_C_G               TCD_0039 
#define SConstrTCD_C_G              TCD_0040
#define DConstrTCDRbsSS             TCD_0041
#define SConstrTCDRbsSS             TCD_0042
#define SConstrTCDISSADATA          TCD_0043
#define SDestrTCD_C_G               TCD_0044
#define DDestrTCDRbsSS              TCD_0045
#define SDestrTCDRbsSS              TCD_0046
#define SDestrTCDISSADATA           TCD_0047
#define GetRbsSSFkt                 TCD_0048
#define TCDIMPGetTabIDAndTypFromPath TCD_0049
#define TCDIMPGetPathAndTypFromID    TCD_0050
#define TCDIMPReleaseTabTreeData     TCD_0051
#define TCDIMPImportTabTreeData      TCD_0052
#endif

#endif


/*------------------------------------------
   Modullokale  Defines und Strukturen
-------------------------------------------*/
struct S_TCDDATE {
       TCD_INT    day ;
       TCD_INT    month ;
       TCD_INT    year ;
} ;

#include "c96.h"
/*------------------------------------------
   Prototypen der internen Funktionen
-------------------------------------------*/
 TCD_DOUBLE DoubToInt (TCD_DOUBLE val)   ;
 TCD_DOUBLE NumOfDays (struct S_TCDDATE date) ;
 void V360Norm (struct S_TCDDATE *date) ;
 void TcdDateToDate (TCD_INT datefmt, struct S_TCDDATE * pDate,
                              char *val) ;



/*------------------------------------------
   Externe Funktion: TCD_ABS
   Beschreibung  :   Absolutfunktion
   Parameter     :   val
   Returnwerte   :   abs (val)
-------------------------------------------*/
TCD_DOUBLE IOP_EXPORT   TCDABS    (TCD_DOUBLE val)
{
   if (val < 0) {
      return ( val * (-1)) ;
   }
   return ( val ) ;
}

/*------------------------------------------
   Externe Funktion: TCD_FAK
   Beschreibung  :   Fakult�tsfunktion
   Parameter     :   val
   Returnwerte   :   val!
-------------------------------------------*/
TCD_DOUBLE IOP_EXPORT   TCDFAK    (TCD_DOUBLE val)
{
   TCD_DOUBLE val1, val2;
   /*----------------------------------------
      ganzzahligen Absolutwert bilden
   -----------------------------------------*/
   if (val < 0)   val *= -1 ;
   val1 = modf (val, &val2) ;
   if (val2 == 0)  return (1) ;
   for (val1 = val2 - 1 ; val1 > 0; val1--) {
     val2 *= val1 ;
   }
   return (val2);
}

/*------------------------------------------
   Externe Funktion: TCDINT
   Beschreibung  :   Integerfunktion
   Parameter     :   val
   Returnwerte   :   ganzzahligen Teil des Wertes
--------------------------------------------*/
TCD_DOUBLE IOP_EXPORT   TCDINT     (TCD_DOUBLE val)
{
   TCD_DOUBLE fract_part, int_part;
   TCD_DOUBLE delta, min_delta, min_deltalog;
   fract_part = modf (val, &int_part) ;
   /* Fehler nach der 15. Stelle (Rechenungenauigkeiten) korrigieren */
   delta = 1.0 - fabs( fract_part );
   if (fabs(val) < 1.0e-15)
      min_deltalog = -30.0; /* max.Signifikanz 30 NK-Stellen */
   else
      min_deltalog = log10( fabs( val ) ) - 15.0;
   min_delta = pow( 10.0, min_deltalog );
   if ( delta < min_delta ) {
	   /* Ergebnis erhoehen ... */
	   if ( fract_part > 0.0 )
		   int_part = int_part + 1.0;
	   /* ... oder verringern */
	   else
		   int_part = int_part - 1.0;
   }
   return (int_part);
}
/*------------------------------------------
   Externe Funktion: TCDSIGN
   Beschreibung  :   Signumsfunktion
   Parameter     :   val
   Returnwerte   :   ganzzahligen Teil des Wertes
--------------------------------------------*/
TCD_DOUBLE IOP_EXPORT   TCDSIGN     (TCD_DOUBLE val)
{
  if (val > 0)   return (1) ;
  if (val < 0)   return (-1) ;
  return (0);
}
/*------------------------------------------
   Externe Funktion: TCDDIV
   Beschreibung  :   ganzzahlige Division
   Parameter     :   val1  Z�hler, val2 Nenner
   Returnwerte   :   ganzzahliger Wert
--------------------------------------------*/
TCD_DOUBLE IOP_EXPORT   TCDDIV     (TCD_DOUBLE val1, TCD_DOUBLE val2)
{
   TCD_DOUBLE val, val3 ;

   if (val2 == 0)  return  (-1) ;
   val = val1 /val2 ;
   val = modf (val, &val3) ;
   return (val3);
}

/*------------------------------------------
   Externe Funktion: TCDEXP
   Beschreibung  :   Exponentialfunktion
   Parameter     :   val1  Z�hler, val2 Nenner val3 ganzzahliger Wert
   Returnwerte   :   -1 :  falls Division /0
                     0 sonst
-------------------------------------------*/
TCD_DOUBLE IOP_EXPORT   TCDEXP     (TCD_DOUBLE val1, TCD_DOUBLE val2)
{
   return (pow (val1, val2)) ;
}

/*-----------------------------------------
   Externe Funktion: TCDMIN
   Beschreibung  :   Minimumfunktion
   Parameter     :   liefert den kleineren von zwei Werten
-------------------------------------------*/
TCD_DOUBLE IOP_EXPORT   TCDMIN     (TCD_DOUBLE val1, TCD_DOUBLE val2)
{
  if (val1 < val2)  return (val1) ;
  return (val2);
}

/*------------------------------------------
   Externe Funktion: TCDMAX
   Beschreibung  :   Maximumfunktion
   Parameter     :   liefert den gr��eren von zwei Werten
-------------------------------------------*/
TCD_DOUBLE IOP_EXPORT   TCDMAX     (TCD_DOUBLE val1, TCD_DOUBLE val2)
{
  if (val1 > val2)  return (val1) ;
  return (val2);
}

/*------------------------------------------
   Externe Funktion: TCDZDAYS
   Beschreibung  : Funktion zur Ermittlung von Kalendertagen
   Parameter     : Anzahl der Kalendertage zwischen zwei Datumsangaben
-------------------------------------------*/
TCD_DOUBLE IOP_EXPORT TCDZDAYS (TCD_INT datefmt,char *val1,char *val2)
{
    struct S_TCDDATE date1 ;
    struct S_TCDDATE  date2 ;

    struct S_TCDDATE * lpfrom = & date1 ;
    struct S_TCDDATE * lpuntil = & date2 ;

    TcdDateToDate (datefmt, &date1,val1) ;
    TcdDateToDate (datefmt, &date2,val2) ;

    V360Norm(&date1);                           /* see CBGIOP.COB  */
    V360Norm(&date2);

    if (  date2.year < date1.year ||
         (date2.year == date1.year &&
          date2.month < date1.month) ||
         (date2.year == date1.year &&
          date2.month == date1.month &&
          date2.day < date1.day )) {
         lpfrom = & date2 ;
         lpuntil= & date1 ;
    }

    if ( lpuntil->day < lpfrom->day ) {
         lpuntil->day += 30 ;
         lpuntil->month -= 1 ;
    }

    if ( lpuntil->month < lpfrom->month) {
         lpuntil->month += 12 ;
         lpuntil->year -= 1 ;
    }

    return ( ((lpuntil->year - lpfrom->year ) * 12L +
               (lpuntil->month - lpfrom->month)) * 30L +
               (lpuntil->day - lpfrom->day)  ) ;
}

/*------------------------------------------
   Externe Funktion: TCDKDAYS
   Beschreibung  :   Funktion zur Ermittlung von Zinstagen
   Parameter     :   Anzahl der Zinstage zwischen zwei Datumsangaben
-------------------------------------------*/
TCD_DOUBLE IOP_EXPORT TCDKDAYS (TCD_INT datefmt,char *val1,char *val2)
{
    struct S_TCDDATE    date1 ;
    struct S_TCDDATE    date2 ;

    TcdDateToDate (datefmt, &date1, val1) ;
    TcdDateToDate (datefmt, &date2, val2) ;

    return (TCDABS ( NumOfDays (date2)- NumOfDays(date1))) ;
}


/*------------------------------------------
   Externe Funktion: TCDRND
   Beschreibung  :   Rundungsfunktion
   Parameter     :   val
   Returnwerte   :   abs (val)
-------------------------------------------*/
TCD_DOUBLE IOP_EXPORT   TCDRND    (TCD_DOUBLE val1, TCD_DOUBLE val2)
{
   TCD_DOUBLE   dresult;         /* temporary for computations */

   dresult = pow (10.0, floor (val2));
   dresult = DoubToInt (val1 * dresult + 0.5) / dresult;
   return ( dresult) ;
}

/*------------------------------------------
   Externe Funktion: TCDCUT
   Beschreibung  :   schneidet Stellen ab
   Parameter     :   val
   Returnwerte   :   abs (val)
-------------------------------------------*/
TCD_DOUBLE IOP_EXPORT   TCDCUT    (TCD_DOUBLE val1, TCD_DOUBLE val2)
{
   TCD_DOUBLE   val1pow10, val2pow10;
   TCD_INT      isign = val1 >= 0;

   val2pow10 = pow(10.0, floor (val2));
   val1 = isign ? val1 : -val1;
   val1pow10 = DoubToInt (val1 * val2pow10) ;
   val1pow10 = isign ? val1pow10 : -val1pow10;
   
   if (val2 > 0) {
       return ( val1pow10 / val2pow10 ) ;
   }
   else {
       return (val1pow10) ;
   }
}

/*------------------------------------------
   Interne Funktion: DoubToInt
   Beschreibung  :   konvertiert eine Double Zahl zu einer integer Zahl
                 liefert die groesste int-Zahl, die kleiner oder gleich
                 der double Zahl ist. Fkt beruecksichtigt die
                 Ungenauigkeit ab Stelle 15
                 this function is meant to be rabbit clear !!
   Parameter     :   val
   Returnwerte   :   abs (val)
-------------------------------------------*/
 TCD_DOUBLE DoubToInt (TCD_DOUBLE val)
{
   TCD_DOUBLE   floorval;
   TCD_DOUBLE   delta ;

   floorval = floor (val) ;

   if (fabs (val) > 0) {
       delta = 1 - pow(10, floor (log10 (fabs (val)))  - 15) ;
       if (fabs (val - floorval) > delta) {
           floorval += 1 ;
        }
   }
   return (floorval) ;
}


 void V360Norm (struct S_TCDDATE *date)
{
    if (date->day == 31)
        date->day = 30;
    else if (date->month == 2)
        if ( date->day == 29  ||
             (date->day == 28 &&
              date->year % 4 == 0 && date->year % 100 != 0 ))
            date->day = 30;
}


 TCD_DOUBLE  NumOfDays (struct S_TCDDATE date)
{
    int months[]=
    { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365 };

    return (TCD_DOUBLE)( date.year*365L +
              (date.year/4) -
              (date.year/100) +
              (date.year/400) +
               months[date.month-1] +
               (date.month > 2 &&
               !(date.year%4) &&
               (date.year%100 ||
               !(date.year%400)) ? 1 : 0) +
               date.day) ;
}


/*------------------------------------------
   Interne Funktion: TcdDateToDate
   Beschreibung  :   wandelt Datumsformat aus einem String in die
                     interne Darstellung um
   Parameter     :   val
   Returnwerte   :   abs (val)
--------------------------------------------*/
 void   TcdDateToDate (TCD_INT datefmt, struct S_TCDDATE * pDate,
                             char *val)
{
  long  x;
  x = atol (val) ;
  switch (datefmt) {
   case 1 : /* ttmmjjjj */
     pDate->day   = (TCD_INT) floor ( (x / pow (10.0, 6)) ) ;
     pDate->month = (TCD_INT) fmod (floor( (x / pow (10.0, 4)) ),100);
     pDate->year  = (TCD_INT) fmod ( x , pow (10.0, 4) ) ;
     break ;
   case 2 : /* mmttjjjj */
     pDate->day=(TCD_INT) fmod (DoubToInt( (x / pow (10.0, 4)) ),100);
     pDate->month=(TCD_INT) floor ( (x / pow (10.0, 6)) );
     pDate->year=(TCD_INT) fmod ( x , pow (10.0, 4) ) ;
     break ;
   case 3 : /* jjjjmmtt */   
              /* RON, 5.10.95: Monat korrigiert (F. 354) */
     pDate->day   = (TCD_INT) fmod ( x , 100 ) ;
     pDate->month = (TCD_INT) fmod (floor((x / pow (10.0, 2)) ),100);
     pDate->year  = (TCD_INT) floor ( (x / pow (10.0, 4)) ) ;
     break ;
  }
  return ;
}



