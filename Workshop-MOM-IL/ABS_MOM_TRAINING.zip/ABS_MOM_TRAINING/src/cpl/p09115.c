/*---------------------------------------------------------------------------

(C) Copyright 1993-2002, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------
.                           
.                             All rights reserved                            
.                                                                            
.  Product:     TCD
.-------------------------------------------------------------------------
.  Description:        
.
.    ADT direkte dynamische Vektoren (S_VECT,S_SVECT)
.
.------------ The next section is maintained by Visual SourceSafe --------
.
. Current
. $Workfile: p09115.c $
. $Revision: 17 $
. $Author: X80 $
. $Date: 30.04.03 13:27 $
 $Log: /tcd_prj/v24/src/p09115.c $
 * 
 * 17    30.04.03 13:27 X80
 * Vergr��erung von direkten Vektoren; das �bergebene neue Element kann
 * ung�ltig werden, falls es selbst schon Bestandteil des Vektors war.
 * 
 * 16    14.04.03 13:53 Kaiser
 * M_CR 3813: Belegung Basisformel einer BV kann jetzt auch ein SSElement
 * sein.
 * 
 * 15    30.12.02 12:56 Kaiser
 * M_CR 3882: Tarife suchen
 * 
 * 14    14.03.02 8:59 Kaiser
 * Copyright teilw. ersetzt und eingef�gt
 * 
 * 13    13.08.99 17:28 X74
 * Be careful!!
 * 
 * 12    13.08.99 17:26 X74
 * Achtung! slk2std geht nicht bei Historie Logs.
 * 
 * 11    7.04.99 18:10 Kle
 * Benutzerverwaltung auf DB umgestellt.
 * $NoKeywords: $
-----------------------------------------------------------------------*/

/*
Datei       : P09115.C

Beschreibung: ADT direkte dynamische Vektoren (S_VECT,S_SVECT)
von         : RWE/MUB
Datum       : 25.07.95
Historie    : 11.04.96 MUB: Funktionen implementiert und getestet
      20.06.96 RWE: _TCDALLOC/_TCDFREE eingebaut
      26.6.96 MUB : in ResizeVector werden die neuen Elemente
                    jetzt immer mit 0 initialisiert, falls kein
                    Konstruktur mitgegeben wurde
      23.7.96 MUB  int/long in TCD_INT/TCD_LONG geaendert ...
Status      : in Produktion
Reviews     :
*/

/* Includes  */
#include <stdio.h>
#include <stdlib.h>

/* C88.H (tcdport.h)   Portability File  herausgenommen, wird schon in
  P09115.H includiert */

#include "c90.h"           /* "tcdc.h"      Tcd-Konstanten   */
#include "c89.h"           /* "tcddat.h"                     */
                                              

#include "p09115.h"

#ifndef SUBSYSTEM
#undef _TCDALLOC
#undef _TCDFREE

#define _TCDALLOC(len,size)    malloc( (len) * (size)) ;
#define _TCDFREE(ptr)          {free(ptr), ptr = NULL;}

#endif

/* 
   Konstruktoren (statisch & dynamisch) fuer S_VECT
  */
ADT_EXPORT S_VECT SInitVect( int ElementSize )
{
	S_VECT	vec = {0};

	vec.iSizeOfData = ElementSize;
	vec.iDelta		= 1;

	return vec;
}

TCD_INT    SConstrVect (LP_VECT pVect,
                       TCD_INT iSizeOfData,
                       TCD_INT iStartLen,
                       TCD_INT iDelta,
                       TCD_INT ( * pCopyData)  (void * , void *),
                       void    ( * pConstrData)(void *)          ,
                       void    ( * pDestrData) (void *)          )
{
   if ( pVect )
   {
      pVect->iSizeOfData  = iSizeOfData;
      pVect->iLen         = 0;
      pVect->iLenOccupied = 0;
      pVect->iDelta       = iDelta ? iDelta : 1;

      pVect->pCopyData    = pCopyData;
      pVect->pConstrData  = pConstrData;
      pVect->pDestrData   = pDestrData;

      pVect->pArray       = NULL;

      if ( !ResizeVect(pVect,iStartLen)) 
		  return 0;
   }
   return 1;
}

LP_VECT    DConstrVect (TCD_INT iSizeOfData, 
                       TCD_INT iStartLen,
                       TCD_INT iDelta,
                       TCD_INT ( * pCopyData) (void *,void *),
                       void ( * pConstrData)(void *)        ,
                       void ( * pDestrData) (void *)        )
{
   /* LP_VECT pVect = (LP_VECT)malloc(sizeof(S_VECT)); */
   /* Aenderung durch RWE, 20.06.96: */
   LP_VECT pVect = (LP_VECT)_TCDALLOC(1,sizeof(S_VECT));
   if ( pVect )
   {
      if ( SConstrVect(pVect,
                       iSizeOfData,iStartLen,iDelta,
                       pCopyData,pConstrData,pDestrData) )

      return pVect;
   }
   return NULL;
}

/* 
   Destruktoren fuer S_VECT
*/
void       SDestrVect             (LP_VECT pVect )
{
   FlushVect(pVect);
}

void       DDestrVect             (void ** ppVect )
{
   SDestrVect(*ppVect);
   /* free(*ppVect);    RWE, 20.06.96 */
   _TCDFREE (*ppVect);
   *ppVect=NULL;
}

/* 
   Methoden fr S_VECT
  */
/* Ausleeren des Vektors: */
void       FlushVect              (LP_VECT pVect )
{
   TCD_INT i;
   if ( pVect->pArray )
   {
      /* --Wenn ein Destruktor fuer die Datenelemente bergeben 
           wurde, nehmen */
      if (pVect->pDestrData)
      {
        TCD_LONG iOffset;
        for (i=0; i < VectLen(pVect); i++)
        {
          iOffset = (TCD_LONG)i * pVect->iSizeOfData;
          pVect->pDestrData ( ((char *)pVect->pArray+iOffset) );
        }
      }

      /* free(pVect->pArray);   RWE, 20.06.96 */
      _TCDFREE (pVect->pArray);
      pVect->pArray       = NULL;
      pVect->iLenOccupied = 0;
      pVect->iLen         = 0;
   }
}


/* Zugriff auf und Besetzen von Vektorkomponenten: */
TCD_INT    AddVectElt             (LP_VECT pVect, void * pData)
{                                                 
    return SetVectElt ( pVect, VectLen( pVect ), pData );
}

/* Ein Vektor-Element kopieren, Kopierfunktion am Vektor nutzen */
TCD_INT CopyVectElt( LP_VECT pVect, void *pDst, void *pSrc )
{
	/* Falls vorhanden, Kopierfunktion am Vektor nutzen */
	if ( pVect->pCopyData ) {
        if ( !(pVect->pCopyData(pDst,pSrc)) )
			return 0;
	}
	/* Sonst mit memcpy Speicher kopieren */
	else 
		memcpy( pDst, pSrc, pVect->iSizeOfData );

	/* Ok */
	return 1;
}

/* Pruefen, ob ein Speicherplatz zum Vektor gehoert */
TCD_INT IsVectElt( LP_VECT pVect, void *pData )
{
	/* Gesamte Groesse des Vektors bestimmen */
	TCD_LONG iSize = pVect->iLen * pVect->iSizeOfData;

	/* Zeiger pData muss im Bereich des Vektors liegen */
	void *pFrom = pVect->pArray;
	void *pTo = (char*) pFrom + iSize;
	if ( pData >= pFrom && pData < pTo )
		return 1;

	/* pData ist kein Element des Vektors */
	return 0;
}

TCD_INT    SetVectElt (LP_VECT pVect, TCD_INT iIndex, void * pData)
{
   TCD_INT rc = 1;
   void *pDst = 0, *pValidData = pData;

   /* falls pData Bestandteil des Vektors pVect ist, Kopie erstellen */
   if ( IsVectElt( pVect, pData ) ) {
	   pValidData = malloc( pVect->iSizeOfData );
	   if ( !CopyVectElt( pVect, pValidData, pData ) )
		   rc = 0;
   }
   /* Zeiger auf Speicherplatz Element(iIndex) suchen- */
   if ( rc )
	   pDst = GetVectElt(pVect,iIndex);
   if ( !pDst )
	   rc = 0;

   /* pData auf den Speicherplatz kopieren */
   if ( rc && !CopyVectElt( pVect, pDst, pValidData ) )
	   rc = 0;

   /* --Verwaltung-- */
   if ( rc && iIndex >= pVect->iLenOccupied )
	   pVect->iLenOccupied=iIndex+1;

   /* Freigabe der Kopie */
   if ( pValidData != pData )
	   free( pValidData );

   return rc;
}

void *     GetVectEltInt (LP_VECT pVect, TCD_INT iIndex)
{
   /* 
      Wurde ber den bereits angelegten Bereich hinaus indiziert,
      muss das array schrittweise vergraert werden, jedoch nicht
      fter als 100 mal
     */
   TCD_LONG iOffset = (TCD_LONG)iIndex * pVect->iSizeOfData;
   TCD_INT i    = 0;

   while (iIndex >= pVect->iLen && i < 100)
   {
     if ( !ResizeVect(pVect,pVect->iDelta) )
        return NULL;
     i++;
   }
   return ((char *)pVect->pArray+iOffset);
}


/* Suche erstes Auftreten eines Elements ber Bedingung: */
void *     FindFirstVectEl        (LP_VECT pVect,
              TCD_INT (* EltTestOk)(void * pEltToTest, void * pArgs),
              TCD_INT * pResultIndex,
              void *   pArgs)
{
   TCD_INT i           = 0;
   TCD_INT iLenOccupied = VectLen(pVect);
   void * p            = NULL;

   *pResultIndex = -1;
   /* 
      Wenn die TestFunktion OK liefert, wurde das 1. Element gefunden
     */
   for (i=0; i < iLenOccupied; i++)
   {
     p = GetVectElt(pVect,i);
     if (p && EltTestOk (p , pArgs) )
     {
       *pResultIndex=i;
       return p;
     }
   }
   return NULL;
}

/* --Element(iIndex) entfernen-- */
/* --die anderen Vektorelemente werden "nachgerckt") */
TCD_INT    DelEltFromVectByIndex  (LP_VECT pVect,
                                   TCD_INT iIndex)
{
   TCD_INT i;
   TCD_LONG iOffset;
   char * pDst;

   /* --Bereichgsgrenze pruefen- */
   if (iIndex >= pVect->iLenOccupied) return 0;

   for (i = iIndex; i < pVect->iLenOccupied-1; i++ )
   {
      iOffset = (TCD_LONG)i * pVect->iSizeOfData;
      pDst    = ((char *)pVect->pArray+iOffset);

      if (pVect->pCopyData)
      {
         if ( !(pVect->pCopyData(pDst , pDst + pVect->iSizeOfData)) )
            return 0;
      }
      else memcpy(pDst,pDst + pVect->iSizeOfData,pVect->iSizeOfData);
   }

   pVect->iLenOccupied--;
   return 1;
}

/* Sortiere Vektor: */
void       SortVect   (LP_VECT pVect,
           TCD_INT (* pCompareData)(const void *,const void *))
{
   void * p = (void *) pVect->pArray;

   /* --Vorerst nur sortieren, wenn kein eigenes CopyData 
        mitgegeben wurde */
   if (pVect->pCopyData) return;
   qsort((void *)p,(size_t)pVect->iLenOccupied, 
         (size_t)pVect->iSizeOfData,pCompareData);

   /* --CompareFunktion eintragen, damit Vektor als sortiert 
        markiert ist- */
   pVect->pCompareData=pCompareData;
}

/* Suche mit Bisektion, falls Vektor sortiert wurde: */
void *     FindVectEltByBisec     (LP_VECT pVect,
                                   void *  pEltToTest,
                                   TCD_INT * pResultIndex)
{
   void * pResult = NULL;
   TCD_LONG lDiff;

   /* --Nur in sortierten Vektoren! */
   if (pVect->pCompareData == 0) return NULL;

   *pResultIndex = -1;

   /* --Es wird die CompareFunktion des Vektors verwendet-- */
   pResult = 
   bsearch((const void *)pEltToTest, (const void *)pVect->pArray,
             (size_t)pVect->iLenOccupied , 
             (size_t)pVect->iSizeOfData , pVect->pCompareData);

   if (pResult)
   {
      lDiff = (TCD_LONG)((char *)pResult - (char *)pVect->pArray);
      *pResultIndex = (TCD_INT)(lDiff / (TCD_LONG)pVect->iSizeOfData);
      return pResult;
   }
   return NULL;
}

TCD_INT    ResizeVect             (LP_VECT pVect, TCD_INT iNumOfElts)
{
   TCD_INT i    = 0;

   size_t iAnz    = pVect->iLen+iNumOfElts;
   size_t iSize   = pVect->iSizeOfData;
   TCD_LONG NewSize = (TCD_LONG)iAnz * iSize;
   char * p;

   /* --Alles hat seine Grenzen !-- */
   /*if ( NewSize > 64000 ) return 0; */

   /* Neuen Speicherbereich anlegen und ggf. initialisieren: */
   /* if ( (p = (char *)calloc(iAnz,iSize)) == NULL ) return 0; */

   /* --Aenderung durch RWE, 20.06.96 (Achtung, kein init mit 0 mehr!):
    */
   p = (char *) _TCDALLOC(iAnz,iSize);
   if ( p == NULL ) return 0;

   /* --anwendungsspezifischen DatenKonstruktor aufrufen, falls 
      vorhanden- */
   if ( pVect->pConstrData )
   {
     TCD_LONG iOffset;
     for (i=0; i < pVect->iLen + iNumOfElts; i++)
     {
        iOffset = (TCD_LONG)i * pVect->iSizeOfData;
        pVect->pConstrData( (p+iOffset) );
     }
   }
   /* --initialisieren, falls kein Konstruktur mitgegeben wurde-- */
   else memset((void *)p,0,(size_t)NewSize);

   /* Vorhandene Daten kopieren, soweit schon welche existieren */
   if (pVect->pCopyData)
   {
     TCD_LONG iOffset;
     for ( i=0; i < pVect->iLenOccupied; i++)
     {
       iOffset = (TCD_LONG)i * pVect->iSizeOfData;
       if ( !(pVect->pCopyData( (p+iOffset) , 
             ((char *)pVect->pArray+iOffset))) )
          return 0;
     }
   }
   else
   {
     if (pVect->iLenOccupied)
       memcpy((void *)p,(void *)pVect->pArray,
              (size_t)pVect->iSizeOfData * pVect->iLenOccupied);
   }

   /* Alte Daten freigeben: */
   if (pVect->pDestrData)
   {
     TCD_LONG iOffset;
     for (i=0; i < pVect->iLen; i++)
     {
        iOffset = (TCD_LONG)i * pVect->iSizeOfData;
        pVect->pDestrData( ((char*)pVect->pArray+iOffset) );
     }
   }
   if (pVect->pArray)
     /* free(pVect->pArray); RWE, 20.06.96 */
     _TCDFREE (pVect->pArray);

   /* Datenelemente updaten: */
   pVect->pArray = p;
   pVect->iLen  += iNumOfElts;

   return 1;
}

/* 
   Der Vektor pSrc wird nach pDst kopiert.
   Der Inhalt von pDst wird berschrieben
  */
TCD_INT    CopyVectToVect                (LP_VECT pDst,
                                          LP_VECT pSrc)
{
   TCD_INT i;
   TCD_INT n = VectLen(pSrc);

   if ( pDst == NULL || pSrc == NULL ) return 0;

   for ( i=0; i < n; i++ )
   {
       if ( !(SetVectElt(pDst,i,((void *) GetVectElt(pSrc,i)))))
          return 0;
   }
   return 1;
}


/* 
   Konstruktoren (statisch & dynamisch) fuer S_SVECT
  */

TCD_INT    SConstrSVect           (LP_SVECT pSVect, 
           TCD_INT  iSizeOfData,
           TCD_INT  iStartLen,
           TCD_INT  iDelta,
           TCD_INT  ( * pCopyData)  (void *,void *),
           void     ( * pConstrData)(void *)        ,
           void     ( * pDestrData) (void *)        ,
           TCD_INT  ( * pCompareData)(const void *, const void *)
           )
{
   if ( SConstrVect(pSVect,iSizeOfData,iStartLen,iDelta,pCopyData, 
                    pConstrData, pDestrData) )
   {
      if (pCompareData)
      {
         pSVect->pCompareData = pCompareData;
         return 1;
      }
      else
      {
         return 0;
      }
   }
   else return 0;
}


LP_SVECT   DConstrSVect           (TCD_INT iSizeOfData,
           TCD_INT iStartLen,
           TCD_INT iDelta,
           TCD_INT ( * pCopyData) (void *,void *),
           void ( * pConstrData)(void *)        ,
           void ( * pDestrData) (void *)        ,
           TCD_INT ( * pCompareData)(const void * , const void *)
                                  )
{
   /* LP_SVECT pSVect = (LP_SVECT) malloc(sizeof(S_SVECT)); */
   /* Aenderung durch RWE, 20.06.96: */
   LP_SVECT pSVect    = (LP_SVECT)_TCDALLOC(1,sizeof(S_SVECT));

   if (SConstrSVect(pSVect,iSizeOfData,iStartLen,iDelta,pCopyData,
                    pConstrData,pDestrData,pCompareData) )

        return pSVect;
   else return NULL;
}


/* Ausleeren des Vektors: */
/* 
   Destruktoren (statisch & dynamisch) fuer S_SVECT
  */
void       SDestrSVect            (LP_SVECT pSVect )
   { SDestrVect(pSVect); }

void       DDestrSVect            (void ** ppSVect )
   { DDestrVect(ppSVect); }

/* 
   Methoden fuer S_SVECT
  */
TCD_INT    InsertSVectElt         (LP_SVECT pSVect, void *pData)
{
   TCD_INT rc = 1;
   /* Da pData ungueltig werden kann, ist evtl. eine Kopie noetig */
   void *pValidData = pData;
   /* Index auf letztes Element */
   TCD_INT index = pSVect->iLenOccupied-1;

   /* Es gibt noch keine Elemente: neues Element an erste Stelle */
   if ( index < 0 )
      return ( SetVectElt( pSVect,0,pData ) );

   /* falls pData Bestandteil des zu veraendernden Vektors ist, 
      benoetigen wir eine Kopie, die in jedem Fall gueltig bleibt */
   if ( IsVectElt( pSVect, pData ) ) {
	   pValidData = malloc( pSVect->iSizeOfData );
	   if ( !CopyVectElt( pSVect, pValidData, pData ) )
		   rc = 0;
   }
   /* 
      vergleiche das Element von(index) mit den neuen Daten:
      solange das neue Datum kleiner ist,schiebe Element(index) 1 nach 
      hinten
     */
   while ( rc &&
	   (pSVect->pCompareData( GetVectElt(pSVect,index) ,pValidData)) > 0 &&
	   index >= 0)
   {
      if ( !SetVectElt(pSVect,index+1,GetVectElt(pSVect,index) ) )
		  rc = 0;

      index--;
   }

   /* --fuege die neuen Daten jetzt ein-- */
   if ( rc )
	   SetVectElt(pSVect,index+1,pValidData);

   /* Speicher der Kopie von pData freigeben */
   if ( pData != pValidData )
	   free( pValidData );

   return rc;
}

/* Zugriff auf Vektorkomponente: */
void *     GetSVectElt            (LP_SVECT pSVect, TCD_INT iIndex)
{
   return GetVectElt(pSVect,iIndex);
}

/* Find-Funktion: */
void *     FindSVectElt           (LP_SVECT pSVect,
                                   void *   pEltToTest,
                                   TCD_INT * pResultIndex)
{
   return FindVectEltByBisec ( pSVect, pEltToTest, pResultIndex );
}


/* Ein Element aus dem Vektor entfernen (pDestrData wird aufgerufen,*/
/* die anderen Vektorelemente werden "nachgerckt") */
/*       TCD_INT  DelEltFromSVect(LP_SVECT pSVect, */
/*                                 void *pData) */
TCD_INT    DelEltFromSVectByIndex (LP_SVECT pSVect,
                                   TCD_INT  iIndex)
{
   return DelEltFromVectByIndex(pSVect,iIndex);
}
/* Ergebnis==success, dh. ob Elt gelscht wurde. */



/* neue Sortierung: */
void       ResortSVect            (LP_SVECT pSVect,
                                   TCD_INT  (* pCompareData)
                                  (const void *,const void *)) 
{
   SortVect(pSVect,pCompareData);
}


void       FlushSVect             (LP_SVECT pSVect )
{
   FlushVect(pSVect);
}

/* Wieviele Elemente sind im Vektor enthalten? */
TCD_INT    SVectLen               (LP_SVECT pSVect)
{
   return VectLen(pSVect);
}
