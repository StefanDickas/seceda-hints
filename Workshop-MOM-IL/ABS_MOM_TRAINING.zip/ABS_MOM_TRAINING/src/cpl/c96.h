/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_IOP_H)
#define TCD_IOP_H

#ifndef SUBSYSTEM
  #define IOP_EXPORT 
#else
  #define IOP_EXPORT
#endif
TCD_DOUBLE IOP_EXPORT   TCDABS     (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDFAK     (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDINT     (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDSIGN    (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDDIV     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDEXP     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDMIN     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDMAX     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDZDAYS   (TCD_INT    datefmt, char *val1, 
                                    char *val2);
TCD_DOUBLE IOP_EXPORT   TCDKDAYS   (TCD_INT    datefmt, char *val1, 
                                    char *val2);
TCD_DOUBLE IOP_EXPORT   TCDRND     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDCUT     (TCD_DOUBLE val1, TCD_DOUBLE val2);


#endif
