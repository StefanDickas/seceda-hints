//This file contains defines that are specific for the Mathleb RBS
// IT is include by TCDRBS.CPP
#ifndef __TCDDEF__
#define __TCDDEF__
extern "C" {
#ifndef INCL_S_TCDATAB
#define NO_STATIC_RBS_DATA

#endif
#include "lifetem1.h"
#include "lifetem6.h"

#ifndef INCL_S_TCDATAB
   extern S_TCD_C_G  LifeTeCP;
   extern S_TCDRBS_SS  LifeTeSS;
#endif

}

#define MAXTABSPALTEN 110
#define MAXTABZEILEN 200
#define RBS0(parm)      LifeTem0(parm)
#define RBS_ATAB_SIZE   LifeTemp_ATAB_SIZE
#define S_RBS_ATTRTAB   s_LifeTemp_AttrTab
#define RBSCP           LifeTeCP
#define RBSSS           LifeTeSS
#endif
