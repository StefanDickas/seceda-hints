/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_PKF_H)
#define TCD_PKF_H
/*---------------------------------------------------------------------
    Modul:        C:\dev\TCD_DB\template\db\R3FE\C\C3E9\lifet250.h

    Beschreibung: Funktionsprototypen der externen Funktionen der
                  Formelsammlungsdatei
    By:           BEGGI
    Generiert am: 16.12.2019 15:07:19
---------------------------------------------------------------------*/
   
      void LifeT128 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT129 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT130 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT131 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT132 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT133 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT134 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT135 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT136 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT137 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT138 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT139 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT140 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT141 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT142 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT143 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT144 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT145 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT146 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT147 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT148 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT149 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT150 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT151 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT152 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT153 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT154 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT155 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT156 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT157 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT158 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT159 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT160 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT161 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT162 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT163 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT164 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT165 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT166 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT167 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT168 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT169 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT170 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT171 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT172 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT173 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT174 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT175 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT176 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT177 (P_TCD_C_F1 pMyPar) ;
   

#endif
