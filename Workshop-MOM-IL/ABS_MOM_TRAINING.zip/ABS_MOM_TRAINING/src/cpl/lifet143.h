/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_PKF_H)
#define TCD_PKF_H
/*---------------------------------------------------------------------
    Modul:        C:\dev\TCD_DB\template\db\R3FE\C\C3E9\lifet143.h

    Beschreibung: Funktionsprototypen der externen Funktionen der
                  Formelsammlungsdatei
    By:           BEGGI
    Generiert am: 16.12.2019 15:07:19
---------------------------------------------------------------------*/
   
      void LifeTe90 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe91 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe92 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe93 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe94 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe95 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe96 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe97 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe98 (P_TCD_C_F1 pMyPar) ;
   
      void LifeTe99 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT100 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT101 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT102 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT103 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT104 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT105 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT106 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT107 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT108 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT109 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT110 (P_TCD_C_F1 pMyPar) ;
   

#endif
