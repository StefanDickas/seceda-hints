/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDC_H)
#define TCDC_H

#ifdef TCDV2_5
#define TCDVERS 25
#endif
#ifdef TCDV3_0
#define TCDVERS 30
#endif
#ifndef TCDVERS
#error TCD Version muss in Makefiles angegeben werden.
#endif

/*---------
Name        : TCDC.H

Beschreibung: Zentrales Include File fuer die Anwendung
TCD weit gueltig
*----------*/

#include "p09115.h" /* direkte Vektoren */

#define  TCD_TRUE                1
#define  TCD_FALSE               0

/*---------
  Definitionen Opcodes
*----------*/
#define  TCD_OPC_INIT_RBS                    1
#define  TCD_OPC_CALC_FRM                    2
#define  TCD_OPC_CALC_PRC                    3
#define  TCD_OPC_GETNUM_FRM                  4
#define  TCD_OPC_GET_ATTR_VAL                5
#define  TCD_OPC_RESET_RBS                   6
#define  TCD_OPC_SET_PRC                     7
#define  TCD_OPC_RESET_PRC                   8
#define  TCD_OPC_SET_POOLTAB                 9
#define  TCD_OPC_RESET_POOLTAB              10
#define  TCD_OPC_SET_ATTR_VAL               11
#define  TCD_OPC_GET_PRC_INFO               12
#define  TCD_OPC_SET_POOLTAB_I              13
#define  TCD_OPC_RESET_POOLTAB_I            14
#define  TCD_OPC_SET_ATTR_IN_PRC            15
#define  TCD_OPC_SET_TRACE_ON               16
#define  TCD_OPC_SET_TRACE_OFF              17
#define  TCD_OPC_REMOVE_RESULTS             18
#define  TCD_OPC_GET_FIRST_RESULTS_INFO     19
#define  TCD_OPC_GET_NEXT_RESULTS_INFO      20

/*---------
  Definitionen Returncodes
*----------*/
#define  TCD_RC_NOT_OK              0
#define  TCD_RC_OK                  1
#define  TCD_RC_ILLOPC              2
#define  TCD_RC_VERSION_CONFLICT    3
#define  TCD_RC_UNKNOWN_FORM        4
#define  TCD_RC_ILLEGAL_FORM        5
#define  TCD_RC_ILLEGAL_PARAM       6
#define  TCD_RC_UNKNOWN_ATTR        7
#define  TCD_RC_NOT_FOUND           8
#define  TCD_RC_INPUT_MISSING       9
#define  TCD_RC_ILLEGAL_DIVISION   10
#define  TCD_RC_ILLEGAL_TAB_RANGE  11
#define  TCD_RC_STACK_OVERFLOW     12
#define  TCD_RC_CONDITION_FAIL     15
#define  TCD_RC_PAR_ERROR          20
#define  TCD_RC_TAB_IN_POOL        21
#define  TCD_RC_TAB_NOT_IN_POOL    22
#define  TCD_RC_PRC_IN_POOL        23
#define  TCD_RC_PRC_NOT_IN_POOL    24
#define  TCD_RC_UNKNOWN_PROC       25
#define  TCD_RC_PAARLISTEN_ERROR   26
#define  TCD_RC_NO_VALUE_AVAIL     30
#define  TCD_RC_USER_SET_ERROR    900
#define  TCD_RC_INTERNAL_ERR      999
#define  TCD_RC_NO_RETURN         888

/*---------
  allgemeine globale Konstanten
*----------*/
#define TCD_INIT_VARSETLEVEL    9999

/*---------
  Konfigurationsangaben
*----------*/
#define TCD_POOLADMIN_SIZE        20
#define TCD_C_MIN_USER_TYPE_ID    0
#define TCD_C_TABLISTLEN          10
#define TCD_C_MAXPRCCALLNR        2147483647

/*---------
  Definitionen Laengenangaben
*----------*/
#define TCD_DATUM_LNG              9
#define TCD_FRM_DATUM_LNG         20
#define TCD_VGLOP_LNG              3
#define TCD_NAME_LNG              26

/*---------
  Definitionen Aufrufart: (Aufzaehlungstyp)
-----------*/
#define TCD_CALLTYP_ATTR        1
#define TCD_CALLTYP_STA         2
#define TCD_CALLTYP_DYN         3
#define TCD_CALLTYP_STA_UE      4

/*---------
  Definitionen Prefix
-----------*/
#define TCD_PREFIX_TAB            '&'
#define TCD_PREFIX_PRC            '$'
#define TCD_PREFIX_FRM            'F'
#define TCD_PREFIX_ATTR           'A'

/*---------
  Definitionen Formeltypen (Aufzaehlungstyp, Wertevergabe analog Cobol)
-----------*/
#define TCD_FRMTYP_SKAL        1
#define TCD_FRMTYP_TAB1        2
#define TCD_FRMTYP_TAB2        3

/*---------
  Definitionen Belegungswerte PoolEntry
-----------*/
#define  TCD_POOLENT_INIT          0
#define  TCD_POOLENT_USED          1
#define  TCD_POOLENT_I_USED        2
#define  TCD_POOLENT_E_USED        3

/*---------
  Definitionen Assigntype
*----------*/
#define  TCD_DC_USE_NOT            0
#define  TCD_DC_USE_FRM            1
#define  TCD_DC_USE_PRC            2
#define  TCD_DC_USE_TAB            3
#define  TCD_DC_USE_VAL            4

/*----------
  Definitionen Formattypen
-----------*/
#define  TCD_ATTRFMT_SKAL          1
#define  TCD_ATTRFMT_TAB1          2
#define  TCD_ATTRFMT_TAB2          3
#define  TCD_ATTRFMT_VGLO          4
#define  TCD_ATTRFMT_DATE          5

/*----------
  Struktur Bestandsattributtabelle
 ----------*/
  typedef struct tagS_TCDATAB {
        char          Name [TCD_NAME_LNG] ;
        TCD_LONG      ID         ;
        TCD_INT       Index      ;
        TCD_INT       AttrTyp    ;
  } S_TCDATAB     ;

 typedef S_TCDATAB     * P_TCDATAB     ;

/*----------
  Struktur Tabelle aller Attribute
 ----------*/
  typedef struct tagS_ATTRTAB
  {
    TCD_LONG  ID    ;
    TCD_INT   Index ;
  } S_ATTRTAB ;

  typedef S_ATTRTAB    * P_ATTRTAB     ;

/*----------
  Typdefinition systemunabhanegiger Typen
 ----------*/
   typedef  char  TCD_VGLOP [TCD_VGLOP_LNG] ;
   typedef  char  TCD_DATUM [TCD_DATUM_LNG] ;

   typedef TCD_DOUBLE TCDTAB1 ;
   typedef P_TCDTAB   P_TCDTAB1 ;

   typedef TCD_DOUBLE TCDTAB2 ;
   typedef P_TCDTAB   P_TCDTAB2 ;

   typedef P_P_TCD_DOUBLE P_P_TCDTAB ;

/*---------
  Union Attributbelegung
 ----------*/
  typedef  union tagU_TCDVALUE {
           TCD_DOUBLE        Skalar;
           P_TCDTAB1         pTab1 ;
           P_TCDTAB2         pTab2 ;
   } U_TCDVALUE ;

  typedef  union tagU_TCDGVALUE {
           TCD_DOUBLE        Skalar;
           P_TCDTAB          pTab  ;
           TCD_VGLOP         VglOp ;
           TCD_DATUM         Datum ;
   } U_TCDGVALUE ;

/* --
 MUB 2.7.96: neu eingefuehrt, weil wir die TabellenID brauchen
--  */
  typedef  union tagU_TCDWVALUE
  {
           TCD_DOUBLE        Skalar;

           TCD_LONG          TabID ;  /*  die relevanten Attribute */
           P_TCDTAB1         pTab  ;  /*  das Ergebnis */

           TCD_VGLOP         VglOp ;
           TCD_DATUM         Datum ;
   } U_TCDWVALUE ;

  typedef struct tagS_TCDPRCVAL {
          TCD_LONG   PrcID ;
          TCD_LONG   FormelNr ;
          TCD_INT    FormelIx ;
          char       FormelName [TCD_NAME_LNG] ;
          TCD_INT    PoolIx ;
#if TCDVERS > 25
/* Version der Formel zur Pruefung 
		  Formel-Generat gegen Transport-Format */
          TCD_INT    FormelVers;
#endif

 } S_TCDPRCVAL ;

  typedef union  tagU_TCDNDVALUE {
          struct   tagTabData {
             TCD_LONG  TabID ;
             TCD_INT   PoolIx ;
          } TabData  ;
          TCD_DOUBLE Skalar ;
          char       Datum [TCD_DATUM_LNG] ;
          char       VglOp [TCD_VGLOP_LNG];
 } U_TCDNDVALUE ;


  typedef struct tagS_TCDFORMEL {
           TCD_LONG  FormelNr ;
           TCD_INT  FormelIx ;
           char     FormelName [TCD_NAME_LNG] ;
           TCD_INT  IsStaRef ;                                 
#if TCDVERS > 25
/* Version der Formel zur Pruefung 
		   Formel-Generat gegen Transport-Format */
		   TCD_INT  FormelVers;
#endif
 } S_TCDFORMEL ;

  typedef union  tagU_TCDASSIGNVAL {

       S_TCDPRCVAL  Prc    ;
       U_TCDNDVALUE Val    ;
       S_TCDFORMEL  Formel  ;

 } U_TCDASSIGNVAL ;

#define TYP3_NOT_OVERWRITTEN 2

typedef struct tagS_TCDREL_ATTR
{                                 
   TCD_LONG    iBerechnungsNummer;
   /* ID des Attributs                            */
   TCD_LONG    AttrID                  ;  
   /* Typ der Belegung SKALAR, TAB, DATUM , VGLOP */
   TCD_INT     AttrType              :4;  
   /* Flag, ob ein geerbter Wert vorhanden ist    */
   TCD_INT     bGeerbterWertVorhanden:2;  
   /* Flag, ob ein geerbter Wert vorhanden ist    */
   TCD_INT     bNotOverwritten         ;
   /* GGf. Wert hierzu                            */
   U_TCDWVALUE Belegung                ;  

}  S_TCDRELATTR;

typedef S_TCDRELATTR * P_TCDRELATTR ;

/* --
   S_TCDRELATTR_IMP    Relevantes Attribut fuer den Import
--  */
typedef struct tagS_TCDREL_ATTR_IMP
{
   TCD_LONG AttrID;
   TCD_INT  AttrType               : 4;
   TCD_INT  iIndex;

}  S_TCDRELATTR_IMP;

typedef S_TCDRELATTR_IMP * P_TCDRELATTR_IMP ;

/* --
   S_PAARLISTEN_EL    Struktur fuer ein PaarlistenElement
--  */
typedef struct tagS_PAARLISTEN_EL
{
   /* Vektor der relevanten Attribute mit der aktuellen Belegung     */
   LP_VECT          pAttrs;        
   /* lfde. Nummer der aktuellen Berechnung                          */
   TCD_LONG         iBerechnungsNummer; 
   
   TCD_LONG         lTabZeilen;         
   TCD_LONG         lTabSpalten;
   
   /* Typ des Ergebnisses (kann 'NOT_OVERWRITTEN' sein)              */
   TCD_INT          iType;              
   /* Ergebnis hierzu                                                */
   U_TCDWVALUE      Ergebnis;           

}  S_PAARLISTEN_EL;

typedef S_PAARLISTEN_EL * P_PAARLISTEN_EL ;

/* --
   S_PAARLISTE     Struktur zu einem Belegknoten einer BV
   Sie enthaelt 1 sortierten Vektor, 1 Liste und eine maximale Laenge
   fuer die Anzahl Elemente der Paarliste (Belegung,Ergebnis)
--  */
typedef struct tagS_PAARLISTE
{
   TCD_INT iWiederVerwendungsTyp;   /* KnotenTyp 1/2/3     */
   TCD_INT iWiederVerwListenLaenge; /* ListenLaenge maximal */
   TCD_INT iAct ;                   /* letztes Element     */

   /* direkter Vektor von S_ATTR_EL's   */
   LP_VECT pAttrs;                  
   /* direkter Vektor von S_PAARLISTEN_EL's */
   LP_VECT pPaarListenElts;         

}  S_PAARLISTE;

typedef S_PAARLISTE * P_PAARLISTE ; 

/* --
   S_ERGEBNIS_POOL_ELT Element eines PoolErgebnisses
--  */
typedef struct tagS_ERGEBNIS_POOL_ELT
{
   TCD_LONG    ID;
   P_PAARLISTE pPaarListe;

}  S_ERGEBNIS_POOL_ELT;

typedef S_ERGEBNIS_POOL_ELT * P_ERGEBNIS_POOL_ELT ;

/*-----------
  Struktur     Belegungsknoten
------------*/
  typedef struct tagS_TCDPRCNODE
  {
      TCD_LONG         AttrID                  ;
      TCD_INT          NodeID                  ;
      TCD_INT          AttrType                ;
      TCD_INT          AssignType              ;
      U_TCDASSIGNVAL   AssignVal               ;
      TCD_INT          SuccNodeIx              ;
      TCD_INT          AnzSuccNodes            ;
      TCD_INT          Usage                   ;

      P_PAARLISTE      pPaarListe              ;
      P_PAARLISTEN_EL  pResultForGetAttr       ;

      TCD_INT          iWiederVerwendungsTyp   ;
      TCD_INT          iWiederVerwListenLaenge ;
      TCD_INT          iAnzRelAttrs            ;
      TCD_INT          iFirstRelAttrIx         ;

  }   S_TCDPRCNODE ;

 typedef S_TCDPRCNODE  * P_TCDPRCNODE ;

/*-----------
  Struktur Auspraegungs-Belegungs-Information
------------*/
  typedef struct tagS_TCDPRCINFO {
         char  Name [TCD_NAME_LNG] ;
         TCD_LONG  ID ;
         TCD_INT   Formattyp ;
         TCD_INT   Typ ;
         TCD_INT   Klasse ;
         TCD_INT   AnzBeleg ;
         TCD_INT   TabIx ;
         TCD_LONG  RefNodeId ;
 } S_TCDPRCINFO ;

 typedef S_TCDPRCINFO  * P_TCDPRCINFO ;

/*--------
  Struktur LocalData MUB 2.7.96: wird nicht mehr verwendet!
 --------*/
  typedef struct tagS_TCDPRCLOCD {
          TCD_LONG FormelNr     ;
          TCD_INT  Usage        ;
          TCD_INT  Typ          ;
          union   {
              TCD_INT    PoolIx ;
              TCD_DOUBLE Val    ;
          } Data ;
          TCD_LONG  CalcByCallNr ;
   } S_TCDPRCLOCD ;

   typedef S_TCDPRCLOCD * P_TCDPRCLOCD ;

/*---------
  Struktur Header Auspraegungsbaum
----------*/
  typedef struct tagS_TCDPRCHDR {
    TCD_LONG       PrcID        ;
    TCD_LONG       FormelNr     ;
    TCD_INT        AnzPrcTree   ;
    TCD_INT        AnzBelegInfo ;
    TCD_INT        AnzRelAttrs  ;
    TCD_BOOL       FlSetAttrSkal;
    TCD_BOOL       FlSetAttrTab ;
    TCD_BOOL       FlSetAttrVgl ;
    TCD_BOOL       FlSetAttrDat ;
    TCD_BOOL       FlPrcCompl   ;
    TCD_LONG       PrcResIx     ;
    TCD_LONG       PrcCallNr    ;

 } S_TCDPRCHDR     ;


/*---------
  Struktur Auspraegungselement
-----------*/
  typedef union  tagU_TCDPRCELEM
  {
     S_TCDPRCHDR      TreeHdr;
     S_TCDPRCNODE     Node ;
     S_TCDPRCINFO     Info ;     
  }  U_TCDPRCELEM ;

 typedef U_TCDPRCELEM  * P_TCDPRCELEM ;

#define TCDPRCSIZE(pPrc)    (pPrc ? sizeof(S_TCDRELATTR_IMP)*\
                            (TCD_LONG)pPrc->TreeHdr.AnzRelAttrs +\
                            sizeof(U_TCDPRCELEM)*\
                            ( (TCD_LONG)pPrc->TreeHdr.AnzPrcTree +\
                             (TCD_LONG)pPrc->TreeHdr.AnzBelegInfo) : 0)


/*-------
  Datenstruktur Mehrfach-Auspraegung (MultiProc)
 --------*/
  typedef struct tagS_TCDMPRCENTRY {
        TCD_INT              PrcBelegt ;
        TCD_LONG             ID ;
        P_TCDPRCELEM         pPrcData ;
 } S_TCDMPRCENTRY ;

  typedef S_TCDMPRCENTRY * P_TCDMPRCENTRY ;

  typedef struct tagS_TCDMPRCADMIN {
        TCD_INT          Anzahl  ;
        P_TCDMPRCENTRY   Data    ;
 } S_TCDMPRCADMIN ;

 typedef S_TCDMPRCADMIN * P_TCDMPRCADMIN ;

/*--------
  Datenstruktur PoolAdmin
--------*/
  typedef struct tagS_TCDPOOLENTRY {
        TCD_LONG     ID ;
        TCD_INT      Usage ;
        TCD_INT      Typ ;
        TCD_INT      Fmttyp ;
        P_TCD_DOUBLE pData ;
  } S_TCDPOOLENTRY ;

  typedef S_TCDPOOLENTRY * P_TCDPOOLENTRY ;

  typedef struct tagS_TCDPOOLADMIN {
        TCD_INT          Anzahl  ;
        TCD_INT          AnzTabs ;
        TCD_INT          AnzProcs ;
        TCD_INT          AnzTemp  ;
        S_TCDPOOLENTRY * Data    ;
 } S_TCDPOOLADMIN ;

  typedef S_TCDPOOLADMIN * P_TCDPOOLADMIN ;

/*------
  Datenstruktur Kontrollstruktur
--------*/
  typedef struct tagS_TCDRBSINFO {
       char TcdVersion [TCD_DATUM_LNG]   ;
       char TcdRelease [TCD_DATUM_LNG]   ;
       char RbsInterf  [TCD_DATUM_LNG]   ;
       TCD_LONG RbsId ;
   } S_TCDRBSINFO ;

   typedef struct tagS_TCDRCINFO {
       TCD_INT   Rc ;
       TCD_INT   Errc ;
       char FormelName [TCD_NAME_LNG] ;
       TCD_INT   FormelNr ;
       char AttrName   [TCD_NAME_LNG] ;
   } S_TCDRCINFO          ;

   typedef S_TCDRCINFO * P_TCDRCINFO ;


   typedef struct tagS_TCDCTLPAR {

/*-
  Opcode:   TCD_OPC_GET_ATTR_VAL, TCD_OPC_SET_ATTR_VAL
--*/
        struct tagS_TCDPARGA {
           TCD_LONG    ProcID;
           TCD_LONG    ID;
           TCD_LONG    TabID;
           TCD_INT     TabIx ;
           U_TCDGVALUE Val ;
           TCD_INT     Typ ;
           TCD_INT     ProcIx;
        }            GA ;

/*-
  Opcode:   TCD_OPC_SET_POOLTAB
--*/
        struct tagS_TCDPARST {
            TCD_LONG  ID;
            TCD_INT   Dim ;
            P_TCDTAB  pTab ;
            TCD_INT    TabIx ;
        }            ST ;

/*-
  Opcode:   TCD_OPC_RESET_POOLTAB
--*/
        struct tagS_TCDPARRT{
            TCD_LONG  ID;
            P_TCDTAB  pTab ;
        }            RT ;

/*-
  Opcode:   TCD_OPC_SET_PRC
--*/
        struct tagS_TCDPARSP {
            TCD_LONG      ProcID;
            P_TCDPRCELEM  pProc;
            TCD_INT       ProcIx;
        }            SP;

/*-
  Opcode:   TCD_OPC_RESET_PRC
--*/
        struct tagS_TCDPARRP {
            TCD_LONG  ProcID;
            P_TCDPRCELEM  pProc;
        }            RP;

/*-
  Opcode:   TCD_OPC_CALC_FRM , TCD_OPC_CALC_PRC
--*/
        struct tagS_TCDPARCFP {
            TCD_LONG       FormelNr ;
            TCD_LONG       ProcID;
            TCD_INT        Typ ;
            U_TCDVALUE     Value ;
            TCD_INT        ProcIx;
        }            CFP ;

/*-
  Opcode:   TCD_OPC_GETNUM_FRM
--*/
        struct tagS_TCDPARGF {
            char  Name [TCD_NAME_LNG] ;
            TCD_LONG  FormelNr ;
        }            GF ;

/*-
  Opcode:   TCD_OPC_GET_PRC_INFO
--*/
        struct tagS_TCDPRCBINFO {
            TCD_LONG        ProcID;
            TCD_INT         ProcIx;
            P_TCDPRCELEM    pProcInfo;
            TCD_INT         AnzProcInfo ;
        }            PI ;

/*-
  Opcode:   TCD_OPC_REMOVE_RESULTS,
            TCD_OPC_GET_FIRST_RESULTS_INFO,
            TCD_OPC_GET_NEXT_RESULTS_INFO
--*/
        struct tagS_TCDPAR_RESULTPOOL {
            TCD_LONG        ProcID;
            TCD_LONG        lNumOfResults;
            TCD_INT         bFinished;
        }            RESP ;

   } S_TCDCTLPAR ;

   typedef S_TCDCTLPAR * P_TCDCTLPAR ;

   typedef struct tagS_TCDRBSCTL {
          TCD_INT       Opc     ;
          S_TCDRBSINFO  RbsInfo ;
          S_TCDRCINFO   RCInfo  ;
          S_TCDCTLPAR   Par     ;
  } S_TCDRBSCTL ;

   typedef S_TCDRBSCTL * P_TCDRBSCTL ;

/*------
  Datenstruktur Rechenbausteinschnittstelle
 --------*/
   typedef struct tagS_TCDV_F_FLAGS {
         TCD_BOOL       V_In   ;
         TCD_BOOL       F_In   ;
         TCD_BOOL       V_Comp ;
         TCD_BOOL       V_Use  ;
         TCD_BOOL       F_Use  ;
         TCD_BOOL       V_Miss ;
         TCD_BOOL       F_Miss ;
   } S_TCDV_F_FLAGS ;

   typedef S_TCDV_F_FLAGS * P_TCDV_F_FLAGS ;

   typedef struct tagS_TCDV_FLAGS {
         TCD_BOOL       V_In   ;
         TCD_BOOL       V_Use  ;
         TCD_BOOL       V_Miss ;
   } S_TCDV_FLAGS ;

   typedef S_TCDV_FLAGS   * P_TCDV_FLAGS   ;

   typedef struct tagS_TCDSKAL_DATA
   {
        TCD_DOUBLE      Val    ;
        TCD_LONG        Formel ;
        S_TCDV_F_FLAGS  Flags  ;
   } S_TCDSKAL_DATA ;

   typedef S_TCDSKAL_DATA * P_TCDSKAL_DATA ;

   typedef struct tagS_TCDTAB1_DATA
   {
     TCD_LONG        TabID;
     P_TCDTAB1       pVal ;
     TCD_LONG        Formel ;
     S_TCDV_F_FLAGS  Flags ;

   } S_TCDTAB1_DATA ;
   typedef S_TCDTAB1_DATA  * P_TCDTAB1_DATA  ;

   typedef struct tagS_TCDTAB2_DATA
   {
     TCD_LONG        TabID;
     P_TCDTAB2       pVal ;
     TCD_LONG        Formel ;
     S_TCDV_F_FLAGS  Flags ;

   } S_TCDTAB2_DATA ;
   typedef S_TCDTAB2_DATA * P_TCDTAB2_DATA ;

   typedef struct tagS_TCDDAT_DATA {
        char             Val [TCD_DATUM_LNG] ;
        S_TCDV_FLAGS     Flags ;
   } S_TCDDAT_DATA ;

   typedef S_TCDDAT_DATA * P_TCDDAT_DATA ;

   typedef struct tagS_TCDVGL_DATA {
        char            Val [TCD_VGLOP_LNG] ;
        S_TCDV_FLAGS    Flags ;
   } S_TCDVGL_DATA ;

   typedef S_TCDVGL_DATA * P_TCDVGL_DATA ;

   typedef struct tagS_TCD_RBS_SSA
   {
        P_TCDSKAL_DATA    pSkal ;
        P_TCDTAB1_DATA    pTab1 ;
        P_TCDTAB2_DATA    pTab2 ;
        P_TCDDAT_DATA     pDat  ;
        P_TCDVGL_DATA     pVgl  ;
   } S_TCD_RBS_SSA ;

   typedef S_TCD_RBS_SSA  * P_TCD_RBS_SSA ;


   typedef struct tagS_TCDRBS_SS {
       S_TCDRBSCTL       RCTL ;
       S_TCD_RBS_SSA     SSAData   ;
       S_TCDPOOLADMIN    PoolAdmin ;
       S_TCDMPRCADMIN    MPrcAdmin ;
 } S_TCDRBS_SS ;

 typedef S_TCDRBS_SS  * P_TCDRBS_SS ;

  typedef struct tagS_TCDPARATTR_SK {
        TCD_INT      Level ;
        TCD_DOUBLE   Val ;
 } S_TCDPARATTR_SK   ;

 typedef S_TCDPARATTR_SK  * P_TCDPARATTR_SK ;

  typedef struct tagS_TCDPARATTR_VGL {
        TCD_INT      Level;
        char         Val  [TCD_VGLOP_LNG] ;
 } S_TCDPARATTR_VGL  ;

 typedef S_TCDPARATTR_VGL * P_TCDPARATTR_VGL ;

  typedef struct tagS_TCDPARATTR_DAT
  {
        TCD_INT      Level;
        char         Val  [TCD_DATUM_LNG] ;
 } S_TCDPARATTR_DAT  ;

 typedef S_TCDPARATTR_DAT * P_TCDPARATTR_DAT ;

/*-----------
  Struktur Schnittstellendaten (interne Sicht)
-----------*/
  typedef struct tagS_TCDISSADATA
  {
     TCD_INT      AnzSSASkal ;
     TCD_INT      AnzSSATab1 ;
     TCD_INT      AnzSSATab2 ;
     TCD_INT      AnzSSADat ;
     TCD_INT      AnzSSAVgl ;
     TCD_INT      AnzParSkal;
     TCD_INT      AnzParVgl ;
     TCD_INT      AnzParDat ;
     TCD_INT      AnzZeilen ;
     TCD_INT      AnzSpalten ;
     P_TCDSKAL_DATA    pSkal ;
     P_TCDTAB1_DATA    pTab1 ;
     P_TCDTAB2_DATA    pTab2 ;
     P_TCDDAT_DATA     pDat ;
     P_TCDVGL_DATA     pVgl ;
     P_TCDPARATTR_SK   pParSkal ;
     P_TCDPARATTR_VGL  pParVgl;
     P_TCDPARATTR_DAT  pParDat;

 }   S_TCDISSADATA ;
 typedef S_TCDISSADATA * P_TCDISSADATA ;



/*------
Datenstruktur globale Daten des Rechenbausteins;
diese Datenstruktur enthaelt Informationen und Teilstrukturen, die
in den programmierten Funktionen benoetigt werden.
Initialisierung dieser Daten erfolgt mehrstufig.
- beim Init: globaler Pointer pTCDTCD initialisiert (zeigt auf die Str)
pRbsSS zeigt auf die RBS-Schnittstelle
- bei auspraegungsspez. Opcodes werden die Teilstrukturen fuer die
Auspraegung initialisiert, ...
- bei einer neuen Berechnung werden die internen Aufrufschnittstellen
initialisiert
--------*/
  typedef struct tagS_TCD_C_G
  {
      P_TCDRBS_SS      pRbsSS      ;
      P_TCDPRCELEM     pPrcData    ;
      S_TCDPRCHDR *    pPrcHdr     ;
      P_TCDPRCELEM     pPrcTreeNode;
      P_TCDPRCELEM     pInfo       ;
      P_TCDRELATTR_IMP pRelAttrs   ;
      P_TCDMPRCADMIN   pMPrcAdmin  ;
      P_TCDRBSCTL      pRbsCtl     ;
      S_TCDISSADATA    SSAData     ;
      P_TCDPOOLADMIN   pPoolAdmin  ;
      TCD_INT          GlbVarSet   ;
      TCD_LONG         RBS_ID      ;
      TCD_BOOL         ValFound    ;
      TCD_BOOL         FrmFound    ;
      TCD_BOOL         V_Comp      ;
      TCD_BOOL         PrcChg      ;
      void *           pApplIf     ;
      P_TCDTAB         ResTab      ;
      TCD_DOUBLE       ResSkal     ;
      
      TCD_LONG         LastCalcPrcID;
      LP_VECT          pErgebnisPool;
      TCD_LONG         iBerechnungsNummer;
      TCD_INT          iErgPoolIteratorGl;                       
      P_PAARLISTE      pPaarListeNotToSave;
      
      TCD_BOOL         btrace_open;
      TCD_BOOL         btrace_enabled;
      
/* RWE, 10.06.1997: Neues Datenelement fuer Beobachtung
   der Wiederverwendung (ehemals WatchPol-Funktionalitaet) */
      TCD_BOOL         bProtWV;
      
  }   S_TCD_C_G ;
  typedef S_TCD_C_G   * P_TCD_C_G ;
#endif
