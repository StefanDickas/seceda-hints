/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_POOL_H)
#define TCD_POOL_H
/*---------------------------------------------------------------------
  Datei      : TCD_POOL.h
  Generiert am 16.12.2019 15:07:18
  Historie      : 27.7.95    BEG neuer Prefix fuer Tabellenentry
---------------------------------------------------------------------*/
void    TCDPIT   (P_TCD_C_G);
void    TCDPRP   (P_TCD_C_G) ;
void    TCDPST   (P_TCD_C_G) ;
void    TCDPRT   (P_TCD_C_G) ;
void    TCDPSAT  (P_TCD_C_G) ;
void    TCDPRTA  (P_TCD_C_G) ;
TCD_INT TCDPGF   (P_TCD_C_G,P_TCD_DOUBLE Var, TCD_INT *PIndex) ;

#endif
