/*---------------------------------------------------------------------

(C) Copyright 1993-2002, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#ifndef TCDADT_H
#define TCDADT_H

#ifndef SUBSYSTEM
  #ifdef __MVS__
        #define ADT_EXPORT 
  #else
  	#define ADT_EXPORT __declspec(dllexport)
  #endif
#else
  #define ADT_EXPORT
  /* Behelfsm��ige Definitionen zur Umgehung von Compiler-Fehlern */
  #ifndef PRECOND
    #define PRECOND
  #endif
  #ifndef TCD_INTL_ERR
    #define TCD_INTL_ERR
  #endif
#endif

#endif
