/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_FCTL_H)
#define TCD_FCTL_H
/*---------------------------------------------------------------------
  Modul:   TCD_FCTL.H
  f�r RBS: LifeTemplate
---------------------------------------------------------------------*/

void  LifeTemF(P_TCD_C_G pTCDTCD) ;
void  LifeTem1(P_TCD_C_F1  pF1 ) ;
void    TCD3FES (P_TCD_C_F1 pMyPar, char * AttrName, TCD_INT Ix,
                       TCD_LONG ID, TCD_INT AttrTyp, TCD_INT ParIx,
                       P_TCD_DOUBLE Var) ;
void    TCD3FET (P_TCD_C_F1 pMyPar, char * AttrName, TCD_INT Ix,
                      TCD_LONG ID, TCD_INT AttrTyp, P_P_TCDTAB Var);
void    TCD3FED (P_TCD_C_F1 pMyPar, char * AttrName,
                      TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                      TCD_INT ParIx, char *Var) ;
void    TCD3FEV (P_TCD_C_F1 pMyPar, char * AttrName,
                      TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                      TCD_INT ParIx, char *Var) ;
TCD_INT TCD3FE1 (P_TCD_C_F1 pMyPar, TCD_BOOL option, char * Name,
                      TCD_LONG ID, TCD_INT FrmNr, P_TCD_DOUBLE Var) ;
TCD_INT TCD3FE2 (P_TCD_C_F1 pMyPar, TCD_BOOL option, char * Name,
                      TCD_LONG ID, TCD_INT FrmNr, P_P_TCDTAB  Var) ;

TCD_INT TCDChkFrm     (P_TCD_C_F1,void *);
void    ClearOverwriteStack(P_TCD_C_G pTCDTCD );

void       TCD3FESaveResult(P_TCD_C_F1);

#endif
