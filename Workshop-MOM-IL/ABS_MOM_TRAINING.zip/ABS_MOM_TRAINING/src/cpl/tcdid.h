#ifndef TCD_ID_HD
#define TCD_ID_HD

#ifndef MAXTABSPALTEN
#define MAXTABSPALTEN 110
#endif
#ifndef MAXTABZEILEN
#define MAXTABZEILEN 200
#endif

#ifndef _MSC_VER
extern "C" {
#endif

#include "c88.h"
#include "c90.h"
#include "c89.h"
#ifndef _MSC_VER
};
#endif

extern "C" {
  #include "lifetem6.h"
}

#define TAB1_ID_BASE			(ANZSKALAR)
#define TAB2_ID_BASE			(TAB1_ID_BASE+ ANZTAB1)
#define DATUM_ID_BASE			(TAB1_ID_BASE + ANZTAB1 + ANZTAB2)
#define USER_ID_BASE			(DATUM_ID_BASE + ANZDATUM + ANZVERGL)

#define VTAR_ID							USER_ID_BASE
#define PSCHABL_ID						(USER_ID_BASE+1)
#define HSPP_ID							(USER_ID_BASE+2)
#define VTAR_VERSION					(USER_ID_BASE+3)
#define VTAR_ID_VORGABE					(USER_ID_BASE+4)
#define VTAR_ID_RECHVTARVORGABE			(USER_ID_BASE+5)

#endif /* TCD_ID_H */
