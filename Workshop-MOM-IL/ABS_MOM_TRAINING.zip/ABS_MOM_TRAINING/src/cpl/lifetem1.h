/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_RCTL_H)
#define TCD_RCTL_H
/*---------------------------------------------------------------------
  Datei :  TCD_RCTL.h
  Beschreibung:      TCD Schnittstelle fur RBS LifeTemplate
---------------------------------------------------------------------*/
#define I_PAR_SKAL_SIZE (89 + 85)
#define I_PAR_VGL_SIZE  (1 + 0)
#define I_PAR_DAT_SIZE  (1 + 0)
#define I_SKAL_DATA_SIZE 89
#define I_TAB1_DATA_SIZE 1
#define I_TAB2_DATA_SIZE 5
#define I_DAT_DATA_SIZE  1
#define I_VGL_DATA_SIZE  1

#define I_ANZ_BSTATTRSK   88
#define I_ANZ_BSTATTRT1   0
#define I_ANZ_BSTATTRT2   4
#define I_ANZ_BSTATTRDT   0
#define I_ANZ_BSTATTRVG   0
#define I_ANZ_ATTRSK      173
#define I_ANZ_ATTRVG      0
#define I_ANZ_ATTRDT      0
#define I_MAXROWS         200
#define I_MAXCOLS         110

#define I_RBS_ID          0X3FE

/*-------------------------------------------------------------------
  Funktionsprototyp Aufruf Rechenbaustein
-------------------------------------------------------------------*/
typedef  void  (*TCDRbsSSFktType) (S_TCD_C_G *);
void            LifeTem0(S_TCD_C_G * pRbsIf) ; 
TCDRbsSSFktType GetRbsSSFkt(); 
               /* Gibt Zeiger auf LifeTem0 zurueck */


/*---------------------------------------------------------------------
 Definition dynamischer Aufbau der RBS-Strukturen
---------------------------------------------------------------------*/
S_TCD_C_G       *DConstrTCD_C_G ();
void             DDestrTCD_C_G  (S_TCD_C_G **ppTCD_C_G);

/*---------------------------------------------------------------------
 Definition statischer RBS-Strukturen
---------------------------------------------------------------------*/

#ifndef NO_STATIC_RBS_DATA
#define STATIC_RBS_DATA
#endif
      
#ifdef STATIC_RBS_DATA

TCDRbsSSFktType TCDRbsSSFkt0 = LifeTem0;

 S_TCDPARATTR_SK  ParSkal [ I_PAR_SKAL_SIZE ] ;
 S_TCDPARATTR_VGL ParVgl  [ I_PAR_VGL_SIZE ] ;
 S_TCDPARATTR_DAT ParDat  [ I_PAR_DAT_SIZE ] ;
 S_TCDSKAL_DATA   Skal    [ I_SKAL_DATA_SIZE ] ;
 S_TCDTAB1_DATA   Tab1    [ I_TAB1_DATA_SIZE ] ;
 S_TCDTAB2_DATA   Tab2    [ I_TAB2_DATA_SIZE ] ;
 S_TCDDAT_DATA    Dat     [ I_DAT_DATA_SIZE ] ;
 S_TCDVGL_DATA    Vgl     [ I_VGL_DATA_SIZE ] ;

/*---------------------------------------------------------------------
 Definition der externen RBS-Schnittstelle
---------------------------------------------------------------------*/
 S_TCDRBS_SS  LifeTeSS  =
{
    /* RCTL      */  { 0 },
    /* SSAData   */  { Skal, Tab1, Tab2, Dat, Vgl },
    /* PoolAdmin */  { 0 },
    /* MPrcAdmin */  { 0 }
} ;

S_TCDRBS_SS *pTCDRbsSS = &LifeTeSS;



/*---------------------------------------------------------------------
 Definition der internen RBS-Schnittstelle
---------------------------------------------------------------------*/
 S_TCD_C_G  LifeTeCP =
{
/* pRbsSS -> RBS-Schnittstelle    */ & LifeTeSS,
/* pPrcData                       */ 0,
/* pPrcHdr                        */ 0,
/* pPrcTreeNode                   */ 0,
/* pInfo                          */ 0,
/* pRelAttrs                      */ 0,
/* pMPrcAdmin Zeiger auf MProcSS  */ & LifeTeSS.MPrcAdmin,
/* pRbsCtl Zeiger auf RBS-Controll*/ & LifeTeSS.RCTL,

/* SSAData -> interne Struktur    */ {
/* der Schnittstellendaten        */
/* AnzSSASkal  Anz.Skal. Attribute*/   I_ANZ_BSTATTRSK,
/* AnzSSATab1  Anz.Tab1  Attribute*/   I_ANZ_BSTATTRT1,
/* AnzSSATab2  Anz.Tab2  Attribute*/   I_ANZ_BSTATTRT2,
/* AnzSSADat   Anz.Dat   Attribute*/   I_ANZ_BSTATTRDT,
/* AnzSSAVgl   Anz.Vgl   Attribute*/   I_ANZ_BSTATTRVG,
/* AnzParSkal  Anz.Parameterattr. */   I_ANZ_ATTRSK,
/* AnzParVgl   Anz.Parameterattr. */   I_ANZ_ATTRVG,
/* AnzParDat   (AnzSkal + AnzVgl) */   I_ANZ_ATTRDT,
/* AnzZeilen einer Tabelle        */   I_MAXROWS,
/* AnzSpalten einer Tabelle       */   I_MAXCOLS,

/* pSkal    -> Anfang skal. SSA   */   Skal,
/* pTab1    -> Anfang Tab1 SSA    */   Tab1,
/* pTab2    -> Anfang Tab2 SSA    */   Tab2,
/* pDat     -> Anfang Dat SSA     */   Dat,
/* pVgl     -> Anfang Vgl SSA     */   Vgl,
/* pParSkal -> skalare Daten (Par)*/   ParSkal,
/* pParVgl  -> Parameter (VglOp)  */   ParVgl,
/* pParDat  -> Parameter (Datum)  */   ParDat
                                     },

/* PoolAdmin                      */ & LifeTeSS.PoolAdmin,
/* GlbVarSet                      */ 0 ,
/* ID des aktuellen RBS           */ I_RBS_ID,
/* ValFound                       */ 0 ,
/* Frm Found                      */ 0 ,
/* Attributkennzeichen            */ 0 ,
/* PrcChg: fur InitChk            */ 0 ,
/* pApplIf                        */ NULL ,
/* ResTab                         */ 0 ,
/* ResSkal                        */ 0 ,



/* Id der letzt berechneten BV    */ 0 ,
/* ErgebnisPool                   */ 0 ,
/* laufende BerechnungsNummer     */ 0 ,
/* ErgPoolIteratorGlobal          */ 0 ,
/* Flag nicht zu merkendes Erg.   */ 0 ,




/* btrace_open                    */ 0,
/* btrace_enabled                 */ 0,


/* bProtWV                        */ 0
} ;

S_TCD_C_G  *pTCDRbsCP = &LifeTeCP ;

#endif /* Definition statischer Rbs-Daten */

#endif
