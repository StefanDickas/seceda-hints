/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
/*---------------------------------------------------------------------
  Modul:        TCD_CIMP.c
  Beschreibung: Funktionen, zum Import von Auspraegungen, Tabellen und
                Knoteninformationen
  Historie:
  17.01.95 BEG  neues Makro _TCDMEMINI anstatt memset
  28.02.95 BEG  Tabellenbaumimport
  15.03.95 BEG  geaendertes Format bei Tabellentransport
  11.05.95 BEG  kein Fehler, wenn im Tabtrp die Vers fehlt
  11.05.95 BEG  Unterscheidung f�r InsertBelInfo: Calltyp
  17.05.95 BEG  Erweiterung Struktur S_TCDPRCHDR um PrcResIx
  31.07.95 BEG  Korrektur in GetNode
  08.09.95 BEG  Procimport ohne Versionsheader
  06.10.95 RON  '\0D' geht nicht (GetTabFile)
  22.01.96 RON  strcpy gegen strcpy ausgetauscht
  27.06.96 MUB  ExtractRelAttrs um nicht aufgerufene Funktion 
  NewRelAttr bereinigt
  02.07.96 MUB  LocalData komplett herausgenommen
                ExtractRelAttrs auf neue Struktur S_TCDRELATTR_IMP 
                umgestellt
                (Es werden nur noch AttrID, AttrType u. Index zum 
                Erbonkel gemerkt.
                Gibt es keinen Erbonkel, wird iIndex auf -1 gesetzt)
  5.7.96   MUB  ExtractRelAttrs weiter abgesichert gegen Fehler wie 
  nicht gefundene
                Erbknoten zu relevanten Attributen bzw. schlecht 
                gelaufenes Einf�gen von relevanten Attributen ...
  16.7.96  MUB  ExtractRelAttrs abgesichert gegen den Fall, dass 
  (durch Fehler beim Transport) keine relevanten Attribute gibt
  12.08.96 KFC  TCD_CALLTYP_STA_UE mit eingebaut
  22.08.96 MUB  Layout verbessert
  26.08.96 KAT  Aus Union U_TCDIMPDATA wird Struktur S_TVDIMPDATA
   (in TCD_CIMP.h) ==> es wird jetzt ein Knotenelement angelegt 
   und die Bestandteiles dieses vor jedem neuen lesen "ausgeleert".
  27.08.96 KAT  Umstellung in TCD_TIMPORT wegen nicht korrekten 
  Zugriff auf AnzZeilen und AnzSpalten
-------------------------------------------------------------------*/

/* Makros                              */
                              /* Wegen Dos-Pfad im Tabellenabschnitt */
#define MAXFILENAMLEN          257
#define DOS_NAME_LNG           257

#define IMPORT_TRACE_FILE      "ITRACE.TCD"

#define TCD_ATTRKL_TAR  1
#define TCD_ATTRKL_BST  2

#define TCDCIMP_TABSTOP  999
#define NEXT_TOKEN_rc(str)    req->Private.ScanLen = MAX_TOKEN_SIZE; \
                              rc = Scan(pImpBuffer,token, \
                                        str,&(req->Private.ScanLen));

#define NEUER_BLOCK    1
#define DATEN          2
#define LISTEN         3
#define LISTEN_ELT     4
#define ERBLISTE       5
#define DELTA          100


#ifdef DEBUG
static int nop ( int line )
{
   if(line) ;
   return 0 ;
}

#define NEXT_TOKEN  req->Private.ScanLen = MAX_TOKEN_SIZE; \
                    if (Scan(pImpBuffer,token,"#", \
                        &(req->Private.ScanLen))==EOF) \
                    { nop(__LINE__); return EOF; }
#else

#define NEXT_TOKEN  req->Private.ScanLen = MAX_TOKEN_SIZE; \
                    if (Scan(pImpBuffer,token,"#", \
                        &(req->Private.ScanLen))==EOF) \
                    { return EOF; }
#endif

#undef DUMP
#ifdef DUMP
#define IMPORT_TRACE_FILE      "ITRACE.TCD" /* Name des Trace-Files */
#endif

/* Includes                            */
/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDPORTAB_H)
#define TCDPORTAB_H

/*-----------------
Name        : TCDPORTAB.H

Beschreibung: externes Include File, das generierumgeungsspezifische
Informationen enthaelt (Makrovorlage).
By          : BEGGI
Datum       : 20.04.94
Historie:     BEG   17.01.95  neues Makro _TCDMEMINI anstatt memset
BEG   02.03.95  bedingte Macros TCDHUGE
BEG   22.06.95  _TCDMEMINI nur im HUGE-Modell redefiniert.
BEG   20.02.96  malloc.h wird nicht mehr inkludiert (FM 451)
RWE   21.06.96  malloc.h wird wieder includiert (aber nur
              fuers HUGE-Modell, d.h. fuer DOS/WIN-Compiler)
RWE   26.06.96  WATCHMEM-Makros eingebaut (fuer TCDALLOC etc)
MUB   17.7.96   Include mit !defined versehen
KFC   02.09.96  #define TCDHUGE vorgezogen

-------------------*/

/* #define TCDHUGE */              /* bei gro�en Tabellen einschalten*/
/* Systemincludes */                  
#include <stdlib.h>                /* atoi, ...       */
#include <stdio.h>                 /* fprintf, ...    */
#include <string.h>                /* strcpy, ...     */
#include <time.h>                  /* time_t, ...     */
#include <math.h>                  /* exp, min, max, ... */

#ifdef TCDHUGE
#include <malloc.h>
#endif

/* Defines */
#define  TCDC_EXT_NAME_LNG    8  /* maximale L�nge von externen 
                                    Bezeichnern*/
/*-----------------
  Definitionen aus standard C-Includes z.B. stdio.h
-------------------*/
#ifndef NULL
#define    NULL    (void *)0
#endif

/*-----------------
  Definitionen von Basistypen
-------------------*/
typedef    short   TCD_BOOL ;
typedef    long    TCD_LONG ;
typedef    int     TCD_INT  ;
typedef    double  TCD_DOUBLE ;


/*-----------------
  modellabhaengige Definitionen von Basistypen
-------------------*/
typedef    TCD_DOUBLE  TCDTAB ;
#ifdef TCDHUGE
typedef    TCDTAB       huge * P_TCDTAB ;
typedef    TCD_DOUBLE   huge * P_TCD_DOUBLE ;
typedef    P_TCD_DOUBLE * P_P_TCD_DOUBLE ;
typedef    char huge    * TCD_LPCHAR ;
#else
typedef    TCDTAB       * P_TCDTAB ;
typedef    TCD_DOUBLE   * P_TCD_DOUBLE ;
typedef    P_TCD_DOUBLE * P_P_TCD_DOUBLE ;
typedef    char         * TCD_LPCHAR ;
#endif

/*-----------------
  weitere (Typ-)Defines 
-------------------*/  
typedef int ERRNO_TYPE;
#define TCD_FILENAME_LNG 128

/*-----------------
  Definitionen von Makros f�r Speicherallokation
-------------------*/  

/* WATCHMEM muss im TCDHUGE-Modus abgeschaltet sein */
#ifdef TCDHUGE
#undef WATCHMEM
#endif

#undef _TCDALLOC
#undef _TCDFREE
#undef _TCDREALLOC

#ifndef WATCHMEM

#define _TCDALLOC(len,size)    malloc( (size_t)(len) * (size)) ;
#define _TCDFREE(ptr)          {free(ptr), ptr = NULL;}
#define _TCDREALLOC(ptr,size)  realloc( ptr, (size_t)(size) ) ;

#else
 
void *MallocAndProt(char *sFile_,int iLine_, size_t size);
#define _TCDALLOC(len,size)\
 MallocAndProt(__FILE__,__LINE__,(len) * (size))

void FreeAndProt(char *sFile_, int iLine_, void *p_);

#define _TCDFREE(ptr)\
       {FreeAndProt(__FILE__, __LINE__, ptr) , ptr = NULL;}

void *ReallocAndProt(char *sFile_,int iLine_, void *p_, size_t size);
#define _TCDREALLOC(ptr,size)\
 ReallocAndProt(__FILE__, __LINE__, ptr,size)

void ResumeWatchmem();

#endif

/*-----------------
  modellabh�ngige Definitionen von Makros f�r Speicherallokation
-------------------*/
#undef _TCDTABALLOC
#undef _TCDTABFREE
#undef _TCDMEMINI

#ifdef TCDHUGE

#define _TCDTABALLOC(len,size)\
  _halloc( (long)(len) , (size_t)(size)) ;
#define _TCDTABFREE(ptr)\
      { _hfree ( (void huge *)ptr); ptr = NULL;}

#else

#ifndef WATCHMEM
#define _TCDTABALLOC(len,size)\
 malloc((size_t)((long)len) * ((size_t)size)) ;
#define _TCDTABFREE(ptr)       {free(ptr), ptr = NULL;}
#else
#define _TCDTABALLOC(len,size)\
 MallocAndProt(__FILE__,__LINE__,(len) * (size))
#define _TCDTABFREE(ptr)\
       FreeAndProt(__FILE__, __LINE__, ptr)
#endif

#endif


#ifdef TCDHUGE
#define _TCDMEMINI(ptr,size,nr)\
{\
   long       j;\
   TCD_LPCHAR lp;\
   for (j= 0 , lp = (TCD_LPCHAR)ptr;\
        j < ((long)(size) * (long)(nr)); j++, lp++) \
      *lp = 0;\
}  

#else
#define _TCDMEMINI(ptr,size,nr)\
 { memset (ptr, 0, (size_t) ((size) * (nr))) ; }
#endif
/*---------------------------------
  NON-Ansi-Namen mit oder ohne "_"
----------------------------------*/

/* #define NON_ANSI_WITHOUT__ */

#ifdef NON_ANSI_WITHOUT__
#define _fcvt fcvt
#endif

/*---------------------------
  ggf. Verkuerzung der Namen
-----------------------------*/
#ifdef TCD_NAMLEN8

#define TCDIMPReleaseProcData       TCD_0001
#define TCDIMPReleaseNodeData       TCD_0002
#define TCDIMPReleaseTabImpData     TCD_0003   

#define FetchFromGlobalErgebnisPool TCD_0004

#define DelEltFromSVect             TCD_0005
#define DelEltFromSVectByIndex      TCD_0006

#define DelEltFromVect              TCD_0007
#define DelEltFromVectByIndex       TCD_0008
                                
                                
#define ReleaseGlobalErgebnisPool   TCD_0009
#define ReleaseGlobalErgebnis       TCD_0010
#define ReleaseLocalErgebnisPool    TCD_0011

#define GetPrcDataSkal              TCD_0012
#define GetPrcDataTab               TCD_0013
#define GetPrcDataDat               TCD_0014
#define GetPrcDataFrm               TCD_0015

#define GetPrcAttrSkal              TCD_0016
#define GetPrcAttrTab               TCD_0017

#define GetSSAttrSkal               TCD_0018
#define GetSSAttrTab                TCD_0019

#define ErgPoolGetFirstInfo         TCD_0020
#define ErgPoolGetNextInfo          TCD_0021

#define DConstrAttrs                TCD_0022
#define DConstrAttrsResults         TCD_0023

#define GetRelAttrs                 TCD_0024

#define GetIndexToGlobalErgPool     TCD_0025
#define GetIndexToPaarListElt       TCD_0026

#define GetIndexToSS                TCD_0027
#define GetIndexToUes               TCD_0028
#define GetFromSS                   TCD_0029
#define GetFromUes                  TCD_0030

#define TCDIMPImportTreeData        TCD_0031
#define TCDIMPNFIntl                TCD_0032
#define TCDIMPGetNodeFromID         TCD_0033
#define TCDIMPGetNodeFromPath       TCD_0034
#define compBsearch                 TCD_0035
#define TCDIMPReleaseTreeData       TCD_0036 
#define TCDIMPReleaseTabData        TCD_0037  
#define DConstrTCD_C_G              TCD_0038
#define DDestrTCD_C_G               TCD_0039 
#define SConstrTCD_C_G              TCD_0040
#define DConstrTCDRbsSS             TCD_0041
#define SConstrTCDRbsSS             TCD_0042
#define SConstrTCDISSADATA          TCD_0043
#define SDestrTCD_C_G               TCD_0044
#define DDestrTCDRbsSS              TCD_0045
#define SDestrTCDRbsSS              TCD_0046
#define SDestrTCDISSADATA           TCD_0047
#define GetRbsSSFkt                 TCD_0048
#define TCDIMPGetTabIDAndTypFromPath TCD_0049
#define TCDIMPGetPathAndTypFromID    TCD_0050
#define TCDIMPReleaseTabTreeData     TCD_0051
#define TCDIMPImportTabTreeData      TCD_0052
#endif

#endif
             /* TCD Typen                */
/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDC_H)
#define TCDC_H

#ifdef TCDV2_5
#define TCDVERS 25
#endif
#ifdef TCDV3_0
#define TCDVERS 30
#endif
#ifndef TCDVERS
#error TCD Version muss in Makefiles angegeben werden.
#endif

/*---------
Name        : TCDC.H

Beschreibung: Zentrales Include File fuer die Anwendung
TCD weit gueltig
*----------*/

#include "p09115.h" /* direkte Vektoren */

#define  TCD_TRUE                1
#define  TCD_FALSE               0

/*---------
  Definitionen Opcodes
*----------*/
#define  TCD_OPC_INIT_RBS                    1
#define  TCD_OPC_CALC_FRM                    2
#define  TCD_OPC_CALC_PRC                    3
#define  TCD_OPC_GETNUM_FRM                  4
#define  TCD_OPC_GET_ATTR_VAL                5
#define  TCD_OPC_RESET_RBS                   6
#define  TCD_OPC_SET_PRC                     7
#define  TCD_OPC_RESET_PRC                   8
#define  TCD_OPC_SET_POOLTAB                 9
#define  TCD_OPC_RESET_POOLTAB              10
#define  TCD_OPC_SET_ATTR_VAL               11
#define  TCD_OPC_GET_PRC_INFO               12
#define  TCD_OPC_SET_POOLTAB_I              13
#define  TCD_OPC_RESET_POOLTAB_I            14
#define  TCD_OPC_SET_ATTR_IN_PRC            15
#define  TCD_OPC_SET_TRACE_ON               16
#define  TCD_OPC_SET_TRACE_OFF              17
#define  TCD_OPC_REMOVE_RESULTS             18
#define  TCD_OPC_GET_FIRST_RESULTS_INFO     19
#define  TCD_OPC_GET_NEXT_RESULTS_INFO      20

/*---------
  Definitionen Returncodes
*----------*/
#define  TCD_RC_NOT_OK              0
#define  TCD_RC_OK                  1
#define  TCD_RC_ILLOPC              2
#define  TCD_RC_VERSION_CONFLICT    3
#define  TCD_RC_UNKNOWN_FORM        4
#define  TCD_RC_ILLEGAL_FORM        5
#define  TCD_RC_ILLEGAL_PARAM       6
#define  TCD_RC_UNKNOWN_ATTR        7
#define  TCD_RC_NOT_FOUND           8
#define  TCD_RC_INPUT_MISSING       9
#define  TCD_RC_ILLEGAL_DIVISION   10
#define  TCD_RC_ILLEGAL_TAB_RANGE  11
#define  TCD_RC_STACK_OVERFLOW     12
#define  TCD_RC_CONDITION_FAIL     15
#define  TCD_RC_PAR_ERROR          20
#define  TCD_RC_TAB_IN_POOL        21
#define  TCD_RC_TAB_NOT_IN_POOL    22
#define  TCD_RC_PRC_IN_POOL        23
#define  TCD_RC_PRC_NOT_IN_POOL    24
#define  TCD_RC_UNKNOWN_PROC       25
#define  TCD_RC_PAARLISTEN_ERROR   26
#define  TCD_RC_NO_VALUE_AVAIL     30
#define  TCD_RC_USER_SET_ERROR    900
#define  TCD_RC_INTERNAL_ERR      999
#define  TCD_RC_NO_RETURN         888

/*---------
  allgemeine globale Konstanten
*----------*/
#define TCD_INIT_VARSETLEVEL    9999

/*---------
  Konfigurationsangaben
*----------*/
#define TCD_POOLADMIN_SIZE        20
#define TCD_C_MIN_USER_TYPE_ID    0
#define TCD_C_TABLISTLEN          10
#define TCD_C_MAXPRCCALLNR        2147483647

/*---------
  Definitionen Laengenangaben
*----------*/
#define TCD_DATUM_LNG              9
#define TCD_FRM_DATUM_LNG         20
#define TCD_VGLOP_LNG              3
#define TCD_NAME_LNG              26

/*---------
  Definitionen Aufrufart: (Aufzaehlungstyp)
-----------*/
#define TCD_CALLTYP_ATTR        1
#define TCD_CALLTYP_STA         2
#define TCD_CALLTYP_DYN         3
#define TCD_CALLTYP_STA_UE      4

/*---------
  Definitionen Prefix
-----------*/
#define TCD_PREFIX_TAB            '&'
#define TCD_PREFIX_PRC            '$'
#define TCD_PREFIX_FRM            'F'
#define TCD_PREFIX_ATTR           'A'

/*---------
  Definitionen Formeltypen (Aufzaehlungstyp, Wertevergabe analog Cobol)
-----------*/
#define TCD_FRMTYP_SKAL        1
#define TCD_FRMTYP_TAB1        2
#define TCD_FRMTYP_TAB2        3

/*---------
  Definitionen Belegungswerte PoolEntry
-----------*/
#define  TCD_POOLENT_INIT          0
#define  TCD_POOLENT_USED          1
#define  TCD_POOLENT_I_USED        2
#define  TCD_POOLENT_E_USED        3

/*---------
  Definitionen Assigntype
*----------*/
#define  TCD_DC_USE_NOT            0
#define  TCD_DC_USE_FRM            1
#define  TCD_DC_USE_PRC            2
#define  TCD_DC_USE_TAB            3
#define  TCD_DC_USE_VAL            4

/*----------
  Definitionen Formattypen
-----------*/
#define  TCD_ATTRFMT_SKAL          1
#define  TCD_ATTRFMT_TAB1          2
#define  TCD_ATTRFMT_TAB2          3
#define  TCD_ATTRFMT_VGLO          4
#define  TCD_ATTRFMT_DATE          5

/*----------
  Struktur Bestandsattributtabelle
 ----------*/
  typedef struct tagS_TCDATAB {
        char          Name [TCD_NAME_LNG] ;
        TCD_LONG      ID         ;
        TCD_INT       Index      ;
        TCD_INT       AttrTyp    ;
  } S_TCDATAB     ;

 typedef S_TCDATAB     * P_TCDATAB     ;

/*----------
  Struktur Tabelle aller Attribute
 ----------*/
  typedef struct tagS_ATTRTAB
  {
    TCD_LONG  ID    ;
    TCD_INT   Index ;
  } S_ATTRTAB ;

  typedef S_ATTRTAB    * P_ATTRTAB     ;

/*----------
  Typdefinition systemunabhanegiger Typen
 ----------*/
   typedef  char  TCD_VGLOP [TCD_VGLOP_LNG] ;
   typedef  char  TCD_DATUM [TCD_DATUM_LNG] ;

   typedef TCD_DOUBLE TCDTAB1 ;
   typedef P_TCDTAB   P_TCDTAB1 ;

   typedef TCD_DOUBLE TCDTAB2 ;
   typedef P_TCDTAB   P_TCDTAB2 ;

   typedef P_P_TCD_DOUBLE P_P_TCDTAB ;

/*---------
  Union Attributbelegung
 ----------*/
  typedef  union tagU_TCDVALUE {
           TCD_DOUBLE        Skalar;
           P_TCDTAB1         pTab1 ;
           P_TCDTAB2         pTab2 ;
   } U_TCDVALUE ;

  typedef  union tagU_TCDGVALUE {
           TCD_DOUBLE        Skalar;
           P_TCDTAB          pTab  ;
           TCD_VGLOP         VglOp ;
           TCD_DATUM         Datum ;
   } U_TCDGVALUE ;

/* --
 MUB 2.7.96: neu eingefuehrt, weil wir die TabellenID brauchen
--  */
  typedef  union tagU_TCDWVALUE
  {
           TCD_DOUBLE        Skalar;

           TCD_LONG          TabID ;  /*  die relevanten Attribute */
           P_TCDTAB1         pTab  ;  /*  das Ergebnis */

           TCD_VGLOP         VglOp ;
           TCD_DATUM         Datum ;
   } U_TCDWVALUE ;

  typedef struct tagS_TCDPRCVAL {
          TCD_LONG   PrcID ;
          TCD_LONG   FormelNr ;
          TCD_INT    FormelIx ;
          char       FormelName [TCD_NAME_LNG] ;
          TCD_INT    PoolIx ;
#if TCDVERS > 25
/* Version der Formel zur Pruefung 
		  Formel-Generat gegen Transport-Format */
          TCD_INT    FormelVers;
#endif

 } S_TCDPRCVAL ;

  typedef union  tagU_TCDNDVALUE {
          struct   tagTabData {
             TCD_LONG  TabID ;
             TCD_INT   PoolIx ;
          } TabData  ;
          TCD_DOUBLE Skalar ;
          char       Datum [TCD_DATUM_LNG] ;
          char       VglOp [TCD_VGLOP_LNG];
 } U_TCDNDVALUE ;


  typedef struct tagS_TCDFORMEL {
           TCD_LONG  FormelNr ;
           TCD_INT  FormelIx ;
           char     FormelName [TCD_NAME_LNG] ;
           TCD_INT  IsStaRef ;                                 
#if TCDVERS > 25
/* Version der Formel zur Pruefung 
		   Formel-Generat gegen Transport-Format */
		   TCD_INT  FormelVers;
#endif
 } S_TCDFORMEL ;

  typedef union  tagU_TCDASSIGNVAL {

       S_TCDPRCVAL  Prc    ;
       U_TCDNDVALUE Val    ;
       S_TCDFORMEL  Formel  ;

 } U_TCDASSIGNVAL ;

#define TYP3_NOT_OVERWRITTEN 2

typedef struct tagS_TCDREL_ATTR
{                                 
   TCD_LONG    iBerechnungsNummer;
   /* ID des Attributs                            */
   TCD_LONG    AttrID                  ;  
   /* Typ der Belegung SKALAR, TAB, DATUM , VGLOP */
   TCD_INT     AttrType              :4;  
   /* Flag, ob ein geerbter Wert vorhanden ist    */
   TCD_INT     bGeerbterWertVorhanden:2;  
   /* Flag, ob ein geerbter Wert vorhanden ist    */
   TCD_INT     bNotOverwritten         ;
   /* GGf. Wert hierzu                            */
   U_TCDWVALUE Belegung                ;  

}  S_TCDRELATTR;

typedef S_TCDRELATTR * P_TCDRELATTR ;

/* --
   S_TCDRELATTR_IMP    Relevantes Attribut fuer den Import
--  */
typedef struct tagS_TCDREL_ATTR_IMP
{
   TCD_LONG AttrID;
   TCD_INT  AttrType               : 4;
   TCD_INT  iIndex;

}  S_TCDRELATTR_IMP;

typedef S_TCDRELATTR_IMP * P_TCDRELATTR_IMP ;

/* --
   S_PAARLISTEN_EL    Struktur fuer ein PaarlistenElement
--  */
typedef struct tagS_PAARLISTEN_EL
{
   /* Vektor der relevanten Attribute mit der aktuellen Belegung     */
   LP_VECT          pAttrs;        
   /* lfde. Nummer der aktuellen Berechnung                          */
   TCD_LONG         iBerechnungsNummer; 
   
   TCD_LONG         lTabZeilen;         
   TCD_LONG         lTabSpalten;
   
   /* Typ des Ergebnisses (kann 'NOT_OVERWRITTEN' sein)              */
   TCD_INT          iType;              
   /* Ergebnis hierzu                                                */
   U_TCDWVALUE      Ergebnis;           

}  S_PAARLISTEN_EL;

typedef S_PAARLISTEN_EL * P_PAARLISTEN_EL ;

/* --
   S_PAARLISTE     Struktur zu einem Belegknoten einer BV
   Sie enthaelt 1 sortierten Vektor, 1 Liste und eine maximale Laenge
   fuer die Anzahl Elemente der Paarliste (Belegung,Ergebnis)
--  */
typedef struct tagS_PAARLISTE
{
   TCD_INT iWiederVerwendungsTyp;   /* KnotenTyp 1/2/3     */
   TCD_INT iWiederVerwListenLaenge; /* ListenLaenge maximal */
   TCD_INT iAct ;                   /* letztes Element     */

   /* direkter Vektor von S_ATTR_EL's   */
   LP_VECT pAttrs;                  
   /* direkter Vektor von S_PAARLISTEN_EL's */
   LP_VECT pPaarListenElts;         

}  S_PAARLISTE;

typedef S_PAARLISTE * P_PAARLISTE ; 

/* --
   S_ERGEBNIS_POOL_ELT Element eines PoolErgebnisses
--  */
typedef struct tagS_ERGEBNIS_POOL_ELT
{
   TCD_LONG    ID;
   P_PAARLISTE pPaarListe;

}  S_ERGEBNIS_POOL_ELT;

typedef S_ERGEBNIS_POOL_ELT * P_ERGEBNIS_POOL_ELT ;

/*-----------
  Struktur     Belegungsknoten
------------*/
  typedef struct tagS_TCDPRCNODE
  {
      TCD_LONG         AttrID                  ;
      TCD_INT          NodeID                  ;
      TCD_INT          AttrType                ;
      TCD_INT          AssignType              ;
      U_TCDASSIGNVAL   AssignVal               ;
      TCD_INT          SuccNodeIx              ;
      TCD_INT          AnzSuccNodes            ;
      TCD_INT          Usage                   ;

      P_PAARLISTE      pPaarListe              ;
      P_PAARLISTEN_EL  pResultForGetAttr       ;

      TCD_INT          iWiederVerwendungsTyp   ;
      TCD_INT          iWiederVerwListenLaenge ;
      TCD_INT          iAnzRelAttrs            ;
      TCD_INT          iFirstRelAttrIx         ;

  }   S_TCDPRCNODE ;

 typedef S_TCDPRCNODE  * P_TCDPRCNODE ;

/*-----------
  Struktur Auspraegungs-Belegungs-Information
------------*/
  typedef struct tagS_TCDPRCINFO {
         char  Name [TCD_NAME_LNG] ;
         TCD_LONG  ID ;
         TCD_INT   Formattyp ;
         TCD_INT   Typ ;
         TCD_INT   Klasse ;
         TCD_INT   AnzBeleg ;
         TCD_INT   TabIx ;
         TCD_LONG  RefNodeId ;
 } S_TCDPRCINFO ;

 typedef S_TCDPRCINFO  * P_TCDPRCINFO ;

/*--------
  Struktur LocalData MUB 2.7.96: wird nicht mehr verwendet!
 --------*/
  typedef struct tagS_TCDPRCLOCD {
          TCD_LONG FormelNr     ;
          TCD_INT  Usage        ;
          TCD_INT  Typ          ;
          union   {
              TCD_INT    PoolIx ;
              TCD_DOUBLE Val    ;
          } Data ;
          TCD_LONG  CalcByCallNr ;
   } S_TCDPRCLOCD ;

   typedef S_TCDPRCLOCD * P_TCDPRCLOCD ;

/*---------
  Struktur Header Auspraegungsbaum
----------*/
  typedef struct tagS_TCDPRCHDR {
    TCD_LONG       PrcID        ;
    TCD_LONG       FormelNr     ;
    TCD_INT        AnzPrcTree   ;
    TCD_INT        AnzBelegInfo ;
    TCD_INT        AnzRelAttrs  ;
    TCD_BOOL       FlSetAttrSkal;
    TCD_BOOL       FlSetAttrTab ;
    TCD_BOOL       FlSetAttrVgl ;
    TCD_BOOL       FlSetAttrDat ;
    TCD_BOOL       FlPrcCompl   ;
    TCD_LONG       PrcResIx     ;
    TCD_LONG       PrcCallNr    ;

 } S_TCDPRCHDR     ;


/*---------
  Struktur Auspraegungselement
-----------*/
  typedef union  tagU_TCDPRCELEM
  {
     S_TCDPRCHDR      TreeHdr;
     S_TCDPRCNODE     Node ;
     S_TCDPRCINFO     Info ;     
  }  U_TCDPRCELEM ;

 typedef U_TCDPRCELEM  * P_TCDPRCELEM ;

#define TCDPRCSIZE(pPrc)    (pPrc ? sizeof(S_TCDRELATTR_IMP)*\
                            (TCD_LONG)pPrc->TreeHdr.AnzRelAttrs +\
                            sizeof(U_TCDPRCELEM)*\
                            ( (TCD_LONG)pPrc->TreeHdr.AnzPrcTree +\
                             (TCD_LONG)pPrc->TreeHdr.AnzBelegInfo) : 0)


/*-------
  Datenstruktur Mehrfach-Auspraegung (MultiProc)
 --------*/
  typedef struct tagS_TCDMPRCENTRY {
        TCD_INT              PrcBelegt ;
        TCD_LONG             ID ;
        P_TCDPRCELEM         pPrcData ;
 } S_TCDMPRCENTRY ;

  typedef S_TCDMPRCENTRY * P_TCDMPRCENTRY ;

  typedef struct tagS_TCDMPRCADMIN {
        TCD_INT          Anzahl  ;
        P_TCDMPRCENTRY   Data    ;
 } S_TCDMPRCADMIN ;

 typedef S_TCDMPRCADMIN * P_TCDMPRCADMIN ;

/*--------
  Datenstruktur PoolAdmin
--------*/
  typedef struct tagS_TCDPOOLENTRY {
        TCD_LONG     ID ;
        TCD_INT      Usage ;
        TCD_INT      Typ ;
        TCD_INT      Fmttyp ;
        P_TCD_DOUBLE pData ;
  } S_TCDPOOLENTRY ;

  typedef S_TCDPOOLENTRY * P_TCDPOOLENTRY ;

  typedef struct tagS_TCDPOOLADMIN {
        TCD_INT          Anzahl  ;
        TCD_INT          AnzTabs ;
        TCD_INT          AnzProcs ;
        TCD_INT          AnzTemp  ;
        S_TCDPOOLENTRY * Data    ;
 } S_TCDPOOLADMIN ;

  typedef S_TCDPOOLADMIN * P_TCDPOOLADMIN ;

/*------
  Datenstruktur Kontrollstruktur
--------*/
  typedef struct tagS_TCDRBSINFO {
       char TcdVersion [TCD_DATUM_LNG]   ;
       char TcdRelease [TCD_DATUM_LNG]   ;
       char RbsInterf  [TCD_DATUM_LNG]   ;
       TCD_LONG RbsId ;
   } S_TCDRBSINFO ;

   typedef struct tagS_TCDRCINFO {
       TCD_INT   Rc ;
       TCD_INT   Errc ;
       char FormelName [TCD_NAME_LNG] ;
       TCD_INT   FormelNr ;
       char AttrName   [TCD_NAME_LNG] ;
   } S_TCDRCINFO          ;

   typedef S_TCDRCINFO * P_TCDRCINFO ;


   typedef struct tagS_TCDCTLPAR {

/*-
  Opcode:   TCD_OPC_GET_ATTR_VAL, TCD_OPC_SET_ATTR_VAL
--*/
        struct tagS_TCDPARGA {
           TCD_LONG    ProcID;
           TCD_LONG    ID;
           TCD_LONG    TabID;
           TCD_INT     TabIx ;
           U_TCDGVALUE Val ;
           TCD_INT     Typ ;
           TCD_INT     ProcIx;
        }            GA ;

/*-
  Opcode:   TCD_OPC_SET_POOLTAB
--*/
        struct tagS_TCDPARST {
            TCD_LONG  ID;
            TCD_INT   Dim ;
            P_TCDTAB  pTab ;
            TCD_INT    TabIx ;
        }            ST ;

/*-
  Opcode:   TCD_OPC_RESET_POOLTAB
--*/
        struct tagS_TCDPARRT{
            TCD_LONG  ID;
            P_TCDTAB  pTab ;
        }            RT ;

/*-
  Opcode:   TCD_OPC_SET_PRC
--*/
        struct tagS_TCDPARSP {
            TCD_LONG      ProcID;
            P_TCDPRCELEM  pProc;
            TCD_INT       ProcIx;
        }            SP;

/*-
  Opcode:   TCD_OPC_RESET_PRC
--*/
        struct tagS_TCDPARRP {
            TCD_LONG  ProcID;
            P_TCDPRCELEM  pProc;
        }            RP;

/*-
  Opcode:   TCD_OPC_CALC_FRM , TCD_OPC_CALC_PRC
--*/
        struct tagS_TCDPARCFP {
            TCD_LONG       FormelNr ;
            TCD_LONG       ProcID;
            TCD_INT        Typ ;
            U_TCDVALUE     Value ;
            TCD_INT        ProcIx;
        }            CFP ;

/*-
  Opcode:   TCD_OPC_GETNUM_FRM
--*/
        struct tagS_TCDPARGF {
            char  Name [TCD_NAME_LNG] ;
            TCD_LONG  FormelNr ;
        }            GF ;

/*-
  Opcode:   TCD_OPC_GET_PRC_INFO
--*/
        struct tagS_TCDPRCBINFO {
            TCD_LONG        ProcID;
            TCD_INT         ProcIx;
            P_TCDPRCELEM    pProcInfo;
            TCD_INT         AnzProcInfo ;
        }            PI ;

/*-
  Opcode:   TCD_OPC_REMOVE_RESULTS,
            TCD_OPC_GET_FIRST_RESULTS_INFO,
            TCD_OPC_GET_NEXT_RESULTS_INFO
--*/
        struct tagS_TCDPAR_RESULTPOOL {
            TCD_LONG        ProcID;
            TCD_LONG        lNumOfResults;
            TCD_INT         bFinished;
        }            RESP ;

   } S_TCDCTLPAR ;

   typedef S_TCDCTLPAR * P_TCDCTLPAR ;

   typedef struct tagS_TCDRBSCTL {
          TCD_INT       Opc     ;
          S_TCDRBSINFO  RbsInfo ;
          S_TCDRCINFO   RCInfo  ;
          S_TCDCTLPAR   Par     ;
  } S_TCDRBSCTL ;

   typedef S_TCDRBSCTL * P_TCDRBSCTL ;

/*------
  Datenstruktur Rechenbausteinschnittstelle
 --------*/
   typedef struct tagS_TCDV_F_FLAGS {
         TCD_BOOL       V_In   ;
         TCD_BOOL       F_In   ;
         TCD_BOOL       V_Comp ;
         TCD_BOOL       V_Use  ;
         TCD_BOOL       F_Use  ;
         TCD_BOOL       V_Miss ;
         TCD_BOOL       F_Miss ;
   } S_TCDV_F_FLAGS ;

   typedef S_TCDV_F_FLAGS * P_TCDV_F_FLAGS ;

   typedef struct tagS_TCDV_FLAGS {
         TCD_BOOL       V_In   ;
         TCD_BOOL       V_Use  ;
         TCD_BOOL       V_Miss ;
   } S_TCDV_FLAGS ;

   typedef S_TCDV_FLAGS   * P_TCDV_FLAGS   ;

   typedef struct tagS_TCDSKAL_DATA
   {
        TCD_DOUBLE      Val    ;
        TCD_LONG        Formel ;
        S_TCDV_F_FLAGS  Flags  ;
   } S_TCDSKAL_DATA ;

   typedef S_TCDSKAL_DATA * P_TCDSKAL_DATA ;

   typedef struct tagS_TCDTAB1_DATA
   {
     TCD_LONG        TabID;
     P_TCDTAB1       pVal ;
     TCD_LONG        Formel ;
     S_TCDV_F_FLAGS  Flags ;

   } S_TCDTAB1_DATA ;
   typedef S_TCDTAB1_DATA  * P_TCDTAB1_DATA  ;

   typedef struct tagS_TCDTAB2_DATA
   {
     TCD_LONG        TabID;
     P_TCDTAB2       pVal ;
     TCD_LONG        Formel ;
     S_TCDV_F_FLAGS  Flags ;

   } S_TCDTAB2_DATA ;
   typedef S_TCDTAB2_DATA * P_TCDTAB2_DATA ;

   typedef struct tagS_TCDDAT_DATA {
        char             Val [TCD_DATUM_LNG] ;
        S_TCDV_FLAGS     Flags ;
   } S_TCDDAT_DATA ;

   typedef S_TCDDAT_DATA * P_TCDDAT_DATA ;

   typedef struct tagS_TCDVGL_DATA {
        char            Val [TCD_VGLOP_LNG] ;
        S_TCDV_FLAGS    Flags ;
   } S_TCDVGL_DATA ;

   typedef S_TCDVGL_DATA * P_TCDVGL_DATA ;

   typedef struct tagS_TCD_RBS_SSA
   {
        P_TCDSKAL_DATA    pSkal ;
        P_TCDTAB1_DATA    pTab1 ;
        P_TCDTAB2_DATA    pTab2 ;
        P_TCDDAT_DATA     pDat  ;
        P_TCDVGL_DATA     pVgl  ;
   } S_TCD_RBS_SSA ;

   typedef S_TCD_RBS_SSA  * P_TCD_RBS_SSA ;


   typedef struct tagS_TCDRBS_SS {
       S_TCDRBSCTL       RCTL ;
       S_TCD_RBS_SSA     SSAData   ;
       S_TCDPOOLADMIN    PoolAdmin ;
       S_TCDMPRCADMIN    MPrcAdmin ;
 } S_TCDRBS_SS ;

 typedef S_TCDRBS_SS  * P_TCDRBS_SS ;

  typedef struct tagS_TCDPARATTR_SK {
        TCD_INT      Level ;
        TCD_DOUBLE   Val ;
 } S_TCDPARATTR_SK   ;

 typedef S_TCDPARATTR_SK  * P_TCDPARATTR_SK ;

  typedef struct tagS_TCDPARATTR_VGL {
        TCD_INT      Level;
        char         Val  [TCD_VGLOP_LNG] ;
 } S_TCDPARATTR_VGL  ;

 typedef S_TCDPARATTR_VGL * P_TCDPARATTR_VGL ;

  typedef struct tagS_TCDPARATTR_DAT
  {
        TCD_INT      Level;
        char         Val  [TCD_DATUM_LNG] ;
 } S_TCDPARATTR_DAT  ;

 typedef S_TCDPARATTR_DAT * P_TCDPARATTR_DAT ;

/*-----------
  Struktur Schnittstellendaten (interne Sicht)
-----------*/
  typedef struct tagS_TCDISSADATA
  {
     TCD_INT      AnzSSASkal ;
     TCD_INT      AnzSSATab1 ;
     TCD_INT      AnzSSATab2 ;
     TCD_INT      AnzSSADat ;
     TCD_INT      AnzSSAVgl ;
     TCD_INT      AnzParSkal;
     TCD_INT      AnzParVgl ;
     TCD_INT      AnzParDat ;
     TCD_INT      AnzZeilen ;
     TCD_INT      AnzSpalten ;
     P_TCDSKAL_DATA    pSkal ;
     P_TCDTAB1_DATA    pTab1 ;
     P_TCDTAB2_DATA    pTab2 ;
     P_TCDDAT_DATA     pDat ;
     P_TCDVGL_DATA     pVgl ;
     P_TCDPARATTR_SK   pParSkal ;
     P_TCDPARATTR_VGL  pParVgl;
     P_TCDPARATTR_DAT  pParDat;

 }   S_TCDISSADATA ;
 typedef S_TCDISSADATA * P_TCDISSADATA ;



/*------
Datenstruktur globale Daten des Rechenbausteins;
diese Datenstruktur enthaelt Informationen und Teilstrukturen, die
in den programmierten Funktionen benoetigt werden.
Initialisierung dieser Daten erfolgt mehrstufig.
- beim Init: globaler Pointer pTCDTCD initialisiert (zeigt auf die Str)
pRbsSS zeigt auf die RBS-Schnittstelle
- bei auspraegungsspez. Opcodes werden die Teilstrukturen fuer die
Auspraegung initialisiert, ...
- bei einer neuen Berechnung werden die internen Aufrufschnittstellen
initialisiert
--------*/
  typedef struct tagS_TCD_C_G
  {
      P_TCDRBS_SS      pRbsSS      ;
      P_TCDPRCELEM     pPrcData    ;
      S_TCDPRCHDR *    pPrcHdr     ;
      P_TCDPRCELEM     pPrcTreeNode;
      P_TCDPRCELEM     pInfo       ;
      P_TCDRELATTR_IMP pRelAttrs   ;
      P_TCDMPRCADMIN   pMPrcAdmin  ;
      P_TCDRBSCTL      pRbsCtl     ;
      S_TCDISSADATA    SSAData     ;
      P_TCDPOOLADMIN   pPoolAdmin  ;
      TCD_INT          GlbVarSet   ;
      TCD_LONG         RBS_ID      ;
      TCD_BOOL         ValFound    ;
      TCD_BOOL         FrmFound    ;
      TCD_BOOL         V_Comp      ;
      TCD_BOOL         PrcChg      ;
      void *           pApplIf     ;
      P_TCDTAB         ResTab      ;
      TCD_DOUBLE       ResSkal     ;
      
      TCD_LONG         LastCalcPrcID;
      LP_VECT          pErgebnisPool;
      TCD_LONG         iBerechnungsNummer;
      TCD_INT          iErgPoolIteratorGl;                       
      P_PAARLISTE      pPaarListeNotToSave;
      
      TCD_BOOL         btrace_open;
      TCD_BOOL         btrace_enabled;
      
/* RWE, 10.06.1997: Neues Datenelement fuer Beobachtung
   der Wiederverwendung (ehemals WatchPol-Funktionalitaet) */
      TCD_BOOL         bProtWV;
      
  }   S_TCD_C_G ;
  typedef S_TCD_C_G   * P_TCD_C_G ;
#endif
                  /* RBS Schnittstelle        */
/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDI_H)
#define TCDI_H
/*--------------
    Name        : TCDI.H

    Beschreibung: Include File intern nur f�r C- Generator
                  wird von den fest programmierten Moduln und
                  generierten Moduln benoetigt
    By          : BEGGI
    Datum       : 22.02.94
    Historie    : BEG   28.11.95   Definition Attributklassen
*--------------*/

/*-------------
  Returncodes FrmRet und ValRet (Definitionen analog Cobol) fuer
  Attributmanager
---------------*/
#define TCD_AIRC_CALLVIAFRM    4

/*-------------
  Definitionen Attributtypen (Aufzaehlungstyp)
---------------*/
#define TCD_ATTYP_TAR_SKAL      1
#define TCD_ATTYP_TAR_TAB1      2
#define TCD_ATTYP_TAR_TAB2      3
#define TCD_ATTYP_TAR_DATE      4
#define TCD_ATTYP_TAR_VGLO      5
#define TCD_ATTYP_BST_SKAL      6
#define TCD_ATTYP_BST_TAB1      7
#define TCD_ATTYP_BST_TAB2      8
#define TCD_ATTYP_BST_DATE      9
#define TCD_ATTYP_BST_VGLO     10

#define TCD_ATTRTYP_SKAL        0
#define TCD_ATTRTYP_TAB1        1
#define TCD_ATTRTYP_TAB2        2
#define TCD_ATTRTYP_DATE        3
#define TCD_ATTRTYP_VGLO        4

/*--------------
  Definitionen Attributklasse
---------------*/
#define TCD_ATTRCLASS_TAR       1
#define TCD_ATTRCLASS_BST       6

/*-------------
  Definitionen Errorcodes
---------------*/
#define TCD_UNKNOWN_OPCODE       1
#define TCD_NO_SPACE_IN_TLIST    2
#define TCD_ERR_GETMEM           3
#define TCD_GETEMPTYENTRY        4
#define TCD_NOPOOLADMIN          5
#define TCD_ILLTABFMT            6
#define TCD_UNK_ASSIGNTYP        7
#define TCD_NO_MPRCADMIN         8
#define TCD_EXPPOOLADMIN         9
#define TCD_NO_MEMORY           10
#define TCD_NO_PRCREF           11
#define TCD_ILLFRM_ID           12
#define TCD_ILLFRM_CMP          13
#define TCD_ERR_INIT_FORMEL     14
#define TCD_FRMGEN_OUT_OF_DATE	15
#define TCD_TRPFMT_OUT_OF_DATE	16

/*----------
  Datenstruktur Freigabeliste  Hilfsvariablentabellen
 ------------*/
  typedef struct tagS_TCDTABLIST    {
         TCD_INT        CallOvw ;
         TCD_LONG       CallerID ;
         TCD_LONG       CallFrmNr ;
         TCD_INT        CallType  ;
         P_TCD_DOUBLE   Adr ;
 } S_TCDTABLIST   ;

 typedef  S_TCDTABLIST  * P_TCDTABLIST  ;

/*----------
  Datenstruktur Formelparameter
 ------------*/
  typedef struct tagS_TCD_C_F1 
  {
     char         * FormelName     ;
     TCD_INT        FrmTyp         ;
     TCD_LONG       FrmNr          ;
     TCD_INT        FrmIx          ;
     char         * AttrName       ;
     TCD_INT        CallType       ;
     TCD_LONG       AttrID         ;
     TCD_INT        AttrTyp        ;
     TCD_INT        AttrIx         ;
     TCD_INT        ParIx          ;
     TCD_INT        Ret            ;
     TCD_INT        ExecCond       ;
     P_TCDPRCNODE   PrcFNode       ;
     P_TCDPRCNODE   pNode          ;
     TCD_INT        MinVarSet      ;
     TCD_INT        BegVarSet      ;
     char         * CmpTime        ;
     TCD_INT        Level          ;
     P_TCD_DOUBLE   pVarSkal       ;
     P_P_TCDTAB     pVarTab        ;
     char         * VarDatVgl      ;
     TCD_INT      * VarIndex       ;
     P_TCDTABLIST   FreeList       ;
     TCD_INT        AnzTabList     ;
     TCD_INT        AnzTabListEnt  ;
     P_TCDPRCNODE   NextFNode      ;
     TCD_INT        NextExecCond   ;
     TCD_INT        NextCallType   ;
     struct tagS_TCD_C_F1 * pPrevLevelInfo ;
     P_TCD_C_G      pTCDTCD ;
  } S_TCD_C_F1 ;

  typedef  S_TCD_C_F1 *   P_TCD_C_F1 ;

  typedef struct tagS_TCDFTAB {
        char          FrmName [TCD_NAME_LNG] ;
        void          (* pFormelFunc ) ( P_TCD_C_F1);
        TCD_LONG      FrmNr      ;
        TCD_INT       FrmTyp     ;
        char          Datum [TCD_FRM_DATUM_LNG] ;
  } S_TCDFTAB     ;

 typedef S_TCDFTAB     * P_TCDFTAB     ;

/* extern P_TCD_C_G pTCDTCD ; */

#endif

                
/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/

#if !defined (TCD_CIMP_H)
#define TCD_CIMP_H
/*---------------------------------------------------------------------
    Name        : TCD_CIMP.H

    Beschreibung: Include File mit Strukturdefinitionen f�r die Import-
                  schnittstelle
    By          : BEGGI
    Datum       : 19.05.94

    Historie:   07.10.95 RON
                Name (f�r Proc) in Struktur S_TCDIMPCTL eingef�gt

                22.12.95 RON
                pRefProc in Contorl-Struktur eingef�hrt.

                28.08.96 KAT
                Union U_TCDIMPDATA durch Struktur S_TCDIMPDATA ersetzt
*--------------------------------------------------------------------*/


/*---------------------------------------------------------------------
  Defines Returncodes
---------------------------------------------------------------------*/
    #define RC_OK                  0
    #define RC_VAL_TRUNCATED       1
    #define RC_ROW_TRUNCATED       2
    #define RC_COL_TRUNCATED       3
    #define RC_PTH_TRUNCATED       4
    #define RC_ATTR_TRUNCATED      5
    #define RC_DESC_TRUNCATED      6
    #define RC_TAB_PTR_0           7
    #define RC_FILE_ERROR          8
    #define RC_ILLEGAL_IMPORT      9
    #define RC_EOT                10
    #define RC_INV_IMPTYP         11
    #define RC_INV_OPC            12
    #define RC_NO_ID              13
    #define RC_NOMEM              14
    #define RC_VERS_CONF          15

    #define RC_SYS_ERROR          -1

/*---------------------------------------------------------------------
  Defines Importtyp
---------------------------------------------------------------------*/
    #define TCD_IMPTYP_TAB1        1
    #define TCD_IMPTYP_TAB2        2
    #define TCD_IMPTYP_PROC        3
    #define TCD_IMPTYP_NODE        4

/*---------------------------------------------------------------------
  Defines Usage
---------------------------------------------------------------------*/
    #define TCD_USAGE_ONCE         1
    #define TCD_USAGE_MULTIPLE     2

/*---------------------------------------------------------------------
  Defines Optionen
---------------------------------------------------------------------*/
    #define TCD_ALLES              1    /* alle Proc-Info uebergeben */
    #define TCD_OHNE_BELEGLISTE    2
    #define TCD_NUR_TABBELEGLISTE  3
    #define TCD_BELEGLISTE_AM_ENDE 4
    #define TCD_COPY_TRPFILE       5

    #define TCD_IMP_TRPFILE        6

/*---------------------------------------------------------------------
  Defines L�ngenangabe
---------------------------------------------------------------------*/
    #define TCD_DESC_LEN          80

/*---------------------------------------------------------------------
  Defines Buffertypes
---------------------------------------------------------------------*/
    #define TCD_FILE               1
    #define TCD_MEM                2

/*---------------------------------------------------------------------
  Defines Statusangaben
---------------------------------------------------------------------*/
   #define TCD_IMPSTAT_INIT        1
   #define TCD_IMPSTAT_NODE        2
   #define TCD_IMPSTAT_PROC        3
   #define TCD_IMPSTAT_EOF        (-1)

/*---------------------------------------------------------------------
  Datenstruktur Importfunktionen
---------------------------------------------------------------------*/
#ifndef DOS_NAME_LNG
   #define DOS_NAME_LNG           257
#endif
   #define MAX_TOKEN_SIZE         1024

typedef struct tagS_TCDATTRDATA 
{            /* Struktur: Knotenattribute */
        char       Name     [TCD_NAME_LNG];
        char       Value    [TCD_NAME_LNG];
        char       DefValue [TCD_NAME_LNG];
} S_TCDATTRDATA ;

typedef  struct tagS_TCDDESCDATA {           /* Descriptorbereich */
         char    Value [TCD_DESC_LEN] ;
} S_TCDDESCDATA ;

typedef  struct tagS_TCDPATHDATA {           /* Pfadknoten */
             char      Path  [TCD_NAME_LNG] ;
} S_TCDPATHDATA ;


typedef struct tagS_TCDNODEDATA 
{                                         
/* Datenbereich: Knotenimport  */
    char          NodeName [TCD_NAME_LNG];
    /* KnotenName                  */
    TCD_LONG      NodeId     ;            
    /* KnotenID                    */
    char          NodeTyp [TCD_NAME_LNG]; 
    /* Knotentyp                   */
    TCD_LONG      NodeTypId  ;            
    /* ID des Knotentyps           */
    TCD_INT       AnzPathEnt ;            
    /* Anzahl Pfadknoten           */
    S_TCDPATHDATA *PathData ;             
    /* Zeiger auf Pfadnamen        */
    TCD_INT       AnzAttrInfo;            
    /* Anzahl Knotenattribute      */
    S_TCDATTRDATA *AttrData ;             
    /* Zeiger auf Knotenattribute  */
    char          *Desc ;                 
    /* Zeiger auf Kommentar        */

} S_TCDNODEDATA ;

typedef S_TCDNODEDATA   * P_TCDNODEDATA ;

typedef struct tagS_TCDTABATTRDATA 
{         /* Struktur: Knotenattribute */
        char       Name     [TCD_NAME_LNG];
        char       Value    [TCD_NAME_LNG];
} S_TCDTABATTRDATA ;


typedef struct tagS_TCDTABINFO 
{            /* Datenbereich: Tabellenimport */
TCD_LONG      NodeId     ;           /* KnotenID                    */
TCD_INT       AnzPathEnt ;           /* Anzahl Pfadknoten           */
S_TCDPATHDATA *PathData ;            /* Zeiger auf Pfadnamen        */
TCD_INT       AnzZeilen ;
TCD_INT       AnzSpalten ;
TCD_INT       AnzStellen ;
TCD_INT       AnzNkStellen ;
TCD_INT       AnzAttrInfo;           /* Anzahl Knotenattribute      */
S_TCDTABATTRDATA *AttrData ;         /* Zeiger auf Knotenattribute  */
char          *Desc ;                /* Zeiger auf Kommentar        */
} S_TCDTABINFO ;

typedef S_TCDTABINFO    *P_TCDTABINFO ;

typedef struct tagS_TCDTABIMPDATA 
{           /* Datenbereich: Tabellenimpor*/
        P_TCDTABINFO   pTabInfo ;
        P_TCDTAB       TabValues ;
} S_TCDTABIMPDATA ;

typedef S_TCDTABIMPDATA * P_TCDTABIMPDATA ;


typedef struct tagS_TCDTREEDATA
{
  TCD_LONG ID;           /*BV-ID*/
  char *sName;      /*BV-Pfad-Name*/
} S_TCDTREEDATA;


typedef struct tagS_TCDTABTREEDATA
{
  TCD_LONG ID;      /*BV-ID        */
  char *sName;      /*Tab-Pfad-Name*/
  int  iCol;        /*Zeilenanzahl */
  int  iRow;        /*Spaltenanzahl*/
  int  iVk;         /*Vorkommastellen*/
  int  iNk;         /*nachkommastellen*/
} S_TCDTABTREEDATA;





typedef struct tagS_TCDIMPDATA 
{             /* Datenbereich import. Daten */
P_TCDNODEDATA    pNodeData;           /* Tarifknotendaten           */
P_TCDPRCELEM     pProcData;           /* Auspr�gungsdaten           */
P_TCDTABIMPDATA  pTabData;            /* Tabellen + Tabknotendaten  */
S_TCDTREEDATA  **   pTreeData;      /* Null-terminierter Vektor von */
                                /* Zeigern auf S_TCDTREEDATAOBJEKTEN*/
S_TCDTABTREEDATA ** pTabTreeData; /* Null-terminierter Vektor von   */
                             /* Zeigern auf S_TCDTABTREEDATAOBJEKTEN*/
} S_TCDIMPDATA ;               


typedef struct tagS_TCDIMPCTL 
{              /* Kontrollstruktur           */
TCD_INT Typ       ;                  /* Import-Typ                 */
                                     /* Wertebereich: Defines Impor*/
TCD_INT  Rc       ;                  /* Returncode                 */
ERRNO_TYPE Errno;                    /* R. wert der I/O-Operationen*/
char     ErrFileName[TCD_FILENAME_LNG];/* Name der Datei, auf der die 
                                        letzte I/O-Operation versucht
                                        wurde */
TCD_INT  AnzZeilen ;                 /* Tabgr��e RBS: Anz. Zeilen  */
TCD_INT  AnzSpalten;                 /* Tabgr��e RBS: Anz. Spalten */
TCD_INT  AnzTabData ;                /* Anzahl der Tabelleneintr�ge*/
                                     /* nur bei Tabs               */
TCD_LONG ID ;                        /* die ID des import. Objects */
                                     /* nur bei Tabs und Procs     */
char       Name     [TCD_NAME_LNG];  /* Name der Prozedur          */
                                     /* RON */
TCD_INT  Dim ;                       /* Dim. 1 /2 , nur bei Tab    */
TCD_INT  Status ;
char *   pRefProc;                   /* 22.12.95, RON,             */
TCD_INT  Option ;                    /* Optionen zum Aufruf        */
FILE    *fpTrpFile;                  /* Ziel-Transport-Datei       */
int  (* ChckFkt)();                  /* Fkt zum Pr�fen erw�nschter */
                                             /* Objekte            */
} S_TCDIMPCTL;

typedef union tagU_TCDIMPBUF
{
    FILE * File;
    char * Mem; 
}   U_TCDIMPBUF;

typedef struct tagS_TCDIMPORT
{
    TCD_INT Type;
    U_TCDIMPBUF Buffer; 
    char   FileName[DOS_NAME_LNG];
    struct tagS_TCDIMPORTSS *pImportSS;
}   S_TCDIMPORT;
typedef S_TCDIMPORT *   P_TCDIMPORT;


typedef struct tagS_PRIVATE
{
	S_TCDIMPORT      ImpBuffer;
	char * 			 TCDImpTreeFNam;
	char             token[MAX_TOKEN_SIZE] ;
	TCD_BOOL         PrcBelegCmpl ;
    int  			 ScanLen ;
    char 			 PathBuf[256];
    P_TCDPRCELEM     pInfo;
    P_TCDRELATTR_IMP pRelAttrs;
	 void *           pSavePtr ; 
} S_PRIVATE;

typedef S_PRIVATE * P_PRIVATE;

typedef struct tagS_TCDIMPORTSS 
{		     				         /* Struktur der Importschnitt-*/
                                     /* stelle                     */
	S_TCDIMPCTL      ICTL ;          /* Kontrollstruktur Importfkt */
	S_TCDIMPDATA     Data ;          /* Datenbereich               */
	S_PRIVATE        Private;        /* private structure          */
} S_TCDIMPORTSS ;

typedef S_TCDIMPORTSS * P_TCDIMPORTSS ;

/*---------------------------------------------------------------------
  Funktions Prototypen
---------------------------------------------------------------------*/
void TCDIMPF  ( P_TCDIMPORTSS req, FILE * ImpStream,\
                char * ImpStreamName );
void TCDIMPB  ( P_TCDIMPORTSS req, char * ImpBuffer );
void TCDIMPNF ( P_TCDIMPORTSS req, char * TreeFNam  );
void TCDCPYNF ( P_TCDIMPORTSS req, char * TreeFNam  );
void TCDIMPR  ( P_TCDIMPORTSS req                   );
void TCDIMPTF ( P_TCDIMPORTSS req, char * TreeFNam  );
void TCDIMPImportTreeData(P_TCDIMPORTSS req, char * TreeFNam);
S_TCDTREEDATA* TCDIMPGetNodeFromID(S_TCDTREEDATA** pTreeData, 
                                    TCD_LONG ID);
S_TCDTREEDATA* TCDIMPGetNodeFromPath(S_TCDTREEDATA **pTree,
                                     char *sPath);
void TCDIMPReleaseTreeData(S_TCDTREEDATA ***pTreeData);
S_TCDTABTREEDATA*
TCDIMPGetTabIDAndTypFromPath(S_TCDTABTREEDATA **pTabTree,
                                     char *sPath);
S_TCDTABTREEDATA*
TCDIMPGetPathAndTypFromID(S_TCDTABTREEDATA **pTabTree, TCD_LONG ID);
void TCDIMPReleaseTabTreeData(S_TCDTABTREEDATA ***pTabTreeData);
void  TCDIMPImportTabTreeData( P_TCDIMPORTSS req, char * TreeFNam);


/* Destruktoren */
void TCDIMPReleaseTabImpData( P_TCDTABIMPDATA * , TCD_BOOL , TCD_BOOL);
void TCDIMPReleaseTabData   ( P_TCDTAB      *ppTabValues );
void TCDIMPReleaseProcData  ( P_TCDPRCELEM  * );
void TCDIMPReleaseNodeData  ( P_TCDNODEDATA * );

#endif
                /* Importschnittstelle      */

/* Prototypen der internen Funktionen  */

static TCD_INT TCD_TIMPORT   ( P_TCDIMPORTSS  ) ;
static void    TCD_AIMPORT   ( P_TCDIMPORTSS  ) ;
static void    ImportTabNode ( P_TCDIMPORTSS  ) ;
static void    GetTabPathNam ( P_TCDIMPORTSS  ) ;
static TCD_INT GetTabFile    ( P_TCDIMPORT, char *) ;
static void    GetTabInfo    ( P_TCDIMPORTSS  ) ;
static void    GetTabAttr    ( P_TCDIMPORTSS  ) ;
static void    GetTabText    ( P_TCDIMPORTSS  ) ;
static TCD_INT Scan          ( P_TCDIMPORT, char *, char *, int * ) ;
static TCD_INT GetNode       ( P_TCDIMPORTSS, char * ) ;
static TCD_INT ReadFile      ( P_TCDIMPORTSS ) ;
static TCD_INT InsertNode    ( const P_TCDPRCNODE ,P_TCDIMPORTSS ) ;
static TCD_INT InsertBelegInfo ( const P_TCDPRCINFO ,\
                                 P_TCDIMPORTSS ) ;
static TCD_INT InsertRelAttrs  ( const P_TCDRELATTR_IMP,\
                                 P_TCDIMPORTSS , TCD_INT *);
static void *  ExpandMem( void * , TCD_INT , TCD_INT  );
static void *  AllocRelAttrs( void *,TCD_INT,TCD_INT);

static TCD_INT ImpGetC( P_TCDIMPORT  );
static TCD_INT ImpUnGetC ( TCD_INT , P_TCDIMPORT  );
static void    NodeImport( P_TCDIMPORTSS  ) ; /* INOUT */
static int     ImportProc(P_TCDIMPORTSS , char * , TCD_LONG ) ;
static void    MakeProcFName (char * , TCD_LONG, char * ) ;
static void    GetNodePathNam( P_TCDIMPORTSS  ) ;
static void    GetNodeAttr( P_TCDIMPORTSS  ) ;
static int     GroupBeginGet( P_TCDIMPORTSS  ) ;
static int     GroupEndGet(P_TCDIMPORT ) ;
static void    GetNodeIdent( P_TCDIMPORTSS  ) ;
static void    GetNodeText( P_TCDIMPORTSS  ) ;
static TCD_INT AppendPath(S_TCDPATHDATA *, S_TCDPATHDATA **,
                          TCD_INT * ) ;
static TCD_INT AppendAttr (S_TCDATTRDATA *, P_TCDNODEDATA );
static TCD_INT GetData( P_TCDIMPORT , char *  ) ;
static int     SkipProcHeader(P_TCDIMPORT pImport) ;

static int     GetVersNr(P_TCDIMPORT pImport) ;
static TCD_INT AppendTabAttr(S_TCDTABATTRDATA * ,P_TCDTABINFO ) ;
void           CopyFile(FILE *, FILE* ) ;
static void    TabImpTrpFile( P_TCDIMPORTSS  ) ;
static int     SConstrImpNode( S_TCDNODEDATA *) ;

static void    SDestrImpNode( S_TCDNODEDATA *);
static void    DDestrImpNode( S_TCDNODEDATA **);
P_TCDPRCNODE   FindNode(TCD_LONG,P_TCDPRCNODE,TCD_INT,TCD_INT *);



static S_TCDNODEDATA   *DConstrImpNode(void);
static TCD_BOOL        ChkVersion(int *, int *, P_PRIVATE ) ;
#ifdef DUMP
static TCD_INT ImpDump ( P_TCDIMPORTSS  );
static const char * SType ( TCD_INT  ) ;
#endif

/*** neu eingefuegt bzw. geandert ****/

static      TCD_INT NodeOrProcImport  (P_TCDIMPORTSS , 
                                       int bReadProcData  ) ; 
static int  GetProc( P_TCDIMPORTSS, int bReadProcData   ) ;
static void TCDIMPNFIntl ( P_TCDIMPORTSS req, char * TreeFNam,
                           int bReadProcData);
static int  relQsort(const void *pElem1,const void *pElem2 ) ;
static int  compBsearch(const void *sPath,const void* pElem);
static char* DetermineTabString(FILE *pFilePointer, int* iState);
static int relQsortTab(const void *pElem1,const void *pElem2 );
static int compBsearchTab(const void *sPath,const void* pElem);




/* Wiederverwendung                    */
int  ExtractRelAttrs (P_TCDIMPORT , P_TCDIMPORTSS );

/*--------------------------------------------------------------------
Externe Funktion:   TCDIMP_F
Beschreibung : 1. Lie�t die Transportdatei einer Auspr�gung aus einem
                File
             2. Baut die BelegInfostruktur auf
Input :  S_TCDIMPCTL ICTL
        ImpBuffer - Puffer mit den Import-Daten
Output:  Auspr�gungsdaten im internen Format S_TCDPRCDATA
---------------------------------------------------------------------*/
void                TCDIMPF ( P_TCDIMPORTSS req, FILE * ImpStream, 
                              char* ImpStreamName )
{           
   P_TCDIMPORT pImpBuffer = &(req->Private.ImpBuffer);
   
   pImpBuffer->Type        = TCD_FILE;
   pImpBuffer->Buffer.File = ImpStream;
   pImpBuffer->FileName[0] = 0;
   pImpBuffer->pImportSS   = req;
   
   if ( ImpStreamName )
       strcpy ( pImpBuffer->FileName, ImpStreamName );

   switch ( req->ICTL.Typ ) 
   {
       case TCD_IMPTYP_PROC :
           TCD_AIMPORT ( req ) ;

#ifdef DUMP
           ImpDump ( req ) ;
#endif /* DUMP */

           break ;

       case TCD_IMPTYP_TAB1:
       case TCD_IMPTYP_TAB2:

           TCD_TIMPORT ( req ) ;
           break ;

       default :
           req->ICTL.Rc = RC_INV_OPC ;
   } 
} 


/*---------------------------------------------------------------------
  Externe Funktion:   TCDIMP_B
  Beschreibung : 1. Lie�t die Transportdatei einer Auspr�gung aus einem
                    Buffer
                 2. Baut die BelegInfostruktur auf
                 3. Baut die LocalData struktur auf
  Input :  S_TCDIMPCTL ICTL
            ImpBuffer - Puffer mit den Import-Daten
  Output:  Auspr�gungsdaten im internen Format S_TCDPRCDATA
---------------------------------------------------------------------*/
void                TCDIMPB ( P_TCDIMPORTSS req, char * ImpMem )
{
   /* Importpuffer ( File oder Memory ) setzten */
   P_TCDIMPORT pImpBuffer = &(req->Private.ImpBuffer);

   pImpBuffer->Type       = TCD_MEM;
   pImpBuffer->Buffer.Mem = ImpMem;
   pImpBuffer->FileName[0] = 0;
   pImpBuffer->pImportSS   = req;   
   
/*------------------------------------------------------------------*/
   switch ( req->ICTL.Typ ) {
       case TCD_IMPTYP_PROC :
           TCD_AIMPORT ( req ) ;
#ifdef DUMP
           ImpDump ( req ) ;
#endif /* DUMP */
           break ;
       case TCD_IMPTYP_TAB1:
       case TCD_IMPTYP_TAB2:
           TCD_TIMPORT ( req ) ;
           break ;
       case TCD_IMPTYP_NODE :
           req->ICTL.Rc = RC_INV_OPC ;
           break ;
       default :
           req->ICTL.Rc = RC_INV_OPC ;
   }
}
/*---------------------------------------------------------------------
Externe Funktion:   TCDCPYNF
Beschreibung : Kopiert Auspr�gungen in eine einzige Transportdatei.
             Dabei wird �ber eine (in req.ICTL.ChckFkt eingetragene)
                Funktion gepr�ft, welche Auspr�gungen kopiert werden
                sollen . Die Zieldatei ist bereits ge�ffnet, der File-
                pointer wird in req.ICTL.fpTrpFile geliefert.
Input :  S_TCDIMPCTL ICTL
        TreeFNam : Datei mit den Knoteninformationen
Output:  Returncode.
---------------------------------------------------------------------*/
void                TCDCPYNF ( P_TCDIMPORTSS req, char * TreeFNam )
{

  FILE *fp ;
  TCD_INT rc ;
  P_TCDIMPORT pImpBuffer = &(req->Private.ImpBuffer);

  pImpBuffer->Type = TCD_FILE;
  req->Private.TCDImpTreeFNam = TreeFNam ;

  if (( fp = fopen (TreeFNam, "r")) == NULL)
  {
        req->ICTL.Rc = RC_FILE_ERROR ;
        req->ICTL.Errno = 0;
        strcpy ( req->ICTL.ErrFileName, TreeFNam );
        return ;
  }
  pImpBuffer->Buffer.File = fp ;
  strcpy ( pImpBuffer->FileName, TreeFNam );
  pImpBuffer->pImportSS = req;

  while ((req->ICTL.Rc == RC_OK || req->ICTL.Rc == RC_FILE_ERROR ) &&
          req->ICTL.Status != TCD_IMPSTAT_EOF )
  {
    req->ICTL.Rc = RC_OK;
    rc = NodeOrProcImport ( req, 1 ) ;
  }
  fclose (pImpBuffer->Buffer.File);
}


/*********************************************************************/
/*********************************************************************/
/**                                                                 **/
/**  Im folgenden Block werden Methoden zum Lesen des TARIFBAUMES   **/
/**  bereitgestellt.                                                **/
/**                                                                 **/
/** 1.)Lesen des Tarifbaumes mit BV-Daten ==> TCDIMNF               **/
/**                                                                 **/
/**      (realsiert durch Aufrufe von TCDIMNFIntl(..., 1),          **/
/**       entspricht der alten TCDIMPNF)                            **/
/**                                                                 **/
/** 2.)Lesen des Tarifbaumes ohne BV-Daten ==> TCDIMPImportTreeData **/
/**                                                                 **/
/**     (realsiert durch Aufrufe von TCDIMNFIntl(...,0))            **/
/**                                                                 **/
/**     ==> Anlegen eines dynamischen Vektors mit Zeigern auf       **/
/**         S_TCDTREEDATA                                           **/
/**     ==> Vektor mit qsort sortieren == Zeiger umhaengen          **/
/**                                                                 **/
/**  3.)Methoden fuer "reduzierten Baum" ==>                        **/
/**                                                                 **/
/**     a)S_TCDTREEDATA* TCDIMPGetNodeFromID                        **/
/**                                                                 **/
/**                                                                 **/
/**     b)S_TCDTREEDATA* TCDIMPGetNodeFromPath                      **/
/**                                                                 **/
/**                                                                 **/
/**     c)void TCDIMPReleaseTreeData                                **/
/**                                                                 **/
/**                                                                 **/
/*********************************************************************/
/*********************************************************************/

/*---------------------------------------------------------------------
  Externe Funktion:   TCDIMPNF
  Beschreibung : Importiert Knoteninformationen und Auspraegungen
       1. liest die Knoteninformationen sequentiell ein
          ein Aufruf der Funktion liefert die Daten eines
          Knotens
       2. liest die Auspraegungen zu einem Knoten sequentiell
  Input :  S_TCDIMPCTL ICTL
       TreeFNam : Datei mit den Knoteninformationen
  Output:  Auspragungsdaten im internen Format S_TCDPRCDATA
---------------------------------------------------------------------*/

void      TCDIMPNF( P_TCDIMPORTSS req, char * TreeFNam)
{
   /*================================================================*/
   /* BV-Daten sollen mitgelesen werden ==> Parameter 1              */
   /*================================================================*/
   TCDIMPNFIntl( req, TreeFNam, 1);
   return;
}

/*********************************************************************/
/*                                                                   */
/*  Externe Funktion: TCDIMPImportTreeData                           */
/*                                                                   */
/*  Beschreibung: liefert sortierten Vektor von BV-Pfaden + Namen    */
/*                                                                   */
/*                                                                   */
/*  INPUT:        P_TCDIMPORTSS req  == Zeiger auf Schnittstelle     */
/*                char* TreeFNam == Transportformatfile              */
/*  OUTPUT:       void                                               */
/*                                                                   */
/*  MOL 23.10.1997                                                   */
/*                                                                   */
/*********************************************************************/
void  TCDIMPImportTreeData( P_TCDIMPORTSS req, char * TreeFNam)
{
   int i, iCount, j, iLen = 0;
   S_TCDTREEDATA **pTreeData  = NULL;
   S_TCDTREEDATA **pTreeData1 = NULL;

   /*----------------------------------------------------------------*/
   /* "Baumdatenstruktur initialisieren                              */
   /*----------------------------------------------------------------*/

   pTreeData = 
      (S_TCDTREEDATA**)_TCDALLOC(DELTA,sizeof(S_TCDTREEDATA*));

   if (pTreeData ==  NULL)
   {
     req->ICTL.Rc = RC_NOMEM;
     return;
   }
   for ( i = 0; i < DELTA; i++)
   {
     pTreeData[i] = NULL;
   }

   /*----------------------------------------------------------------*/
   /* Import starten                                                 */
   /*----------------------------------------------------------------*/
   TCDIMPNFIntl( req, TreeFNam, 0);

   if( req->ICTL.Rc != RC_OK )
   {
      _TCDFREE(pTreeData);
      return ;
   }

   /*----------------------------------------------------------------*/
   /* Baumtransportformat scannen                                    */
   /*----------------------------------------------------------------*/
   iCount = 0;
   while( req->ICTL.Status != TCD_IMPSTAT_EOF)
   {
       switch( req->ICTL.Typ)
       {
            case TCD_IMPTYP_NODE:
            {
                break;
            }

            case TCD_IMPTYP_PROC:
            {
               /*----------------------------------------------------*/
               /* "Baum" vergroessern                                */
               /*----------------------------------------------------*/
                if (iCount >0 &&  iCount%DELTA == 0)
                {
                   pTreeData1 =
                   (S_TCDTREEDATA**)_TCDREALLOC(pTreeData,
                              (iCount+DELTA)*sizeof(S_TCDTREEDATA*));
                   if (pTreeData1 == NULL)
                   {
                       req->ICTL.Rc = RC_NOMEM;
                        _TCDFREE(pTreeData[iCount-1]->sName);
                       pTreeData[iCount-1]->sName = NULL;
                       _TCDFREE(pTreeData[iCount-1]);
                       pTreeData[iCount-1] = NULL;
                       TCDIMPReleaseTreeData(&pTreeData);

                       return ;
                   }

                   pTreeData = pTreeData1;
                   
                   for ( i = 0; i < DELTA; i++)
                   {
                     pTreeData[iCount+i] = NULL;
                   }
                }

                /*---------------------------------------------------*/
                /* Knoten in Vektor lesen                            */
                /*---------------------------------------------------*/
                pTreeData[iCount]  = 
                    (S_TCDTREEDATA*)_TCDALLOC(1,sizeof(S_TCDTREEDATA));
                
                if ( pTreeData[iCount] == NULL )
                {
                  req->ICTL.Rc = RC_NOMEM;
                  
                  /*-------------------------------------------------*/
                  /* Bisherigen Import rueckgaengig machen           */
                  /*-------------------------------------------------*/
                  
                  TCDIMPReleaseTreeData(&pTreeData);

                  return ;
                }

                /*---------------------------------------------------*/
                /* ID setzen                                         */
                /*---------------------------------------------------*/

                pTreeData[iCount]->ID = (TCD_LONG) req->ICTL.ID;

                /*---------------------------------------------------*/
                /* Pfaddatenlaenge bestimmen                         */
                /*---------------------------------------------------*/
                iLen = 0;
                for ( j=0; j < (req->Data).pNodeData->AnzPathEnt ; j++)
                {
                 iLen += 
                     strlen((req->Data).pNodeData->PathData[j].Path);

                }
                iLen += strlen((req->Data).pNodeData->NodeName);
                iLen += strlen((req->ICTL).Name);
                iLen += (req->Data).pNodeData->AnzPathEnt + 3;

                /*---------------------------------------------------*/
                /* Pfaddaten bestimmen                               */
                /*---------------------------------------------------*/

                pTreeData[iCount]->sName = 
                     (char*)_TCDALLOC(iLen, sizeof(char));
                if ( pTreeData[iCount]->sName == NULL )
                {
                  
                   req->ICTL.Rc = RC_NOMEM;

                  /*-------------------------------------------------*/
                  /*  Bisherigen Import r�ckg�ngig machen            */
                  /*-------------------------------------------------*/
                  _TCDFREE(pTreeData[iCount]);
                  pTreeData[iCount] = NULL;
                  TCDIMPReleaseTreeData(&pTreeData);
                  return ;
                }
                pTreeData[iCount]->sName[0]  = '\0';

                for ( j=0; j<(req->Data).pNodeData->AnzPathEnt ; j++)
                {
                   strcat(pTreeData[iCount]->sName, 
                          (req->Data).pNodeData->PathData[j].Path);
                   strcat(pTreeData[iCount]->sName, "\\");
                }
                strcat(pTreeData[iCount]->sName, 
                       (req->Data).pNodeData->NodeName);
                strcat(pTreeData[iCount]->sName, "\\");
                strcat(pTreeData[iCount]->sName, (req->ICTL).Name);

                iCount++;

                break;
        }

        default:  /**** nichts zu tun ********************************/

        break;
       }

       TCDIMPNFIntl( req, TreeFNam, 0); 
       
       if( req->ICTL.Rc != RC_OK )
       {
          if ( iCount > 0)
          {
             _TCDFREE(pTreeData[iCount-1]->sName);
             pTreeData[iCount-1]->sName = NULL;
             _TCDFREE(pTreeData[iCount-1]);
             pTreeData[iCount-1] = NULL;
          }
          TCDIMPReleaseTreeData(&pTreeData);
          return ;
       }
   }


   /*----------------------------------------------------------------*/
   /* Baumvektor sortieren                                           */
   /*----------------------------------------------------------------*/

   qsort((void*)pTreeData, 
         (size_t) iCount, 
         (size_t) sizeof(S_TCDTREEDATA*), 
         relQsort);

   /*----------------------------------------------------------------*/
   /*  Baumvektor an Struktur uebergeben                             */
   /*----------------------------------------------------------------*/

   pTreeData1 =
   (S_TCDTREEDATA**)_TCDREALLOC(pTreeData,
                                (iCount+1)*sizeof(S_TCDTREEDATA*));

   if (pTreeData1 == NULL)
   {
       req->ICTL.Rc = RC_NOMEM;
       if ( iCount > 0)
       {
          _TCDFREE(pTreeData[iCount-1]->sName);
          pTreeData[iCount-1]->sName = NULL;
          _TCDFREE(pTreeData[iCount-1]);
          pTreeData[iCount-1] = NULL;
       }
       TCDIMPReleaseTreeData(&pTreeData);
       return ;
   }

   pTreeData = pTreeData1;
 
   pTreeData[iCount] = NULL;

   (req->Data).pTreeData = pTreeData;

   return;
}
/*******************************************************************/
/*                                                                 */
/* Interne Funktion: relQsort                                      */
/*                                                                 */
/* legt Sortierkriterium fuer qsort fest                           */
/*                                                                 */
/* MOL 23.10.1997                                                  */
/*                                                                 */
/*******************************************************************/

static int relQsort(const void *pElem1,const void *pElem2 )
{

   return strcmp((*(S_TCDTREEDATA**)pElem1)->sName,
                 (*(S_TCDTREEDATA**)pElem2)->sName);
}

/*********************************************************************/
/*                                                                   */
/*  Externe Funktion: TCDIMPGetNodeFromID                            */
/*                                                                   */
/*  Beschreibung: ordnet der ID den Pfad zu                          */
/*                                                                   */
/*                                                                   */
/*  INPUT:        S_TCDTREEDATA **pTree  == Baumvektor               */
/*                int ID              == ID der BV                   */
/*  OUTPUT:       S_TCDTREEDATA *     == Zeiger auf das Vektorelement*/
/*                                                                   */
/*  MOL 23.10.1997                                                   */
/*                                                                   */
/*********************************************************************/

S_TCDTREEDATA* TCDIMPGetNodeFromID(S_TCDTREEDATA **pTree, TCD_LONG ID)
{
  int iCount = 0;

  while( pTree[iCount] != NULL )
  {
     if (pTree[iCount]->ID == ID)
     {
       return pTree[iCount];
     }
     iCount++;
  }
  return NULL;
}

/*********************************************************************/
/*                                                                   */
/*  Externe Funktion: TCDIMPGetNodeFromPath                          */
/*                                                                   */
/*  Beschreibung: ordnet Pfad die ID zu                              */
/*                                                                   */
/*                                                                   */
/*  INPUT:        S_TCDTREEDATA **pTree  == Baumvektor               */
/*                char* sPath         == Pfad der BV                 */
/*  OUTPUT:       S_TCDTREEDATA *     == Zeiger auf das Vektorelement*/
/*                                       falls vorhanden, NULL sonst */
/*  MOL 23.10.97                                                     */
/*                                                                   */
/*********************************************************************/

S_TCDTREEDATA* TCDIMPGetNodeFromPath(S_TCDTREEDATA **pTree, 
                                     char *sPath)
{
   int iCount = 0;
   int i = 0;
   S_TCDTREEDATA *pNode = NULL;
   

   /*--------------------------------------------------------*/
   /* Laenge des Vektors bestimmen                           */
   /*--------------------------------------------------------*/
   while( pTree[iCount] != NULL)
   {
     iCount++;
   }
   /*--------------------------------------------------------*/
   /* String behandeln + binaere Suche                       */
   /*--------------------------------------------------------*/

   if (strlen(sPath) >1  &&  sPath[0] == '.'
                         && (sPath[1] == '\\' || sPath[1] == '/'))
   {
      pNode = bsearch(&sPath[2], (void*) pTree, 
                    (size_t) iCount,
                    (size_t) sizeof(S_TCDTREEDATA *), compBsearch);
   }
   else
   {
      if (strlen(sPath) >0 && (sPath[0] == '\\' || sPath[0] == '/'))
      {
         pNode = bsearch(&sPath[1], (void*) pTree, 
                    (size_t) iCount,
                    (size_t) sizeof(S_TCDTREEDATA *), compBsearch);
      }
      else
      {
         pNode = bsearch(sPath, (void*) pTree, 
                    (size_t) iCount,
                    (size_t) sizeof(S_TCDTREEDATA *), compBsearch);
      }
    }   

   /*----------------------------------------------------------*/
   /* Zurueckgeben                                             */
   /*----------------------------------------------------------*/

   if (pNode == NULL)   /***der gesuchte Eintrag wurde nicht***/
     return NULL;       /***gefunden***************************/
   else
     return *(S_TCDTREEDATA**) pNode;
}

/*******************************************************************/
/*                                                                 */
/* Interne Funktion: compBsearch                                   */
/*                                                                 */
/* legt Vergleichskriterium fuer bsearch fest                      */
/*                                                                 */
/* MOL 23.10.1997                                                  */
/*                                                                 */
/*******************************************************************/
static int compBsearch(const void *sPath,const void* pElem)
{

   int iCount = 0;

   while (((char* )sPath)[iCount] != '\0' && 
          (*(S_TCDTREEDATA**)pElem)->sName[iCount] != '\0')
   {
     if (((char *) sPath)[iCount] == '\\' || 
         ((char *) sPath)[iCount] == '/')
     {
       if ((*(S_TCDTREEDATA**)pElem)->sName[iCount] != '\\'
       && (*(S_TCDTREEDATA**)pElem)->sName[iCount] != '/')
       return ((char *) sPath)[iCount] - 
               (*(S_TCDTREEDATA**)pElem)->sName[iCount];
     }
     else
     {
      if ( ((char *) sPath)[iCount] != 
            (*(S_TCDTREEDATA**)pElem)->sName[iCount])
      return ((char *) sPath)[iCount] - 
              (*(S_TCDTREEDATA**)pElem)->sName[iCount];
     }
     iCount++;
   }

   if (((char *) sPath)[iCount] == '\0' && 
         (*(S_TCDTREEDATA**)pElem)->sName[iCount] == '\0')
     return 0;
   else
     return ((char *) sPath)[iCount] - 
             (*(S_TCDTREEDATA**)pElem)->sName[iCount];

}

/********************************************************************/
/*                                                                   */
/*  Externe Funktion: TCDIMPReleaseTreeData                          */
/*                                                                   */
/*  Beschreibung: gibt Baumvektor frei                               */
/*                                                                   */
/*                                                                   */
/*  INPUT:        S_TCDTREEDATA ***pTree  == Zeiger auf  Baumvektor, */
/*                                           letzter Eintrag NULL-   */
/*                                            zeiger !!!             */
/*                                                                   */
/*  OUTPUT:       void                                               */
/*                                                                   */
/*  MOL 23.10.1997                                                   */
/*                                                                   */
/*********************************************************************/

void TCDIMPReleaseTreeData(S_TCDTREEDATA ***pTreeData)
{
  int iCount = 0;
  
  /*----------------------------------------------------------------*/
  /* fuer korrekte Arbeitsweise mu� die letzte Vektorkomponente     */
  /* Zeiger auf NULL sein !                                         */
  /*----------------------------------------------------------------*/
  
  while( (*pTreeData)[iCount] != NULL)
  {
    _TCDFREE((*pTreeData)[iCount]->sName);
    (*pTreeData)[iCount]->sName = NULL;
    _TCDFREE((*pTreeData)[iCount]);
    (*pTreeData)[iCount] = NULL;
    iCount++;
  }
  _TCDFREE(*pTreeData);
  *pTreeData = NULL;
  return;
}

/*---------------------------------------------------------------------
  Externe Funktion:   TCDIMPNFIntl
  Beschreibung : Importiert Knoteninformationen und Auspraegungen
                 1. liest die Knoteninformationen sequentiell ein
                    ein Aufruf der Funktion liefert die Daten eines
                    Knotens
                 2. liest die Auspraegungen zu einem Knoten sequentiell
  Input :  S_TCDIMPCTL ICTL
            TreeFNam : Datei mit den Knoteninformationen
  Output:  Auspr�gungsdaten im internen Format S_TCDPRCDATA
---------------------------------------------------------------------*/
static void TCDIMPNFIntl ( P_TCDIMPORTSS req, char * TreeFNam, 
                           int bReadProcData )
{
    FILE *  fp = 0;
    TCD_INT rc = 0;
    P_TCDIMPORT pImpBuffer = &(req->Private.ImpBuffer);

	 req->ICTL.Rc = RC_OK ; /* Rueckgabe erstmal auf OK initialisieren */

    /*-----------------------------------------------------------------
     Importiert wird aus File !!
    -----------------------------------------------------------------*/

    pImpBuffer->Type = TCD_FILE;
    req->Private.TCDImpTreeFNam = TreeFNam ;
    
    if (req->ICTL.Status == TCD_IMPSTAT_INIT) 
    {
        if (( fp = fopen (TreeFNam, "r")) == NULL) 
        {
            req->ICTL.Rc = RC_FILE_ERROR ;
            req->ICTL.Errno = 0;  
            strcpy ( req->ICTL.ErrFileName, TreeFNam );
            return ;
        }
        pImpBuffer->Buffer.File = fp ;
        strcpy ( pImpBuffer->FileName, TreeFNam );
        pImpBuffer->pImportSS = req;
    }
    if (req->ICTL.Status == TCD_IMPSTAT_EOF) 
    {
        fclose (pImpBuffer->Buffer.File);
        return ;
    }
    /*---------------------------------------------------------------*/
    /* Sollen BV mitimportiert werden oder nicht ?                   */
    /*---------------------------------------------------------------*/
    if ( bReadProcData == 0)
       rc = NodeOrProcImport ( req, 0 ) ;
    else
       rc = NodeOrProcImport ( req, 1 ) ;

    if (rc == RC_SYS_ERROR || req->ICTL.Status == TCD_IMPSTAT_EOF) 
    {
        fclose (pImpBuffer->Buffer.File);
    }
    return  ;
}

/***************************** ENDE DES BLOCKES **********************/
/***************************** Anfang des neuen Blockes **************/
/*********************************************************************/
/*********************************************************************/
/*                                                                   */
/*  Externe Funktion: TCDIMPImportTabTreeData                        */
/*                                                                   */
/*  Beschreibung: liefert sortierten Vektor von Tab-Pfaden + Namen   */
/*                                                                   */
/*                                                                   */
/*  INPUT:        P_TCDIMPORTSS req  == Zeiger auf Schnittstelle     */
/*                char* TabTreeFNam == Datei mit verdichteteten      */
/*                                     Tabellentransportdaten        */
/*  OUTPUT:       void                                               */
/*                                                                   */
/*  MOL 27.02.1998                                                   */
/*                                                                   */
/*********************************************************************/
void  TCDIMPImportTabTreeData( P_TCDIMPORTSS req, char * TreeFNam)
{
   char *sSingleTabString;
   int i, iCount, j;
   int iLen = 0;
   int iState = 0;
   S_TCDTABTREEDATA **pTabTreeData  = NULL;
   S_TCDTABTREEDATA **pTabTreeData1 = NULL;
   FILE *pFilePointer = NULL;
   P_TCDIMPORT pImpBuffer = &(req->Private.ImpBuffer);

   /*----------------------------------------------------------------*/
   /* "Baumdatenstruktur initialisieren                              */
   /*----------------------------------------------------------------*/

   pTabTreeData =
      (S_TCDTABTREEDATA**)_TCDALLOC(DELTA,sizeof(S_TCDTABTREEDATA*));

   if (pTabTreeData ==  NULL)
   {
     req->ICTL.Rc = RC_NOMEM;
     return;
   }

   for ( i = 0; i < DELTA; i++)
   {
     pTabTreeData[i] = NULL;
   }

   pFilePointer = fopen(TreeFNam, "r");
   if (pFilePointer == NULL)
   {
      req->ICTL.Rc = RC_NOMEM;
      return;
   }

   /*----------------------------------------------------------------*/
   /* Import starten                                                 */
   /*----------------------------------------------------------------*/

   sSingleTabString = DetermineTabString(pFilePointer, &iState);

   if (sSingleTabString == NULL)
   {
      req->ICTL.Rc = RC_NOMEM;
   }

   if (sSingleTabString != NULL)
   {
      pImpBuffer->Type = TCD_MEM;
      pImpBuffer->Buffer.Mem = sSingleTabString;
      pImpBuffer->pImportSS = req;
      req->ICTL.Rc = RC_OK;         
      req->Data.pTabData = NULL;
      ImportTabNode(req);
      _TCDFREE(sSingleTabString);
      sSingleTabString = NULL;
   }

   if( req->ICTL.Rc != RC_OK )
   {
      _TCDFREE(pTabTreeData);
      fclose(pFilePointer);
      return ;
   }

   /*----------------------------------------------------------------*/
   /* Baumtransportformat scannen                                    */
   /*----------------------------------------------------------------*/
   iCount = 0;
   while( iState == 0)
   {

      /*------------------------------------------------------------*/
      /* "Baum" vergroessern                                        */
      /*------------------------------------------------------------*/
      if (iCount >0 &&  iCount%DELTA == 0)
      {
         pTabTreeData1 =
         (S_TCDTABTREEDATA**)_TCDREALLOC(pTabTreeData,
                         (iCount+DELTA)*sizeof(S_TCDTABTREEDATA*));
         if (pTabTreeData1 == NULL)
         {
            req->ICTL.Rc = RC_NOMEM;
           _TCDFREE(pTabTreeData[iCount-1]->sName);
            pTabTreeData[iCount-1]->sName = NULL;
           _TCDFREE(pTabTreeData[iCount-1]);
            pTabTreeData[iCount-1] = NULL;
            TCDIMPReleaseTabTreeData(&pTabTreeData);

           return ;
          }

          pTabTreeData = pTabTreeData1;

          for ( i = 0; i < DELTA; i++)
          {
             pTabTreeData[iCount+i] = NULL;
          }
       }

       /*---------------------------------------------------*/
       /*Vektoreintrag erzeugen und Daten aus ImportSS lesen*/
       /*---------------------------------------------------*/
       pTabTreeData[iCount]  =
       (S_TCDTABTREEDATA*)_TCDALLOC(1,sizeof(S_TCDTABTREEDATA));

       if ( pTabTreeData[iCount] == NULL )
       {
          req->ICTL.Rc = RC_NOMEM;
          TCDIMPReleaseTabTreeData(&pTabTreeData);

          return ;
       }

       pTabTreeData[iCount]->ID = 
       	(TCD_LONG) (req->Data).pTabData->pTabInfo->NodeId;
       pTabTreeData[iCount]->iCol =
       	(req->Data).pTabData->pTabInfo->AnzSpalten;
       pTabTreeData[iCount]->iRow =
       	(req->Data).pTabData->pTabInfo->AnzZeilen;
       pTabTreeData[iCount]->iVk =
       	(req->Data).pTabData->pTabInfo->AnzStellen;
       pTabTreeData[iCount]->iNk =
       	(req->Data).pTabData->pTabInfo->AnzNkStellen;

       iLen = 0;
       for ( j=0; j < (req->Data).pTabData->pTabInfo->AnzPathEnt; j++)
       {
          iLen +=
          strlen((req->Data).pTabData->pTabInfo->PathData[j].Path);

       }

       pTabTreeData[iCount]->sName =
       (char*)_TCDALLOC(iLen+
         (req->Data).pTabData->pTabInfo->AnzPathEnt +1, sizeof(char));
       if ( pTabTreeData[iCount]->sName == NULL )
       {

          req->ICTL.Rc = RC_NOMEM;


          _TCDFREE(pTabTreeData[iCount]);
          pTabTreeData[iCount] = NULL;
          TCDIMPReleaseTabTreeData(&pTabTreeData);
          fclose(pFilePointer);
          return ;
       }
       pTabTreeData[iCount]->sName[0]  = '\0';

       for ( j=0; j<(req->Data).pTabData->pTabInfo->AnzPathEnt ; j++)
       {
          if ( j >0)
             strcat(pTabTreeData[iCount]->sName, "\\");
          strcat(pTabTreeData[iCount]->sName,
                (req->Data).pTabData->pTabInfo->PathData[j].Path);
       }

      /*_TCDFREE((req->Data).pTabData->pTabInfo);
      _TCDFREE((req->Data).pTabData);
      _TCD*/
      TCDIMPReleaseTabImpData(&(req->Data).pTabData,0,1);
      iCount++;

      /*------------------------------------------------------------*/
      /* Daten fuer neue Tabelle importieren                        */
      /*------------------------------------------------------------*/

      sSingleTabString = DetermineTabString(pFilePointer, &iState);

      if (sSingleTabString == NULL)
      {
         req->ICTL.Rc = RC_NOMEM;
      }

      if (iState == 0 && sSingleTabString != NULL)
      {
         pImpBuffer->Type = TCD_MEM;
         pImpBuffer->Buffer.Mem = sSingleTabString;
         pImpBuffer->pImportSS = req;
         req->ICTL.Rc = RC_OK;
         req->Data.pTabData = NULL;
         ImportTabNode(req);
         _TCDFREE(sSingleTabString);
      }

      if (sSingleTabString != NULL && iState == 1)
      {
         _TCDFREE(sSingleTabString);
      }

      if( req->ICTL.Rc != RC_OK )
      {
         if ( iCount > 0)
         {
             _TCDFREE(pTabTreeData[iCount-1]->sName);
             pTabTreeData[iCount-1]->sName = NULL;
             _TCDFREE(pTabTreeData[iCount-1]);
             pTabTreeData[iCount-1] = NULL;
          }
          TCDIMPReleaseTabTreeData(&pTabTreeData);
          fclose(pFilePointer);
          return ;
       }
     }


     /*-------------------------------------------------------*/
     /* Vektor sortieren (nach dem Pfad)                      */
     /*-------------------------------------------------------*/

     qsort((void*)pTabTreeData,
     (size_t) iCount,
     (size_t) sizeof(S_TCDTABTREEDATA*),
     relQsortTab);



    pTabTreeData1 =
   (S_TCDTABTREEDATA**)_TCDREALLOC(pTabTreeData,
                                (iCount+1)*sizeof(S_TCDTABTREEDATA*));

   if (pTabTreeData1 == NULL)
   {
       req->ICTL.Rc = RC_NOMEM;
       if ( iCount > 0)
       {
          _TCDFREE(pTabTreeData[iCount-1]->sName);
          pTabTreeData[iCount-1]->sName = NULL;
          _TCDFREE(pTabTreeData[iCount-1]);
          pTabTreeData[iCount-1] = NULL;
       }
       TCDIMPReleaseTabTreeData(&pTabTreeData);
       return ;
   }

   pTabTreeData = pTabTreeData1;

   pTabTreeData[iCount] = NULL;

   (req->Data).pTabTreeData = pTabTreeData;

   fclose(pFilePointer);

   return;
}

/********************************************************************/
/*                                                                  */
/*   Interne Funktion: DetermineTabString                           */
/*                                                                  */
/*   liest Datei mit verdichteten Tabellenbauminformationen         */
/*   zeilenweise                                                    */
/*                                                                  */
/*   Return: Datenstring oder NULL, falls Fehler                    */
/*                                                                  */
/*   MOL 03.03.98                                                   */
/********************************************************************/
static char* DetermineTabString(FILE* pFilePointer, int* iState)
{
   char *sString;
   long   lPos;
   int c,iCount = 0;
   
   if (*iState == 1)
   {
     *iState = 2;
     return NULL;
   }
   /*----------------------------------------------------*/
   /* Laenge des aktuellen Tabelleneintrages bestimmen   */
   /*----------------------------------------------------*/
   lPos = ftell(pFilePointer);

   if (lPos >= 0)
   {
      while((c=fgetc(pFilePointer)) != EOF && c != '\n')
      {
         iCount++;
      }
   }
   else
      return NULL;

   /*-----------------------------------------------------*/
   /* String lesen                                        */
   /*-----------------------------------------------------*/
   if (fseek(pFilePointer,lPos,SEEK_SET) >= 0)
   {

      sString = (char*)_TCDALLOC((iCount +1),sizeof(char));
      if (sString == NULL)
         return NULL;
      iCount = 0;
      while((c=fgetc(pFilePointer)) != EOF && c != '\n')
      {
        sString[iCount] = (char) c;
        iCount++;
      }
    if (c == EOF)
      *iState = 1;
    sString[iCount] ='\0';
   }
   else
     return NULL;
   return sString;

}
/*******************************************************************/
/*                                                                 */
/* Interne Funktion: relQsortTab                                   */
/*                                                                 */
/* legt Sortierkriterium fuer qsort fest                           */
/*                                                                 */
/* MOL 02.03.1998                                                  */
/*                                                                 */
/*******************************************************************/

static int relQsortTab(const void *pElem1,const void *pElem2 )
{

   return strcmp((*(S_TCDTABTREEDATA**)pElem1)->sName,
                 (*(S_TCDTABTREEDATA**)pElem2)->sName);
}

/*******************************************************************/
/*                                                                 */
/*  Externe Funktion: TCDIMPGetPathAndTypFromID                    */
/*                                                                 */
/*  Beschreibung: ordnet der ID den Pfad zu                        */
/*                                                                 */
/*                                                                 */
/*  INPUT:        S_TCDTABTREEDATA **pTabTree  == Baumvektor       */
/*                int ID              == ID der Tabelle            */
/*  OUTPUT:       S_TCDTABTREEDATA *     == Zeiger auf das         */
/*                                          Vektorelement          */
/*                                                                 */
/*  MOL 02.03.98                                                   */
/*                                                                 */
/*******************************************************************/

S_TCDTABTREEDATA*
TCDIMPGetPathAndTypFromID(S_TCDTABTREEDATA **pTabTree, TCD_LONG ID)
{
  int iCount = 0;

  while( pTabTree[iCount] != NULL )
  {
     if (pTabTree[iCount]->ID == ID)
     {
       return pTabTree[iCount];
     }
     iCount++;
  }
  return NULL;
}

/*******************************************************************/
/*                                                                 */
/*  Externe Funktion: TCDIMPGetTabIDAndTypFromPath                 */
/*                                                                 */
/*  Beschreibung: ordnet Pfad die ID zu                            */
/*                                                                 */
/*                                                                 */
/*  INPUT:        S_TCDTABTREEDATA **pTabTree  == Baumvektor       */
/*                char* sPath         == Pfad der BV               */
/*  OUTPUT:       S_TCDTABTREEDATA *     == Zeiger auf das         */
/*                                          Vektorelement          */
/*                                     falls vorhanden, NULL sonst */
/*  MOL 02.03.98                                                   */
/*                                                                 */
/*******************************************************************/

S_TCDTABTREEDATA*
TCDIMPGetTabIDAndTypFromPath(S_TCDTABTREEDATA **pTabTree,
                                     char *sPath)
{
   int iCount = 0;
   int i = 0;
   S_TCDTABTREEDATA *pNode = NULL;


   /*--------------------------------------------------------*/
   /* Laenge des Vektors bestimmen                           */
   /*--------------------------------------------------------*/
   while( pTabTree[iCount] != NULL)
   {
     iCount++;
   }
   /*--------------------------------------------------------*/
   /* String behandeln + binaere Suche                       */
   /*--------------------------------------------------------*/

   if (strlen(sPath) >1  &&  sPath[0] == '.'
                         && (sPath[1] == '\\' || sPath[1] == '/'))
   {
      pNode = bsearch(&sPath[2], (void*) pTabTree,
                 (size_t) iCount,
                 (size_t) sizeof(S_TCDTABTREEDATA *), compBsearchTab);
   }
   else
   {
      if (strlen(sPath) >0 && (sPath[0] == '\\' || sPath[0] == '/'))
      {
         pNode = bsearch(&sPath[1], (void*) pTabTree,
                 (size_t) iCount,
                 (size_t) sizeof(S_TCDTABTREEDATA *), compBsearchTab);
      }
      else
      {
         pNode = bsearch(sPath, (void*) pTabTree,
                 (size_t) iCount,
                 (size_t) sizeof(S_TCDTABTREEDATA *), compBsearchTab);
      }
   }

   /*----------------------------------------------------------*/
   /* Zurueckgeben                                             */
   /*----------------------------------------------------------*/

   if (pNode == NULL)   /***der gesuchte Eintrag wurde nicht***/
     return NULL;       /***gefunden***************************/
   else
     return *(S_TCDTABTREEDATA**) pNode;
}

/*******************************************************************/
/*                                                                 */
/* Interne Funktion: compBsearchTab                                */
/*                                                                 */
/* legt Vergleichskriterium fuer bsearch fest                      */
/*                                                                 */
/* MOL 02.03.1998                                                  */
/*                                                                 */
/*******************************************************************/
static int compBsearchTab(const void *sPath,const void* pElem)
{

   int iCount = 0;

   while (((char* )sPath)[iCount] != '\0' &&
          (*(S_TCDTABTREEDATA**)pElem)->sName[iCount] != '\0')
   {
     if (((char *) sPath)[iCount] == '\\' ||
         ((char *) sPath)[iCount] == '/')
     {
       if ((*(S_TCDTABTREEDATA**)pElem)->sName[iCount] != '\\'
       && (*(S_TCDTABTREEDATA**)pElem)->sName[iCount] != '/')
       return ((char *) sPath)[iCount] -
               (*(S_TCDTABTREEDATA**)pElem)->sName[iCount];
     }
     else
     {
      if ( ((char *) sPath)[iCount] !=
            (*(S_TCDTABTREEDATA**)pElem)->sName[iCount])
      return ((char *) sPath)[iCount] -
              (*(S_TCDTABTREEDATA**)pElem)->sName[iCount];
     }
     iCount++;
   }

   if (((char *) sPath)[iCount] == '\0' &&
         (*(S_TCDTABTREEDATA**)pElem)->sName[iCount] == '\0')
     return 0;
   else
     return ((char *) sPath)[iCount] -
             (*(S_TCDTABTREEDATA**)pElem)->sName[iCount];

}

/******************************************************************/
/*                                                                 */
/*  Externe Funktion: TCDIMPReleaseTabTreeData                     */
/*                                                                 */
/*  Beschreibung: gibt Baumvektor frei                             */
/*                                                                 */
/*                                                                 */
/*  INPUT:        S_TCDTABTREEDATA ***pTree  == Zeiger auf         */
/*                                              Baumvektor,        */
/*                                             letzter Eintrag 0-  */
/*                                              zeiger !!!         */
/*                                                                 */
/*  OUTPUT:       void                                             */
/*                                                                 */
/*  MOL 27.02.1998                                                 */
/*                                                                 */
/*******************************************************************/

void TCDIMPReleaseTabTreeData(S_TCDTABTREEDATA ***pTabTreeData)
{
  int iCount = 0;

  /*----------------------------------------------------------------*/
  /* fuer korrekte Arbeitsweise mu� die letzte Vektorkomponente     */
  /* Zeiger auf NULL sein !                                         */
  /*----------------------------------------------------------------*/

  while( (*pTabTreeData)[iCount] != NULL)
  {
    _TCDFREE((*pTabTreeData)[iCount]->sName);
    (*pTabTreeData)[iCount]->sName = NULL;
    _TCDFREE((*pTabTreeData)[iCount]);
    (*pTabTreeData)[iCount] = NULL;
    iCount++;
  }
  _TCDFREE(*pTabTreeData);
  *pTabTreeData = NULL;
  return;
}

/****************** ENDE DES NEUEN BLOCKES *************************/
/*------------------------------------------------------------------
  Externe Funktion:   TCDIMPTF
  Beschreibung : Importiert Teilbaum von Tabellen
                 liest die Baumtransportdatei, die die Namen
                 der Dateien enth�lt, die jeweils die Daten der 
                 Tabelle enthalten
  Input :  S_TCDIMPCTL ICTL
            TreeFNam: Name der Baumtransportdatei
  Output:  Tabellendaten
--------------------------------------------------------------------*/
void                TCDIMPTF ( P_TCDIMPORTSS req, char * TreeFNam )
{
   static S_TCDIMPORT ImpBufferLoc;
   char    TabFile [MAXFILENAMLEN ] ;
   TCD_INT rc = 0;
   char * ptr = NULL;
   P_TCDIMPORT pImpBuffer = &(req->Private.ImpBuffer);
   
  /*-----------------------------------------------------------------
     Importiert wird aus File !!
   ------------------------------------------------------------------*/
   pImpBuffer->Type = TCD_FILE;
   req->Private.TCDImpTreeFNam = TreeFNam ;
  if (req->ICTL.Option == TCD_IMP_TRPFILE) {
      TabImpTrpFile (req) ;
      return ;
  }


  if (req->ICTL.Status == TCD_IMPSTAT_INIT) {
      if ((ImpBufferLoc.Buffer.File = fopen(TreeFNam, "r")) == NULL) {
           req->ICTL.Rc = RC_FILE_ERROR ;
           req->ICTL.Errno = 0;
           strcpy ( req->ICTL.ErrFileName, TreeFNam );
           return ;
      }

      req->ICTL.Status = TCD_IMPSTAT_NODE ;
      pImpBuffer->Buffer.File = ImpBufferLoc.Buffer.File ; 
      strcpy ( pImpBuffer->FileName, TreeFNam );
      pImpBuffer->pImportSS = req;
  }

  if (req->ICTL.Status == TCD_IMPSTAT_EOF) {
     fclose (pImpBuffer->Buffer.File);
     return ;
  }

  strcpy (TabFile, TreeFNam);                      
  ptr = &(TabFile[strlen(TabFile)]);              
  while (*ptr != '\\' && ptr != TabFile) ptr--;   
  if (ptr != TabFile) ptr++;                      
  rc = GetTabFile (pImpBuffer,ptr) ;
  if (rc <= 0) {
     if (req->ICTL.Rc==RC_FILE_ERROR) 
       return;
     req->ICTL.Status = TCD_IMPSTAT_EOF ;
     fclose (ImpBufferLoc.Buffer.File) ;
     return ;
  }

  ImpBufferLoc = *pImpBuffer;

  pImpBuffer->Buffer.File = fopen (TabFile, "r") ;
  if (pImpBuffer->Buffer.File == NULL) {
      req->ICTL.Rc = RC_FILE_ERROR ;
      /* fclose (fp) ; 
        RWE im Auftrag v. RON: damit das Generieren derTab-Moduln 
        nicht abbricht, wenn eine Tabelle zwar im 
        transportiertenBaum, nicht aber als 
        transportierte Datei vorliegt (11.10.1996) 
	  */
      *pImpBuffer = ImpBufferLoc;
      req->ICTL.Errno = 0;
      strcpy ( req->ICTL.ErrFileName, TabFile );
      return ;
     }    
  else strcpy(pImpBuffer->FileName,TabFile);     

  if ( req->ICTL.Option == TCD_COPY_TRPFILE )  
  {
    CopyFile (req->ICTL.fpTrpFile, pImpBuffer->Buffer.File);
  }
  else {
           TCD_TIMPORT ( req );    
       /* RON: die Tabellenwerte brauchen wir auch !!!!! */
  }

  fclose (pImpBuffer->Buffer.File);
  /* THK: Kein Abbruch mehr falls zuviele Spalten oder/und Zeilen
  if (req->ICTL.Rc != RC_OK) {
     fclose (ImpBufferLoc.Buffer.File) ;
  }
  */
  *pImpBuffer = ImpBufferLoc;
  return ;
}

/*---------------------------------------------------------------------
  Interne Funktion:   TabImpTrpFile
  Beschreibung :      Importiert Teilbaum von Tabellen
                 liest die Baumtransportdatei, die die Namen
                 der Dateien enth�lt, aus der Datei, deren Filepointer
                 in der req Schnittstelle uebergeben wird

  Input :  S_TCDIMPCTL ICTL
            TreeFNam: Name der Baumtransportdatei
  Output:  Tabellendaten
---------------------------------------------------------------------*/
static void     TabImpTrpFile ( P_TCDIMPORTSS req )
{
	S_TCDIMPORT ImpBufferLoc = {0};
   P_TCDIMPORT pImpBuffer = &(req->Private.ImpBuffer);

   if (!req->ICTL.fpTrpFile ) {
      req->ICTL.Rc = RC_FILE_ERROR ;
      return ;
   }
   ImpBufferLoc = *pImpBuffer;
   pImpBuffer->Buffer.File = req->ICTL.fpTrpFile ;
   TCD_TIMPORT (req) ;
   
   *pImpBuffer = ImpBufferLoc;
   return ;
}

/*---------------------------------------------------------------------
  Interne Funktion:   GetTabFile
  Beschreibung :     liest Tabellenname aus Datei
---------------------------------------------------------------------*/
static TCD_INT GetTabFile ( P_TCDIMPORT bp, char * buf )
{
   TCD_INT     c = 0 ;
   * buf = '\0' ;

   while ( ( c = ImpGetC(bp) ) != EOF ) {
       switch (c) {
          case '\r':      
                break ;                               
          case '\n':      
                * buf = '\0' ;
                return(c) ;
          default:
               * buf = (char) c ;
               buf ++;
       }
   }
   return (c);
}


/*---------------------------------------------------------------------
Interne Funktion:   ImportTabNode
Beschreibung :     Baut die Tabelleninformation auf
Input : S_TCDIMPCTL ICTL
Output: Knoteninformationsdaten werden im internen Format SS_TCDTABINFO
       abgelegt ; Aufrufer muss fuer Freigabe sorgen
---------------------------------------------------------------------*/
static void         ImportTabNode ( P_TCDIMPORTSS req )
{
   int             VersNr = 0;
   int             RelNr  = 0;
   P_TCDTABIMPDATA pData = NULL;
   P_TCDTABINFO    pInfo = NULL;
   TCD_INT         rc = 0;                           
   char *          token = req->Private.token;
   P_TCDIMPORT     pImpBuffer = &(req->Private.ImpBuffer);
/*-------------------------------------------------------------------*/
   if (! ChkVersion (&VersNr, &RelNr, &(req->Private))) {
         if (req->ICTL.Rc!=RC_FILE_ERROR) 
            req->ICTL.Rc = RC_VERS_CONF ;
         return ;
    }
/*-------------------------------------------------------------------*/
    if (! req->Data.pTabData) {
    pData = (P_TCDTABIMPDATA)  _TCDALLOC (1, sizeof(S_TCDTABIMPDATA)) ;
    if (! pData) {
         req->ICTL.Rc = RC_NOMEM ;
         return ;
    }
    memset ( pData , 0, sizeof(S_TCDTABIMPDATA) );
    req->Data.pTabData = pData;
    }
/*-------------------------------------------------------------------*/
    pInfo = (P_TCDTABINFO)  _TCDALLOC (1, sizeof(S_TCDTABINFO)) ;
    if (! pInfo) {
         req->ICTL.Rc = RC_NOMEM ;
         return ;
    }
    memset ( pInfo , 0, sizeof(S_TCDTABINFO) );
    req->Data.pTabData->pTabInfo =  pInfo ;

   do  {
     rc = ImpGetC( pImpBuffer ) ;
   } while ( rc != EOF && rc != '?' && rc != '&') ;

   if (req->ICTL.Rc == RC_FILE_ERROR) goto exit_eof;

/*-------------------------------------------------------------------*/
   GetTabPathNam (req ) ;
   if (req->ICTL.Rc == RC_FILE_ERROR) goto exit_eof ;
/*-------------------------------------------------------------------*/
   NEXT_TOKEN_rc("&")
   if (rc == EOF) goto exit_eof ;
   req->Data.pTabData->pTabInfo->NodeId = atol(&token[1]);
/*-------------------------------------------------------------------*/
   GetTabInfo (req) ;
   if (req->ICTL.Rc == RC_FILE_ERROR) goto exit_eof ;
/*-------------------------------------------------------------------*/
   GetTabAttr (req) ;
   if (req->ICTL.Rc == RC_FILE_ERROR) goto exit_eof ;
/*-------------------------------------------------------------------*/
   GetTabText  (req) ;
   if (req->ICTL.Rc == RC_FILE_ERROR) goto exit_eof ;
/*-------------------------------------------------------------------*/
   return ;
   
exit_eof :
   if (req->ICTL.Rc != RC_FILE_ERROR)
      req->ICTL.Rc = RC_ILLEGAL_IMPORT ;
   return ;
}


/*---------------------------------------------------------------------
  Interne Funktion:   ChkVersion
  Beschreibung :    ueberprueft, ob Datei eine Versionsangabe enthaelt
  Input :   -
  Return :  Ergebnis der Ueberpruefung
---------------------------------------------------------------------*/
static TCD_BOOL     ChkVersion (int *VersNr, int *RelNr, 
                                P_PRIVATE pPrivate)
{                              
   P_TCDIMPORT pImpBuffer = &(pPrivate->ImpBuffer);
   int         ch = ImpGetC( pImpBuffer ) ;

   if (ch == EOF) return (TCD_FALSE) ;

   if (ch != '%') {
      /* wenn als erstes Zeichen kein %-kommt fehlt Versionsangabe */
      return (TCD_FALSE) ;
   }

   /* das 2. Zeichen muss ein @ sein */
   ch = ImpGetC( pImpBuffer ) ;
   if (ch != '@') {
      return (TCD_FALSE) ;
   }
   while (ch != ')' ) {
      ch = ImpGetC( pImpBuffer ) ;
      if (ch == EOF) return (TCD_FALSE) ;
   }

  /*-------------------------------------------------------------------
     Lesen der Versionsnummer
   ------------------------------------------------------------------*/
   *VersNr = GetVersNr (pImpBuffer) ;

  /*-------------------------------------------------------------------
     Lesen der Releasenummer
   ------------------------------------------------------------------*/
   *RelNr = GetVersNr (pImpBuffer) ;

   do  {
     ch = ImpGetC( pImpBuffer ) ;
   } while ( ch != EOF && ch != '@') ;

    return (TCD_TRUE) ;

}

static int GetVersNr (P_TCDIMPORT pImpBuffer)
{
   static char NumBuf [5] ;
   int rc = RC_OK ;
   int i  = 0 ;               

   for (i= 0; i < 4 && rc != EOF; i++) {
      rc = ImpGetC( pImpBuffer ) ;
      NumBuf [i] = (char) rc ;
   }
   NumBuf [i] = 0 ;
   return (atoi(NumBuf)) ;
}


/*---------------------------------------------------------------------
  Interne Funktion:   GetTabPathNam
  Beschreibung : 1. Baut die Tabellenpfadinformation auf
  Input :  S_TCDIMPCTL ICTL
  Output:  Knotenionformationsdaten im internen Format S_TCDNDDATA
---------------------------------------------------------------------*/
static void         GetTabPathNam ( P_TCDIMPORTSS req )
{
	S_TCDPATHDATA   PathEntry = {0};
   TCD_INT         rc = 0 ;
   char SuchString[] ="#&";       
   char *          token = req->Private.token;         
   P_TCDIMPORT 	   pImpBuffer = &(req->Private.ImpBuffer);

   while (rc != '&' && rc != EOF) {
     NEXT_TOKEN_rc(SuchString)
     strcpy (PathEntry.Path, token) ;
     AppendPath (&PathEntry,&(req->Data.pTabData->pTabInfo->PathData),
                 &(req->Data.pTabData->pTabInfo->AnzPathEnt)) ;
   }
  return ;
}

/*---------------------------------------------------------------------
  Interne Funktion:   GetTabInfo
  Beschreibung :      Holt sich die Tabelleninformationen
  Input :  S_TCDIMPCTL ICTL
  Output:  Knotenionformationsdaten im internen Format S_TCDNDDATA
---------------------------------------------------------------------*/
static void         GetTabInfo ( P_TCDIMPORTSS req )
{
   TCD_INT         rc = 0 ;                              
   char *          token = req->Private.token;
   P_TCDIMPORT 	   pImpBuffer = &(req->Private.ImpBuffer);

   /*------------------------------------------------------------------
     AnzSpalten
   ------------------------------------------------------------------*/
   NEXT_TOKEN_rc("#")
/* AnzSpalten    */
   req->Data.pTabData->pTabInfo->AnzSpalten = atoi (token) ;

   /*------------------------------------------------------------------
     AnzZeilen
   ------------------------------------------------------------------*/
/* AnzZeilen   */
   NEXT_TOKEN_rc("#")
   req->Data.pTabData->pTabInfo->AnzZeilen = atoi (token) ;

   /*------------------------------------------------------------------
     AnzStellen
   ------------------------------------------------------------------*/
   NEXT_TOKEN_rc("#")
/* AnzStellen    */
   req->Data.pTabData->pTabInfo->AnzStellen = atoi (token) ;

   /*------------------------------------------------------------------
     AnzNKStellen
   ------------------------------------------------------------------*/
   NEXT_TOKEN_rc("&#")
/* AnzStellen    */
   req->Data.pTabData->pTabInfo->AnzNkStellen = atoi (token) ;
}

/*---------------------------------------------------------------------
  Interne Funktion:   GetTabAttr
  Beschreibung :      Baut die Attributinformation auf
  Input :  S_TCDIMPCTL ICTL
  Output:  Knotenionformationsdaten im internen Format S_TCDNDDATA
---------------------------------------------------------------------*/
static void         GetTabAttr ( P_TCDIMPORTSS req )
{
	S_TCDTABATTRDATA AttrData = {0} ;  /* Zeiger auf Knotenattribute  */
   TCD_INT          rc = 0 ;
   char *           token = req->Private.token;
   P_TCDIMPORT      pImpBuffer = &(req->Private.ImpBuffer);

   while (rc != '!' && rc != EOF && rc != '&') {
         NEXT_TOKEN_rc("!#&*")
         strcpy (AttrData.Name, token) ;
         if (rc == '#')
         {
          NEXT_TOKEN_rc("!#&*")
          strcpy (AttrData.Value, token) ;
         }
         else
         {
         *(AttrData.Value) = '\0';
         }
         AppendTabAttr (&AttrData, req->Data.pTabData->pTabInfo) ;
   }
  return ;
}


static void         GetTabText ( P_TCDIMPORTSS req )
{
  TCD_INT     len = 0;
  TCD_INT     rc = 0; 
  char *      token = req->Private.token;
  P_TCDIMPORT pImpBuffer = &(req->Private.ImpBuffer);
  /*-------------------------------------------------------------------
     Kommentar
   ------------------------------------------------------------------*/
   NEXT_TOKEN_rc ("&")
   len = strlen(token);

   if (len)
   {      
     req->Data.pTabData->pTabInfo->Desc = 
           _TCDALLOC((len+1), sizeof(char)) ;
     if (req->Data.pTabData->pTabInfo->Desc == 0) return ;
     strcpy (req->Data.pTabData->pTabInfo->Desc, token);
   }
   else
     req->Data.pTabData->pTabInfo->Desc = 0;

   while ((req->Private.ScanLen) == -1)
   { /* ueberlies restlichen Kommentar */
     NEXT_TOKEN_rc ("&")
   }
   return ;
}


/*---------------------------------------------------------------------
Externe Funktion:   TCDIMP_R
Beschreibung : Freigabe des Speichers, der von den Auspraegungsroutinen
              allokiert wurde
Input :  S_TCDIMPCTL ICTL
        ImpBuffer - Puffer mit den Import-Daten
Output:  -
---------------------------------------------------------------------*/
void                TCDIMPR ( P_TCDIMPORTSS req)
{
   switch ( req->ICTL.Typ ) {
       case TCD_IMPTYP_PROC :
            if (req->Data.pProcData) {
                _TCDFREE (req->Data.pProcData) ;
                req->Data.pProcData = 0;
            } ;
            break ;

       case TCD_IMPTYP_TAB1:
       case TCD_IMPTYP_TAB2:
            if (req->Data.pTabData->TabValues) {
                _TCDTABFREE (req->Data.pTabData->TabValues) ;
            }
            req->Data.pTabData->TabValues = 0;
            break ;

       case TCD_IMPTYP_NODE :
            break ;
   }
}

#define NEXT_TOKEN_TIMPORT NEXT_TOKEN \
                           if (req->ICTL.Rc==RC_FILE_ERROR) \
                           goto exit_inv_imptyp;

/*---------------------------------------------------------------------
  Interne Funktion:   TCD_TIMPORT
  Beschreibung : 1. allokiert Speicher fuer die Tabellenadministartion
                    und die Tabelle selbst
                 2. importiert eine Tabelle
  Input :  S_TCDIMPCTL ICTL
  Output:  CTL.pTabData zeigt auf die Tabellenadministration
---------------------------------------------------------------------*/
static TCD_INT      TCD_TIMPORT ( P_TCDIMPORTSS req )
{
   TCD_LONG        fields  = 0;
   TCD_INT         rc      = 0;
   TCD_INT         Zeile   = 0;
   TCD_INT         Spalte  = 0;
   TCD_INT         linelen = 0;
   TCD_DOUBLE      wert    = 0.0;
   TCD_DOUBLE      faktor  = 0.0;
   TCD_LONG        tabid   = 0;
   P_TCDTAB        pTab    = NULL;
   int             VersNr  = 0;
   int             RelNr   = 0;
   char *          cpSavedPos = NULL ;
   long            lFtell  = 0;
   P_TCDIMPORT     pImpBuffer = &(req->Private.ImpBuffer);
   char *          token = req->Private.token;
   
   req->ICTL.Rc       = RC_OK ;
   
   req->Data.pTabData = NULL;                              
   
   /* gegenw�rtige Dateiposition merken 
      und TabellenInformationen mit vorhandener Funktion einlesen */
   /* ECB - 28.09.97 - kein ftell/fseek bei memory-Import */
   if ( pImpBuffer->Type != TCD_MEM )
      lFtell = ftell(pImpBuffer->Buffer.File);
   else
      cpSavedPos = pImpBuffer->Buffer.Mem ;

   ImportTabNode(req);

   /* Dateiposition wiederherstellen und Tabelle selbst einlesen */    
   /* ECB - 28.09.97 - kein ftell/fseek bei memory-Import */
   if ( pImpBuffer->Type != TCD_MEM )
      fseek(pImpBuffer->Buffer.File,lFtell,SEEK_SET);
   else
      pImpBuffer->Buffer.Mem = cpSavedPos ;
/*---------------------------------------------------------------------
   Versionsangaben ueberpruefen
---------------------------------------------------------------------*/
    if (! ChkVersion (&VersNr, &RelNr, &(req->Private))) 
    {         
         VersNr = 0 ;
         RelNr = 0 ;
         rc = '&';
    }

   if (VersNr > 0 && RelNr > 0) 
   {
      rc = ImpGetC( pImpBuffer );
   }
   
   if ( rc != '&' ) 
      goto exit_inv_imptyp;

   for( rc = ImpGetC( pImpBuffer ); rc != EOF && rc != '&'; 
        rc = ImpGetC( pImpBuffer ) ) 
      ;

   if ( rc != '&' ) 
      goto exit_inv_imptyp;
   
   rc = ImpGetC( pImpBuffer );
   
   if ( rc != '?' ) 
      goto exit_inv_imptyp;

/*---------------------------------------------------------------------
  Tabellenid
---------------------------------------------------------------------*/
   rc = 0 ;
   while ( ( token[rc] = (char)ImpGetC( pImpBuffer ) ) != '&' )
      ++rc ;
      
   token[rc] = '\0' ;
   tabid = atol(token) ;
   req->ICTL.ID = tabid ;

   if ( rc == 0 ) 
      goto exit_inv_imptyp;

/*---------------------------------------------------------------------
  Bestimmen der Dimension aus der Anzahl der Spalten
---------------------------------------------------------------------*/
   rc = 0 ;
   NEXT_TOKEN_TIMPORT                            
   
   rc = atoi(token);                           
   switch (rc)  
   {
       case 0 :

           req->ICTL.Rc  = RC_INV_IMPTYP ;
           fields        = 0;
           req->ICTL.Dim = req->ICTL.Typ = 0 ;
           
           return RC_SYS_ERROR ;           

       case 1:
           fields        = req->ICTL.AnzZeilen ;
           linelen       = 1;
           req->ICTL.Dim = req->ICTL.Typ = 1 ;
           
           break ;

       default:
           fields        = req->ICTL.AnzZeilen * req->ICTL.AnzSpalten;
           linelen       = req->ICTL.AnzSpalten ;
           req->ICTL.Dim = req->ICTL.Typ = 2 ;
           
           break ;
   }
                                                  
   if ( fields == 0 ) 
   {
        req->ICTL.Rc = RC_EOT ;
        return (RC_SYS_ERROR) ;
   }

   req->ICTL.AnzTabData = (TCD_INT) fields ;

/*---------------------------------------------------------------------
  Anzahl der Zeilen
---------------------------------------------------------------------*/
   rc = 0 ;
   NEXT_TOKEN_TIMPORT
   rc = atoi(token) ;

   switch (rc)  
   {
      case 0 :
         req->ICTL.Rc = RC_INV_IMPTYP ;
         return RC_SYS_ERROR ;

      default:
         if ( rc > req->ICTL.AnzZeilen ) 
            req->ICTL.Rc = RC_ROW_TRUNCATED ;
   }


  /* Speicher f�r die gesamte Tabelle anfordern  */
   pTab = (P_TCDTAB)_TCDTABALLOC((TCD_INT)fields,sizeof(TCD_DOUBLE));
   
   if ( pTab == NULL )
   {
       req->ICTL.Rc = RC_SYS_ERROR ;
       return (RC_SYS_ERROR) ;
   }
   
   _TCDMEMINI(pTab,sizeof(TCD_DOUBLE),(size_t)fields);
   req->Data.pTabData->TabValues = pTab ;

/*---------------------------------------------------------------------
   Anzahl Stellen
---------------------------------------------------------------------*/
      NEXT_TOKEN_TIMPORT
/*---------------------------------------------------------------------
   Nachkommastellen
---------------------------------------------------------------------*/
   rc = 0 ;
   while ( ( token[rc] = (char)ImpGetC( pImpBuffer ) ) != '&' )
      ++ rc ;
   token[rc] = '\0' ;

   rc = atoi(token) ;

   faktor = 10 ;
   rc *= -1 ;
   faktor = pow (faktor, rc) ;

/*---------------------------------------------------------------------
   Faktor wird auf 1 normiert
---------------------------------------------------------------------*/
   if (VersNr >= 1) 
   {
      faktor = 1;
   }
/*------------------------------------------------------------------
   Skip rest of header:
   frueher fscanf( Stream, "%*[^&]&%*[^&]&" ) ;
------------------------------------------------------------------*/
   for( rc = ImpGetC( pImpBuffer );rc != EOF && rc != '&';
        rc = ImpGetC( pImpBuffer ) )
      ;

   if ( rc != '&' ) 
      goto exit_inv_imptyp;
   
   for( rc = ImpGetC( pImpBuffer );rc != EOF && rc != '&';
        rc = ImpGetC( pImpBuffer ) )
      ;
   
   if ( rc != '&' ) 
      goto exit_inv_imptyp;

/*---------------------------------------------------------------------
   Tabelle lesen
---------------------------------------------------------------------*/
   
   while ( rc != EOF ) 
   {
       NEXT_TOKEN_TIMPORT
       Spalte = atoi( token ) ;
       if ( Spalte == TCDCIMP_TABSTOP) 
       /* ueberlesen CRLF und naechstes # */
       {
          NEXT_TOKEN_TIMPORT
          NEXT_TOKEN_TIMPORT
          continue ;
       }
       if ( Spalte >= req->ICTL.AnzSpalten ) 
       {
          if ( req->ICTL.Rc != RC_COL_TRUNCATED                     && 
               req->ICTL.Rc != (RC_ROW_TRUNCATED + RC_COL_TRUNCATED) )
             req->ICTL.Rc += RC_COL_TRUNCATED;
          
          NEXT_TOKEN_TIMPORT  /* Zeile �berlesen */
          NEXT_TOKEN_TIMPORT  /* Wert  �berlesen */
          continue;   
       }
       NEXT_TOKEN_TIMPORT
       Zeile = atoi( token ) ;                 
       if ( Zeile >= req->ICTL.AnzZeilen ) 
       {
          if ( req->ICTL.Rc != RC_ROW_TRUNCATED                     &&
               req->ICTL.Rc != (RC_ROW_TRUNCATED + RC_COL_TRUNCATED) )
             req->ICTL.Rc += RC_ROW_TRUNCATED;
          
          NEXT_TOKEN_TIMPORT  /* Wert �berlesen */
          continue;
       }  
       NEXT_TOKEN_TIMPORT
       wert = atof( token ) ;
       pTab [Zeile * linelen + Spalte] = wert * faktor ;
   }
   return (req->ICTL.Rc ) ;


/* Fehlerausgang */
exit_inv_imptyp:
   if (req->ICTL.Rc!=RC_FILE_ERROR) 
      req->ICTL.Rc = RC_INV_IMPTYP ;
   return (RC_SYS_ERROR) ;
}


/*---------------------------------------------------------------------
  Interne Funktion:   TCD_AIMPORT
  Beschreibung : 1. Lie�t die Transprotdatei einer Auspr�gung
           2. Baut die BelegInfo Array auf.
           3. Baut die RelAttrs auf
  Input :  S_TCDIMPCTL ICTL
  Output:  Auspr�gungsdaten im internen Format S_TCDPRCDATA
---------------------------------------------------------------------*/
static void         TCD_AIMPORT ( P_TCDIMPORTSS req )
{
   P_TCDPRCELEM    mem = NULL;
   S_TCDPRCHDR *   pPrcHdr = NULL;
   P_TCDIMPORT     pImpBuffer = &(req->Private.ImpBuffer);

   TCD_INT         VersNr = 0;
   TCD_INT         RelNr  = 0;
   TCD_INT         rc     = 0;
   TCD_INT         i      = 0;
   TCD_INT         index  = 0;

   req->ICTL.Rc  = RC_OK ;
   req->ICTL.Dim = 0;

   /* Versionscheck */
   req->ICTL.pRefProc = req->Private.PathBuf;
   if (! ChkVersion (&VersNr, &RelNr, &(req->Private)))
   {
         VersNr = 0 ;
         RelNr = 0 ;
         rc = '%';
   }
   if (VersNr > 0 && RelNr > 0)
   {
      rc = ImpGetC( pImpBuffer );
      rc = ImpUnGetC( rc, pImpBuffer );
   }

   if (req->ICTL.Rc==RC_FILE_ERROR) 
      return;

   if ( rc != '%')
   {                 
       if (SkipProcHeader (pImpBuffer) != RC_OK)
       {
           if (req->ICTL.Rc!=RC_FILE_ERROR) 
               req->ICTL.Rc = RC_INV_IMPTYP ;
           return ;
       }
   }
   rc = ImpGetC( pImpBuffer ); 
   if (req->ICTL.Rc==RC_FILE_ERROR) 
      return;

   /* Transportdatei einlesen,die einzelnen Teilstrukturen aufbauen */
   ReadFile ( req ) ;
   if ( req->ICTL.Rc != RC_OK )
       return ;

   pPrcHdr             = &(req->Data.pProcData[0].TreeHdr) ;
   pPrcHdr->FlPrcCompl = req->Private.PrcBelegCmpl ;


   pPrcHdr->FormelNr = 
          req->Data.pProcData[1].Node.AssignVal.Formel.FormelNr;

   /* Auspraegung, Beleginfo und RelAttrs Struktur zusammenfassen */
   {
      long lReallocSize = 0;  
      
      if (req->ICTL.Option != TCD_OHNE_BELEGLISTE)

           lReallocSize = (sizeof(U_TCDPRCELEM)     * 
                          (pPrcHdr->AnzPrcTree      + 
                           pPrcHdr->AnzBelegInfo))  +
                          (sizeof(S_TCDRELATTR_IMP) * 
                          pPrcHdr->AnzRelAttrs      );
      
      else lReallocSize = sizeof(U_TCDPRCELEM)      * 
                          (pPrcHdr->AnzPrcTree )    +
                          (sizeof(S_TCDRELATTR_IMP) * 
                          pPrcHdr->AnzRelAttrs) ;

      mem=(void *)
          _TCDREALLOC(req->Data.pProcData,(size_t)lReallocSize);
   }

   /* Fehlerbehandlung  */
   if ( mem == 0 )
   {
       _TCDFREE( req->Data.pProcData ) ;
       _TCDFREE( req->Private.pInfo ) ;
       if ( req->Private.pRelAttrs) _TCDFREE( req->Private.pRelAttrs);

       req->ICTL.Rc = RC_SYS_ERROR ;
       return ;
   }

   /* Reinitialisierung pPrcHdr nach Realloc */
   {
      long lOffset = 0;

      req->Data.pProcData = (P_TCDPRCELEM)mem;
      pPrcHdr             = &(req->Data.pProcData[0].TreeHdr) ;
      pPrcHdr->FormelNr   = 
             req->Data.pProcData[1].Node.AssignVal.Formel.FormelNr;

      lOffset = pPrcHdr->AnzPrcTree;

      switch (req->ICTL.Option)
      {
         case TCD_OHNE_BELEGLISTE :
            pPrcHdr->AnzBelegInfo = 0;
            break ;

         default:
            memcpy(&mem[pPrcHdr->AnzPrcTree ],
                    req->Private.pInfo,
                    sizeof(U_TCDPRCELEM) * pPrcHdr->AnzBelegInfo ) ;
            lOffset += pPrcHdr->AnzBelegInfo;
      }

      if (req->Private.pInfo )
        _TCDFREE( req->Private.pInfo ) ;

      if ( req->Private.pRelAttrs )
      {
         memcpy((void *)&mem[lOffset],req->Private.pRelAttrs,
                 sizeof(S_TCDRELATTR_IMP) * pPrcHdr->AnzRelAttrs);
         _TCDFREE( req->Private.pRelAttrs);
      }
   }

/*---------------------------------------------------------------------
MUB: Ist BelegInfo[Index] mit Tabelle belegt, wird der TabIndex 
dort um die Anzahl der vorhandenen Knoten der BV erh�ht
(wozu auch immer ... )

Indizes innerhalb BelegInfo um Offset der Auspr�gung erh�hen
---------------------------------------------------------------------*/
   index = pPrcHdr->AnzPrcTree + pPrcHdr->AnzBelegInfo ;

   while ( -- index > pPrcHdr->AnzPrcTree )
   {
       if ( req->Data.pProcData[index].Info.TabIx )
            req->Data.pProcData[index].Info.TabIx += 
            pPrcHdr->AnzPrcTree ;
   }
   req->ICTL.ID = pPrcHdr->PrcID;
   return ;
}

/*---------------------------------------------------------------------
Interne Funktion:   NodeOrProcImport
Beschreibung :      Importschnittstelle f�r Teilbaumimport
Input :             S_TCDIMPCTL ICTL
                    int bReadProcData ==> 1 IMPORT mit BV-Daten
                                          0 IMPORT ohne BV-Daten
Output:             Knoteninformationsdaten werden in der S_TCDNDDATA
                  abgelegt.
                  Auspr�gungsdaten werden in der Struktur S_TCDPROCDATA
                  abgelegt.
IN/OUTPUT:          Der Status zeigt an, in welchem zustand der Knoten-
                  import sich befindet:
                  INIT: Status, der anzeigt, dass der import das erste
                        Mal aufgerufen wird (IN). Nach einem Init
                        ist die Knoteninfo abgelegt und die Daten
                        zur 1. Auspr�gung (sofern es eine gibt)
                  NODE: zeigt an, dass als naechstes ein Knoteninfo
                        importiert wird (INOUT)
                  PROC: zeigt an, dass als naechstes eine Auspraegung
                        importiert wird (INOUT). Gibt es unter dem
                        Knoten keine Auspraegung mehr, wird der Status
                        auf NODE, wenn nachfolgend noch Knoten kommen
                        ansonsten auf EOF. Die Knotendaten werden bei
                        naechsten Importaufruf geliefert.
                        geliefert.
                  EOF:  nichts mehr zu importieren
---------------------------------------------------------------------*/
static TCD_INT      NodeOrProcImport ( P_TCDIMPORTSS req, 
                                       int bReadProcData)
{
    if (req->ICTL.Status == TCD_IMPSTAT_INIT) 
    {
        req->Data.pNodeData = DConstrImpNode(); 
        if (req->Data.pNodeData == NULL)
		  {
				req->Private.pSavePtr = NULL ;
            return (TCD_RC_INTERNAL_ERR);
		  }

		  /* Zeiger fuer spaetere Freigabe merken, 
		     da er zwischendurch veraendert wird */
		  req->Private.pSavePtr = (void*)req->Data.pNodeData ;
    
        GroupBeginGet (req) ;
    }
    
    if (req->ICTL.Status == TCD_IMPSTAT_NODE) 
    {
        NodeImport (req) ;
        return (RC_OK) ;
    }
    
    if (req->ICTL.Status == TCD_IMPSTAT_PROC) 
    {
        
        /*----------------------------------------------------------*/
        /* Sollen die BV-Daten mitgelesen werden ?                  */
        /*----------------------------------------------------------*/
        if ( bReadProcData == 0)
           GetProc(req, 0);
        else
          GetProc(req, 1);
    
        if (req->ICTL.Status == TCD_IMPSTAT_NODE)
            NodeImport (req) ;
        
        return (RC_OK) ;
    }
    return (req->ICTL.Status) ;
}


/*---------------------------------------------------------------------
  Interne Funktion:   NodeImport
  Beschreibung :     Baut die Knoteninformation auf
  Input : S_TCDIMPCTL ICTL
  Output: Knoteninformationsdaten werden im internen Format S_TCDNDDATA
          abgelegt
---------------------------------------------------------------------*/
static void         NodeImport ( P_TCDIMPORTSS req )
{
   TCD_INT         rc = 0;
/*---------------------------------------------------------------------
   Alle Komponeneten des Knotens werden freigegebne und anschlie�end
   wieder initialisiert, KAT 26.08.96
---------------------------------------------------------------------*/
   SDestrImpNode ( req->Data.pNodeData );
   SConstrImpNode( req->Data.pNodeData );
/*---------------------------------------------------------------------
   Knoteninfos gruppenweise einlesen, dabei werden die einzelnen
   Teilstrukturen aufgebaut
---------------------------------------------------------------------*/
   rc = GroupBeginGet (req) ;
   if (req->ICTL.Status == TCD_IMPSTAT_EOF) return;
   if (rc == 'P') {
       GetNodePathNam (req ) ;
       rc = GroupBeginGet (req) ;
   }
   if (rc == 'I') {
      GetNodeIdent (req) ;
       rc = GroupBeginGet (req) ;
   }
   if (rc == 'A') {
      GetNodeAttr (req) ;
      rc = GroupBeginGet (req) ;
   }
   if (rc == 'T') {
      GetNodeText (req) ;
      rc = GroupBeginGet (req) ;
   }

   if (rc == 'O') {
      req->ICTL.Status = TCD_IMPSTAT_PROC ;
   }

   req->ICTL.Typ = TCD_IMPTYP_NODE;

   return ;
}


/*---------------------------------------------------------------------
Interne Funktion:   GetProc
Beschreibung : liest die Auspraegungsspezifischen Daten (ID und Name)
               bildet daraus den Dateinamen und importiert die Auspr-
Input :  S_TCDIMPCTL ICTL
Output:  Knoteninformationsdaten werden im internen Format S_TCDNDDATA
       abgelegt
---------------------------------------------------------------------*/
static int GetProc ( P_TCDIMPORTSS req, int bReadProcData)
{
  char ProcName [DOS_NAME_LNG] ;
  S_TCDIMPORT ImpBufferLoc = {0};
  TCD_LONG ProcID = 0;
  TCD_INT rc      = 0;           
  char *          token = req->Private.token;
  P_TCDIMPORT pImpBuffer = &(req->Private.ImpBuffer);
  
   

   rc = GetData(pImpBuffer,token) ;

   if (rc == '!')  {
      req->ICTL.Status = TCD_IMPSTAT_NODE ;
      return (rc) ;
   }

   if (rc == EOF) {
      req->ICTL.Status = TCD_IMPSTAT_EOF ;
      return (rc);
   }

  /*-------------------------------------------------------------------
     Auspr�gungsname
   ------------------------------------------------------------------*/
   strcpy (ProcName, token) ;
   strcpy ( req->ICTL.Name, token) ;

  /*-------------------------------------------------------------------
     Auspr�gungsID
   ------------------------------------------------------------------*/
   rc = GetData(pImpBuffer,token) ;   /* ID der Auspr.  */
   if (req->ICTL.Rc == RC_FILE_ERROR)
      return(RC_FILE_ERROR);
   ProcID = atol(token) ;
                                  
   /*----------------------------------------------------------------*/
   /* Falls keine BV-Daten geslen werden sollen ==> fertig !         */
   /*----------------------------------------------------------------*/

   if ( bReadProcData == 0)
   {
     req->ICTL.Typ = TCD_IMPTYP_PROC;
     req->ICTL.ID = ProcID;
     return rc;
   }
                               
                                  
  /*-------------------------------------------------------------------
     Filepointer fuer Knotenimport sichern, Auspraeg. import aufrufen
   ------------------------------------------------------------------*/
   ImpBufferLoc = *pImpBuffer;
   req->ICTL.Typ = TCD_IMPTYP_PROC; 
   rc = ImportProc (req, ProcName, ProcID) ;
   *pImpBuffer = ImpBufferLoc;
   return (rc);
}


/*---------------------------------------------------------------------
  Interne Funktion:   ImportProc

  Aufruf Import einer Auspraegung aus dem Knotenimport
  bildet den Dateinamen aus dem Namen der Auspraegung,
  oeffnet die Datei und importiert die Auspraegung
  Input : S_TCDIMPCTL ICTL
  Output: Knoteninformationsdaten werden im internen Format S_TCDNDDATA
           abgelegt
---------------------------------------------------------------------*/
static int          ImportProc (P_TCDIMPORTSS req, char * ProcFNam, 
                                TCD_LONG ProcID)
{
  TCD_INT  rc = RC_OK ;
  P_TCDIMPORT pImpBuffer = &(req->Private.ImpBuffer);

  if ( req->ICTL.Option == TCD_COPY_TRPFILE  
       &&
       ! req->ICTL.ChckFkt (req->ICTL.Name)
     )
     return rc;

  if (req->ICTL.Option == TCD_IMP_TRPFILE)  {
      if (req->ICTL.ChckFkt (req->ICTL.Name)) {
          TCDIMPF  (req, req->ICTL.fpTrpFile,ProcFNam) ;
      }
     return rc ;
  }

  /*-------------------------------------------------------------------
     Erzeugen des FileNamens aus dem Auspr�gungsnamen und dem FileNamen
   ------------------------------------------------------------------*/
  MakeProcFName (ProcFNam, ProcID, req->Private.TCDImpTreeFNam);
  /*-------------------------------------------------------------------
     Oeffnen des FileNamens aus dem Auspr�gungsnamen und dem FileNamen
   ------------------------------------------------------------------*/
  strcpy ( pImpBuffer->FileName, ProcFNam );
  pImpBuffer->Buffer.File = fopen (ProcFNam, "r") ;
  pImpBuffer->pImportSS = req;
  if (pImpBuffer->Buffer.File == NULL) {
     req->ICTL.Rc = RC_FILE_ERROR ;
     req->ICTL.Errno = 0;  
     strcpy ( req->ICTL.ErrFileName, ProcFNam );
     return (RC_SYS_ERROR) ;
  }
  if ( req->ICTL.Option == TCD_COPY_TRPFILE )
      CopyFile ( req->ICTL.fpTrpFile,  pImpBuffer->Buffer.File);
  else
  {
    rc = SkipProcHeader (pImpBuffer);
    if (rc == RC_OK) {
        TCD_AIMPORT (req) ;
    }
  }
  fclose (pImpBuffer->Buffer.File) ;
  return (rc) ;
}



/*---------------------------------------------------------------------
  Interne Funktion:   MakeProcFName
  Beschreibung :     bildet den FileNamen des Files, das die zu
                     importierende Auspraegung enthaelt.
  Input : S_TCDIMPCTL ICTL
  Output: Knoteninformationsdaten werden im internen Format S_TCDNDDATA
          abgelegt
---------------------------------------------------------------------*/
static void         MakeProcFName (char * ProcFNam, TCD_LONG ProcID,
								   char * ImpTreeFNam)
{
  char * Ptr = NULL;
  TCD_INT Pos = 0;

  strcpy (ProcFNam, ImpTreeFNam) ;
  Ptr = strrchr (ProcFNam, (int) '\\')  ;
  Pos = (TCD_INT) (Ptr - ProcFNam) + 1 ;
  ProcFNam[Pos] = 0;
  strcat (ProcFNam, "prc");
  Pos = strlen (ProcFNam);
  sprintf (&ProcFNam[Pos], "%x", ProcID) ;
  strcat (ProcFNam, ".0") ;
}

/*---------------------------------------------------------------------
  Interne Funktion:   SkipProcHeader
  Beschreibung :     springt ueber den Header der Auspraegung

                     22.12.95, RON: �bertr�gt Pfadname einer
                     referenzierten Proc in Path-Buffer
                     '!' im Proc-Header trennt Pfadnamen der Tabs
                     von folgenden Parametern. Parameter '!1!'
                     ist der Pfadname der referenzierten Proc.
                     Andere Parameter k�nnen hinzugef�gt werden.
                     dem '!1!' folgt noch die L�nge des Pfadnamens:
                     '!1!<Laenge>!<Pfadname>'


  Input :  S_TCDIMPCTL ICTL
  Output: Knoteninformationsdaten werden im internen Format S_TCDNDDATA
           abgelegt
---------------------------------------------------------------------*/
static int     SkipProcHeader (P_TCDIMPORT pImpBuffer)
{
   TCD_INT c = 0;

   while ( c != EOF && c != '%')
     c = ImpGetC( pImpBuffer ) ;

   if (c == '%')
   {
    ImpUnGetC( c , pImpBuffer );
    return (RC_OK) ;
   }
   return (EOF) ;
}


/*---------------------------------------------------------------------
  Interne Funktion:   GetNodePathNam
  Beschreibung : 1. Baut die Knoteninformation auf
  Input :  S_TCDIMPCTL ICTL
  Output:  Knotenionformationsdaten im internen Format S_TCDNDDATA
---------------------------------------------------------------------*/
static void         GetNodePathNam ( P_TCDIMPORTSS req )
{
	S_TCDPATHDATA   PathEntry = {0};
   TCD_INT         rc = 0 ;
   P_TCDIMPORT     pImpBuffer = &(req->Private.ImpBuffer);
   char *          token = req->Private.token;

   rc = GetData(pImpBuffer,token) ;
   while (rc != '!' && rc != EOF) {
         strcpy (PathEntry.Path, token) ;
         AppendPath (&PathEntry, &(req->Data.pNodeData->PathData),
                     &(req->Data.pNodeData->AnzPathEnt)) ;
         rc = GetData(pImpBuffer,token) ;
   }
  return ;
}

/*---------------------------------------------------------------------
  Interne Funktion:   GetNodeAttr
  Beschreibung :      Baut die Attributinformation auf
  Input :  S_TCDIMPCTL ICTL
  Output:  Knotenionformationsdaten im internen Format S_TCDNDDATA
---------------------------------------------------------------------*/
static void         GetNodeAttr ( P_TCDIMPORTSS req )
{
	S_TCDATTRDATA   AttrData ={0} ; /* Zeiger auf Knotenattribute  */
   TCD_INT         rc = 0 ;
   P_TCDIMPORT     pImpBuffer = &(req->Private.ImpBuffer);
   char *          token = req->Private.token;
   

   rc = GetData(pImpBuffer,token) ;

   while (rc != '!' && rc != EOF) {
         strcpy (AttrData.Name, token) ;
         rc = GetData(pImpBuffer,token) ;
         if (rc==EOF) break;
         strcpy (AttrData.Value, token) ;
         rc = GetData(pImpBuffer,token) ;
         if (rc==EOF) break;
         strcpy (AttrData.DefValue, token) ;
         AppendAttr (&AttrData, req->Data.pNodeData) ;
         rc = GetData(pImpBuffer,token) ;
   }
  return ;
}


/*---------------------------------------------------------------------
  Interne Funktion:   GroupBeginGet
  Beschreibung :      liest in der Transportdatei bis zum Beginn einer
                      Gruppe und liefert das Gruppenkennzeichen als
                      Returnwert.
                      Falls es kein Gruppenbeginn gibt, wird EOF
                      zur�ckgeliefert.
  Input :  S_TCDIMPCTL ICTL
---------------------------------------------------------------------*/
static int          GroupBeginGet ( P_TCDIMPORTSS req )
{
   TCD_INT rc = 0 ;          
   P_TCDIMPORT pImpBuffer = &(req->Private.ImpBuffer);
   
   while ( rc != EOF && rc != '?' && rc != '&') {
     rc = ImpGetC( pImpBuffer ) ;
   }

   if (rc == '?') {
       return (ImpGetC( pImpBuffer )) ;
   }

   if (rc == '&') {
      req->ICTL.Status = TCD_IMPSTAT_NODE ;
      return (rc) ;
   }
   if (rc == EOF) {
      req->ICTL.Status = TCD_IMPSTAT_EOF ;
      return (rc) ;
   }

   return (rc) ;
}

/*---------------------------------------------------------------------
  Interne Funktion:   GroupEndGet
  Beschreibung :      liest in der Transportdatei bis zum Beginn einer
                      Gruppe und liefert das Gruppenkennzeichen als
                      Returnwert.
                      Falls es kein Gruppenbeginn gibt, wird EOF
                      zur�ckgeliefert.
  Input :  S_TCDIMPCTL ICTL
---------------------------------------------------------------------*/
static int          GroupEndGet (P_TCDIMPORT pImpBuffer)
{
   TCD_INT rc = 0 ;          

   while ( rc != EOF && rc != '!') {
     rc = ImpGetC( pImpBuffer ) ;
   }
   return (rc);
}


/*---------------------------------------------------------------------
  Interne Funktion:   GetNodeIdent
  Beschreibung :      Liest die knotenidentifizierenden Daten aus
                      der Transportdatei in die Importstruktur
  Input :  S_TCDIMPCTL ICTL
  Output:  Knotenionformationsdaten im internen Format S_TCDNDDATA
---------------------------------------------------------------------*/
static void         GetNodeIdent ( P_TCDIMPORTSS req )
{
   TCD_INT rc ;
   P_TCDIMPORT pImpBuffer = &(req->Private.ImpBuffer);
   char *      token = req->Private.token;

   /*------------------------------------------------------------------
     KnotenName
---------------------------------------------------------------------*/
   rc = GetData(pImpBuffer,token) ;   /* Knoten Name */      
   if (rc==EOF) return;
   strcpy (req->Data.pNodeData->NodeName, token);

   /*------------------------------------------------------------------
     KnotenID
   ------------------------------------------------------------------*/
   rc = GetData(pImpBuffer,token) ; /*  Knoten ID */
   if (rc==EOF) return;
   req->Data.pNodeData->NodeId   = atol(token);

   /*------------------------------------------------------------------
     KnotenTyp
   ------------------------------------------------------------------*/
   rc = GetData(pImpBuffer,token) ;   /* Knoten Typ  */
   if (rc==EOF) return;
   strcpy (req->Data.pNodeData->NodeTyp, token);

   /*------------------------------------------------------------------
     KnotenTypID
   ------------------------------------------------------------------*/
   rc = GetData(pImpBuffer,token) ; /*  Knoten Typ ID */
   if (rc==EOF) return;
   req->Data.pNodeData->NodeTypId     = atol(token);

   GroupEndGet (pImpBuffer) ;
   return ;
}


/*---------------------------------------------------------------------
  Interne Funktion:   GetNodeText
  Beschreibung :      Liest den Knotentext , zun�chst die L�nge des
                      Kommentars und dann den Kommentar selbst
  Input :  S_TCDIMPCTL ICTL
  Output:  Knotenionformationsdaten im internen Format S_TCDNDDATA
---------------------------------------------------------------------*/
static void         GetNodeText ( P_TCDIMPORTSS req )
{
   TCD_INT    len = 0;
   TCD_INT    c   = 0;     
   P_TCDIMPORT pImpBuffer = &(req->Private.ImpBuffer);
   char *           token = req->Private.token;
   char * pDesc = NULL;
   int i=0;

   /* Kommentarlenge */
   c   = GetData(pImpBuffer,token) ; 
   if (c==EOF) return;
   len = atoi (token) +1 ;
   
   /* Speicher fuer Knoten-Kommentar anlegen */
   req->Data.pNodeData->Desc = _TCDALLOC((len+1), sizeof(char));
   if ( req->Data.pNodeData->Desc == NULL )
      return ;
   /* den Anfang merken und intialisieren */
   pDesc = req->Data.pNodeData->Desc;
   *pDesc = '\0';
   
/* Das Einlesen des Kommentars mit der normalen Routine GetData() 
 f�hrt zu fehlerhaftem Verhalten des restlichen Imports, 
 wenn der Kommentar Zeichen wie %,?,# enthaelt 
 Der gesamte Kommentar mu� unbesehen seines Inhalts gelesen 
 werden
    
 c = GetData(&ImpBuffer,token);
*/

/* 05.Aug.2004:
   Ist der Kommentar laenger als MAX_TOKEN_SIZE so kommt es
   zum Ueberlauf, wenn der Umweg ueber den token gemacht wird.
   Deshlab wird der Kommentar jetzt direkt in den dafuer
   reservierten Speicher gelesen
*/

   for ( i=0; i < len; i++ )
   {
        *(pDesc+i) = (char) ImpGetC(pImpBuffer);
        if (req->ICTL.Rc == RC_FILE_ERROR)
           return;
   }
   *(pDesc+i) = '\0';

   /* Endekennzeichen lesen */
   GroupEndGet (pImpBuffer) ;
   return ;
}

/*---------------------------------------------------------------------
  Interne Funktion:   AppendPath
  Beschreibung :     h�ngt einen Pfadeintrag an die Liste der Pfadnamen
                     der Transportdatei in die Importstruktur
  Input :  S_TCDIMPCTL ICTL
  Output:  Knotenionformationsdaten im internen Format S_TCDNDDATA
---------------------------------------------------------------------*/
static TCD_INT      AppendPath (S_TCDPATHDATA *token, 
                                S_TCDPATHDATA **pPathData,
                                TCD_INT *Anz )
{
   S_TCDPATHDATA  * Adr = NULL;
   TCD_INT          i = 0;
   TCD_INT          len = 0;
   TCD_INT          oldlen = 0; 

   i = *Anz                           ;
   len    = (i + 1 ) * sizeof(S_TCDPATHDATA) ;
   oldlen = i        * sizeof(S_TCDPATHDATA) ;

   if (i == 0) 
   {
        *pPathData = (S_TCDPATHDATA *) 
        _TCDALLOC(1,sizeof(S_TCDPATHDATA)); 
        if ( *pPathData == 0) return 0 ;
   }
   else 
   {
       *pPathData = (S_TCDPATHDATA *) _TCDREALLOC (*pPathData, len) ;

       if ( *pPathData == 0) 
       {
           _TCDFREE( *pPathData) ;
           return (0) ;
       }
   }
   Adr = (S_TCDPATHDATA *) &((*pPathData) [i]) ;  
   *Adr = (*token) ;
   *Anz = *Anz + 1; 
   
   return (TCD_RC_OK) ;
}



static TCD_INT      AppendAttr (S_TCDATTRDATA * AttrData,
                            P_TCDNODEDATA pNodeData)
{
   S_TCDATTRDATA * Adr = NULL;
   TCD_INT i = 0;
   TCD_INT len = 0;
   TCD_INT oldlen = 0;

   i = pNodeData->AnzAttrInfo ; 
   len = (i + 1 ) * sizeof(S_TCDATTRDATA) ;
   oldlen = i * sizeof(S_TCDATTRDATA) ;

   if (i == 0) {
        pNodeData->AttrData = (S_TCDATTRDATA *) _TCDALLOC(1, 
                               sizeof(S_TCDATTRDATA)) ;
        if ( pNodeData->AttrData == 0) return 0 ;
   }
   else {
       pNodeData->AttrData =
         (S_TCDATTRDATA *) _TCDREALLOC (pNodeData->AttrData, len) ;

       if ( pNodeData->AttrData == 0) {
           _TCDFREE( pNodeData->AttrData) ;
           return (0) ;
       }
   }

   Adr = (S_TCDATTRDATA *) &(pNodeData->AttrData [i ])     ; /* RON */
   * Adr = (* AttrData) ;
   pNodeData->AnzAttrInfo ++ ;
   return (TCD_RC_OK) ;
}



static TCD_INT      AppendTabAttr (S_TCDTABATTRDATA * AttrData,
                              P_TCDTABINFO      pTabInfo )
{
   S_TCDTABATTRDATA * Adr = NULL;
   TCD_INT i = 0;
   TCD_INT len = 0;
   TCD_INT oldlen = 0;

   i = pTabInfo->AnzAttrInfo          ;
   len = (i + 1 ) * sizeof(S_TCDTABATTRDATA) ;
   oldlen = i * sizeof(S_TCDTABATTRDATA) ;

   if (i == 0) {
        pTabInfo->AttrData = (S_TCDTABATTRDATA *)
                               _TCDALLOC(1, sizeof(S_TCDTABATTRDATA));
        if ( pTabInfo->AttrData == 0) return 0 ;
   }
   else {
       pTabInfo->AttrData =
         (S_TCDTABATTRDATA *) _TCDREALLOC (pTabInfo->AttrData, len) ;

       if ( pTabInfo->AttrData == 0) {
           _TCDFREE( pTabInfo->AttrData) ;
           return (0) ;
       }
   }

   Adr = (S_TCDTABATTRDATA *) &(pTabInfo->AttrData [i]) ; 
   * Adr = (* AttrData) ;
   pTabInfo->AnzAttrInfo ++ ;
   return (TCD_RC_OK) ;
}

/* ------------------------------------------------------------------
  Interne Funktion    Scan
  Liest ein Element vom Eingabestream.
  Input :   Stream
  Output:   Name des Elements
------------------------------------------------------------------  */
static TCD_INT      Scan ( P_TCDIMPORT bp, char * buf , 
                           char * compstr , int * len)
{
   TCD_INT     c = 0;
   char *  pc1 = buf ;

   * buf = '\0' ;

   while ( ( c = ImpGetC(bp) ) != EOF )
   {
       if ( c == '%' )
       {
           /* Sonderbehandlung letztes Element */
           if ( * pc1 == '\0' )
              return EOF ;
           else
           {
               ImpUnGetC( c, bp ) ;
               break ;
           }
       }

       if ( c == '\n')
           continue;

       if ( strchr( compstr, c) )   
           break ;

       *  buf = (char) c ;
       (* len) --;
       if (! (* len) ) { (* len) = -1; return c;}
       ++ buf ;
   } /* while */

   * buf = '\0' ;

   return c ;
} /* Scan */


/* ------------------------------------------------------------------
  Interne Funktion    GetData
  Bemerk:  Lie�t ein Datenelement, das durch # und $ begrenzt wird
           und legt es in buf ab. (ohne die Begrenzungszeichen)
  Input :  Stream
  Output:  Name des Elements

-------------------------------------------------------------------  */
static TCD_INT      GetData( P_TCDIMPORT bp,
                      char *       buf ) 
{
   TCD_INT c = 0;
   char *  pc1 = buf ;

   * buf = '\0' ;

   c = ImpGetC(bp) ;
   if (c == '#') 
   {
      while ( ( c = ImpGetC(bp) ) != EOF ) 
      {
         if ( c == '%' ) 
         {
            /* Sonderbehandlung letztes Element  */
            if ( *pc1 == '\0' )
            {
               return EOF ;
            }
            else 
            {
               ImpUnGetC( c, bp ) ;
               break ;
            }
         } 
         else
         {
            if ( c == '$' )
               break ;
          
            *buf = (char) c ;
            ++ buf ;
         }
      
      }  /* while  */
   
   }  /* if c == # */

   *buf = '\0' ;
   return c ;
}

/*---------------------------------------------------------------------
  Interne Funktion:   InsertBelegInfo
  Beschreibung :      Erzeugt BelegInfo Array.
  Input :  S_TCDIMPCTL ICTL
  Output:  Array um ein Element erweitert.
---------------------------------------------------------------------*/
static TCD_INT      InsertBelegInfo ( const P_TCDPRCINFO Info,
                                   P_TCDIMPORTSS   req ) 
{
   TCD_INT             index = 0;
   S_TCDPRCHDR  * pPrcHdr = NULL;

   pPrcHdr = &(req->Data.pProcData[0].TreeHdr) ;

   /* Beleginformation der Tabelle suchen */
   if ( Info->Formattyp == TCD_ATTRFMT_TAB1 ||
        Info->Formattyp == TCD_ATTRFMT_TAB2   ) {
       index = pPrcHdr->AnzBelegInfo ;
       while ( -- index > 0 ) {
           if (req->Private.pInfo [index].Info.ID == Info->RefNodeId){
               Info->TabIx = index ;
               break ;
           }
       }
   }

   /* Belegung merken: In Info->AnzBeleg steht der AssingTyp */
   if ( Info->AnzBeleg > 0 )
        Info->AnzBeleg = 1 ;


   /* Attribut suchen */
   index = pPrcHdr->AnzBelegInfo ;
   while ( -- index > 0 ) {
       if ( req->Private.pInfo [index].Info.ID == Info->ID &&
            req->Private.pInfo [index].Info.Typ == Info->Typ )
           break ;
   }

   /* Falls noch nicht vorhanden, Platz f�r neues Element schaffen */
   if ( index <= 0 ) {
      req->Private.pInfo = 
      				(P_TCDPRCELEM) ExpandMem ( req->Private.pInfo,
                     pPrcHdr->AnzBelegInfo ,
                     pPrcHdr->AnzBelegInfo + 1 ) ;
      if ( req->Private.pInfo == 0 )
          return (RC_SYS_ERROR) ;

      index = pPrcHdr->AnzBelegInfo ;
      ++ pPrcHdr->AnzBelegInfo ;
      req->Private.pInfo [index].Info = (* Info) ;
   }
   else {
      req->Private.pInfo [index].Info.AnzBeleg *= Info->AnzBeleg ;
   }

   /* Falls belegt, dann RefNodeId �bernehmen */
   if ( Info->AnzBeleg )
      req->Private.pInfo [index].Info.RefNodeId = Info->RefNodeId ;

   /* Falls Bestandsattribut und belegt: 
      Belegungsinfo im Header updaten */

   if (Info->Klasse == TCD_ATTRKL_BST   &&
       Info->AnzBeleg > 0) {

       switch (Info->Formattyp) {
            case TCD_ATTRFMT_TAB1 :
            case TCD_ATTRFMT_TAB2 :
                 pPrcHdr->FlSetAttrTab = TCD_TRUE ;
                 break ;
            case TCD_ATTRFMT_SKAL :
                 pPrcHdr->FlSetAttrSkal = TCD_TRUE ;
                 break ;
            case TCD_ATTRFMT_VGLO :
                 pPrcHdr->FlSetAttrVgl = TCD_TRUE ;
                 break ;
            case TCD_ATTRFMT_DATE :
                 pPrcHdr->FlSetAttrDat = TCD_TRUE ;
                 break ;
       }
   }

   return (RC_OK) ;
}


/*---------------------------------------------------------------------
  Interne Funktion:   InsertNode
  Beschreibung:       Erweitert die Auspr�gung.
  Input :  S_TCDIMPCTL ICTL
  Output:  Array um ein Element erweitert.
---------------------------------------------------------------------*/
static TCD_INT      InsertNode ( const P_TCDPRCNODE Node,
                              P_TCDIMPORTSS       req )
{
   S_TCDPRCHDR  * pPrcHdr = NULL;

   pPrcHdr = &(req->Data.pProcData[0].TreeHdr) ;
   /* Platz f�r einen neuen Knoten schaffen */
   req->Data.pProcData = (P_TCDPRCELEM) ExpandMem( req->Data.pProcData,
                          pPrcHdr->AnzPrcTree,pPrcHdr->AnzPrcTree + 1);

   if ( req->Data.pProcData == 0 ) {
       req->ICTL.Rc = RC_SYS_ERROR ;
       return (RC_SYS_ERROR) ;
   }

   pPrcHdr = &(req->Data.pProcData[0].TreeHdr) ;

   req->Data.pProcData [pPrcHdr->AnzPrcTree].Node = * Node ;
   pPrcHdr->AnzPrcTree ++   ;

   return (RC_OK);
}


/*---------------------------------------------------------------------
  Interne Funktion:   InsertRelAttrs
  Beschreibung :      Erzeugt das RelAttrs  Array.
  Input :             S_TCDIMPCTL ICTL
                      index:      Referenznummer des Knotens
                      Data :      Datenelement, das in die RelAttrs
                                  Struktur �bernommen wird
---------------------------------------------------------------------*/
static TCD_INT InsertRelAttrs  ( const P_TCDRELATTR_IMP Data  ,
                                 P_TCDIMPORTSS          req   ,
                                 TCD_INT  *             RelAttrsIx)
{
   S_TCDPRCHDR  * pPrcHdr = NULL;

   pPrcHdr   = &(req->Data.pProcData[0].TreeHdr) ;
   req->Private.pRelAttrs = (P_TCDRELATTR_IMP) AllocRelAttrs (
                	req->Private.pRelAttrs, pPrcHdr->AnzRelAttrs,
                	pPrcHdr->AnzRelAttrs+1);

   if ( req->Private.pRelAttrs == 0 )
       return RC_SYS_ERROR ;

   *RelAttrsIx = pPrcHdr->AnzRelAttrs;
   req->Private.pRelAttrs[*RelAttrsIx] = (* Data) ;

   pPrcHdr->AnzRelAttrs++;
   return (RC_OK) ;
}

/* ------------------------------------------------------------------
    Interne Funktion    AllocRelAttrs
    
    AllocRelAttrs macht pro RelAttr genau einen      
    realloc. Das fragmentiert den Speicher mehr als     
    notwendig w�re.                                     
------------------------------------------------------------------  */
static void *       AllocRelAttrs ( void *  pp,
                                    TCD_INT anz_alt,
                                    TCD_INT anz_neu )
{
   void * mem = NULL;

   if ( anz_neu <= anz_alt )
       return 0;

   /* Platz f�r neue Elemente schaffen */
   if ( anz_alt == 0 )
   {
       mem = _TCDALLOC( anz_neu, sizeof(S_TCDRELATTR_IMP));
   }
   else
   {
       mem = _TCDREALLOC ( pp, sizeof(S_TCDRELATTR_IMP) * anz_neu ) ;
       if ( mem == 0 )
       {
           _TCDFREE( pp ) ;
       }
   }

   if ( mem == 0 )
       return 0 ;

   memset(& ((P_TCDRELATTR_IMP)mem)[anz_alt],0,
              sizeof(S_TCDRELATTR_IMP) * (anz_neu - anz_alt) );
   return (mem) ;
}

/* ------------------------------------------------------------------
  Interne Funktion    ReadFile
  Bemerk:  Lie�t die Transprotdatei einer Auspr�gung
  Input :  S_TCDIMPCTL ICTL
  Output:  Auspr�gungsdaten im internen Format S_TCDPRCDATA
------------------------------------------------------------------  */
static TCD_INT      ReadFile ( P_TCDIMPORTSS req )
{
   S_TCDPRCHDR * pPrcHdr = NULL;
   char *        token = req->Private.token;
   TCD_INT       count = 0;
   TCD_INT       rc    = 0;       
   P_TCDIMPORT   pImpBuffer = &(req->Private.ImpBuffer);

   req->Data.pProcData = (P_TCDPRCELEM)
        ExpandMem ( req->Data.pProcData, 0, 1 ) ;

   if ( req->Data.pProcData == 0 )
   {
       req->ICTL.Rc = RC_SYS_ERROR ;
       return req->ICTL.Rc ;
   }
   pPrcHdr = &(req->Data.pProcData[0].TreeHdr) ;

   pPrcHdr->AnzPrcTree   = 1 ;
   pPrcHdr->AnzBelegInfo = 0 ;
   pPrcHdr->AnzRelAttrs  = 0 ;

   pPrcHdr->FlSetAttrSkal = TCD_FALSE ;
   pPrcHdr->FlSetAttrTab  = TCD_FALSE ;
   pPrcHdr->FlSetAttrVgl  = TCD_FALSE ;
   pPrcHdr->FlSetAttrDat  = TCD_FALSE ;
   pPrcHdr->FlPrcCompl    = TCD_FALSE ;
   pPrcHdr->PrcResIx      = -1 ;
   pPrcHdr->PrcCallNr     = 0;

   /* Ersten '#' �berlesen */
   NEXT_TOKEN

   /* Proc-Id lesen */
   NEXT_TOKEN
   if ( token[0] != TCD_PREFIX_PRC )
   {
       if (req->ICTL.Rc!=RC_FILE_ERROR) 
          req->ICTL.Rc = RC_INV_IMPTYP ;
       return req->ICTL.Rc ;
   }
   pPrcHdr->PrcID = atol( & token[1] ) ;

   count = 1 ;
   rc = TCD_RC_OK ;

   while ( rc != EOF )
   {
   /* -------------------------------------------------------------
   NEXT_TOKEN
   geht hier nicht, weil Makro mit unmittelbarem Return f�r c=='%'
   ------------------------------------------------------------ */

       if ( (rc = (Scan(pImpBuffer,token,"#",
                        &(req->Private.ScanLen)))) == EOF )
          break;

       rc = GetNode ( req, token ) ;
   }
   /* Nur Relevante Attribute extrahieren, wenn alles OK war ... */
   rc = TCD_RC_OK ;
   if ( req->ICTL.Rc == RC_OK )
       rc = ExtractRelAttrs(pImpBuffer,req);
   
   if (req->ICTL.Rc != RC_FILE_ERROR)
      req->ICTL.Rc = rc;

   return req->ICTL.Rc ;
}
     

#define NEXT_TOKEN_IN_GET_NODE      NEXT_TOKEN \
                                    if (req->ICTL.Rc==RC_FILE_ERROR) \
                                      return EOF;

#define TCDSTRCPY(s)				{char *c = strchr(token,'@'); \
									if (c!=NULL) *c=0; \
									strcpy(s,token);};

/* ------------------------------------------------------------------
  Interne Funktion:   GetNode
  Bemerk:  Lie�t eine Zeile der Transportdatei.
  Input :  FILE *
  Output:  Ausgabearray wird mit realloc um ein Element vergr��ert.
------------------------------------------------------------------  */
static TCD_INT      GetNode ( P_TCDIMPORTSS req,
                              char *        token )
{
   TCD_INT         rc      = 0;
   TCD_INT         RefNum  = 0;
   TCD_INT         CallTyp = 0;
   TCD_INT         NodeNum = 0;   
   S_TCDPRCINFO    Info = {0};
   S_TCDPRCINFO    TInfo = {0};
   S_TCDPRCNODE    node = {0};
   S_TCDRELATTR    RelAttr = {0};
   P_TCDIMPORT     pImpBuffer = &(req->Private.ImpBuffer);

   /* number sons */
   node.AnzSuccNodes = atoi( token ) ;

   /* index of first son */
   NEXT_TOKEN_IN_GET_NODE                

   node.SuccNodeIx = atoi( token ) - 1;

   /* node class */
   NEXT_TOKEN_IN_GET_NODE
   Info.Klasse = atoi( token ) ;

   /* node number: Nicht aufsteigend. */
   NEXT_TOKEN_IN_GET_NODE
   node.NodeID = atoi(token);

   NodeNum =  atoi( token ) ;
   if (NodeNum == 1)
   {
       if (Info.Klasse == 1)
       {
           req->Private.PrcBelegCmpl = TCD_TRUE ;
       }
       else
       {
          req->Private.PrcBelegCmpl = TCD_FALSE ;
       }
   }

   /* attr id */
   NEXT_TOKEN_IN_GET_NODE
   node.AttrID = atol( token ) ;
   Info.ID = node.AttrID ;

   /* node type */
   NEXT_TOKEN_IN_GET_NODE
   node.AttrType = atoi( token ) ;
   Info.Formattyp = node.AttrType ;

   /* node name */
   NEXT_TOKEN_IN_GET_NODE
   strcpy( Info.Name, token ) ;

   /* reference number */
   NEXT_TOKEN_IN_GET_NODE
   RefNum = atoi( token ) ;

   /* usage */
   NEXT_TOKEN_IN_GET_NODE
   node.Usage = atoi( token ) ;

   /* Type-dependent-data */
   NEXT_TOKEN_IN_GET_NODE
   node.AssignType = atoi( token ) ;
   Info.AnzBeleg = node.AssignType ;  /* Flag f�r InsertBelegInfo */
                                      /* Vorbelegung Aufruftyp */
   CallTyp = 0       ;

   switch ( node.AssignType )
   {
       /* Procedure */
       case TCD_DC_USE_PRC :
           /* Proc ID */
           NEXT_TOKEN_IN_GET_NODE
           node.AssignVal.Prc.PrcID = atol( & token[1] ) ;

           /* Proc-Name */
           NEXT_TOKEN_IN_GET_NODE
           /* not used */

           /* Formel ID */
           NEXT_TOKEN_IN_GET_NODE
           node.AssignVal.Prc.FormelNr = atol( token );	   
           node.AssignVal.Prc.FormelIx = -1;

           /* Formel Name */
           NEXT_TOKEN_IN_GET_NODE
		   TCDSTRCPY(node.AssignVal.Prc.FormelName)

           break ;
       /* Tabelle */
       case TCD_DC_USE_TAB :
           Info.Typ = TCD_DC_USE_TAB ;
           TInfo = Info ;

           /* Umsetzung auf Typ Skal. Unterscheidung �ber Formattyp */
           node.AssignType = TCD_DC_USE_VAL ;

           /* Tabellen ID */
           NEXT_TOKEN_IN_GET_NODE
           if ( token[0] != TCD_PREFIX_TAB )
           {
               req->ICTL.Rc = RC_INV_IMPTYP ;
               return EOF ;
           }
           node.AssignVal.Val.TabData.TabID = atol( & token[1] ) ;
           TInfo.ID = node.AssignVal.Val.TabData.TabID ;

           /* Tabellen Name */
           NEXT_TOKEN_IN_GET_NODE
           strcpy( TInfo.Name, token ) ;

           /* Tabelle in BelegInfo eintragen */
           TInfo.Typ = TCD_PREFIX_TAB ;
           TInfo.AnzBeleg = 0 ;
           rc = InsertBelegInfo ( & TInfo, req ) ;
           if ( rc != RC_OK )
           {               
               if (req->ICTL.Rc != RC_FILE_ERROR)
                  req->ICTL.Rc = RC_SYS_ERROR ;
               return EOF ;
           }
           /* Merker f�r InsertBelegInfo */
           Info.RefNodeId = TInfo.ID ;
           break ;
       /* Wert */
       case TCD_DC_USE_VAL :
           /* Anzahl Vorkomma */
           NEXT_TOKEN_IN_GET_NODE
           /* not used */

           /* Anzahl Nachkomma */
           NEXT_TOKEN_IN_GET_NODE
           /* not used */

           /* Wertangabe */
           NEXT_TOKEN_IN_GET_NODE

           switch (node.AttrType)
           {
               case TCD_ATTRFMT_DATE :
                  strcpy (node.AssignVal.Val.Datum,    token ) ;
                  break ;

               case TCD_ATTRFMT_VGLO :
                  strcpy (node.AssignVal.Val.VglOp, token ) ;
                  break ;

               default :
                  node.AssignVal.Val.Skalar = atof( token ) ;
           }
           break ;
       /* Formel */
       case TCD_DC_USE_FRM :
           /* Call Typ */

           NEXT_TOKEN_IN_GET_NODE
           CallTyp = atoi ( token )  ;
           /* Zur Erkennung ob eine statische Referenz vorliegt */
           if ( (CallTyp == TCD_CALLTYP_STA) || 
                (CallTyp == TCD_CALLTYP_STA_UE) )
                node.AssignVal.Formel.IsStaRef = CallTyp;
           else node.AssignVal.Formel.IsStaRef = 0;     

           /* Formel ID */
           NEXT_TOKEN_IN_GET_NODE
           node.AssignVal.Formel.FormelNr = atol( token ) ;

           /* Formel Index */
           node.AssignVal.Formel.FormelIx = -1 ;

           /* Formel Name */
           NEXT_TOKEN_IN_GET_NODE
#if TCDVERS > 25
           /* Formel Version */
		   {
			   char *c = strchr(token,'@'); 
			   node.AssignVal.Prc.FormelVers = 0;
			   if (c!=NULL) 
				   node.AssignVal.Prc.FormelVers=atol(++c);
		   }
#endif
		   /* Formel Name */
		   TCDSTRCPY(node.AssignVal.Formel.FormelName)
           break ;

       default :
           ;
   }

   if (node.AttrID == Info.ID &&
       node.AssignType != 0 )
   {
       Info.RefNodeId = req->Data.pProcData[0].TreeHdr.AnzPrcTree ;
   }
   else
   {
       Info.RefNodeId = -1 ;
   }

   if (CallTyp != TCD_CALLTYP_STA &&
       CallTyp != TCD_CALLTYP_STA_UE)
   {
       rc = InsertBelegInfo ( & Info, req ) ;
       if ( rc != RC_OK )
       {
           if (req->ICTL.Rc!=RC_FILE_ERROR)
              req->ICTL.Rc = RC_SYS_ERROR ;
           return EOF ;
       }
   }

   if ( node.AssignType != 0)
   {
       rc = InsertNode ( & node, req ) ;
       if ( rc != RC_OK )
       {
           if (req->ICTL.Rc!=RC_FILE_ERROR)
              req->ICTL.Rc = RC_SYS_ERROR ;
           return EOF ;
       }
   }

   return RC_OK ;

} /* GetNode */


  /* ------------------------------------------------------------------
  Interne Funktion    ExpandMem
  Bemerk:  Allokiert ein zus�tzliches Arrayelement.
  Input :  Pointer auf erstes Arrayelement.
           Anzahl an Elementen
  Output:  Neuer Poitner.
           0   Fehler
  ------------------------------------------------------------------ */
static void *       ExpandMem ( void *    pp,
                          TCD_INT         anz_alt,
                          TCD_INT         anz_neu )
{
   void *      mem = NULL;

   if ( anz_neu <= anz_alt )
       return 0;

   /* Platz f�r neue Elemente schaffen */
   if ( anz_alt == 0 )
   {
       mem = _TCDALLOC( anz_neu, sizeof(U_TCDPRCELEM) ) ;
   }
   else
   {
       mem = _TCDREALLOC ( pp, sizeof(U_TCDPRCELEM) * anz_neu ) ;
       if ( mem == 0 )
       {
           _TCDFREE( pp ) ;
       }
   }

   if ( mem == 0 )
       return 0 ;

   memset( & (((P_TCDPRCELEM) mem) [anz_alt]), 0,
           sizeof(U_TCDPRCELEM) * (anz_neu - anz_alt) );

   return (mem) ;
}

/* ------------------------------------------------------------------
  Interne Funktion    ImpGetC
  Bemerk:  liefert das naechste Zeichen des Importpuffers
          (File oder Memory )
  Input :  Importpuffer
  Output:  naechstes Zeichen
------------------------------------------------------------------   */
static TCD_INT      ImpGetC( P_TCDIMPORT pBuffer )
{
   TCD_INT c = 0;
   if ( pBuffer->Type == TCD_FILE )
   {
      c = fgetc( pBuffer->Buffer.File );
      if ( c == EOF ) {
          /* Ende oder Error */
          if ( !feof ( pBuffer->Buffer.File ) ) {
              /* kein Ende, also Error */
              pBuffer->pImportSS->ICTL.Errno = 
                  ferror ( pBuffer->Buffer.File );
              pBuffer->pImportSS->ICTL.Rc = RC_FILE_ERROR;
              strcpy ( pBuffer->pImportSS->ICTL.ErrFileName, 
                       pBuffer->FileName );
          }    
      }
      goto exit;
   }

   /* pBuffer->Type == TCD_MEM */
   c = (TCD_INT) *pBuffer->Buffer.Mem++;
	if (c == 0)
	{
		c = EOF;
	}
exit:
   return ( c );
}
/* --------------------------------------------------------------------
  Interne Funktion    CopyFile
  Bemerk:  Liest Datei fp_src und �bertr�gt sie nach
           Datei mit Filepointer fp_trg
  Input :  Importpuffer
  Output:  naechstes Zeichen
------------------------------------------------------------------  */
void                CopyFile(FILE *fp_trg, FILE* fp_src)
{

   TCD_INT c = 0;

   while ( (c = fgetc( fp_src ))  != EOF )
      fputc( c, fp_trg );      
}

/* ------------------------------------------------------------------
  Interne Funktion    ImpUnGetC
  Bemerk:  siehe ungetc
  Input :  Importpuffer
  Output:  naechstes Zeichen
------------------------------------------------------------------  */
static TCD_INT      ImpUnGetC( TCD_INT c,
                      P_TCDIMPORT pBuffer ) 
{
   TCD_INT rc = 0;
   if ( pBuffer->Type == TCD_FILE )
   {
      rc = ungetc( c, pBuffer->Buffer.File );
      if ( c == EOF ) {
     /* Ende oder Error */
     if ( !feof ( pBuffer->Buffer.File ) ) {
         /* kein Ende, also Error */
         pBuffer->pImportSS->ICTL.Errno = 
             ferror ( pBuffer->Buffer.File );
         pBuffer->pImportSS->ICTL.Rc = RC_FILE_ERROR;
         strcpy ( pBuffer->pImportSS->ICTL.ErrFileName, 
                  pBuffer->FileName );
     }    
      }
      return rc;
   }

   pBuffer->Buffer.Mem--;
   *pBuffer->Buffer.Mem = (char) c;
   rc = c;

   return ( rc );
}


#ifdef DUMP
/* --------------------------------------------------------------------
  Interne Funktion    ImpDump
  Bemerk:  Schreibt Informationen in eine Trace Datei.
  Input :  define IMPORT_TRACE_FILE = Stream der Ausgabedatei.
  Output:  Datei
------------------------------------------------------------------  */
static TCD_INT      ImpDump ( P_TCDIMPORTSS req )
{
   FILE *      fd = 0;
   time_t      ltime = 0;
   TCD_INT         index = 0;
   S_TCDPRCHDR     * pPrcHdr = NULL ;
   S_TCDPRCLOCD    * pData = NULL ;
   S_TCDPRCINFO    * pInfo = NULL ;
   S_TCDPRCNODE    * pNode = NULL;

   pPrcHdr = &(req->Data.pProcData[0].TreeHdr) ;

   fd = fopen( IMPORT_TRACE_FILE, "w" );
   if ( fd == 0 )
       return RC_SYS_ERROR ;

   time(&ltime) ;
   fprintf( fd, " TCD Import-Dump vom %s\n\n", ctime(&ltime) );

   fprintf( fd, "Auspraegung %ld = Index 0, Basisformel : %ld\n",
            pPrcHdr->PrcID, pPrcHdr->FormelNr) ;


  fprintf(fd,"Idx AtID Type ATyp Succ AnzS Use Type-dependent-data\n");
   index = 0 ;
   while ( index < pPrcHdr->AnzPrcTree ) {
       pNode = &(req->Data.pProcData[index].Node) ;
       fprintf( fd, "%3d %4ld %4s %4d %4d %4d %3d ",
                index,
                pNode->AttrID,
                SType(pNode->AttrType),
                (TCD_INT) pNode->AssignType,
                (TCD_INT) pNode->SuccNodeIx,
                (TCD_INT) pNode->AnzSuccNodes,
                (TCD_INT) pNode->Usage ) ;

       switch ( pNode->AssignType ) {
           case TCD_DC_USE_PRC :
                fprintf( fd, "PrcID: %4ld, FrmNr: %4ld, Name: %s\n",
                             pNode->AssignVal.Prc.PrcID,
                             pNode->AssignVal.Prc.FormelNr,
                             pNode->AssignVal.Prc.FormelName );
               break ;

           case TCD_DC_USE_VAL :

               switch( pNode->AttrType ) {
                   case TCD_ATTRFMT_TAB1 :
                   case TCD_ATTRFMT_TAB2 :
                        fprintf( fd, "TabID: %4ld\n",
                                 pNode->AssignVal.Val.TabData.TabID );
                        break ;

                   default:
                     fprintf( fd, "Wert = %lf\n",
                              pNode->AssignVal.Val.Skalar );
               }
               break ;

           case TCD_DC_USE_FRM :
                fprintf( fd, "FrmNr: %ld, Ix: %4d, Name: %s\n",
                             pNode->AssignVal.Formel.FormelNr,
                             0,
                             pNode->AssignVal.Formel.FormelName) ;
               break ;

           default :
              fprintf( fd, "No Assign-Type\n" );
       }
       ++ index ;
   } /* while */

   fprintf( fd, "\n**** BelegInfo ****\n" );
   fprintf( fd, "Idx ID   Frm Typ Bel Tbx RefN Kls Name\n" );

   while ( index < (pPrcHdr->AnzPrcTree + pPrcHdr->AnzBelegInfo) ) {

       pInfo = &(req->Data.pProcData[index].Info) ;

       fprintf( fd, "%3d %4ld %3d %3d %3d %3d %4ld %3d %s\n",
                index,
                pInfo->ID,
                pInfo->Formattyp,
                pInfo->Typ,
                pInfo->AnzBeleg,
                pInfo->TabIx,
                pInfo->RefNodeId,
                pInfo->Klasse,
                pInfo->Name ) ;
       ++ index ;
   } /* while */

   fprintf( fd, "\n**** Local Data ****\n" );
   fprintf( fd, "Idx FNr Typ\n" );

   fclose( fd ) ;
   return (RC_OK) ;
}

/* ------------------------------------------------------------------
  Interne Funktion    SType
  Bemerk:  Hilffunktion, wandelt Typ in String.
  Input :  NumTyp.
  Output:  String
------------------------------------------------------------------  */
static const char * SType ( TCD_INT Typ )
{
   switch( Typ )
   {
       case TCD_ATTRFMT_SKAL :
           return("SKAL");
       case TCD_ATTRFMT_TAB1 :
           return("TAB1");
       case TCD_ATTRFMT_TAB2 :
           return("TAB2");
       case TCD_ATTRFMT_VGLO :
           return("VGLO");
       case TCD_ATTRFMT_DATE :
           return("DATE");
   }
   return("????");
}
#endif /* DUMP */


/* ------------------------------------------------------------------
  Interne Funktion    ExtractRelAttrs :
   Holt die relevanten Attribute aus dem TransportFile und
   stellt sie in die ber�hmte Union
------------------------------------------------------------------  */
int           ExtractRelAttrs    (P_TCDIMPORT bp , P_TCDIMPORTSS req)
{

	S_TCDRELATTR_IMP RelAttr = {0};
   P_TCDPRCNODE     pNode  = NULL;

   TCD_INT          i               = 0;
   TCD_INT          iIndex          = 0;
   TCD_INT          iIndexSet       = 0;
   TCD_INT          iDummy          = 0;
   TCD_INT          iLevel          = 0;
   TCD_INT          iDatenElt       = 0;
   TCD_INT          iListenElt      = 0;
   TCD_INT          c ;

   TCD_LONG         NodeID          = 0;
   char             s[21];

   /* PRelAttrs vorher initialisieren: */
   req->Private.pRelAttrs = NULL;

   /* ueberlesen Konstante 'RELEV_ATTS, Vn.nn' */
   while ( (c=ImpGetC(bp)) != '{' && c != EOF ) ;

   do
   {
      switch ( c )
      {
     /* ---------------------------------------------------------------
        In diesem Fall fehlen die relevanten Attribute!
        Mit Fehler zur�ckkehren.
     --------------------------------------------------------------  */
         case EOF  :
            return TCD_RC_INTERNAL_ERR ;

         case '{'  :
            iLevel++;
            break;

         case '}'  :
            iLevel--;
            break;

         case ','  :
         case ' '  :
         case '\n' :
            break;

         default   :

            switch ( iLevel )
            {
               case DATEN       :

                  iDatenElt = 0;
                  i         = 0;
                  iIndexSet = 0;

                  /* DatenElemente holen */
                  while ( c != '{' ) /* Anfang der ggf. leeren Liste */
                  {
					  if (c == EOF)	
				            return TCD_RC_INTERNAL_ERR ;
                     /* Neues DatenElement */
                     if ( c == ',' )
                     {
                        s[i]='\0';
                        switch ( iDatenElt )
                        {
                       case 0:
                          /* BV-Knoten zur KnotenID holen */
                          NodeID=atol(s);

                          if ( (pNode =
                            FindNode(NodeID,
                             &req->Data.pProcData[1].Node,
                             req->Data.pProcData[0].TreeHdr.AnzPrcTree,
                             &iIndex)) == NULL )

                                return TCD_RC_INTERNAL_ERR ;
                           else break;

                           case 1:

                              /* KnotenTyp */
                              if ( pNode )
                                 pNode->iWiederVerwendungsTyp=atoi(s);
                              break;

                           case 2:

                              /* Laenge der WiederverwendungsListe */
                              if ( pNode )
                                pNode->iWiederVerwListenLaenge=atoi(s);

                              break;
                        }
                        iDatenElt++;
                        i=0;
                     }
                     else { s[i++]=(char)c; }
                     c=ImpGetC(bp);
                     if (req->ICTL.Rc==RC_FILE_ERROR) 
                        return TCD_RC_INTERNAL_ERR;
                  }
                  /* letztes Zeichen zuruckstellen */
                  ImpUnGetC(c,bp);
                  if (req->ICTL.Rc==RC_FILE_ERROR) 
                      return TCD_RC_INTERNAL_ERR;
                  break;

/* --------------------------------------------------------------------
  Aenderungen nach verkleinern der ImportStruktur TCDRELATTR :
  Es werden nur noch die AttrID und ggf. der Index f�r geerbte Werte
  gef�llt.
-------------------------------------------------------------------- */
               case LISTEN_ELT  :

                  iListenElt = 0;
                  i          = 0;

                  /* ListenElemente holen */
                  while ( c != '\0' )
                  {
					  if (c == EOF)	
				            return TCD_RC_INTERNAL_ERR ;
                     /* Neues ListenElement */
                     if ( c == ',' || c == '}' )
                     {
                        s[i]='\0';

                        /* Die einzelnen ListenElemente */
                        switch ( iListenElt )
                        {
                           case 0:
                              RelAttr.AttrID = atol(s);
                              break;

                           case 1:

                              RelAttr.AttrType = atoi(s);
                              break;
                        }

                        iListenElt++;
                        i=0;
                     }
                     else  s[i++]=(char)c;

                     /* ListenElement fertig */
                     if ( pNode && c == '}' )
                     {
                        RelAttr.iIndex       = -1;

                        if ( iListenElt == 1 ) 
                        /* nuur 1 Element, also KnotenID ErbListe */
                        {
/* ------------------------------------------------------------------
Wann gibt es keinen Knoten zur KnotenID der Erbliste ?

Es handelt sich um eine referenzierte BV, in der das Attribut belegt 
ist.
In der refenzierenden BV wird sie aber nur mit �berschreibung dieses
Attributes aufgerufen. Die Belegung dieses Knotens wird dann im 
BV-Editor aufgehoben und mit [..] gekennzeichnet.
Der AssignType wird zu 0 und damit wird der Knoten vom Import nicht 
in dieSchnittstelle �bernommen.
------------------------------------------------------------------  */

                           P_TCDPRCNODE pNode=FindNode(RelAttr.AttrID,
                             &req->Data.pProcData[1].Node,
                             req->Data.pProcData[0].TreeHdr.AnzPrcTree,
                             &RelAttr.iIndex);

/* ------------------------------------------------------------------
Es gibt keinen Knoten mit dieser KnotenID :
Die Funktion beendet sich mit TCD_RC_INTERNAL_ERR !
------------------------------------------------------------------  */
                           if ( pNode )
                           {
                                   RelAttr.AttrID   = pNode->AttrID;
                                   RelAttr.AttrType = pNode->AttrType;
                            }       
                            else 
							{
/*#pragma message( "Workaround f�r nicht vorhandene Erbknoten" ) */
								break;
								return TCD_RC_INTERNAL_ERR ;
							}
                        }

                        if ( (InsertRelAttrs ( &RelAttr,req,&iDummy))
                             != RC_OK )
                           return TCD_RC_INTERNAL_ERR ;

                        if ( !iIndexSet )
                        {
                           pNode->iFirstRelAttrIx=iDummy;
                           iIndexSet++;
                        }
                        memset((void *)&RelAttr,0,sizeof(RelAttr));
                        pNode->iAnzRelAttrs++;

                        break;
                     }
                     else {
                       c=ImpGetC(bp);
                       if (req->ICTL.Rc==RC_FILE_ERROR) 
                          return TCD_RC_INTERNAL_ERR;
                     }     

                  }  /* while ListenElemente */

                  ImpUnGetC(c,bp);
                  if (req->ICTL.Rc==RC_FILE_ERROR) 
                     return TCD_RC_INTERNAL_ERR;
                  break;

               default :
                  break;

            }  /* switch Level */
      }
      c=ImpGetC(bp);
      if (req->ICTL.Rc==RC_FILE_ERROR) 
           return TCD_RC_INTERNAL_ERR;
   }  while ( (iLevel > 0) && ( c != EOF) );

   /* letztes Zeichen zur�ckstellen */
   ImpUnGetC(c,bp);
   if (req->ICTL.Rc==RC_FILE_ERROR) 
      return TCD_RC_INTERNAL_ERR;
   return RC_OK ;
}


/* ------------------------------------------------------------------
  Interne Funktion    SConstrImpNode                       :
  alle Komponeneten von pImpNode werden mit NULL initialisiert
------------------------------------------------------------------  */
static int    SConstrImpNode( S_TCDNODEDATA *pImpNode)
{
    if (!pImpNode) return (TCD_RC_NOT_OK);
    
    pImpNode->NodeName [0] = 0;
    /* KnotenName        */
    pImpNode->NodeId       = 0;       
    /* KnotenID          */
    pImpNode->NodeTyp[0]   = 0;
    /* Knotentyp         */
    pImpNode->NodeTypId    = 0;
    /* ID des Knotentyps      */
    pImpNode->AnzPathEnt   = 0;       
    /* Anzahl Pfadknoten      */
    pImpNode->PathData = NULL;
    /* Zeiger auf Pfadnamen   */
    pImpNode->AnzAttrInfo  = 0;       
    /* Anzahl Knotenattribute      */
    pImpNode->AttrData = NULL;
    /* Zeiger auf Knotenattribute  */
    pImpNode->Desc     = NULL;             
    /* Zeiger auf Kommentar   */
    return (TCD_RC_OK);
}

/* ------------------------------------------------------------------
  Interne Funktion    DConstrImpNode                       :
  Legt neues Listenelement an, return S_TCDNODEDATA
------------------------------------------------------------------  */
static S_TCDNODEDATA      *DConstrImpNode()
{
 S_TCDNODEDATA *pImpNode = NULL;

 pImpNode = (P_TCDNODEDATA) _TCDALLOC (1, sizeof(S_TCDNODEDATA) );
 if ( pImpNode == NULL ) goto exit_f;
 memset ( pImpNode, 0, sizeof(S_TCDNODEDATA) ) ;
 SConstrImpNode( pImpNode );

 return( pImpNode );

exit_f:
 return ( NULL );
}


/* ------------------------------------------------------------------
  Interne Funktion    SDestrImpNode                        :
  alle Komponeneten von pImpNode werden freigegeben (statisch)
------------------------------------------------------------------  */
static void       SDestrImpNode( S_TCDNODEDATA *pImpNode)
{

    if (!pImpNode) return;
    
    if ( pImpNode->PathData != NULL ) _TCDFREE (pImpNode->PathData);
    if ( pImpNode->AttrData != NULL ) _TCDFREE (pImpNode->AttrData);
    if ( pImpNode->Desc     != NULL ) _TCDFREE (pImpNode->Desc);
    pImpNode->AnzPathEnt  = 0;
    pImpNode->AnzAttrInfo = 0;
}

/* ------------------------------------------------------------------
  Interne Funktion    DDestrImpNode                        :
  alle Komponeneten von pImpNode werden freigegeben (dyn.)
------------------------------------------------------------------  */
static void       DDestrImpNode( S_TCDNODEDATA ** ppImpNode)
{
   if ( *ppImpNode != NULL) {
      SDestrImpNode(*ppImpNode);
      _TCDFREE (*ppImpNode);       
      *ppImpNode = NULL;
   } 
}

/* ------------------------------------------------------------------
   FindNode :
   Sucht einen Knoten in der Schnittstelle
   Aufrufer ist der Import C95.C
------------------------------------------------------------------  */
P_TCDPRCNODE  FindNode           (TCD_LONG NodeID,
                                  P_TCDPRCNODE pNode,
                                  TCD_INT      iAnzPrcTree,
                                  TCD_INT *    iIndex )
{
   TCD_INT i = 0;
   for ( i=0; i < iAnzPrcTree; i++ )
   {
      if ( pNode->NodeID == NodeID )
      {
         *iIndex = i;
         return (P_TCDPRCNODE)pNode;
      }
      pNode++;
   }
   return NULL;
}

void TCDIMPReleaseProcData  ( P_TCDPRCELEM * ppProcData )
{
    if ( *ppProcData ) 
    {
        _TCDFREE(*ppProcData);    
        *ppProcData = NULL;
    }    
}                        

void TCDIMPReleaseNodeData  ( P_TCDNODEDATA * ppNodeData )
{
    if ( *ppNodeData )
        DDestrImpNode(ppNodeData);
}

void TCDIMPReleaseTabImpData( P_TCDTABIMPDATA * ppTabImpData     ,
                              TCD_BOOL          bReleaseTabValues,
                              TCD_BOOL          bReleaseTabInfo  )
{       
    P_TCDTABIMPDATA pTabImpData = (P_TCDTABIMPDATA) *ppTabImpData;
         
    if ( !pTabImpData ) return;

    /* TabellenInfo */
    if ( bReleaseTabInfo && pTabImpData->pTabInfo )
    {                                    
        if ( pTabImpData->pTabInfo->PathData )
            _TCDFREE(pTabImpData->pTabInfo->PathData);

        if ( pTabImpData->pTabInfo->AttrData )
            _TCDFREE(pTabImpData->pTabInfo->AttrData);
                        
        if ( pTabImpData->pTabInfo->Desc )
            _TCDFREE(pTabImpData->pTabInfo->Desc);

        _TCDFREE(pTabImpData->pTabInfo);
    }    
        
    /* Tabellenwerte */
    if ( bReleaseTabValues)
    {
        if ( pTabImpData->TabValues )
            _TCDTABFREE(pTabImpData->TabValues);
    }
    _TCDFREE(pTabImpData);
    *ppTabImpData = NULL;
}    

    
void TCDIMPReleaseTabData   ( P_TCDTAB      *ppTabValues )
{
   P_TCDTAB pTabValues = NULL;
   if (!ppTabValues || !*ppTabValues ) 
      return;
   pTabValues = *ppTabValues;
   _TCDFREE(pTabValues);
   *ppTabValues = NULL;
}
