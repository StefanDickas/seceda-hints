/*---------------------------------------------------------------------------

(C) Copyright 1993-2002, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------------*/
#if !defined (TCD_ATTR_H)
#define TCD_ATTR_H
/*---------------------------------------------------------------------
  Datei:        TCD_ATTR.H
  Beschreibung: Attributmanager
---------------------------------------------------------------------*/
TCD_INT   TCDAATS (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAATT (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAABS (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAABT (P_TCD_C_F1 pF1) ;
void      TCDAATD (P_TCD_C_F1 pF1) ;
void      TCDAABD (P_TCD_C_F1 pF1) ;
void      TCDAATV (P_TCD_C_F1 pF1) ;
void      TCDAABV (P_TCD_C_F1 pF1) ;
void      TCDAFT  (P_TCD_C_F1 pF1) ;
void      TCDAFBS (P_TCD_C_F1 pF1) ;
void      TCDAFBT (P_TCD_C_F1 pF1) ;

#endif
