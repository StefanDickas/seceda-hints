/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
 /*--------------------------------------------------------------------
    Modul:        TCD_PKF.c

    Beschreibung: Funktionen C-Generator, die vom Makrogenerator
                  aufgerufen werden
    By:           BEGGI
    Datum:        16.12.2019 15:07:19
    Historie :    BEG  22.11.95      FM: 384
  MUB  21.5.96 Optimierung begonnen, Beschaffungsflags etc.
  MUB          Pr�fung, ob Ergebnis schon berechnet wurde.
  MUB 17.7.96  Abweisungen zwischen #ifdef TRACEFKT #endif korrigiert
  MUB 26.7.96  Erfolgreiche Wiederverwendung eines Ergebnisses
               ins Tracefile schreiben
---------------------------------------------------------------------*/

/* Includes */
/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDPORTAB_H)
#define TCDPORTAB_H

/*-----------------
Name        : TCDPORTAB.H

Beschreibung: externes Include File, das generierumgeungsspezifische
Informationen enthaelt (Makrovorlage).
By          : BEGGI
Datum       : 20.04.94
Historie:     BEG   17.01.95  neues Makro _TCDMEMINI anstatt memset
BEG   02.03.95  bedingte Macros TCDHUGE
BEG   22.06.95  _TCDMEMINI nur im HUGE-Modell redefiniert.
BEG   20.02.96  malloc.h wird nicht mehr inkludiert (FM 451)
RWE   21.06.96  malloc.h wird wieder includiert (aber nur
              fuers HUGE-Modell, d.h. fuer DOS/WIN-Compiler)
RWE   26.06.96  WATCHMEM-Makros eingebaut (fuer TCDALLOC etc)
MUB   17.7.96   Include mit !defined versehen
KFC   02.09.96  #define TCDHUGE vorgezogen

-------------------*/

/* #define TCDHUGE */              /* bei gro�en Tabellen einschalten*/
/* Systemincludes */                  
#include <stdlib.h>                /* atoi, ...       */
#include <stdio.h>                 /* fprintf, ...    */
#include <string.h>                /* strcpy, ...     */
#include <time.h>                  /* time_t, ...     */
#include <math.h>                  /* exp, min, max, ... */

#ifdef TCDHUGE
#include <malloc.h>
#endif

/* Defines */
#define  TCDC_EXT_NAME_LNG    8  /* maximale L�nge von externen 
                                    Bezeichnern*/
/*-----------------
  Definitionen aus standard C-Includes z.B. stdio.h
-------------------*/
#ifndef NULL
#define    NULL    (void *)0
#endif

/*-----------------
  Definitionen von Basistypen
-------------------*/
typedef    short   TCD_BOOL ;
typedef    long    TCD_LONG ;
typedef    int     TCD_INT  ;
typedef    double  TCD_DOUBLE ;


/*-----------------
  modellabhaengige Definitionen von Basistypen
-------------------*/
typedef    TCD_DOUBLE  TCDTAB ;
#ifdef TCDHUGE
typedef    TCDTAB       huge * P_TCDTAB ;
typedef    TCD_DOUBLE   huge * P_TCD_DOUBLE ;
typedef    P_TCD_DOUBLE * P_P_TCD_DOUBLE ;
typedef    char huge    * TCD_LPCHAR ;
#else
typedef    TCDTAB       * P_TCDTAB ;
typedef    TCD_DOUBLE   * P_TCD_DOUBLE ;
typedef    P_TCD_DOUBLE * P_P_TCD_DOUBLE ;
typedef    char         * TCD_LPCHAR ;
#endif

/*-----------------
  weitere (Typ-)Defines 
-------------------*/  
typedef int ERRNO_TYPE;
#define TCD_FILENAME_LNG 128

/*-----------------
  Definitionen von Makros f�r Speicherallokation
-------------------*/  

/* WATCHMEM muss im TCDHUGE-Modus abgeschaltet sein */
#ifdef TCDHUGE
#undef WATCHMEM
#endif

#undef _TCDALLOC
#undef _TCDFREE
#undef _TCDREALLOC

#ifndef WATCHMEM

#define _TCDALLOC(len,size)    malloc( (size_t)(len) * (size)) ;
#define _TCDFREE(ptr)          {free(ptr), ptr = NULL;}
#define _TCDREALLOC(ptr,size)  realloc( ptr, (size_t)(size) ) ;

#else
 
void *MallocAndProt(char *sFile_,int iLine_, size_t size);
#define _TCDALLOC(len,size)\
 MallocAndProt(__FILE__,__LINE__,(len) * (size))

void FreeAndProt(char *sFile_, int iLine_, void *p_);

#define _TCDFREE(ptr)\
       {FreeAndProt(__FILE__, __LINE__, ptr) , ptr = NULL;}

void *ReallocAndProt(char *sFile_,int iLine_, void *p_, size_t size);
#define _TCDREALLOC(ptr,size)\
 ReallocAndProt(__FILE__, __LINE__, ptr,size)

void ResumeWatchmem();

#endif

/*-----------------
  modellabh�ngige Definitionen von Makros f�r Speicherallokation
-------------------*/
#undef _TCDTABALLOC
#undef _TCDTABFREE
#undef _TCDMEMINI

#ifdef TCDHUGE

#define _TCDTABALLOC(len,size)\
  _halloc( (long)(len) , (size_t)(size)) ;
#define _TCDTABFREE(ptr)\
      { _hfree ( (void huge *)ptr); ptr = NULL;}

#else

#ifndef WATCHMEM
#define _TCDTABALLOC(len,size)\
 malloc((size_t)((long)len) * ((size_t)size)) ;
#define _TCDTABFREE(ptr)       {free(ptr), ptr = NULL;}
#else
#define _TCDTABALLOC(len,size)\
 MallocAndProt(__FILE__,__LINE__,(len) * (size))
#define _TCDTABFREE(ptr)\
       FreeAndProt(__FILE__, __LINE__, ptr)
#endif

#endif


#ifdef TCDHUGE
#define _TCDMEMINI(ptr,size,nr)\
{\
   long       j;\
   TCD_LPCHAR lp;\
   for (j= 0 , lp = (TCD_LPCHAR)ptr;\
        j < ((long)(size) * (long)(nr)); j++, lp++) \
      *lp = 0;\
}  

#else
#define _TCDMEMINI(ptr,size,nr)\
 { memset (ptr, 0, (size_t) ((size) * (nr))) ; }
#endif
/*---------------------------------
  NON-Ansi-Namen mit oder ohne "_"
----------------------------------*/

/* #define NON_ANSI_WITHOUT__ */

#ifdef NON_ANSI_WITHOUT__
#define _fcvt fcvt
#endif

/*---------------------------
  ggf. Verkuerzung der Namen
-----------------------------*/
#ifdef TCD_NAMLEN8

#define TCDIMPReleaseProcData       TCD_0001
#define TCDIMPReleaseNodeData       TCD_0002
#define TCDIMPReleaseTabImpData     TCD_0003   

#define FetchFromGlobalErgebnisPool TCD_0004

#define DelEltFromSVect             TCD_0005
#define DelEltFromSVectByIndex      TCD_0006

#define DelEltFromVect              TCD_0007
#define DelEltFromVectByIndex       TCD_0008
                                
                                
#define ReleaseGlobalErgebnisPool   TCD_0009
#define ReleaseGlobalErgebnis       TCD_0010
#define ReleaseLocalErgebnisPool    TCD_0011

#define GetPrcDataSkal              TCD_0012
#define GetPrcDataTab               TCD_0013
#define GetPrcDataDat               TCD_0014
#define GetPrcDataFrm               TCD_0015

#define GetPrcAttrSkal              TCD_0016
#define GetPrcAttrTab               TCD_0017

#define GetSSAttrSkal               TCD_0018
#define GetSSAttrTab                TCD_0019

#define ErgPoolGetFirstInfo         TCD_0020
#define ErgPoolGetNextInfo          TCD_0021

#define DConstrAttrs                TCD_0022
#define DConstrAttrsResults         TCD_0023

#define GetRelAttrs                 TCD_0024

#define GetIndexToGlobalErgPool     TCD_0025
#define GetIndexToPaarListElt       TCD_0026

#define GetIndexToSS                TCD_0027
#define GetIndexToUes               TCD_0028
#define GetFromSS                   TCD_0029
#define GetFromUes                  TCD_0030

#define TCDIMPImportTreeData        TCD_0031
#define TCDIMPNFIntl                TCD_0032
#define TCDIMPGetNodeFromID         TCD_0033
#define TCDIMPGetNodeFromPath       TCD_0034
#define compBsearch                 TCD_0035
#define TCDIMPReleaseTreeData       TCD_0036 
#define TCDIMPReleaseTabData        TCD_0037  
#define DConstrTCD_C_G              TCD_0038
#define DDestrTCD_C_G               TCD_0039 
#define SConstrTCD_C_G              TCD_0040
#define DConstrTCDRbsSS             TCD_0041
#define SConstrTCDRbsSS             TCD_0042
#define SConstrTCDISSADATA          TCD_0043
#define SDestrTCD_C_G               TCD_0044
#define DDestrTCDRbsSS              TCD_0045
#define SDestrTCDRbsSS              TCD_0046
#define SDestrTCDISSADATA           TCD_0047
#define GetRbsSSFkt                 TCD_0048
#define TCDIMPGetTabIDAndTypFromPath TCD_0049
#define TCDIMPGetPathAndTypFromID    TCD_0050
#define TCDIMPReleaseTabTreeData     TCD_0051
#define TCDIMPImportTabTreeData      TCD_0052
#endif

#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDC_H)
#define TCDC_H

#ifdef TCDV2_5
#define TCDVERS 25
#endif
#ifdef TCDV3_0
#define TCDVERS 30
#endif
#ifndef TCDVERS
#error TCD Version muss in Makefiles angegeben werden.
#endif

/*---------
Name        : TCDC.H

Beschreibung: Zentrales Include File fuer die Anwendung
TCD weit gueltig
*----------*/

#include "p09115.h" /* direkte Vektoren */

#define  TCD_TRUE                1
#define  TCD_FALSE               0

/*---------
  Definitionen Opcodes
*----------*/
#define  TCD_OPC_INIT_RBS                    1
#define  TCD_OPC_CALC_FRM                    2
#define  TCD_OPC_CALC_PRC                    3
#define  TCD_OPC_GETNUM_FRM                  4
#define  TCD_OPC_GET_ATTR_VAL                5
#define  TCD_OPC_RESET_RBS                   6
#define  TCD_OPC_SET_PRC                     7
#define  TCD_OPC_RESET_PRC                   8
#define  TCD_OPC_SET_POOLTAB                 9
#define  TCD_OPC_RESET_POOLTAB              10
#define  TCD_OPC_SET_ATTR_VAL               11
#define  TCD_OPC_GET_PRC_INFO               12
#define  TCD_OPC_SET_POOLTAB_I              13
#define  TCD_OPC_RESET_POOLTAB_I            14
#define  TCD_OPC_SET_ATTR_IN_PRC            15
#define  TCD_OPC_SET_TRACE_ON               16
#define  TCD_OPC_SET_TRACE_OFF              17
#define  TCD_OPC_REMOVE_RESULTS             18
#define  TCD_OPC_GET_FIRST_RESULTS_INFO     19
#define  TCD_OPC_GET_NEXT_RESULTS_INFO      20

/*---------
  Definitionen Returncodes
*----------*/
#define  TCD_RC_NOT_OK              0
#define  TCD_RC_OK                  1
#define  TCD_RC_ILLOPC              2
#define  TCD_RC_VERSION_CONFLICT    3
#define  TCD_RC_UNKNOWN_FORM        4
#define  TCD_RC_ILLEGAL_FORM        5
#define  TCD_RC_ILLEGAL_PARAM       6
#define  TCD_RC_UNKNOWN_ATTR        7
#define  TCD_RC_NOT_FOUND           8
#define  TCD_RC_INPUT_MISSING       9
#define  TCD_RC_ILLEGAL_DIVISION   10
#define  TCD_RC_ILLEGAL_TAB_RANGE  11
#define  TCD_RC_STACK_OVERFLOW     12
#define  TCD_RC_CONDITION_FAIL     15
#define  TCD_RC_PAR_ERROR          20
#define  TCD_RC_TAB_IN_POOL        21
#define  TCD_RC_TAB_NOT_IN_POOL    22
#define  TCD_RC_PRC_IN_POOL        23
#define  TCD_RC_PRC_NOT_IN_POOL    24
#define  TCD_RC_UNKNOWN_PROC       25
#define  TCD_RC_PAARLISTEN_ERROR   26
#define  TCD_RC_NO_VALUE_AVAIL     30
#define  TCD_RC_USER_SET_ERROR    900
#define  TCD_RC_INTERNAL_ERR      999
#define  TCD_RC_NO_RETURN         888

/*---------
  allgemeine globale Konstanten
*----------*/
#define TCD_INIT_VARSETLEVEL    9999

/*---------
  Konfigurationsangaben
*----------*/
#define TCD_POOLADMIN_SIZE        20
#define TCD_C_MIN_USER_TYPE_ID    0
#define TCD_C_TABLISTLEN          10
#define TCD_C_MAXPRCCALLNR        2147483647

/*---------
  Definitionen Laengenangaben
*----------*/
#define TCD_DATUM_LNG              9
#define TCD_FRM_DATUM_LNG         20
#define TCD_VGLOP_LNG              3
#define TCD_NAME_LNG              26

/*---------
  Definitionen Aufrufart: (Aufzaehlungstyp)
-----------*/
#define TCD_CALLTYP_ATTR        1
#define TCD_CALLTYP_STA         2
#define TCD_CALLTYP_DYN         3
#define TCD_CALLTYP_STA_UE      4

/*---------
  Definitionen Prefix
-----------*/
#define TCD_PREFIX_TAB            '&'
#define TCD_PREFIX_PRC            '$'
#define TCD_PREFIX_FRM            'F'
#define TCD_PREFIX_ATTR           'A'

/*---------
  Definitionen Formeltypen (Aufzaehlungstyp, Wertevergabe analog Cobol)
-----------*/
#define TCD_FRMTYP_SKAL        1
#define TCD_FRMTYP_TAB1        2
#define TCD_FRMTYP_TAB2        3

/*---------
  Definitionen Belegungswerte PoolEntry
-----------*/
#define  TCD_POOLENT_INIT          0
#define  TCD_POOLENT_USED          1
#define  TCD_POOLENT_I_USED        2
#define  TCD_POOLENT_E_USED        3

/*---------
  Definitionen Assigntype
*----------*/
#define  TCD_DC_USE_NOT            0
#define  TCD_DC_USE_FRM            1
#define  TCD_DC_USE_PRC            2
#define  TCD_DC_USE_TAB            3
#define  TCD_DC_USE_VAL            4

/*----------
  Definitionen Formattypen
-----------*/
#define  TCD_ATTRFMT_SKAL          1
#define  TCD_ATTRFMT_TAB1          2
#define  TCD_ATTRFMT_TAB2          3
#define  TCD_ATTRFMT_VGLO          4
#define  TCD_ATTRFMT_DATE          5

/*----------
  Struktur Bestandsattributtabelle
 ----------*/
  typedef struct tagS_TCDATAB {
        char          Name [TCD_NAME_LNG] ;
        TCD_LONG      ID         ;
        TCD_INT       Index      ;
        TCD_INT       AttrTyp    ;
  } S_TCDATAB     ;

 typedef S_TCDATAB     * P_TCDATAB     ;

/*----------
  Struktur Tabelle aller Attribute
 ----------*/
  typedef struct tagS_ATTRTAB
  {
    TCD_LONG  ID    ;
    TCD_INT   Index ;
  } S_ATTRTAB ;

  typedef S_ATTRTAB    * P_ATTRTAB     ;

/*----------
  Typdefinition systemunabhanegiger Typen
 ----------*/
   typedef  char  TCD_VGLOP [TCD_VGLOP_LNG] ;
   typedef  char  TCD_DATUM [TCD_DATUM_LNG] ;

   typedef TCD_DOUBLE TCDTAB1 ;
   typedef P_TCDTAB   P_TCDTAB1 ;

   typedef TCD_DOUBLE TCDTAB2 ;
   typedef P_TCDTAB   P_TCDTAB2 ;

   typedef P_P_TCD_DOUBLE P_P_TCDTAB ;

/*---------
  Union Attributbelegung
 ----------*/
  typedef  union tagU_TCDVALUE {
           TCD_DOUBLE        Skalar;
           P_TCDTAB1         pTab1 ;
           P_TCDTAB2         pTab2 ;
   } U_TCDVALUE ;

  typedef  union tagU_TCDGVALUE {
           TCD_DOUBLE        Skalar;
           P_TCDTAB          pTab  ;
           TCD_VGLOP         VglOp ;
           TCD_DATUM         Datum ;
   } U_TCDGVALUE ;

/* --
 MUB 2.7.96: neu eingefuehrt, weil wir die TabellenID brauchen
--  */
  typedef  union tagU_TCDWVALUE
  {
           TCD_DOUBLE        Skalar;

           TCD_LONG          TabID ;  /*  die relevanten Attribute */
           P_TCDTAB1         pTab  ;  /*  das Ergebnis */

           TCD_VGLOP         VglOp ;
           TCD_DATUM         Datum ;
   } U_TCDWVALUE ;

  typedef struct tagS_TCDPRCVAL {
          TCD_LONG   PrcID ;
          TCD_LONG   FormelNr ;
          TCD_INT    FormelIx ;
          char       FormelName [TCD_NAME_LNG] ;
          TCD_INT    PoolIx ;
#if TCDVERS > 25
/* Version der Formel zur Pruefung 
		  Formel-Generat gegen Transport-Format */
          TCD_INT    FormelVers;
#endif

 } S_TCDPRCVAL ;

  typedef union  tagU_TCDNDVALUE {
          struct   tagTabData {
             TCD_LONG  TabID ;
             TCD_INT   PoolIx ;
          } TabData  ;
          TCD_DOUBLE Skalar ;
          char       Datum [TCD_DATUM_LNG] ;
          char       VglOp [TCD_VGLOP_LNG];
 } U_TCDNDVALUE ;


  typedef struct tagS_TCDFORMEL {
           TCD_LONG  FormelNr ;
           TCD_INT  FormelIx ;
           char     FormelName [TCD_NAME_LNG] ;
           TCD_INT  IsStaRef ;                                 
#if TCDVERS > 25
/* Version der Formel zur Pruefung 
		   Formel-Generat gegen Transport-Format */
		   TCD_INT  FormelVers;
#endif
 } S_TCDFORMEL ;

  typedef union  tagU_TCDASSIGNVAL {

       S_TCDPRCVAL  Prc    ;
       U_TCDNDVALUE Val    ;
       S_TCDFORMEL  Formel  ;

 } U_TCDASSIGNVAL ;

#define TYP3_NOT_OVERWRITTEN 2

typedef struct tagS_TCDREL_ATTR
{                                 
   TCD_LONG    iBerechnungsNummer;
   /* ID des Attributs                            */
   TCD_LONG    AttrID                  ;  
   /* Typ der Belegung SKALAR, TAB, DATUM , VGLOP */
   TCD_INT     AttrType              :4;  
   /* Flag, ob ein geerbter Wert vorhanden ist    */
   TCD_INT     bGeerbterWertVorhanden:2;  
   /* Flag, ob ein geerbter Wert vorhanden ist    */
   TCD_INT     bNotOverwritten         ;
   /* GGf. Wert hierzu                            */
   U_TCDWVALUE Belegung                ;  

}  S_TCDRELATTR;

typedef S_TCDRELATTR * P_TCDRELATTR ;

/* --
   S_TCDRELATTR_IMP    Relevantes Attribut fuer den Import
--  */
typedef struct tagS_TCDREL_ATTR_IMP
{
   TCD_LONG AttrID;
   TCD_INT  AttrType               : 4;
   TCD_INT  iIndex;

}  S_TCDRELATTR_IMP;

typedef S_TCDRELATTR_IMP * P_TCDRELATTR_IMP ;

/* --
   S_PAARLISTEN_EL    Struktur fuer ein PaarlistenElement
--  */
typedef struct tagS_PAARLISTEN_EL
{
   /* Vektor der relevanten Attribute mit der aktuellen Belegung     */
   LP_VECT          pAttrs;        
   /* lfde. Nummer der aktuellen Berechnung                          */
   TCD_LONG         iBerechnungsNummer; 
   
   TCD_LONG         lTabZeilen;         
   TCD_LONG         lTabSpalten;
   
   /* Typ des Ergebnisses (kann 'NOT_OVERWRITTEN' sein)              */
   TCD_INT          iType;              
   /* Ergebnis hierzu                                                */
   U_TCDWVALUE      Ergebnis;           

}  S_PAARLISTEN_EL;

typedef S_PAARLISTEN_EL * P_PAARLISTEN_EL ;

/* --
   S_PAARLISTE     Struktur zu einem Belegknoten einer BV
   Sie enthaelt 1 sortierten Vektor, 1 Liste und eine maximale Laenge
   fuer die Anzahl Elemente der Paarliste (Belegung,Ergebnis)
--  */
typedef struct tagS_PAARLISTE
{
   TCD_INT iWiederVerwendungsTyp;   /* KnotenTyp 1/2/3     */
   TCD_INT iWiederVerwListenLaenge; /* ListenLaenge maximal */
   TCD_INT iAct ;                   /* letztes Element     */

   /* direkter Vektor von S_ATTR_EL's   */
   LP_VECT pAttrs;                  
   /* direkter Vektor von S_PAARLISTEN_EL's */
   LP_VECT pPaarListenElts;         

}  S_PAARLISTE;

typedef S_PAARLISTE * P_PAARLISTE ; 

/* --
   S_ERGEBNIS_POOL_ELT Element eines PoolErgebnisses
--  */
typedef struct tagS_ERGEBNIS_POOL_ELT
{
   TCD_LONG    ID;
   P_PAARLISTE pPaarListe;

}  S_ERGEBNIS_POOL_ELT;

typedef S_ERGEBNIS_POOL_ELT * P_ERGEBNIS_POOL_ELT ;

/*-----------
  Struktur     Belegungsknoten
------------*/
  typedef struct tagS_TCDPRCNODE
  {
      TCD_LONG         AttrID                  ;
      TCD_INT          NodeID                  ;
      TCD_INT          AttrType                ;
      TCD_INT          AssignType              ;
      U_TCDASSIGNVAL   AssignVal               ;
      TCD_INT          SuccNodeIx              ;
      TCD_INT          AnzSuccNodes            ;
      TCD_INT          Usage                   ;

      P_PAARLISTE      pPaarListe              ;
      P_PAARLISTEN_EL  pResultForGetAttr       ;

      TCD_INT          iWiederVerwendungsTyp   ;
      TCD_INT          iWiederVerwListenLaenge ;
      TCD_INT          iAnzRelAttrs            ;
      TCD_INT          iFirstRelAttrIx         ;

  }   S_TCDPRCNODE ;

 typedef S_TCDPRCNODE  * P_TCDPRCNODE ;

/*-----------
  Struktur Auspraegungs-Belegungs-Information
------------*/
  typedef struct tagS_TCDPRCINFO {
         char  Name [TCD_NAME_LNG] ;
         TCD_LONG  ID ;
         TCD_INT   Formattyp ;
         TCD_INT   Typ ;
         TCD_INT   Klasse ;
         TCD_INT   AnzBeleg ;
         TCD_INT   TabIx ;
         TCD_LONG  RefNodeId ;
 } S_TCDPRCINFO ;

 typedef S_TCDPRCINFO  * P_TCDPRCINFO ;

/*--------
  Struktur LocalData MUB 2.7.96: wird nicht mehr verwendet!
 --------*/
  typedef struct tagS_TCDPRCLOCD {
          TCD_LONG FormelNr     ;
          TCD_INT  Usage        ;
          TCD_INT  Typ          ;
          union   {
              TCD_INT    PoolIx ;
              TCD_DOUBLE Val    ;
          } Data ;
          TCD_LONG  CalcByCallNr ;
   } S_TCDPRCLOCD ;

   typedef S_TCDPRCLOCD * P_TCDPRCLOCD ;

/*---------
  Struktur Header Auspraegungsbaum
----------*/
  typedef struct tagS_TCDPRCHDR {
    TCD_LONG       PrcID        ;
    TCD_LONG       FormelNr     ;
    TCD_INT        AnzPrcTree   ;
    TCD_INT        AnzBelegInfo ;
    TCD_INT        AnzRelAttrs  ;
    TCD_BOOL       FlSetAttrSkal;
    TCD_BOOL       FlSetAttrTab ;
    TCD_BOOL       FlSetAttrVgl ;
    TCD_BOOL       FlSetAttrDat ;
    TCD_BOOL       FlPrcCompl   ;
    TCD_LONG       PrcResIx     ;
    TCD_LONG       PrcCallNr    ;

 } S_TCDPRCHDR     ;


/*---------
  Struktur Auspraegungselement
-----------*/
  typedef union  tagU_TCDPRCELEM
  {
     S_TCDPRCHDR      TreeHdr;
     S_TCDPRCNODE     Node ;
     S_TCDPRCINFO     Info ;     
  }  U_TCDPRCELEM ;

 typedef U_TCDPRCELEM  * P_TCDPRCELEM ;

#define TCDPRCSIZE(pPrc)    (pPrc ? sizeof(S_TCDRELATTR_IMP)*\
                            (TCD_LONG)pPrc->TreeHdr.AnzRelAttrs +\
                            sizeof(U_TCDPRCELEM)*\
                            ( (TCD_LONG)pPrc->TreeHdr.AnzPrcTree +\
                             (TCD_LONG)pPrc->TreeHdr.AnzBelegInfo) : 0)


/*-------
  Datenstruktur Mehrfach-Auspraegung (MultiProc)
 --------*/
  typedef struct tagS_TCDMPRCENTRY {
        TCD_INT              PrcBelegt ;
        TCD_LONG             ID ;
        P_TCDPRCELEM         pPrcData ;
 } S_TCDMPRCENTRY ;

  typedef S_TCDMPRCENTRY * P_TCDMPRCENTRY ;

  typedef struct tagS_TCDMPRCADMIN {
        TCD_INT          Anzahl  ;
        P_TCDMPRCENTRY   Data    ;
 } S_TCDMPRCADMIN ;

 typedef S_TCDMPRCADMIN * P_TCDMPRCADMIN ;

/*--------
  Datenstruktur PoolAdmin
--------*/
  typedef struct tagS_TCDPOOLENTRY {
        TCD_LONG     ID ;
        TCD_INT      Usage ;
        TCD_INT      Typ ;
        TCD_INT      Fmttyp ;
        P_TCD_DOUBLE pData ;
  } S_TCDPOOLENTRY ;

  typedef S_TCDPOOLENTRY * P_TCDPOOLENTRY ;

  typedef struct tagS_TCDPOOLADMIN {
        TCD_INT          Anzahl  ;
        TCD_INT          AnzTabs ;
        TCD_INT          AnzProcs ;
        TCD_INT          AnzTemp  ;
        S_TCDPOOLENTRY * Data    ;
 } S_TCDPOOLADMIN ;

  typedef S_TCDPOOLADMIN * P_TCDPOOLADMIN ;

/*------
  Datenstruktur Kontrollstruktur
--------*/
  typedef struct tagS_TCDRBSINFO {
       char TcdVersion [TCD_DATUM_LNG]   ;
       char TcdRelease [TCD_DATUM_LNG]   ;
       char RbsInterf  [TCD_DATUM_LNG]   ;
       TCD_LONG RbsId ;
   } S_TCDRBSINFO ;

   typedef struct tagS_TCDRCINFO {
       TCD_INT   Rc ;
       TCD_INT   Errc ;
       char FormelName [TCD_NAME_LNG] ;
       TCD_INT   FormelNr ;
       char AttrName   [TCD_NAME_LNG] ;
   } S_TCDRCINFO          ;

   typedef S_TCDRCINFO * P_TCDRCINFO ;


   typedef struct tagS_TCDCTLPAR {

/*-
  Opcode:   TCD_OPC_GET_ATTR_VAL, TCD_OPC_SET_ATTR_VAL
--*/
        struct tagS_TCDPARGA {
           TCD_LONG    ProcID;
           TCD_LONG    ID;
           TCD_LONG    TabID;
           TCD_INT     TabIx ;
           U_TCDGVALUE Val ;
           TCD_INT     Typ ;
           TCD_INT     ProcIx;
        }            GA ;

/*-
  Opcode:   TCD_OPC_SET_POOLTAB
--*/
        struct tagS_TCDPARST {
            TCD_LONG  ID;
            TCD_INT   Dim ;
            P_TCDTAB  pTab ;
            TCD_INT    TabIx ;
        }            ST ;

/*-
  Opcode:   TCD_OPC_RESET_POOLTAB
--*/
        struct tagS_TCDPARRT{
            TCD_LONG  ID;
            P_TCDTAB  pTab ;
        }            RT ;

/*-
  Opcode:   TCD_OPC_SET_PRC
--*/
        struct tagS_TCDPARSP {
            TCD_LONG      ProcID;
            P_TCDPRCELEM  pProc;
            TCD_INT       ProcIx;
        }            SP;

/*-
  Opcode:   TCD_OPC_RESET_PRC
--*/
        struct tagS_TCDPARRP {
            TCD_LONG  ProcID;
            P_TCDPRCELEM  pProc;
        }            RP;

/*-
  Opcode:   TCD_OPC_CALC_FRM , TCD_OPC_CALC_PRC
--*/
        struct tagS_TCDPARCFP {
            TCD_LONG       FormelNr ;
            TCD_LONG       ProcID;
            TCD_INT        Typ ;
            U_TCDVALUE     Value ;
            TCD_INT        ProcIx;
        }            CFP ;

/*-
  Opcode:   TCD_OPC_GETNUM_FRM
--*/
        struct tagS_TCDPARGF {
            char  Name [TCD_NAME_LNG] ;
            TCD_LONG  FormelNr ;
        }            GF ;

/*-
  Opcode:   TCD_OPC_GET_PRC_INFO
--*/
        struct tagS_TCDPRCBINFO {
            TCD_LONG        ProcID;
            TCD_INT         ProcIx;
            P_TCDPRCELEM    pProcInfo;
            TCD_INT         AnzProcInfo ;
        }            PI ;

/*-
  Opcode:   TCD_OPC_REMOVE_RESULTS,
            TCD_OPC_GET_FIRST_RESULTS_INFO,
            TCD_OPC_GET_NEXT_RESULTS_INFO
--*/
        struct tagS_TCDPAR_RESULTPOOL {
            TCD_LONG        ProcID;
            TCD_LONG        lNumOfResults;
            TCD_INT         bFinished;
        }            RESP ;

   } S_TCDCTLPAR ;

   typedef S_TCDCTLPAR * P_TCDCTLPAR ;

   typedef struct tagS_TCDRBSCTL {
          TCD_INT       Opc     ;
          S_TCDRBSINFO  RbsInfo ;
          S_TCDRCINFO   RCInfo  ;
          S_TCDCTLPAR   Par     ;
  } S_TCDRBSCTL ;

   typedef S_TCDRBSCTL * P_TCDRBSCTL ;

/*------
  Datenstruktur Rechenbausteinschnittstelle
 --------*/
   typedef struct tagS_TCDV_F_FLAGS {
         TCD_BOOL       V_In   ;
         TCD_BOOL       F_In   ;
         TCD_BOOL       V_Comp ;
         TCD_BOOL       V_Use  ;
         TCD_BOOL       F_Use  ;
         TCD_BOOL       V_Miss ;
         TCD_BOOL       F_Miss ;
   } S_TCDV_F_FLAGS ;

   typedef S_TCDV_F_FLAGS * P_TCDV_F_FLAGS ;

   typedef struct tagS_TCDV_FLAGS {
         TCD_BOOL       V_In   ;
         TCD_BOOL       V_Use  ;
         TCD_BOOL       V_Miss ;
   } S_TCDV_FLAGS ;

   typedef S_TCDV_FLAGS   * P_TCDV_FLAGS   ;

   typedef struct tagS_TCDSKAL_DATA
   {
        TCD_DOUBLE      Val    ;
        TCD_LONG        Formel ;
        S_TCDV_F_FLAGS  Flags  ;
   } S_TCDSKAL_DATA ;

   typedef S_TCDSKAL_DATA * P_TCDSKAL_DATA ;

   typedef struct tagS_TCDTAB1_DATA
   {
     TCD_LONG        TabID;
     P_TCDTAB1       pVal ;
     TCD_LONG        Formel ;
     S_TCDV_F_FLAGS  Flags ;

   } S_TCDTAB1_DATA ;
   typedef S_TCDTAB1_DATA  * P_TCDTAB1_DATA  ;

   typedef struct tagS_TCDTAB2_DATA
   {
     TCD_LONG        TabID;
     P_TCDTAB2       pVal ;
     TCD_LONG        Formel ;
     S_TCDV_F_FLAGS  Flags ;

   } S_TCDTAB2_DATA ;
   typedef S_TCDTAB2_DATA * P_TCDTAB2_DATA ;

   typedef struct tagS_TCDDAT_DATA {
        char             Val [TCD_DATUM_LNG] ;
        S_TCDV_FLAGS     Flags ;
   } S_TCDDAT_DATA ;

   typedef S_TCDDAT_DATA * P_TCDDAT_DATA ;

   typedef struct tagS_TCDVGL_DATA {
        char            Val [TCD_VGLOP_LNG] ;
        S_TCDV_FLAGS    Flags ;
   } S_TCDVGL_DATA ;

   typedef S_TCDVGL_DATA * P_TCDVGL_DATA ;

   typedef struct tagS_TCD_RBS_SSA
   {
        P_TCDSKAL_DATA    pSkal ;
        P_TCDTAB1_DATA    pTab1 ;
        P_TCDTAB2_DATA    pTab2 ;
        P_TCDDAT_DATA     pDat  ;
        P_TCDVGL_DATA     pVgl  ;
   } S_TCD_RBS_SSA ;

   typedef S_TCD_RBS_SSA  * P_TCD_RBS_SSA ;


   typedef struct tagS_TCDRBS_SS {
       S_TCDRBSCTL       RCTL ;
       S_TCD_RBS_SSA     SSAData   ;
       S_TCDPOOLADMIN    PoolAdmin ;
       S_TCDMPRCADMIN    MPrcAdmin ;
 } S_TCDRBS_SS ;

 typedef S_TCDRBS_SS  * P_TCDRBS_SS ;

  typedef struct tagS_TCDPARATTR_SK {
        TCD_INT      Level ;
        TCD_DOUBLE   Val ;
 } S_TCDPARATTR_SK   ;

 typedef S_TCDPARATTR_SK  * P_TCDPARATTR_SK ;

  typedef struct tagS_TCDPARATTR_VGL {
        TCD_INT      Level;
        char         Val  [TCD_VGLOP_LNG] ;
 } S_TCDPARATTR_VGL  ;

 typedef S_TCDPARATTR_VGL * P_TCDPARATTR_VGL ;

  typedef struct tagS_TCDPARATTR_DAT
  {
        TCD_INT      Level;
        char         Val  [TCD_DATUM_LNG] ;
 } S_TCDPARATTR_DAT  ;

 typedef S_TCDPARATTR_DAT * P_TCDPARATTR_DAT ;

/*-----------
  Struktur Schnittstellendaten (interne Sicht)
-----------*/
  typedef struct tagS_TCDISSADATA
  {
     TCD_INT      AnzSSASkal ;
     TCD_INT      AnzSSATab1 ;
     TCD_INT      AnzSSATab2 ;
     TCD_INT      AnzSSADat ;
     TCD_INT      AnzSSAVgl ;
     TCD_INT      AnzParSkal;
     TCD_INT      AnzParVgl ;
     TCD_INT      AnzParDat ;
     TCD_INT      AnzZeilen ;
     TCD_INT      AnzSpalten ;
     P_TCDSKAL_DATA    pSkal ;
     P_TCDTAB1_DATA    pTab1 ;
     P_TCDTAB2_DATA    pTab2 ;
     P_TCDDAT_DATA     pDat ;
     P_TCDVGL_DATA     pVgl ;
     P_TCDPARATTR_SK   pParSkal ;
     P_TCDPARATTR_VGL  pParVgl;
     P_TCDPARATTR_DAT  pParDat;

 }   S_TCDISSADATA ;
 typedef S_TCDISSADATA * P_TCDISSADATA ;



/*------
Datenstruktur globale Daten des Rechenbausteins;
diese Datenstruktur enthaelt Informationen und Teilstrukturen, die
in den programmierten Funktionen benoetigt werden.
Initialisierung dieser Daten erfolgt mehrstufig.
- beim Init: globaler Pointer pTCDTCD initialisiert (zeigt auf die Str)
pRbsSS zeigt auf die RBS-Schnittstelle
- bei auspraegungsspez. Opcodes werden die Teilstrukturen fuer die
Auspraegung initialisiert, ...
- bei einer neuen Berechnung werden die internen Aufrufschnittstellen
initialisiert
--------*/
  typedef struct tagS_TCD_C_G
  {
      P_TCDRBS_SS      pRbsSS      ;
      P_TCDPRCELEM     pPrcData    ;
      S_TCDPRCHDR *    pPrcHdr     ;
      P_TCDPRCELEM     pPrcTreeNode;
      P_TCDPRCELEM     pInfo       ;
      P_TCDRELATTR_IMP pRelAttrs   ;
      P_TCDMPRCADMIN   pMPrcAdmin  ;
      P_TCDRBSCTL      pRbsCtl     ;
      S_TCDISSADATA    SSAData     ;
      P_TCDPOOLADMIN   pPoolAdmin  ;
      TCD_INT          GlbVarSet   ;
      TCD_LONG         RBS_ID      ;
      TCD_BOOL         ValFound    ;
      TCD_BOOL         FrmFound    ;
      TCD_BOOL         V_Comp      ;
      TCD_BOOL         PrcChg      ;
      void *           pApplIf     ;
      P_TCDTAB         ResTab      ;
      TCD_DOUBLE       ResSkal     ;
      
      TCD_LONG         LastCalcPrcID;
      LP_VECT          pErgebnisPool;
      TCD_LONG         iBerechnungsNummer;
      TCD_INT          iErgPoolIteratorGl;                       
      P_PAARLISTE      pPaarListeNotToSave;
      
      TCD_BOOL         btrace_open;
      TCD_BOOL         btrace_enabled;
      
/* RWE, 10.06.1997: Neues Datenelement fuer Beobachtung
   der Wiederverwendung (ehemals WatchPol-Funktionalitaet) */
      TCD_BOOL         bProtWV;
      
  }   S_TCD_C_G ;
  typedef S_TCD_C_G   * P_TCD_C_G ;
#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCDI_H)
#define TCDI_H
/*--------------
    Name        : TCDI.H

    Beschreibung: Include File intern nur f�r C- Generator
                  wird von den fest programmierten Moduln und
                  generierten Moduln benoetigt
    By          : BEGGI
    Datum       : 22.02.94
    Historie    : BEG   28.11.95   Definition Attributklassen
*--------------*/

/*-------------
  Returncodes FrmRet und ValRet (Definitionen analog Cobol) fuer
  Attributmanager
---------------*/
#define TCD_AIRC_CALLVIAFRM    4

/*-------------
  Definitionen Attributtypen (Aufzaehlungstyp)
---------------*/
#define TCD_ATTYP_TAR_SKAL      1
#define TCD_ATTYP_TAR_TAB1      2
#define TCD_ATTYP_TAR_TAB2      3
#define TCD_ATTYP_TAR_DATE      4
#define TCD_ATTYP_TAR_VGLO      5
#define TCD_ATTYP_BST_SKAL      6
#define TCD_ATTYP_BST_TAB1      7
#define TCD_ATTYP_BST_TAB2      8
#define TCD_ATTYP_BST_DATE      9
#define TCD_ATTYP_BST_VGLO     10

#define TCD_ATTRTYP_SKAL        0
#define TCD_ATTRTYP_TAB1        1
#define TCD_ATTRTYP_TAB2        2
#define TCD_ATTRTYP_DATE        3
#define TCD_ATTRTYP_VGLO        4

/*--------------
  Definitionen Attributklasse
---------------*/
#define TCD_ATTRCLASS_TAR       1
#define TCD_ATTRCLASS_BST       6

/*-------------
  Definitionen Errorcodes
---------------*/
#define TCD_UNKNOWN_OPCODE       1
#define TCD_NO_SPACE_IN_TLIST    2
#define TCD_ERR_GETMEM           3
#define TCD_GETEMPTYENTRY        4
#define TCD_NOPOOLADMIN          5
#define TCD_ILLTABFMT            6
#define TCD_UNK_ASSIGNTYP        7
#define TCD_NO_MPRCADMIN         8
#define TCD_EXPPOOLADMIN         9
#define TCD_NO_MEMORY           10
#define TCD_NO_PRCREF           11
#define TCD_ILLFRM_ID           12
#define TCD_ILLFRM_CMP          13
#define TCD_ERR_INIT_FORMEL     14
#define TCD_FRMGEN_OUT_OF_DATE	15
#define TCD_TRPFMT_OUT_OF_DATE	16

/*----------
  Datenstruktur Freigabeliste  Hilfsvariablentabellen
 ------------*/
  typedef struct tagS_TCDTABLIST    {
         TCD_INT        CallOvw ;
         TCD_LONG       CallerID ;
         TCD_LONG       CallFrmNr ;
         TCD_INT        CallType  ;
         P_TCD_DOUBLE   Adr ;
 } S_TCDTABLIST   ;

 typedef  S_TCDTABLIST  * P_TCDTABLIST  ;

/*----------
  Datenstruktur Formelparameter
 ------------*/
  typedef struct tagS_TCD_C_F1 
  {
     char         * FormelName     ;
     TCD_INT        FrmTyp         ;
     TCD_LONG       FrmNr          ;
     TCD_INT        FrmIx          ;
     char         * AttrName       ;
     TCD_INT        CallType       ;
     TCD_LONG       AttrID         ;
     TCD_INT        AttrTyp        ;
     TCD_INT        AttrIx         ;
     TCD_INT        ParIx          ;
     TCD_INT        Ret            ;
     TCD_INT        ExecCond       ;
     P_TCDPRCNODE   PrcFNode       ;
     P_TCDPRCNODE   pNode          ;
     TCD_INT        MinVarSet      ;
     TCD_INT        BegVarSet      ;
     char         * CmpTime        ;
     TCD_INT        Level          ;
     P_TCD_DOUBLE   pVarSkal       ;
     P_P_TCDTAB     pVarTab        ;
     char         * VarDatVgl      ;
     TCD_INT      * VarIndex       ;
     P_TCDTABLIST   FreeList       ;
     TCD_INT        AnzTabList     ;
     TCD_INT        AnzTabListEnt  ;
     P_TCDPRCNODE   NextFNode      ;
     TCD_INT        NextExecCond   ;
     TCD_INT        NextCallType   ;
     struct tagS_TCD_C_F1 * pPrevLevelInfo ;
     P_TCD_C_G      pTCDTCD ;
  } S_TCD_C_F1 ;

  typedef  S_TCD_C_F1 *   P_TCD_C_F1 ;

  typedef struct tagS_TCDFTAB {
        char          FrmName [TCD_NAME_LNG] ;
        void          (* pFormelFunc ) ( P_TCD_C_F1);
        TCD_LONG      FrmNr      ;
        TCD_INT       FrmTyp     ;
        char          Datum [TCD_FRM_DATUM_LNG] ;
  } S_TCDFTAB     ;

 typedef S_TCDFTAB     * P_TCDFTAB     ;

/* extern P_TCD_C_G pTCDTCD ; */

#endif


/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_POOL_H)
#define TCD_POOL_H
/*---------------------------------------------------------------------
  Datei      : TCD_POOL.h
  Generiert am 16.12.2019 15:07:18
  Historie      : 27.7.95    BEG neuer Prefix fuer Tabellenentry
---------------------------------------------------------------------*/
void    TCDPIT   (P_TCD_C_G);
void    TCDPRP   (P_TCD_C_G) ;
void    TCDPST   (P_TCD_C_G) ;
void    TCDPRT   (P_TCD_C_G) ;
void    TCDPSAT  (P_TCD_C_G) ;
void    TCDPRTA  (P_TCD_C_G) ;
TCD_INT TCDPGF   (P_TCD_C_G,P_TCD_DOUBLE Var, TCD_INT *PIndex) ;

#endif

/*---------------------------------------------------------------------------

(C) Copyright 1993-2002, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------------*/
#if !defined (TCD_ATTR_H)
#define TCD_ATTR_H
/*---------------------------------------------------------------------
  Datei:        TCD_ATTR.H
  Beschreibung: Attributmanager
---------------------------------------------------------------------*/
TCD_INT   TCDAATS (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAATT (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAABS (P_TCD_C_F1 pF1) ;
TCD_INT   TCDAABT (P_TCD_C_F1 pF1) ;
void      TCDAATD (P_TCD_C_F1 pF1) ;
void      TCDAABD (P_TCD_C_F1 pF1) ;
void      TCDAATV (P_TCD_C_F1 pF1) ;
void      TCDAABV (P_TCD_C_F1 pF1) ;
void      TCDAFT  (P_TCD_C_F1 pF1) ;
void      TCDAFBS (P_TCD_C_F1 pF1) ;
void      TCDAFBT (P_TCD_C_F1 pF1) ;

#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_FRT_H)
#define TCD_FRT_H
/*---------------------------------------------------------------------
    Datei:        TCD_FRT.H

Beschreibung: Modul zur allgemeinen Endebehandlung einer Formelfunktion
By:           BEGGI
Datum:        30.03.94
Historie:     BEG    28.11.95  neue Funktion: TCDSetPD
---------------------------------------------------------------------*/
TCD_INT TCDInit (P_TCD_C_F1 pMyPar, TCD_INT FrmNr, char *fctl_cmptime,
				 TCD_LONG VerNr);
void    TCDFtID (P_TCD_C_F1 pMyPar, char * AttrName,
                 TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                 TCD_INT *Var) ;

void    TCDSetPS (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                 TCD_DOUBLE *Var1, TCD_INT *Var2, TCD_DOUBLE Var3) ;
void    TCDSetPV (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                  char *Var1, TCD_INT *Var2, char *Var3) ;
void    TCDSetPD (P_TCD_C_F1 pMyPar, TCD_BOOL option, TCD_INT ParIx,
                  char *Var1, TCD_INT *Var2, char *Var3) ;

TCD_INT TCDGetTb (P_TCD_C_F1 pMyPar, P_P_TCDTAB Var) ;
void    TCDIniPS (P_TCD_C_G) ;

void    TCDIniFC (P_TCD_C_G) ;
void    TCDIniFU (P_TCD_C_G) ;
void    TCDIniFM (P_TCD_C_G) ;

void    TCDRetSk (P_TCD_C_F1 pMyPar, P_TCD_DOUBLE  VarSkal) ;
void    TCDRetTb (P_TCD_C_F1 pF1, P_P_TCDTAB  VarTab) ;

/*-----------------
  TraceFunktionsprototypen und Trace Makros
-------------------*/
#ifdef TRACEFKT
void _TCD_TRACE( const char * ,const char * ,const char *,P_TCD_C_G );
void _TCD_TRVAL( const char * , int , double *, double,P_TCD_C_G  ) ;

#define TCD_TRACE(pack,func,text, pTCDTCD)  \
            _TCD_TRACE(pack,func,text, pTCDTCD);
#define TCD_TRVAL(text,type,val1,val2, pTCDTCD) \
            _TCD_TRVAL(text,type,val1,val2, pTCDTCD);
#endif

#define C_TRACEFILE        "CTRACE.TCD"

#endif
  
/* RWE, 10.06.1997   */
/*-----------------
  Funktionsprototypen fuer Wiederverwendungsprotokoll
-------------------*/ 
#ifdef PROTWV
void     SetProtWV             (P_TCD_C_G pIf, TCD_BOOL bProtWV);   
  /* ^Dieser Prototyp ist auch in commands.c enthalten! */
TCD_BOOL ProtWVEnabled         (P_TCD_C_G pIf);
void     ProtWV1               (P_TCD_C_F1 pMyPar); 
void     ProtWV2               (P_TCD_C_F1   pMyPar, 
                                P_TCDPRCNODE pNode,
                                P_PAARLISTE  pPaarListe, 
                                TCD_INT      iFlag);
void     ProtWVString          (char *s);
                                
#define C_PROTWVFILE       "CPROTWV.TCD"
#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_IOP_H)
#define TCD_IOP_H

#ifndef SUBSYSTEM
  #define IOP_EXPORT 
#else
  #define IOP_EXPORT
#endif
TCD_DOUBLE IOP_EXPORT   TCDABS     (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDFAK     (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDINT     (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDSIGN    (TCD_DOUBLE val)                  ;
TCD_DOUBLE IOP_EXPORT   TCDDIV     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDEXP     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDMIN     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDMAX     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDZDAYS   (TCD_INT    datefmt, char *val1, 
                                    char *val2);
TCD_DOUBLE IOP_EXPORT   TCDKDAYS   (TCD_INT    datefmt, char *val1, 
                                    char *val2);
TCD_DOUBLE IOP_EXPORT   TCDRND     (TCD_DOUBLE val1, TCD_DOUBLE val2);
TCD_DOUBLE IOP_EXPORT   TCDCUT     (TCD_DOUBLE val1, TCD_DOUBLE val2);


#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_FCTL_H)
#define TCD_FCTL_H
/*---------------------------------------------------------------------
  Modul:   TCD_FCTL.H
  f�r RBS: LifeTemplate
---------------------------------------------------------------------*/

void  LifeTemF(P_TCD_C_G pTCDTCD) ;
void  LifeTem1(P_TCD_C_F1  pF1 ) ;
void    TCD3FES (P_TCD_C_F1 pMyPar, char * AttrName, TCD_INT Ix,
                       TCD_LONG ID, TCD_INT AttrTyp, TCD_INT ParIx,
                       P_TCD_DOUBLE Var) ;
void    TCD3FET (P_TCD_C_F1 pMyPar, char * AttrName, TCD_INT Ix,
                      TCD_LONG ID, TCD_INT AttrTyp, P_P_TCDTAB Var);
void    TCD3FED (P_TCD_C_F1 pMyPar, char * AttrName,
                      TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                      TCD_INT ParIx, char *Var) ;
void    TCD3FEV (P_TCD_C_F1 pMyPar, char * AttrName,
                      TCD_INT Ix, TCD_LONG ID, TCD_INT AttrTyp,
                      TCD_INT ParIx, char *Var) ;
TCD_INT TCD3FE1 (P_TCD_C_F1 pMyPar, TCD_BOOL option, char * Name,
                      TCD_LONG ID, TCD_INT FrmNr, P_TCD_DOUBLE Var) ;
TCD_INT TCD3FE2 (P_TCD_C_F1 pMyPar, TCD_BOOL option, char * Name,
                      TCD_LONG ID, TCD_INT FrmNr, P_P_TCDTAB  Var) ;

TCD_INT TCDChkFrm     (P_TCD_C_F1,void *);
void    ClearOverwriteStack(P_TCD_C_G pTCDTCD );

void       TCD3FESaveResult(P_TCD_C_F1);

#endif

/*---------------------------------------------------------------------

(C) Copyright 1993-2004, M�nchener R�ckversicherungsgesellschaft 
                         Aktiengesellschaft in M�nchen

---------------------------------------------------------------------*/
#if !defined (TCD_PKF_H)
#define TCD_PKF_H
/*---------------------------------------------------------------------
    Modul:        C:\dev\TCD_DB\template\db\R3FE\C\C3E9\lifet190.h

    Beschreibung: Funktionsprototypen der externen Funktionen der
                  Formelsammlungsdatei
    By:           BEGGI
    Generiert am: 16.12.2019 15:07:19
---------------------------------------------------------------------*/
   
      void LifeT111 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT112 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT113 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT114 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT115 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT116 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT117 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT118 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT119 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT120 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT121 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT122 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT123 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT124 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT125 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT126 (P_TCD_C_F1 pMyPar) ;
   
      void LifeT127 (P_TCD_C_F1 pMyPar) ;
   

#endif



/*---------------------------------------------------------
   Externe Funktion : LifeT638
   Beschreibung: Die Funktion berechnet die Formel 
                 F_FirstYieldAlloc
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT638 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
   TCD_DOUBLE  HV_1 = 0;
   TCD_DOUBLE  HV_3 = 0;
   TCD_DOUBLE  HV_8 = 0;
   TCD_DOUBLE  HV_10 = 0;
   TCD_DOUBLE  HV_11 = 0;
   TCD_INT     HV_0 = 0;
   TCD_INT     HV_2 = 0;
   TCD_INT     HV_4 = 0;
   TCD_INT     HV_5 = 0;
   TCD_INT     HV_6 = 0;
   TCD_INT     HV_9 = 0;
   TCD_INT     HV_12 = 0;
   P_TCDTAB2   HV_7;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT638","Begin F_FirstYieldAlloc",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,638,"12.12.2019 17:29:49",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_8);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT638",
              "Ende F_FirstYieldAlloc",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_6 = 0;
      HV_9 = 0;
      HV_12 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_5: 
      HV_4 = (TCD_INT) ( HV_1) ;
      if ( HV_2 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "_FirstYieldAlloc", 639, 639, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_8: 
      HV_5 = (TCD_INT) ( HV_3) ;
      if ( HV_6 != 0 ) goto l_11 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_11: 
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_4 < 0 || HV_4 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_7 [ HV_4 * 110 + HV_5 ]  == 0 ) goto l_24 ;
      goto l_36 ;
   l_24: 
      if ( HV_9 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "F_n", 364, 364, &HV_10);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_9 = 1;
   l_14: 
      HV_11 = HV_10 + 1;
      HV_8 = HV_11;
      goto l_3 ;
   l_36: 
      if ( HV_0 != 0 ) goto l_17 ;
      rc = TCD3FE1 (pMyPar, 2, "F_RowIndex", 591, 591, &HV_1);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_0 = 1;
   l_17: 
      HV_4 = (TCD_INT) ( HV_1) ;
      if ( HV_2 != 0 ) goto l_20 ;
      rc = TCD3FE1 (pMyPar, 2, "_FirstYieldAlloc", 639, 639, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_20: 
      HV_5 = (TCD_INT) ( HV_3) ;
      if ( HV_6 != 0 ) goto l_23 ;
      TCD3FET (pMyPar, "CostTab", 0, 357, 8,  (P_TCDTAB *) &HV_7);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_6 = 1;
   l_23: 
      if ( HV_5 < 0 || HV_5 > pMyPar->pTCDTCD->SSAData.AnzSpalten - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      if ( HV_4 < 0 || HV_4 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_8 = HV_7 [ HV_4 * 110 + HV_5 ] ;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_8);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT638","End F_FirstYieldAlloc",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_FirstYieldAlloc", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_FirstYieldAlloc", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_FirstYieldAlloc");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT737
   Beschreibung: Die Funktion berechnet die Formel 
                 F_t_allocDate
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT737 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_11 = 0;
      TCD_INT     HV_15 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT737","Begin F_t_allocDate",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,737,"12.12.2019 17:29:49",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_10);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT737",
              "Ende F_t_allocDate",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_5 = 0;
      HV_15 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "e_CalcDate", 29, 351, 6, 29, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_1);
      if ( HV_5 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_YieldDate", 78, 465, 1, 166, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_8: 
   TCDSetPS (pMyPar, 1, 116, &HV_8, &HV_7, HV_6);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_8, &HV_7, HV_6);
      if ( HV_4 <  HV_9 ) goto l_36 ;
      goto l_57 ;
   l_36: 
      if ( HV_5 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_YieldDate", 78, 465, 1, 166, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_11: 
      if ( HV_15 != 0 ) goto l_43 ;
   TCDSetPS (pMyPar, 1, 115, &HV_12, &HV_11, HV_6);
      rc = TCD3FE1 (pMyPar, 4, "F_Years", 576, 576, &HV_13);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 115, &HV_12, &HV_11, HV_6);
      HV_15 = 1;
   l_43: 
      HV_14 = HV_13 - 1;
      HV_10 = HV_14;
      goto l_3 ;
   l_57: 
      if ( HV_5 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_YieldDate", 78, 465, 1, 166, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_14: 
      if ( HV_15 != 0 ) goto l_61 ;
   TCDSetPS (pMyPar, 1, 115, &HV_12, &HV_11, HV_6);
      rc = TCD3FE1 (pMyPar, 4, "F_Years", 576, 576, &HV_13);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 115, &HV_12, &HV_11, HV_6);
      HV_15 = 1;
   l_61: 
      HV_10 = HV_13;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_10);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT737","End F_t_allocDate",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_t_allocDate", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_t_allocDate", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_t_allocDate");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT753
   Beschreibung: Die Funktion berechnet die Formel 
                 F_AddYieldFactors
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT753 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_11 = 0;
      TCD_INT     HV_16 = 0;
      TCD_INT     HV_19 = 0;
      TCD_INT     HV_20 = 0;
      TCD_INT     HV_21 = 0;
      P_TCDTAB1   HV_1;
      P_TCDTAB2   HV_5;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_3 = 1;
      TCD_INT     HV_14 = 2;
      TCD_INT     HV_15 = 0;
      TCD_INT     HV_18 = 6;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT753","Begin F_AddYieldFactors",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,753,"12.12.2019 17:29:49",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Besorgen einer freien Tabelle, falls Formel vom Typ TAB1/TAB2 */
   rc =    TCDGetTb (pMyPar, &HV_1);


   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_1);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT753",
              "Ende F_AddYieldFactors",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_4 = 0;
      HV_6 = 0;
      HV_8 = 0;
      HV_16 = 0;
      HV_20 = 0;
      HV_21 = 0;
      for ( HV_0 = (TCD_INT) (199) ; HV_0 >= 0; HV_0 = HV_0 - 1 ) {
         if ( HV_0 > 20 ) goto l_18 ;
         goto l_27 ;
      l_18: 
         HV_2 = 0;
         HV_1 [ HV_0 ]  = HV_2;
         continue ;
      l_27: 
         if ( HV_20 != 0 ) goto l_58 ;
         if ( HV_6 != 0 ) goto l_5 ;
         TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_7);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_6 = 1;
      l_5: 
         if ( HV_8 != 0 ) goto l_8 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_9);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_8 = 1;
      l_8: 
         HV_10 = HV_7 + HV_9;
         HV_20 = 1;
      l_58: 
         if ( HV_21 != 0 ) goto l_49 ;
      TCDSetPS (pMyPar, 1, 116, &HV_12, &HV_11, HV_10);
         rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_13);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 116, &HV_12, &HV_11, HV_10);
         HV_21 = 1;
      l_49: 
         if ( HV_4 != 0 ) goto l_11 ;
         TCD3FET (pMyPar, "YieldFactorTab", 2, 394, 8,  (P_TCDTAB *)
            &HV_5);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_4 = 1;
      l_11: 
         if ( HV_3 < 0 || HV_3 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
            1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         if ( HV_5 [ HV_0 * 110 + HV_3 ]  <= HV_13 ) goto l_66 ;
         goto l_126 ;
      l_66: 
         if ( HV_20 != 0 ) goto l_88 ;
         if ( HV_6 != 0 ) goto l_14 ;
         TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_7);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_6 = 1;
      l_14: 
         if ( HV_8 != 0 ) goto l_17 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_9);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_8 = 1;
      l_17: 
         HV_10 = HV_7 + HV_9;
         HV_20 = 1;
      l_88: 
         if ( HV_21 != 0 ) goto l_79 ;
      TCDSetPS (pMyPar, 1, 116, &HV_12, &HV_11, HV_10);
         rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_13);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 116, &HV_12, &HV_11, HV_10);
         HV_21 = 1;
      l_79: 
         if ( HV_4 != 0 ) goto l_20 ;
         TCD3FET (pMyPar, "YieldFactorTab", 2, 394, 8,  (P_TCDTAB *)
            &HV_5);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_4 = 1;
      l_20: 
         if ( HV_14 < 0 || HV_14 > pMyPar->pTCDTCD->SSAData.AnzSpalten
            - 1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         if ( HV_5 [ HV_0 * 110 + HV_14 ]  > HV_13 ) goto l_96 ;
         goto l_126 ;
      l_96: 
         if ( HV_4 != 0 ) goto l_23 ;
         TCD3FET (pMyPar, "YieldFactorTab", 2, 394, 8,  (P_TCDTAB *)
            &HV_5);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_4 = 1;
      l_23: 
         if ( HV_16 != 0 ) goto l_26 ;
         TCD3FES (pMyPar, "i_tarif_nr", 24, 321, 1, 112, &HV_17);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_16 = 1;
      l_26: 
         if ( HV_15 < 0 || HV_15 > pMyPar->pTCDTCD->SSAData.AnzSpalten
            - 1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         if ( HV_5 [ HV_0 * 110 + HV_15 ]  == HV_17 ) goto l_111 ;
         goto l_126 ;
      l_111: 
         if ( HV_4 != 0 ) goto l_29 ;
         TCD3FET (pMyPar, "YieldFactorTab", 2, 394, 8,  (P_TCDTAB *)
            &HV_5);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_4 = 1;
      l_29: 
         if ( HV_18 < 0 || HV_18 > pMyPar->pTCDTCD->SSAData.AnzSpalten
            - 1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         HV_1 [ HV_0 ]  = HV_5 [ HV_0 * 110 + HV_18 ] ;
         continue ;
      l_126: 
         HV_19 = HV_0 + 1;
         if ( HV_19 < 0 || HV_19 > pMyPar->pTCDTCD->SSAData.AnzZeilen -
            1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         HV_1 [ HV_0 ]  = HV_1 [ HV_19 ] ;
         continue ;
      }


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetTb (pMyPar, &HV_1);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT753","End F_AddYieldFactors",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_AddYieldFactors", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_AddYieldFactors", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_AddYieldFactors");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT754
   Beschreibung: Die Funktion berechnet die Formel 
                 F_AddYieldFactor
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT754 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_INT     HV_2 = 0;
      P_TCDTAB1   HV_3;
      TCD_INT     HV_1 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT754","Begin F_AddYieldFactor",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,754,"12.12.2019 17:29:49",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT754",
              "Ende F_AddYieldFactor",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_2 = 0;
      if ( HV_2 != 0 ) goto l_5 ;
      rc = TCD3FE2 (pMyPar, 2, "F_AddYieldFactors", 753, 753, &HV_3);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_2 = 1;
   l_5: 
      if ( HV_1 < 0 || HV_1 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1) {
         
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_0 = HV_3 [ HV_1 ] ;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT754","End F_AddYieldFactor",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_AddYieldFactor", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_AddYieldFactor", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_AddYieldFactor");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT755
   Beschreibung: Die Funktion berechnet die Formel 
                 F_AddYield
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT755 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT755","Begin F_AddYield",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,755,"12.12.2019 17:29:49",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT755",
              "Ende F_AddYield",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_SumInsured", 26, 325, 1, 114, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
      if ( HV_3 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AddYieldFactor", 754, 754, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_3 = 1;
   l_8: 
      HV_5 = HV_2 * HV_4;
      HV_6 =   TCDRND ( HV_5, 2 ) ;
      HV_0 = HV_6;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT755","End F_AddYield",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_AddYield", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_AddYield", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_AddYield");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT756
   Beschreibung: Die Funktion berechnet die Formel 
                 F_InterestYFactors
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT756 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_4 = 0;
      TCD_INT     HV_6 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_15 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_23 = 0;
      TCD_INT     HV_27 = 0;
      TCD_INT     HV_30 = 0;
      TCD_INT     HV_31 = 0;
      P_TCDTAB1   HV_1;
      P_TCDTAB2   HV_5;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_3 = 1;
      TCD_INT     HV_21 = 2;
      TCD_INT     HV_26 = 0;
      TCD_INT     HV_29 = 3;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT756","Begin F_InterestYFactors",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,756,"12.12.2019 17:29:48",
                       1);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Besorgen einer freien Tabelle, falls Formel vom Typ TAB1/TAB2 */
   rc =    TCDGetTb (pMyPar, &HV_1);


   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_1);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT756",
              "Ende F_InterestYFactors",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_4 = 0;
      HV_6 = 0;
      HV_10 = 0;
      HV_12 = 0;
      HV_27 = 0;
      HV_31 = 0;
      for ( HV_0 = (TCD_INT) (199) ; HV_0 >= 0; HV_0 = HV_0 - 1 ) {
         if ( HV_0 > 20 ) goto l_18 ;
         goto l_27 ;
      l_18: 
         HV_2 = 0;
         HV_1 [ HV_0 ]  = HV_2;
         continue ;
      l_27: 
         if ( HV_6 != 0 ) goto l_5 ;
         TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_7);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_6 = 1;
      l_5: 
         if ( HV_31 != 0 ) goto l_76 ;
         if ( HV_10 != 0 ) goto l_8 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_11);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_10 = 1;
      l_8: 
         if ( HV_12 != 0 ) goto l_11 ;
         TCD3FES (pMyPar, "i_UsePreviousYear", 80, 468, 1, 168,
            &HV_13);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_12 = 1;
      l_11: 
         HV_14 = HV_11 - HV_13;
         HV_31 = 1;
      l_76: 
      TCDSetPS (pMyPar, 1, 116, &HV_9, &HV_8, HV_7);
      TCDSetPS (pMyPar, 1, 119, &HV_16, &HV_15, HV_14);
         rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY_plus_i_t", 579, 579,
            &HV_17);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 119, &HV_16, &HV_15, HV_14);
      TCDSetPS (pMyPar, 0, 116, &HV_9, &HV_8, HV_14);
      TCDSetPS (pMyPar, 1, 116, &HV_19, &HV_18, HV_17);
         rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_20);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 116, &HV_19, &HV_18, HV_17);
         if ( HV_4 != 0 ) goto l_14 ;
         TCD3FET (pMyPar, "YieldFactorTab", 2, 394, 8,  (P_TCDTAB *)
            &HV_5);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_4 = 1;
      l_14: 
         if ( HV_3 < 0 || HV_3 > pMyPar->pTCDTCD->SSAData.AnzSpalten -
            1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         if ( HV_5 [ HV_0 * 110 + HV_3 ]  <= HV_20 ) goto l_84 ;
         goto l_162 ;
      l_84: 
         if ( HV_6 != 0 ) goto l_17 ;
         TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_7);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_6 = 1;
      l_17: 
         if ( HV_31 != 0 ) goto l_124 ;
         if ( HV_10 != 0 ) goto l_20 ;
         TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_11);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_10 = 1;
      l_20: 
         if ( HV_12 != 0 ) goto l_23 ;
         TCD3FES (pMyPar, "i_UsePreviousYear", 80, 468, 1, 168,
            &HV_13);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_12 = 1;
      l_23: 
         HV_14 = HV_11 - HV_13;
         HV_31 = 1;
      l_124: 
      TCDSetPS (pMyPar, 1, 116, &HV_9, &HV_8, HV_7);
      TCDSetPS (pMyPar, 1, 119, &HV_16, &HV_15, HV_14);
         rc = TCD3FE1 (pMyPar, 4, "F_DDMMYYYY_plus_i_t", 579, 579,
            &HV_22);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 119, &HV_16, &HV_15, HV_14);
      TCDSetPS (pMyPar, 0, 116, &HV_9, &HV_8, HV_14);
      TCDSetPS (pMyPar, 1, 116, &HV_24, &HV_23, HV_22);
         rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_25);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 116, &HV_24, &HV_23, HV_22);
         if ( HV_4 != 0 ) goto l_26 ;
         TCD3FET (pMyPar, "YieldFactorTab", 2, 394, 8,  (P_TCDTAB *)
            &HV_5);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_4 = 1;
      l_26: 
         if ( HV_21 < 0 || HV_21 > pMyPar->pTCDTCD->SSAData.AnzSpalten
            - 1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         if ( HV_5 [ HV_0 * 110 + HV_21 ]  > HV_25 ) goto l_132 ;
         goto l_162 ;
      l_132: 
         if ( HV_4 != 0 ) goto l_29 ;
         TCD3FET (pMyPar, "YieldFactorTab", 2, 394, 8,  (P_TCDTAB *)
            &HV_5);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_4 = 1;
      l_29: 
         if ( HV_27 != 0 ) goto l_32 ;
         TCD3FES (pMyPar, "i_tarif_nr", 24, 321, 1, 112, &HV_28);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_27 = 1;
      l_32: 
         if ( HV_26 < 0 || HV_26 > pMyPar->pTCDTCD->SSAData.AnzSpalten
            - 1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         if ( HV_5 [ HV_0 * 110 + HV_26 ]  == HV_28 ) goto l_147 ;
         goto l_162 ;
      l_147: 
         if ( HV_4 != 0 ) goto l_35 ;
         TCD3FET (pMyPar, "YieldFactorTab", 2, 394, 8,  (P_TCDTAB *)
            &HV_5);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_4 = 1;
      l_35: 
         if ( HV_29 < 0 || HV_29 > pMyPar->pTCDTCD->SSAData.AnzSpalten
            - 1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         HV_1 [ HV_0 ]  = HV_5 [ HV_0 * 110 + HV_29 ] ;
         continue ;
      l_162: 
         HV_30 = HV_0 + 1;
         if ( HV_30 < 0 || HV_30 > pMyPar->pTCDTCD->SSAData.AnzZeilen -
            1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         HV_1 [ HV_0 ]  = HV_1 [ HV_30 ] ;
         continue ;
      }


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetTb (pMyPar, &HV_1);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT756","End F_InterestYFactors",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_InterestYFactors", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_InterestYFactors", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_InterestYFactors");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT757
   Beschreibung: Die Funktion berechnet die Formel 
                 F_InterestYFactor
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT757 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_7 = 0;
      P_TCDTAB1   HV_5;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_4 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT757","Begin F_InterestYFactor",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,757,"12.12.2019 17:29:48",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT757",
              "Ende F_InterestYFactor",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_7 = 0;
   TCDSetPS (pMyPar, 1, 168, &HV_3, &HV_2, HV_1);
      rc = TCD3FE2 (pMyPar, 4, "F_InterestYFactors", 756, 756, &HV_5);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_6 = HV_5 [ HV_4 ] ;
   TCDSetPS (pMyPar, 0, 168, &HV_3, &HV_2, HV_1);
      if ( HV_7 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_InterestRate", 63, 417, 1, 151, &HV_8);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_7 = 1;
   l_5: 
      HV_9 = HV_6 - HV_8;
      HV_10 = TCDMAX ( 0, HV_9 ) ;
      HV_0 = HV_10;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT757","End F_InterestYFactor",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_InterestYFactor", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_InterestYFactor", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_InterestYFactor");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT758
   Beschreibung: Die Funktion berechnet die Formel 
                 F_InterestYield
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT758 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT758","Begin F_InterestYield",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,758,"12.12.2019 17:29:48",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT758",
              "Ende F_InterestYield",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_Vxnt", 14, 278, 1, 102, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
      if ( HV_3 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_InterestYFactor", 757, 757, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_3 = 1;
   l_8: 
      HV_5 = HV_2 * HV_4;
      HV_6 =   TCDRND ( HV_5, 2 ) ;
      HV_7 = TCDMAX ( 0, HV_6 ) ;
      HV_0 = HV_7;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT758","End F_InterestYield",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_InterestYield", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_InterestYield", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_InterestYield");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT759
   Beschreibung: Die Funktion berechnet die Formel 
                 F_TotalYieldAmount
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT759 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_16 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_20 = 0;
      TCD_INT     HV_22 = 0;
      TCD_INT     HV_24 = 0;
      TCD_INT     HV_15 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT759","Begin F_TotalYieldAmount",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,759,"12.12.2019 17:29:48",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_14);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT759",
              "Ende F_TotalYieldAmount",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_2 = 0;
      HV_8 = 0;
      HV_16 = 0;
      HV_18 = 0;
      HV_20 = 0;
      HV_22 = 0;
      HV_24 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_2 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_3);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_2 = 1;
   l_8: 
      HV_4 = HV_1 + HV_3;
   TCDSetPS (pMyPar, 1, 116, &HV_6, &HV_5, HV_4);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_7);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_6, &HV_5, HV_4);
      if ( HV_8 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_StartDateYield", 75, 456, 1, 163, &HV_9);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_8 = 1;
   l_11: 
   TCDSetPS (pMyPar, 1, 116, &HV_11, &HV_10, HV_9);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_12);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_11, &HV_10, HV_9);
      HV_13 = HV_7 - HV_12;
      if ( HV_13 <  0 ) goto l_48 ;
      goto l_54 ;
   l_48: 
      HV_15 = 0;
      HV_14 = HV_15;
      goto l_3 ;
   l_54: 
      if ( HV_16 != 0 ) goto l_14 ;
      TCD3FES (pMyPar, "i_State", 67, 421, 1, 155, &HV_17);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_16 = 1;
   l_14: 
      if ( HV_18 != 0 ) goto l_17 ;
      rc = TCD3FE1 (pMyPar, 2, "_premFree", 648, 648, &HV_19);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_18 = 1;
   l_17: 
      if ( HV_17 == HV_19 ) goto l_69 ;
      goto l_84 ;
   l_69: 
      if ( HV_20 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_StateDetail", 68, 422, 1, 156, &HV_21);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_20 = 1;
   l_20: 
      if ( HV_21 == 1 ) goto l_78 ;
      goto l_84 ;
   l_78: 
      if ( HV_22 != 0 ) goto l_23 ;
      rc = TCD3FE1 (pMyPar, 2, "F_InterestYield", 758, 758, &HV_23);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_22 = 1;
   l_23: 
      HV_14 = HV_23;
      goto l_3 ;
   l_84: 
      if ( HV_22 != 0 ) goto l_26 ;
      rc = TCD3FE1 (pMyPar, 2, "F_InterestYield", 758, 758, &HV_23);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_22 = 1;
   l_26: 
      if ( HV_24 != 0 ) goto l_29 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AddYield", 755, 755, &HV_25);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_24 = 1;
   l_29: 
      HV_26 = HV_23 + HV_25;
      HV_14 = HV_26;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_14);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT759","End F_TotalYieldAmount",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_TotalYieldAmount", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_TotalYieldAmount", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_TotalYieldAmount");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT760
   Beschreibung: Die Funktion berechnet die Formel 
                 F_YieldCalculation
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT760 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_DOUBLE  HV_29 = 0;
      TCD_DOUBLE  HV_30 = 0;
      TCD_DOUBLE  HV_31 = 0;
      TCD_DOUBLE  HV_32 = 0;
      TCD_DOUBLE  HV_33 = 0;
      TCD_DOUBLE  HV_34 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_10 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_15 = 0;
      TCD_INT     HV_22 = 0;
      TCD_INT     HV_27 = 0;
      TCD_INT     HV_28 = 0;
      TCD_INT     HV_38 = 0;
      TCD_INT     HV_39 = 0;
      TCD_INT     HV_40 = 0;
      TCD_INT     HV_41 = 0;
      P_TCDTAB1   HV_12;
      TCD_INT     HV_35 = 0;
      TCD_INT     HV_36 = 0;
      TCD_INT     HV_37 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT760","Begin F_YieldCalculation",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,760,"12.12.2019 17:29:47",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Besorgen einer freien Tabelle, falls Formel vom Typ TAB1/TAB2 */
   rc =    TCDGetTb (pMyPar, &HV_12);


   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_12);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT760",
              "Ende F_YieldCalculation",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_3 = 0;
      HV_8 = 0;
      HV_10 = 0;
      HV_13 = 0;
      HV_22 = 0;
      HV_38 = 0;
      HV_39 = 0;
      for ( HV_0 = (TCD_INT) (0) ; HV_0 <= 199; HV_0 = HV_0 + 1 ) {
         HV_40 = 0;
         HV_41 = 0;
         if ( HV_38 != 0 ) goto l_25 ;
         if ( HV_3 != 0 ) goto l_5 ;
         TCD3FES (pMyPar, "i_t_AllocDate", 79, 466, 1, 167, &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_5: 
         HV_5 = TCDINT ( HV_4 ) ;
         HV_38 = 1;
      l_25: 
         if ( HV_39 != 0 ) goto l_22 ;
         HV_6 = HV_5 + 1;
         HV_39 = 1;
      l_22: 
         if ( HV_1 != 0 ) goto l_8 ;
         TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_2);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_1 = 1;
      l_8: 
         HV_7 = HV_2 - HV_6;
         if ( HV_0 <= HV_7 ) goto l_33 ;
         goto l_276 ;
      l_33: 
         if ( HV_8 != 0 ) goto l_11 ;
         TCD3FES (pMyPar, "i_pst", 76, 457, 1, 164, &HV_9);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_8 = 1;
      l_11: 
         if ( HV_10 != 0 ) goto l_14 ;
         rc = TCD3FE1 (pMyPar, 2, "_Accrual", 682, 682, &HV_11);
      if (rc != TCD_RC_OK)       goto l_ende ;
         HV_10 = 1;
      l_14: 
         if ( HV_9 == HV_11 ) goto l_45 ;
         goto l_267 ;
      l_45: 
         if ( HV_0 == 0 ) goto l_57 ;
         goto l_120 ;
      l_57: 
         if ( HV_38 != 0 ) goto l_88 ;
         if ( HV_3 != 0 ) goto l_17 ;
         TCD3FES (pMyPar, "i_t_AllocDate", 79, 466, 1, 167, &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_17: 
         HV_5 = TCDINT ( HV_4 ) ;
         HV_38 = 1;
      l_88: 
         if ( HV_39 != 0 ) goto l_85 ;
         HV_6 = HV_5 + 1;
         HV_39 = 1;
      l_85: 
      TCDSetPS (pMyPar, 1, 88, &HV_16, &HV_15, HV_6);
         rc = TCD3FE1 (pMyPar, 4, "F_AccruedInt_ToMM", 767, 767,
            &HV_17);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 88, &HV_16, &HV_15, HV_6);
         if ( HV_13 != 0 ) goto l_20 ;
         TCD3FES (pMyPar, "i_YieldValue", 77, 464, 1, 165, &HV_14);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_13 = 1;
      l_20: 
         HV_18 = HV_14 * HV_17;
         if ( HV_38 != 0 ) goto l_109 ;
         if ( HV_3 != 0 ) goto l_23 ;
         TCD3FES (pMyPar, "i_t_AllocDate", 79, 466, 1, 167, &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_23: 
         HV_5 = TCDINT ( HV_4 ) ;
         HV_38 = 1;
      l_109: 
         if ( HV_39 != 0 ) goto l_106 ;
         HV_6 = HV_5 + 1;
         HV_39 = 1;
      l_106: 
      TCDSetPS (pMyPar, 1, 88, &HV_16, &HV_15, HV_6);
         rc = TCD3FE1 (pMyPar, 4, "F_TotalYieldAmount", 759, 759,
            &HV_19);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 88, &HV_16, &HV_15, HV_6);
         HV_20 = HV_18 + HV_19;
         HV_21 =   TCDRND ( HV_20, 2 ) ;
         HV_12 [ HV_0 ]  = HV_21;
         continue ;
      l_120: 
         if ( HV_22 != 0 ) goto l_26 ;
         TCD3FES (pMyPar, "i_t_delta", 7, 205, 1, 95, &HV_23);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_22 = 1;
      l_26: 
         HV_24 = HV_23 + 1;
         if ( HV_0 <= HV_24 ) goto l_138 ;
         goto l_258 ;
      l_138: 
         if ( HV_38 != 0 ) goto l_151 ;
         if ( HV_3 != 0 ) goto l_29 ;
         TCD3FES (pMyPar, "i_t_AllocDate", 79, 466, 1, 167, &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_29: 
         HV_5 = TCDINT ( HV_4 ) ;
         HV_38 = 1;
      l_151: 
         if ( HV_40 != 0 ) goto l_148 ;
         HV_25 = HV_5 + HV_0;
         HV_40 = 1;
      l_148: 
         if ( HV_41 != 0 ) goto l_145 ;
         HV_26 = HV_25 + 1;
         HV_41 = 1;
      l_145: 
         if ( HV_1 != 0 ) goto l_32 ;
         TCD3FES (pMyPar, "i_n", 5, 169, 1, 93, &HV_2);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_1 = 1;
      l_32: 
         if ( HV_26 <= HV_2 ) goto l_165 ;
         goto l_249 ;
      l_165: 
         HV_27 = HV_0 - 1;
         if ( HV_38 != 0 ) goto l_208 ;
         if ( HV_3 != 0 ) goto l_35 ;
         TCD3FES (pMyPar, "i_t_AllocDate", 79, 466, 1, 167, &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_35: 
         HV_5 = TCDINT ( HV_4 ) ;
         HV_38 = 1;
      l_208: 
         if ( HV_40 != 0 ) goto l_205 ;
         HV_25 = HV_5 + HV_0;
         HV_40 = 1;
      l_205: 
         if ( HV_41 != 0 ) goto l_202 ;
         HV_26 = HV_25 + 1;
         HV_41 = 1;
      l_202: 
      TCDSetPS (pMyPar, 1, 88, &HV_29, &HV_28, HV_26);
         rc = TCD3FE1 (pMyPar, 4, "F_AccruedInt_Interp", 765, 765,
            &HV_30);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 88, &HV_29, &HV_28, HV_26);
         if ( HV_27 < 0 || HV_27 > pMyPar->pTCDTCD->SSAData.AnzZeilen -
            1) { 
            pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
            goto l_ende ;
          } ;
         HV_31 = HV_12 [ HV_27 ]  * HV_30;
         if ( HV_38 != 0 ) goto l_235 ;
         if ( HV_3 != 0 ) goto l_38 ;
         TCD3FES (pMyPar, "i_t_AllocDate", 79, 466, 1, 167, &HV_4);
         if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
            l_ende;
         HV_3 = 1;
      l_38: 
         HV_5 = TCDINT ( HV_4 ) ;
         HV_38 = 1;
      l_235: 
         if ( HV_40 != 0 ) goto l_232 ;
         HV_25 = HV_5 + HV_0;
         HV_40 = 1;
      l_232: 
         if ( HV_41 != 0 ) goto l_229 ;
         HV_26 = HV_25 + 1;
         HV_41 = 1;
      l_229: 
      TCDSetPS (pMyPar, 1, 88, &HV_29, &HV_28, HV_26);
         rc = TCD3FE1 (pMyPar, 4, "F_TotalYieldAmount", 759, 759,
            &HV_32);
      if (rc != TCD_RC_OK)       goto l_ende ;
      TCDSetPS (pMyPar, 0, 88, &HV_29, &HV_28, HV_26);
         HV_33 = HV_31 + HV_32;
         HV_34 =   TCDRND ( HV_33, 2 ) ;
         HV_12 [ HV_0 ]  = HV_34;
         continue ;
      l_249: 
         HV_35 = 0;
         HV_12 [ HV_0 ]  = HV_35;
         continue ;
      l_258: 
         HV_36 = 0;
         HV_12 [ HV_0 ]  = HV_36;
         continue ;
      l_267: 
         HV_37 = 0;
         HV_12 [ HV_0 ]  = HV_37;
         continue ;
      l_276: 
      goto l_ende ;
      }


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetTb (pMyPar, &HV_12);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT760","End F_YieldCalculation",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_YieldCalculation", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_YieldCalculation", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_YieldCalculation");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT761
   Beschreibung: Die Funktion berechnet die Formel 
                 F_GetYieldFromVector
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT761 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_DOUBLE  HV_27 = 0;
      TCD_DOUBLE  HV_28 = 0;
      TCD_DOUBLE  HV_33 = 0;
      TCD_DOUBLE  HV_34 = 0;
      TCD_DOUBLE  HV_35 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_14 = 0;
      TCD_INT     HV_16 = 0;
      TCD_INT     HV_18 = 0;
      TCD_INT     HV_22 = 0;
      TCD_INT     HV_24 = 0;
      TCD_INT     HV_29 = 0;
      TCD_INT     HV_30 = 0;
      TCD_INT     HV_32 = 0;
      TCD_INT     HV_37 = 0;
      TCD_INT     HV_38 = 0;
      P_TCDTAB1   HV_31;
      TCD_INT     HV_11 = 0;
      TCD_INT     HV_36 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT761","Begin F_GetYieldFromVector",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,761,"12.12.2019 17:29:47",
                       4);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_10);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT761",
              "Ende F_GetYieldFromVector",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_5 = 0;
      HV_12 = 0;
      HV_14 = 0;
      HV_16 = 0;
      HV_18 = 0;
      HV_22 = 0;
      HV_24 = 0;
      HV_30 = 0;
      HV_32 = 0;
      HV_37 = 0;
      HV_38 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "e_CalcDate", 29, 351, 6, 29, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_1);
      if ( HV_5 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_StartDateYield", 75, 456, 1, 163, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_8: 
   TCDSetPS (pMyPar, 1, 116, &HV_8, &HV_7, HV_6);
      rc = TCD3FE1 (pMyPar, 4, "F_YYYYMMDD", 582, 582, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_8, &HV_7, HV_6);
      if ( HV_4 <  HV_9 ) goto l_36 ;
      goto l_42 ;
   l_36: 
      HV_11 = 0;
      HV_10 = HV_11;
      goto l_3 ;
   l_42: 
      if ( HV_12 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_pst", 76, 457, 1, 164, &HV_13);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_12 = 1;
   l_11: 
      if ( HV_14 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "_Accrual", 682, 682, &HV_15);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_14 = 1;
   l_14: 
      if ( HV_13 == HV_15 ) goto l_54 ;
      goto l_132 ;
   l_54: 
      if ( HV_37 != 0 ) goto l_67 ;
      if ( HV_18 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_t_AllocDate", 79, 466, 1, 167, &HV_19);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_18 = 1;
   l_17: 
      HV_20 = TCDINT ( HV_19 ) ;
      HV_37 = 1;
   l_67: 
      if ( HV_38 != 0 ) goto l_64 ;
      HV_21 = HV_20 + 1;
      HV_38 = 1;
   l_64: 
      if ( HV_16 != 0 ) goto l_20 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_17);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_16 = 1;
   l_20: 
      if ( HV_17 <  HV_21 ) goto l_75 ;
      goto l_93 ;
   l_75: 
      if ( HV_22 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_YieldValue", 77, 464, 1, 165, &HV_23);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_22 = 1;
   l_23: 
      if ( HV_24 != 0 ) goto l_26 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AccruedInt_MidYear", 764, 764,
         &HV_25);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_24 = 1;
   l_26: 
      HV_26 = HV_23 * HV_25;
      HV_27 =   TCDRND ( HV_26, 2 ) ;
      HV_10 = HV_27;
      goto l_3 ;
   l_93: 
      if ( HV_16 != 0 ) goto l_29 ;
      TCD3FES (pMyPar, "i_t", 0, 158, 1, 88, &HV_17);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_16 = 1;
   l_29: 
      HV_28 = TCDINT ( HV_17 ) ;
      if ( HV_37 != 0 ) goto l_118 ;
      if ( HV_18 != 0 ) goto l_32 ;
      TCD3FES (pMyPar, "i_t_AllocDate", 79, 466, 1, 167, &HV_19);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_18 = 1;
   l_32: 
      HV_20 = TCDINT ( HV_19 ) ;
      HV_37 = 1;
   l_118: 
      if ( HV_38 != 0 ) goto l_115 ;
      HV_21 = HV_20 + 1;
      HV_38 = 1;
   l_115: 
      HV_29 = (TCD_INT) ( HV_28 - HV_21) ;
      if ( HV_30 != 0 ) goto l_35 ;
      rc = TCD3FE2 (pMyPar, 2, "F_YieldCalculation", 760, 760,
         &HV_31);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_30 = 1;
   l_35: 
      if ( HV_32 != 0 ) goto l_38 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AccruedInt_FromMM", 766, 766,
         &HV_33);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_32 = 1;
   l_38: 
      if ( HV_29 < 0 || HV_29 > pMyPar->pTCDTCD->SSAData.AnzZeilen - 1)
         { 
         pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 11;
         goto l_ende ;
       } ;
      HV_34 = HV_31 [ HV_29 ]  * HV_33;
      HV_35 =   TCDRND ( HV_34, 2 ) ;
      HV_10 = HV_35;
      goto l_3 ;
   l_132: 
      HV_36 = 0;
      HV_10 = HV_36;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_10);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT761","End F_GetYieldFromVector",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_GetYieldFromVector", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_GetYieldFromVector", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_GetYieldFromVector");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT762
   Beschreibung: Die Funktion berechnet die Formel 
                 F_AccruedInt_CurrY
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT762 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_4 = 0;
      P_TCDTAB1   HV_7;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_6 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT762","Begin F_AccruedInt_CurrY",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,762,"12.12.2019 17:29:47",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT762",
              "Ende F_AccruedInt_CurrY",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
   TCDSetPS (pMyPar, 1, 168, &HV_5, &HV_4, HV_3);
      rc = TCD3FE2 (pMyPar, 4, "F_InterestYFactors", 756, 756, &HV_7);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_8 = HV_7 [ HV_6 ] ;
   TCDSetPS (pMyPar, 0, 168, &HV_5, &HV_4, HV_3);
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Interest", 688, 688, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
      HV_9 = TCDMAX ( HV_2, HV_8 ) ;
      HV_0 = HV_9;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT762","End F_AccruedInt_CurrY",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_AccruedInt_CurrY", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_AccruedInt_CurrY", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_AccruedInt_CurrY");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT763
   Beschreibung: Die Funktion berechnet die Formel 
                 F_AccruedInt_PrevY
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT763 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_4 = 0;
      P_TCDTAB1   HV_7;
      TCD_INT     HV_3 = 1;
      TCD_INT     HV_6 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT763","Begin F_AccruedInt_PrevY",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,763,"12.12.2019 17:29:47",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT763",
              "Ende F_AccruedInt_PrevY",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
   TCDSetPS (pMyPar, 1, 168, &HV_5, &HV_4, HV_3);
      rc = TCD3FE2 (pMyPar, 4, "F_InterestYFactors", 756, 756, &HV_7);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_8 = HV_7 [ HV_6 ] ;
   TCDSetPS (pMyPar, 0, 168, &HV_5, &HV_4, HV_3);
      if ( HV_1 != 0 ) goto l_5 ;
      rc = TCD3FE1 (pMyPar, 2, "F_Interest", 688, 688, &HV_2);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_1 = 1;
   l_5: 
      HV_9 = TCDMAX ( HV_2, HV_8 ) ;
      HV_0 = HV_9;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT763","End F_AccruedInt_PrevY",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_AccruedInt_PrevY", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_AccruedInt_PrevY", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_AccruedInt_PrevY");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT764
   Beschreibung: Die Funktion berechnet die Formel 
                 F_AccruedInt_MidYear
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT764 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_19 = 0;
      TCD_INT     HV_27 = 0;
      TCD_INT     HV_28 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT764","Begin F_AccruedInt_MidYear",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,764,"12.12.2019 17:29:46",
                       4);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_10);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT764",
              "Ende F_AccruedInt_MidYear",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_5 = 0;
      HV_13 = 0;
      HV_19 = 0;
      HV_27 = 0;
      HV_28 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "e_CalcDate", 29, 351, 6, 29, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_28 != 0 ) goto l_13 ;
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_1);
      HV_28 = 1;
   l_13: 
      if ( HV_5 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_YieldDate", 78, 465, 1, 166, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_8: 
      if ( HV_27 != 0 ) goto l_25 ;
   TCDSetPS (pMyPar, 1, 116, &HV_8, &HV_7, HV_6);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_8, &HV_7, HV_6);
      HV_27 = 1;
   l_25: 
      if ( HV_4 <  HV_9 ) goto l_36 ;
      goto l_108 ;
   l_36: 
      if ( HV_5 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_YieldDate", 78, 465, 1, 166, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_11: 
      if ( HV_27 != 0 ) goto l_61 ;
   TCDSetPS (pMyPar, 1, 116, &HV_8, &HV_7, HV_6);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_8, &HV_7, HV_6);
      HV_27 = 1;
   l_61: 
      HV_11 = 13 - HV_9;
   if ( 12 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_12 = HV_11 / 12;
      if ( HV_13 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AccruedInt_PrevY", 763, 763,
         &HV_14);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_13 = 1;
   l_14: 
      HV_15 = HV_12 * HV_14;
      HV_16 = 1 + HV_15;
      if ( HV_0 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "e_CalcDate", 29, 351, 6, 29, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_17: 
      if ( HV_28 != 0 ) goto l_88 ;
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_1);
      HV_28 = 1;
   l_88: 
      HV_17 = HV_4 - 1;
   if ( 12 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_18 = HV_17 / 12;
      if ( HV_19 != 0 ) goto l_20 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AccruedInt_CurrY", 762, 762,
         &HV_20);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_19 = 1;
   l_20: 
      HV_21 = HV_18 * HV_20;
      HV_22 = HV_16 + HV_21;
      HV_10 = HV_22;
      goto l_3 ;
   l_108: 
      if ( HV_0 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "e_CalcDate", 29, 351, 6, 29, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_23: 
      if ( HV_28 != 0 ) goto l_127 ;
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_1);
      HV_28 = 1;
   l_127: 
      if ( HV_5 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_YieldDate", 78, 465, 1, 166, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_26: 
      if ( HV_27 != 0 ) goto l_139 ;
   TCDSetPS (pMyPar, 1, 116, &HV_8, &HV_7, HV_6);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_8, &HV_7, HV_6);
      HV_27 = 1;
   l_139: 
      HV_23 = HV_4 - HV_9;
   if ( 12 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_24 = HV_23 / 12;
      if ( HV_19 != 0 ) goto l_29 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AccruedInt_CurrY", 762, 762,
         &HV_20);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_19 = 1;
   l_29: 
      HV_25 = HV_24 * HV_20;
      HV_26 = 1 + HV_25;
      HV_10 = HV_26;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_10);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT764","End F_AccruedInt_MidYear",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_AccruedInt_MidYear", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_AccruedInt_MidYear", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_AccruedInt_MidYear");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT765
   Beschreibung: Die Funktion berechnet die Formel 
                 F_AccruedInt_Interp
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT765 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_0 = 0;
      TCD_DOUBLE  HV_2 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_5 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_7 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_13 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_19 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_INT     HV_1 = 0;
      TCD_INT     HV_3 = 0;
      TCD_INT     HV_8 = 0;
      TCD_INT     HV_12 = 0;
      TCD_INT     HV_17 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT765","Begin F_AccruedInt_Interp",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,765,"12.12.2019 17:29:46",
                       2);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_0);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT765",
              "Ende F_AccruedInt_Interp",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_1 = 0;
      HV_8 = 0;
      HV_17 = 0;
      if ( HV_1 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_5: 
   TCDSetPS (pMyPar, 1, 116, &HV_4, &HV_3, HV_2);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_5);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_4, &HV_3, HV_2);
      HV_6 = 13 - HV_5;
   if ( 12 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_7 = HV_6 / 12;
      if ( HV_8 != 0 ) goto l_8 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AccruedInt_PrevY", 763, 763, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_8 = 1;
   l_8: 
      HV_10 = HV_7 * HV_9;
      HV_11 = 1 + HV_10;
      if ( HV_1 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_2);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_1 = 1;
   l_11: 
   TCDSetPS (pMyPar, 1, 116, &HV_13, &HV_12, HV_2);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_14);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_13, &HV_12, HV_2);
      HV_15 = HV_14 - 1;
   if ( 12 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_16 = HV_15 / 12;
      if ( HV_17 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AccruedInt_CurrY", 762, 762,
         &HV_18);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_17 = 1;
   l_14: 
      HV_19 = HV_16 * HV_18;
      HV_20 = HV_11 + HV_19;
      HV_0 = HV_20;


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_0);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT765","End F_AccruedInt_Interp",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_AccruedInt_Interp", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_AccruedInt_Interp", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_AccruedInt_Interp");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT766
   Beschreibung: Die Funktion berechnet die Formel 
                 F_AccruedInt_FromMM
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT766 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_19 = 0;
      TCD_INT     HV_27 = 0;
      TCD_INT     HV_28 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT766","Begin F_AccruedInt_FromMM",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,766,"12.12.2019 17:29:46",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_10);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT766",
              "Ende F_AccruedInt_FromMM",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_5 = 0;
      HV_13 = 0;
      HV_19 = 0;
      HV_27 = 0;
      HV_28 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "e_CalcDate", 29, 351, 6, 29, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_28 != 0 ) goto l_13 ;
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_1);
      HV_28 = 1;
   l_13: 
      if ( HV_5 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_8: 
      if ( HV_27 != 0 ) goto l_25 ;
   TCDSetPS (pMyPar, 1, 116, &HV_8, &HV_7, HV_6);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_8, &HV_7, HV_6);
      HV_27 = 1;
   l_25: 
      if ( HV_4 <  HV_9 ) goto l_36 ;
      goto l_108 ;
   l_36: 
      if ( HV_5 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_11: 
      if ( HV_27 != 0 ) goto l_61 ;
   TCDSetPS (pMyPar, 1, 116, &HV_8, &HV_7, HV_6);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_8, &HV_7, HV_6);
      HV_27 = 1;
   l_61: 
      HV_11 = 13 - HV_9;
   if ( 12 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_12 = HV_11 / 12;
      if ( HV_13 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AccruedInt_PrevY", 763, 763,
         &HV_14);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_13 = 1;
   l_14: 
      HV_15 = HV_12 * HV_14;
      HV_16 = 1 + HV_15;
      if ( HV_0 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "e_CalcDate", 29, 351, 6, 29, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_17: 
      if ( HV_28 != 0 ) goto l_88 ;
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_1);
      HV_28 = 1;
   l_88: 
      HV_17 = HV_4 - 1;
   if ( 12 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_18 = HV_17 / 12;
      if ( HV_19 != 0 ) goto l_20 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AccruedInt_CurrY", 762, 762,
         &HV_20);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_19 = 1;
   l_20: 
      HV_21 = HV_18 * HV_20;
      HV_22 = HV_16 + HV_21;
      HV_10 = HV_22;
      goto l_3 ;
   l_108: 
      if ( HV_0 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "e_CalcDate", 29, 351, 6, 29, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_23: 
      if ( HV_28 != 0 ) goto l_127 ;
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_1);
      HV_28 = 1;
   l_127: 
      if ( HV_5 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_26: 
      if ( HV_27 != 0 ) goto l_139 ;
   TCDSetPS (pMyPar, 1, 116, &HV_8, &HV_7, HV_6);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_8, &HV_7, HV_6);
      HV_27 = 1;
   l_139: 
      HV_23 = HV_4 - HV_9;
   if ( 12 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_24 = HV_23 / 12;
      if ( HV_19 != 0 ) goto l_29 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AccruedInt_CurrY", 762, 762,
         &HV_20);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_19 = 1;
   l_29: 
      HV_25 = HV_24 * HV_20;
      HV_26 = 1 + HV_25;
      HV_10 = HV_26;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_10);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT766","End F_AccruedInt_FromMM",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_AccruedInt_FromMM", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_AccruedInt_FromMM", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_AccruedInt_FromMM");
   }                                         
   return ;

   }
}

/*---------------------------------------------------------
   Externe Funktion : LifeT767
   Beschreibung: Die Funktion berechnet die Formel 
                 F_AccruedInt_ToMM
                 Im Fehlerfall wird die globale Returninformation
                 versorgt
   Parameter:  pMyPar: Formelparameter der Formel
------------------------------------------------------------*/
void LifeT767 (P_TCD_C_F1 pMyPar)
{
   TCD_INT  rc = TCD_RC_OK ;
   TCD_INT iResultFound = 0;
   
   /* Gen-Hvars : */
      TCD_DOUBLE  HV_1 = 0;
      TCD_DOUBLE  HV_3 = 0;
      TCD_DOUBLE  HV_4 = 0;
      TCD_DOUBLE  HV_6 = 0;
      TCD_DOUBLE  HV_8 = 0;
      TCD_DOUBLE  HV_9 = 0;
      TCD_DOUBLE  HV_10 = 0;
      TCD_DOUBLE  HV_11 = 0;
      TCD_DOUBLE  HV_12 = 0;
      TCD_DOUBLE  HV_14 = 0;
      TCD_DOUBLE  HV_15 = 0;
      TCD_DOUBLE  HV_16 = 0;
      TCD_DOUBLE  HV_17 = 0;
      TCD_DOUBLE  HV_18 = 0;
      TCD_DOUBLE  HV_20 = 0;
      TCD_DOUBLE  HV_21 = 0;
      TCD_DOUBLE  HV_22 = 0;
      TCD_DOUBLE  HV_23 = 0;
      TCD_DOUBLE  HV_24 = 0;
      TCD_DOUBLE  HV_25 = 0;
      TCD_DOUBLE  HV_26 = 0;
      TCD_INT     HV_0 = 0;
      TCD_INT     HV_2 = 0;
      TCD_INT     HV_5 = 0;
      TCD_INT     HV_7 = 0;
      TCD_INT     HV_13 = 0;
      TCD_INT     HV_19 = 0;
      TCD_INT     HV_27 = 0;
      TCD_INT     HV_28 = 0;


   /* Generierung der BeschaffungsFlags: */
   

   /* Trace: Formelbeginn */
   #ifdef TRACEFKT
      TCD_TRACE("","LifeT767","Begin F_AccruedInt_ToMM",
            pMyPar->pTCDTCD)
   #endif

   /* Initialcheck: Formeltyp und Name und formelspez. Init. */
   rc = TCDInit(pMyPar,767,"12.12.2019 17:29:46",
                       3);

   if (rc != TCD_RC_OK)
      goto l_ende ;

   

   /* Schon ein passendes Ergebnis gespeichert ? */
   {

#ifdef PROTWV      
      if (ProtWVEnabled(pMyPar->pTCDTCD))
        { ProtWV1(pMyPar); /* Name der Funktion, Knotentyp etc. */ }
#endif      

      iResultFound =    TCDChkFrm (pMyPar, (void *)&HV_10);

      switch ( iResultFound )
      {      
         case 1 :
/* #ifdef TRACEFKT
    TCD_TRACE("Ergebnis wiederverwendet ","LifeT767",
              "Ende F_AccruedInt_ToMM",pMyPar->pTCDTCD)
   #endif */
#ifdef PROTWV    
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolg!"); 
#endif            
            goto l_ende;
         
         case 0:
#ifdef PROTWV         
            if (ProtWVEnabled(pMyPar->pTCDTCD)) 
                ProtWVString("\n   Erfolglos."); 
#endif            
            break;
         
         default:
            goto l_ende;   
      }                      

/* Rechenteil: */
      HV_0 = 0;
      HV_5 = 0;
      HV_13 = 0;
      HV_19 = 0;
      HV_27 = 0;
      HV_28 = 0;
      if ( HV_0 != 0 ) goto l_5 ;
      TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_5: 
      if ( HV_28 != 0 ) goto l_13 ;
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_1);
      HV_28 = 1;
   l_13: 
      if ( HV_5 != 0 ) goto l_8 ;
      TCD3FES (pMyPar, "i_YieldDate", 78, 465, 1, 166, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_8: 
      if ( HV_27 != 0 ) goto l_25 ;
   TCDSetPS (pMyPar, 1, 116, &HV_8, &HV_7, HV_6);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_8, &HV_7, HV_6);
      HV_27 = 1;
   l_25: 
      if ( HV_4 <= HV_9 ) goto l_36 ;
      goto l_108 ;
   l_36: 
      if ( HV_5 != 0 ) goto l_11 ;
      TCD3FES (pMyPar, "i_YieldDate", 78, 465, 1, 166, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_11: 
      if ( HV_27 != 0 ) goto l_61 ;
   TCDSetPS (pMyPar, 1, 116, &HV_8, &HV_7, HV_6);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_8, &HV_7, HV_6);
      HV_27 = 1;
   l_61: 
      HV_11 = 13 - HV_9;
   if ( 12 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_12 = HV_11 / 12;
      if ( HV_13 != 0 ) goto l_14 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AccruedInt_PrevY", 763, 763,
         &HV_14);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_13 = 1;
   l_14: 
      HV_15 = HV_12 * HV_14;
      HV_16 = 1 + HV_15;
      if ( HV_0 != 0 ) goto l_17 ;
      TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_17: 
      if ( HV_28 != 0 ) goto l_88 ;
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_1);
      HV_28 = 1;
   l_88: 
      HV_17 = HV_4 - 1;
   if ( 12 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_18 = HV_17 / 12;
      if ( HV_19 != 0 ) goto l_20 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AccruedInt_CurrY", 762, 762,
         &HV_20);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_19 = 1;
   l_20: 
      HV_21 = HV_18 * HV_20;
      HV_22 = HV_16 + HV_21;
      HV_10 = HV_22;
      goto l_3 ;
   l_108: 
      if ( HV_0 != 0 ) goto l_23 ;
      TCD3FES (pMyPar, "i_TBeg", 22, 316, 1, 110, &HV_1);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_0 = 1;
   l_23: 
      if ( HV_28 != 0 ) goto l_127 ;
   TCDSetPS (pMyPar, 1, 116, &HV_3, &HV_2, HV_1);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_4);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_3, &HV_2, HV_1);
      HV_28 = 1;
   l_127: 
      if ( HV_5 != 0 ) goto l_26 ;
      TCD3FES (pMyPar, "i_YieldDate", 78, 465, 1, 166, &HV_6);
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc != TCD_RC_OK) goto
         l_ende;
      HV_5 = 1;
   l_26: 
      if ( HV_27 != 0 ) goto l_139 ;
   TCDSetPS (pMyPar, 1, 116, &HV_8, &HV_7, HV_6);
      rc = TCD3FE1 (pMyPar, 4, "F_Month", 578, 578, &HV_9);
   if (rc != TCD_RC_OK)    goto l_ende ;
   TCDSetPS (pMyPar, 0, 116, &HV_8, &HV_7, HV_6);
      HV_27 = 1;
   l_139: 
      HV_23 = HV_4 - HV_9;
   if ( 12 == 0) { 
      pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc = 10;
      goto l_ende ;
    } ;
      HV_24 = HV_23 / 12;
      if ( HV_19 != 0 ) goto l_29 ;
      rc = TCD3FE1 (pMyPar, 2, "F_AccruedInt_CurrY", 762, 762,
         &HV_20);
   if (rc != TCD_RC_OK)    goto l_ende ;
      HV_19 = 1;
   l_29: 
      HV_25 = HV_24 * HV_20;
      HV_26 = 1 + HV_25;
      HV_10 = HV_26;
      goto l_3 ;
   l_3: 


/* Formelende : */
l_ende :
   if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
   {
         TCDRetSk (pMyPar, &HV_10);

      if ( !iResultFound )
      {
         /* Merken des Ergebnisses */
         TCD3FESaveResult(pMyPar);
      }

   #ifdef TRACEFKT
      TCD_TRACE("","LifeT767","End F_AccruedInt_ToMM",
               pMyPar->pTCDTCD)
      if (pMyPar->pTCDTCD->pRbsCtl->RCInfo.Rc == TCD_RC_OK)
      {
         if ( pMyPar->pVarTab )
            TCD_TRVAL("F_AccruedInt_ToMM", 
            pMyPar->FrmTyp, *pMyPar->pVarTab ,0, pMyPar->pTCDTCD )

         else if ( pMyPar->pVarSkal )
                 TCD_TRVAL("F_AccruedInt_ToMM", 
                 pMyPar->FrmTyp, 0 , 
                 *pMyPar->pVarSkal,pMyPar->pTCDTCD)
      }
   #endif
   }
   else
   {
       ClearOverwriteStack(pMyPar->pTCDTCD );
       if (strcmp(
           pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,"") == 0)
           strcpy (pMyPar->pTCDTCD->pRbsCtl->RCInfo.FormelName,
                   "F_AccruedInt_ToMM");
   }                                         
   return ;

   }
}

