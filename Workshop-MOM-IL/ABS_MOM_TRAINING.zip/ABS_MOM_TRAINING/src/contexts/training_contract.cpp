#include <iomanip>

#include "math_utils.h"

#include "lookup.h"

#include "training_contract.h"

#include "boost/foreach.hpp"


ContractContextTraining::ContractContextTraining(const std::string & key, bool load)
        : TcdSharedContext(key, NULL)
{
}

ContractContextTraining::~ContractContextTraining()
{
}
